<?php
/**
 * Original script source
 * 
 * http://playground.zaplabs.com/sandbox/qa/stackexchange/stackoverflow/17269448/index.php
 * http://playground.zaplabs.com/sandbox/qa/stackexchange/stackoverflow/17269448/index.php.source
 */
$client_id = "YOURCLIENTIDHERE";

$image = $_POST['url'];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.imgur.com/3/image.json');
curl_setopt($ch, CURLOPT_POST, TRUE);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_HTTPHEADER, array( 'Authorization: Client-ID ' . $client_id ));
curl_setopt($ch, CURLOPT_POSTFIELDS, array( 'image' => $image ));

$reply = curl_exec($ch);
curl_close($ch);

$reply = json_decode($reply);
$newimgurl = $reply->data->link;

echo $newimgurl;

exit();

?>