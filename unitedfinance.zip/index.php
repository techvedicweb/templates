<?php include('header.php');?>
<style>
#loanlinks{
  text-decoration: none;
}
</style>
  <!-- Start slider 
  <section id="slider">
    <div class="main-slider">
      <div class="single-slide">
        <img src="assets/images/yourloan.jpg" alt="img">
        <!-- <div class="slide-content">
          <div class="container">
            <div class="row">
              <div class="col-md-6 col-sm-6">
                <div class="slide-article">
                  <h1 class="wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.5s">Creative Design & Best Feature</h1>
                  <p class="wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.75s">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since</p>
                  <a class="read-more-btn wow fadeInUp" data-wow-duration="1s" data-wow-delay="1s" href="#">Read More</a>
                </div>
              </div>
              <div class="col-md-6 col-sm-6">
                <div class="slider-img wow fadeInUp">
                  <img src="assets/images/person1.png" alt="business man">
                </div>
              </div>
            </div>
          </div>
        </div> -->
     <!-- </div>

           <div class="single-slide">
        <img src="assets/images/personalloan.png" alt="img">
        <div class="slide-content">

        </div>
      </div>

               <div class="single-slide">
        <img src="assets/images/studentloan1.jpg" alt="img">
        <div class="slide-content">

        </div>
      </div>

    <div class="single-slide">
        <img src="assets/images/propertyloan.jpg" alt="img">
        <div class="slide-content">

        </div>
      </div>

          <div class="single-slide">
        <img src="assets/images/homeloans.jpg" alt="img">
        <div class="slide-content">

        </div>
      </div>

          <div class="single-slide">
        <img src="assets/images/business_loan1.jpg" alt="img">
        <div class="slide-content">

        </div>
      </div>

      <div class="single-slide">
        <img src="assets/images/car_loan_banner.jpg" alt="img">
        <div class="slide-content">
        </div>
      </div>          
    </div>
  </section>
  <!-- End slider -->

  <!-- Start Feature -->
  <section id="feature">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="title-area">
           <h2 class="title">Loans We Provide</h2>
            <span class="line" style="width:50%;"></span>
            <p>In finance, a loan is the lending of money from one individual, organization or entity to another individual, organization or entity</p>
        
          </div>
        </div>
        <div class="col-md-12">
          <div class="feature-content">
            <div class="row">
              <div class="col-md-4 col-sm-6">
                <div class="single-feature wow zoomIn">
                  <i class="fa fa-home feature-icon"></i>
                 <a href="home-loan.php" id="loanlinks">  <h4 class="feat-title">Home Loan</h4>
                  <p>We understand that a home is not just a place to stay. It is much more than that. It is a warm little corner in the world that is yours, tailored by your tastes and needs. It is the place where you celebrate the joys and enjoy the journey called life.</p>
                </a>
                </div>
              </div>
              <div class="col-md-4 col-sm-6">
                <div class="single-feature wow zoomIn">
                  <i class="fa fa-user feature-icon"></i>
                  <a href="personal-loan.php" id="loanlinks">  <h4 class="feat-title">Personal Loan </h4>
                  <p>Dreaming of a vacation, a perfect wedding, home renovation or a much desired gadget,you no longer need to wait to realize your dreams. Make life picture perfect with  Bank
Personal Loans.</p>
</a>
                </div>
              </div>
              <div class="col-md-4 col-sm-6">
                <div class="single-feature wow zoomIn">
                  <i class="fa fa-car feature-icon"></i>
                 <a href="car-loan.php" id="loanlinks">   <h4 class="feat-title">Car Loan</h4>
                  <p> Bank offers car loans up to 100% ex-showroom price of the car, with
attractive interest rates and up to 7 years tenure.Car Loan offers are extended to select existing customers of  Bank. Existing customers also get the benefit of reduced documentation.</p>
               
</a>
                </div>
              </div>
              <div class="col-md-4 col-sm-6">
                <div class="single-feature wow zoomIn">
                  <i class="fa fa-industry feature-icon"></i>
                  <a href="business-loan.php" id="loanlinks">  <h4 class="feat-title">Business Loan</h4>
                  <p>Managing finance is unarguably the most important component of any business. For SMEs, timely finance is the key to making the most of business opportunities. Keeping this in mind, we at  Bank have designed a package of loans to best suit their business .</p>
                </a>
                </div>
              </div>
              <div class="col-md-4 col-sm-6">
                <div class="single-feature wow zoomIn">
                  <i class="fa fa-edit feature-icon"></i>
                <a href="property-loan.php" id="loanlinks">    <h4 class="feat-title">Property Loan</h4>
                  <p>Loan Against Property can get you a higher loan amount for your business or personal needs with the benefit of lower EMI. With easy documentation, speedy approvals and flexible repayment options, getting a loan couldn't get easier.</p>
                </a>
                </div>
              </div>
              <div class="col-md-4 col-sm-6">
                <div class="single-feature wow zoomIn">
                  <i class="fa fa-book feature-icon"></i>
                  <a href="study-loan.php" id="loanlinks">  <h4 class="feat-title">Study Loan</h4>
                  <p>A meritorious student is never far away from their dream career, courtesy of  Bank’s education loans. Students from every discipline can now take their first steps on the path to success.</p>
                </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End Feature -->

  <!-- Start about  -->
  <section id="about">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="title-area">
            <h2 class="title">About us</h2>
            <span class="line"></span>
            <p>Welcome to India's fastest growing most diversified Non Bank Finance Company which also
happens to be amongst India's 29 Best Employers. The businesses are spread across lending,
insurance, wealth management verticals. UNITED FINANCE is the lending arm of the group,
with product lines which broadly focuses on consumer finance, SME and commercial
business. We've seen our belief at work every day for the last 07 years. And our journey to
become India's fastest growing and most diversified Non Bank Financing Company is proof
that Empowerment delivers.<br> A registered and legitimate MNC loan
lender. We lender financial services (LOANS) and we give out loans at low interest rate to the
financial handicapped_ Individuals, Companies, Industries, Firms and people in the Society
and also Sponsor you to furnish your talent and achieve your goals. We give out loans
ranging from 1 Lakh to 1 Crores and above.<br>
Note: We deal in all kinds of loan- Home Loan, Personal Loan, Business Loan. Education
Loan. Contacts our executive for more details. If your loan not sanction within 1 to 24
working hours, then your security amount will be refund within next Ito 24 working hours
We will provide the Buiseness Loan from UNITED FINANCE and your loan amount is 40 Lakhs and loan tenure is 10
years</p>
          </div>
        </div>
        <div class="col-md-12">
          <div class="about-content">
            <div class="row">
             <!--  <div class="col-md-6">
                <div class="our-skill">
                  <h3>Our Skills</h3>                  
                  <div class="our-skill-content">
                  <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour</p>
                    <div class="progress">
                      <div class="progress-bar six-sec-ease-in-out" role="progressbar" data-transitiongoal="100">
                        <span class="progress-title">Html5</span>
                      </div>
                  </div>
                  <div class="progress">
                      <div class="progress-bar six-sec-ease-in-out" role="progressbar" data-transitiongoal="85">
                        <span class="progress-title">Css3</span>
                      </div>
                  </div>
                  <div class="progress">
                      <div class="progress-bar six-sec-ease-in-out" role="progressbar" data-transitiongoal="70">
                        <span class="progress-title">JQuery</span>
                      </div>
                  </div>
                  <div class="progress">
                      <div class="progress-bar six-sec-ease-in-out" role="progressbar" data-transitiongoal="60">
                        <span class="progress-title">wordPress</span>
                      </div>
                  </div>
                  <div class="progress">
                      <div class="progress-bar six-sec-ease-in-out" role="progressbar" data-transitiongoal="40">
                        <span class="progress-title">Php</span>
                      </div>
                  </div>
                   <div class="progress">
                      <div class="progress-bar six-sec-ease-in-out" role="progressbar" data-transitiongoal="25">
                        <span class="progress-title">Java</span>
                      </div>
                  </div>
                  </div>                  
                </div>
              </div> -->
              <div class="col-md-12">
                <div class="why-choose-us">
                  <h3>Why Choose Us?</h3>
                  <div class="panel-group why-choose-group" id="accordion">
                    <div class="panel panel-default">
                      <div class="panel-heading">
                        <h4 class="panel-title">
                          <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
                            Our Approach <span class="fa fa-minus-square"></span>
                          </a>
                        </h4>
                      </div>
                      <div id="collapseOne" class="panel-collapse collapse in">
                        <div class="panel-body">
                        <img class="why-choose-img" src="assets/images/testi1.jpg" alt="img">
                         <p> To us, it's not just work - we take pride in the solutions we deliver. We encourage each other to achieve excellence in all endeavours and aren't satisfied until projects meet our own personal high standards.</p>
                        </div>
                      </div>
                    </div>
                    <div class="panel panel-default ">
                      <div class="panel-heading">
                        <h4 class="panel-title">
                          <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
                          Our Unique Abilities <span class="fa fa-plus-square"></span>
                          </a>
                        </h4>
                      </div>
                      <div id="collapseTwo" class="panel-collapse collapse">
                        <div class="panel-body">
                         <p>We listen, we discuss, we advise. Sounds obvious but we listen to your ideas, plans and objectives for your business. We then select the best solution to fit. We don’t shoehorn projects and if we feel we’re not a good fit we’ll be honest and tell you from the outset.</p>
                        </div>
                      </div>
                    </div>
                    <div class="panel panel-default">
                      <div class="panel-heading">
                        <h4 class="panel-title">
                          <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
                            Experience <span class="fa fa-plus-square"></span>
                          </a>
                        </h4>
                      </div>
                      <div id="collapseThree" class="panel-collapse collapse">
                        <div class="panel-body">
                          <p>As a company we have been trading last few years however we’ve been designing and developing websites since the mid-nineties. We love discussing and planning new projects and have years of knowledge and experience that we bring to the table.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>              
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- end about -->

  <!--  Start counter 
  <section id="counter">
    <div class="counter-overlay">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="counter-area">
              <div class="row">
                <!-- Start single counter 
                <div class="col-md-3 col-sm-6">
                  <div class="single-counter">
                    <div class="counter-icon">
                      <i class="fa fa-suitcase"></i>
                    </div>
                    <div class="counter-no counter">
                      1275
                    </div>
                    <div class="counter-label">
                      Projects
                    </div>
                  </div>
                </div>
                <!-- End single counter 
                <!-- Start single counter 
                <div class="col-md-3 col-sm-6">
                  <div class="single-counter">
                    <div class="counter-icon">
                      <i class="fa fa-clock-o"></i>
                    </div>
                    <div class="counter-no counter">
                      5275
                    </div>
                    <div class="counter-label">
                      Hours Work
                    </div>
                  </div>
                </div>
                <!-- End single counter 
                <!-- Start single counter 
                <div class="col-md-3 col-sm-6">
                 <div class="single-counter">
                    <div class="counter-icon">
                      <i class="fa fa-trophy"></i>
                    </div>
                    <div class="counter-no counter">
                      350
                    </div>
                    <div class="counter-label">
                      Awards
                    </div>
                  </div>
                </div>
                <!-- End single counter 
                <!-- Start single counter 
                <div class="col-md-3 col-sm-6">
                  <div class="single-counter">
                    <div class="counter-icon">
                      <i class="fa fa-users"></i>
                    </div>
                    <div class="counter-no counter">
                      875
                    </div>
                    <div class="counter-label">
                      Clients
                    </div>
                  </div>
                </div>
                <!-- End single counter 
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section> -->
  <!-- End counter -->


  <!-- Start Service 
  <section id="service">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="title-area">
            <h2 class="title">Our Services</h2>
            <span class="line"></span>
            <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour</p>
          </div>
        </div>
        <div class="col-md-12">
          <div class="service-content">
            <div class="row">
              <!-- Start single service 
              <div class="col-md-4 col-sm-6">
                <div class="single-service wow zoomIn">
                  <i class="fa fa-desktop service-icon"></i>
                  <h4 class="service-title">Web Development</h4>
                  <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form.</p>
                </div>
              </div>
              <!-- End single service 
              <!-- Start single service 
              <div class="col-md-4 col-sm-6">
                <div class="single-service wow zoomIn">
                  <i class="fa fa-paw service-icon"></i>
                  <h4 class="service-title">Digital Design</h4>
                  <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form.</p>
                </div>
              </div>
              <!-- End single service 
              <!-- Start single service 
              <div class="col-md-4 col-sm-6">
                <div class="single-service wow zoomIn">
                  <i class="fa fa-magic service-icon"></i>
                  <h4 class="service-title">Marketing</h4>
                  <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form.</p>
                </div>
              </div>
              <!-- End single service 
              <!-- Start single service 
              <div class="col-md-4 col-sm-6">
                <div class="single-service wow zoomIn">
                  <i class="fa fa-shopping-cart service-icon"></i>
                  <h4 class="service-title">E-commerce</h4>
                  <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form.</p>
                </div>
              </div>
              <!-- End single service 
              <!-- Start single service 
              <div class="col-md-4 col-sm-6">
                <div class="single-service wow zoomIn">
                  <i class="fa fa-mobile service-icon"></i>
                  <h4 class="service-title">App Development</h4>
                  <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form.</p>
                </div>
              </div>
              <!-- End single service 
              <!-- Start single service 
              <div class="col-md-4 col-sm-6">
                <div class="single-service wow zoomIn">
                  <i class="fa fa-rocket service-icon"></i>
                  <h4 class="service-title">S.E.O</h4>
                  <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form.</p>
                </div>
              </div>
              <!-- End single service 
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
 End Service -->

  <!-- Start Pricing table -->
 <!--  <section id="pricing-table">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="title-area">
            <h2 class="title">Our Pricing Tables</h2>
            <span class="line"></span>
            <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour</p>
          </div>
        </div>
        <div class="col-md-12">
          <div class="pricing-table-content">
            <div class="row">
              <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="single-table-price wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.5s">
                  <div class="price-header">
                    <span class="price-title">Basic</span>
                    <div class="price">
                      <sup class="price-up">$</sup>
                      25
                      <span class="price-down">/mo</span>
                    </div>
                  </div>
                  <div class="price-article">
                    <ul>
                      <li>2GB Space</li>
                      <li>10GB Bandwidth</li>
                      <li>Free Domain</li>
                      <li>Free Email</li>
                      <li>Unlimited Support</li>
                    </ul>
                  </div>
                  <div class="price-footer">
                    <a class="purchase-btn" href="#">Purchase</a>
                  </div>
                </div>
              </div>
              <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="single-table-price wow fadeInUp" data-wow-duration="0.75s" data-wow-delay="0.75s">
                  <div class="price-header">
                    <span class="price-title">Advanced</span>
                    <div class="price">
                      <sup class="price-up">$</sup>
                      50
                      <span class="price-down">/mo</span>
                    </div>
                  </div>
                  <div class="price-article">
                    <ul>
                      <li>2GB Space</li>
                      <li>10GB Bandwidth</li>
                      <li>Free Domain</li>
                      <li>Free Email</li>
                      <li>Unlimited Support</li>
                    </ul>
                  </div>
                  <div class="price-footer">
                    <a class="purchase-btn" href="#">Purchase</a>
                  </div>
                </div>
              </div>
              <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="single-table-price featured-price wow fadeInUp" data-wow-duration="1s" data-wow-delay="1s">
                  <div class="price-header">
                    <span class="price-title">Professional</span>
                    <div class="price">
                      <sup class="price-up">$</sup>
                      100
                      <span class="price-down">/mo</span>
                    </div>
                  </div>
                  <div class="price-article">
                    <ul>
                      <li>2GB Space</li>
                      <li>10GB Bandwidth</li>
                      <li>Free Domain</li>
                      <li>Free Email</li>
                      <li>Unlimited Support</li>
                    </ul>
                  </div>
                  <div class="price-footer">
                    <a class="purchase-btn" href="#">Purchase</a>
                  </div>
                </div>
              </div>
              <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="single-table-price wow fadeInUp" data-wow-duration="1.15s" data-wow-delay="1.15s">
                  <div class="price-header">
                    <span class="price-title">Exclusive</span>
                    <div class="price">
                      <sup class="price-up">$</sup>
                      125
                      <span class="price-down">/mo</span>
                    </div>
                  </div>
                  <div class="price-article">
                    <ul>
                      <li>2GB Space</li>
                      <li>10GB Bandwidth</li>
                      <li>Free Domain</li>
                      <li>Free Email</li>
                      <li>Unlimited Support</li>
                    </ul>
                  </div>
                  <div class="price-footer">
                    <a class="purchase-btn" href="#">Purchase</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section> -->
  <!-- End Pricing table -->  

<!-- Start Pricing table -->
  <section id="our-team">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="title-area">
            <h2 class="title">Our Experts</h2>
            <span class="line"></span>
          <!--   <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour</p> -->
          </div>
        </div>
        <div class="col-md-12">
          <div class="our-team-content">
            <div class="row">
              <!-- Start single team member -->
              <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="single-team-member">
                 <div class="team-member-img">
                   <img src="assets/images/rajan.jpg" alt="team member img">
                 </div>
                 <div class="team-member-name">
                   <p>Rajan  Koushik</p>
                   <span>CEO</span>
                 </div>
               <!--   <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.</p> -->
                 <div class="team-member-link">
                   <a href="#"><i class="fa fa-facebook"></i></a>
                   <a href="#"><i class="fa fa-twitter"></i></a>
                   <a href="#"><i class="fa fa-linkedin"></i></a>
                 </div>
                </div>
              </div>
              <!-- Start single team member -->
              <!-- Start single team member -->
              <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="single-team-member">
                 <div class="team-member-img">
                   <img src="assets/images/narender.jpg" alt="team member img">
                 </div>
                 <div class="team-member-name">
                   <p>Narender  Reddy</p>
                   <span>Certified Public Accountant</span>
                 </div>
                <!--  <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.</p> -->
                 <div class="team-member-link">
                   <a href="#"><i class="fa fa-facebook"></i></a>
                   <a href="#"><i class="fa fa-twitter"></i></a>
                   <a href="#"><i class="fa fa-linkedin"></i></a>
                 </div>
                </div>
              </div>
              <!-- Start single team member -->
              <!-- Start single team member -->
              <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="single-team-member">
                 <div class="team-member-img">
                   <img src="assets/images/rohit.jpg" alt="team member img">
                 </div>
                 <div class="team-member-name">
                   <p>Rohit Dewaan</p>
                   <span>Chartered Financial Advisor</span>
                 </div>
                <!--  <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.</p> -->
                 <div class="team-member-link">
                   <a href="#"><i class="fa fa-facebook"></i></a>
                   <a href="#"><i class="fa fa-twitter"></i></a>
                   <a href="#"><i class="fa fa-linkedin"></i></a>
                 </div>
                </div>
              </div>
              <!-- Start single team member -->
              <!-- Start single team member -->
              <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="single-team-member">
                 <div class="team-member-img">
                   <img src="assets/images/badha.jpg" alt="team member img">
                 </div>
                 <div class="team-member-name">
                   <p>Badha Chadha </p>
                   <span>Registered Tax Preparer</span>
                 </div>
               <!--   <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.</p> -->
                 <div class="team-member-link">
                   <a href="#"><i class="fa fa-facebook"></i></a>
                   <a href="#"><i class="fa fa-twitter"></i></a>
                   <a href="#"><i class="fa fa-linkedin"></i></a>
                 </div>
                </div>
              </div>
              <!-- Start single team member -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End Pricing table -->
  
  <!-- Start Testimonial section -->
  <section id="testimonial">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <div class="row">
            <div class="col-md-12">
              <div class="title-area">
                <h2 class="title">Whats Client Say</h2>
                <span class="line"></span>           
              </div>
            </div>
            <div class="col-md-12">
              <!-- Start testimonial slider -->
              <div class="testimonial-slider">
                <!-- Start single slider -->
                <div class="single-slider">
                  <div class="testimonial-img">
                    <img src="assets/images/testi1.jpg" alt="testimonial image">
                  </div>
                  <div class="testimonial-content">
                    <p>"Thank you so very much for all of your help in securing our loan for our new home here in Fruitland. You were organized & thorough & professional, as well as kind which made all of the difference in our interactions with you. We put our trust in you and you most definitely came through for us. Thank you for your patience as well as treating us as people rather than just home loan customers. You stand above the rest, John Burley! Our hats off to you!!" .</p>
                    <h6>Ram Mohan, <span>New Delhi</span></h6>
                  </div>
                </div>
                <!-- Start single slider -->
                <div class="single-slider">
                  <div class="testimonial-img">
                    <img src="assets/images/testi2.jpeg" alt="testimonial image">
                  </div>
                  <div class="testimonial-content">
                    <p>"Subhash has always explained things very well. He will go over it & over it if you are having trouble understanding any part of the loan process. We look to John to provide us with honest & reliable information & have never been disappointed. He is always our 1st choice, if we need loan help." .</p>
                    <h6>Subhash Singh, <span>Jaipur</span></h6>
                  </div>
                </div>
                <!-- Start single slider -->
                <div class="single-slider">
                  <div class="testimonial-img">
                    <img src="assets/images/testi3.jpg" alt="testimonial image">
                  </div>
                  <div class="testimonial-content">
                    <p>After comparing with over 10 lenders and brokers, I settled on Brent Mendelson and Choice Finance based on the outstanding interest rate and closing fees.  There were several examples during the closing process where we almost ran into snags, but Brent went out of his way to negotiate with all parties to ensure that there were no problems.</p>
                    <h6>Mena Kumari, <span>West Bangal</span></h6>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-6"></div>        
      </div>
    </div>
  </section>
  <!-- End Testimonial section -->

 <!--Start Clients brand  -->
  <section id="clients-brand">
    <div class="container">
      <div class="row">
        <div class="col-md-12">

          <div class="clients-brand-area">
 <center><h2 class="title" style="color:#2bcdc1;">Our Partners</h2></center>
 <span class="line"></span>
            <ul class="clients-brand-slide">
              <li class="col-md-3">
                <div class="single-brand">
                  <img src="assets/images/excelfinance.png" alt="img" width="250" height="70">
                </div>
              </li>
              <li class="col-md-3">
                <div class="single-brand">
                  <img src="assets/images/careindia.png" alt="img" width="250" height="70">
                </div>
              </li>
             <!--  <li class="col-md-3">
                <div class="single-brand">
                  <img src="assets/images/envato.png" alt="img">
                </div>
              </li>
              <li class="col-md-3">
                <div class="single-brand">
                  <img src="assets/images/tuenti.png" alt="img">
                </div>
              </li>
               <li class="col-md-3">
                <div class="single-brand">
                  <img src="assets/images/amazon.png" alt="img">
                </div>
              </li>
              <li class="col-md-3">
                <div class="single-brand">
                  <img src="assets/images/discovery.png" alt="img">
                </div>
              </li>
              <li class="col-md-3">
                <div class="single-brand">
                  <img src="assets/images/envato.png" alt="img">
                </div>
              </li>
              <li class="col-md-3">
                <div class="single-brand">
                  <img src="assets/images/tuenti.png" alt="img">
                </div>
              </li> -->
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
 <!--End Clients brand --> 

  <!-- Start latest news -->
 <!--  <section id="latest-news">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="title-area">
            <h2 class="title">Latest News</h2>
            <span class="line"></span>
            <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour</p>
          </div>
        </div>
        <div class="col-md-12">
          <div class="latest-news-content">
            <div class="row">
              <!-- start single latest news 
              <div class="col-md-4">
                <article class="blog-news-single">
                  <div class="blog-news-img">
                    <a href="blog-single-with-right-sidebar.html"><img src="assets/images/blog-img-1.jpg" alt="image"></a>
                  </div>
                  <div class="blog-news-title">
                    <h2><a href="blog-single-with-right-sidebar.html">All about writing story</a></h2>
                    <p>By <a class="blog-author" href="#">John Powell</a> <span class="blog-date">|18 October 2015</span></p>
                  </div>
                  <div class="blog-news-details">
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the</p>
                    <a class="blog-more-btn" href="blog-single-with-right-sidebar.html">Read More <i class="fa fa-long-arrow-right"></i></a>
                  </div>
                </article>
              </div>
              <!-- start single latest news 
              <div class="col-md-4">
                <article class="blog-news-single">
                  <div class="blog-news-img">
                    <a href="blog-single-with-right-sidebar.html"><img src="assets/images/blog-img-2.jpg" alt="image"></a>
                  </div>
                  <div class="blog-news-title">
                    <h2><a href="blog-single-with-right-sidebar.html">Best Mobile Device</a></h2>
                    <p>By <a class="blog-author" href="#">John Powell</a> <span class="blog-date">|18 October 2015</span></p>
                  </div>
                  <div class="blog-news-details">
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the</p>
                    <a class="blog-more-btn" href="blog-single-with-right-sidebar.html">Read More <i class="fa fa-long-arrow-right"></i></a>
                  </div>
                </article>
              </div>
              <!-- start single latest news 
              <div class="col-md-4">
                <article class="blog-news-single">
                  <div class="blog-news-img">
                    <a href="blog-single-with-right-sidebar.html"><img src="assets/images/blog-img-3.jpg" alt="image"></a>
                  </div>
                  <div class="blog-news-title">
                    <h2><a href="blog-single-with-right-sidebar.html">Personal Note Details</a></h2>
                    <p>By <a class="blog-author" href="#">John Powell</a> <span class="blog-date">|18 October 2015</span></p>
                  </div>
                  <div class="blog-news-details">
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the</p>
                    <a class="blog-more-btn" href="blog-single-with-right-sidebar.html">Read More <i class="fa fa-long-arrow-right"></i></a>
                  </div>
                </article>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section> -->



<?php include('footer.php');?>