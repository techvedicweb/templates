<?php include('header.php');?>
  <!-- Start single page header -->
  <section id="single-page-header">
    <div class="overlay">
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-sm-6 col-xs-12">
            <div class="single-page-header-left">
              <h2>Our Partners</h2>
              <p></p>
            </div>
          </div>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <div class="single-page-header-right">
              <ol class="breadcrumb">
                <li><a href="#">Home</a></li>
                <li class="active">Our Partners</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End single page header -->
  
  <!-- Start blog archive -->
  <section id="blog-archive">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="blog-archive-area">
            <div class="row">
              <div class="col-md-2"></div>
              <div class="col-md-8">
                <div class="blog-archive-left">
                  <!-- Start blog news single -->
                  <article class="blog-news-single">
                    <!-- <div class="blog-news-img">
                      <img src="assets/images/car_loan_banner.jpg" alt="image">
                    </div> -->
                    <div class="blog-news-title">
                     <!--  <h2>All about writing story</h2>
                      <p>By <a class="blog-author" href="#">John Powell</a> <span class="blog-date">|18 October 2015</span></p> -->
                    </div>
         <section id="clients-brand">
    <div class="container">
      <div class="row">
        <div class="col-md-12">

          <div class="clients-brand-area">

            <ul class="clients-brand-slide">
              <li class="col-md-3">
                <div class="single-brand">
                  <img src="assets/images/excelfinance.png" alt="img" width="250" height="70">
                </div>
              </li>
              <li class="col-md-3">
                <div class="single-brand">
                  <img src="assets/images/careindia.png" alt="img" width="250" height="70">
                </div>
              </li>
             <!--  <li class="col-md-3">
                <div class="single-brand">
                  <img src="assets/images/envato.png" alt="img">
                </div>
              </li>
              <li class="col-md-3">
                <div class="single-brand">
                  <img src="assets/images/tuenti.png" alt="img">
                </div>
              </li>
               <li class="col-md-3">
                <div class="single-brand">
                  <img src="assets/images/amazon.png" alt="img">
                </div>
              </li>
              <li class="col-md-3">
                <div class="single-brand">
                  <img src="assets/images/discovery.png" alt="img">
                </div>
              </li>
              <li class="col-md-3">
                <div class="single-brand">
                  <img src="assets/images/envato.png" alt="img">
                </div>
              </li>
              <li class="col-md-3">
                <div class="single-brand">
                  <img src="assets/images/tuenti.png" alt="img">
                </div>
              </li> -->
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
                   <!--    <blockquote>
                        <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from</p>
                        <span> - John Doe</span>
                      </blockquote> 
                      <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text</p>
                      <ul>
                        <li>There are many variations of passages of Lorem Ipsum</li>
                        <li>There are many variations of passages of Lorem Ipsum</li>
                        <li>There are many variations of passages of Lorem Ipsum</li>
                        <li>There are many variations of passages of Lorem Ipsum</li>
                        <li>There are many variations of passages of Lorem Ipsum</li>
                      </ul>
                      <ol>
                        <li>There are many variations of passages of Lorem Ipsum</li>
                        <li>There are many variations of passages of Lorem Ipsum</li>
                        <li>There are many variations of passages of Lorem Ipsum</li>
                        <li>There are many variations of passages of Lorem Ipsum</li>
                        <li>There are many variations of passages of Lorem Ipsum</li>
                      </ol>
                      <h1>This is H1 Title Example</h1>
                      <h2>This is H2 Title Example</h2>
                      <h3>This is H3 Title Example</h3>
                      <h4>This is H4 Title Example</h4>
                      <h5>This is H5 Title Example</h5>
                      <h6>This is H6 Title Example</h6>
                      <div class="blog-single-bottom">
                        <div class="row">
                          <div class="col-md-8">
                            <div class="blog-single-tag">
                              <span class="fa fa-tags"></span>
                              <a href="#">Design,</a>
                              <a href="#">Photoshop,</a>
                              <a href="#">Development</a>
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="blog-single-social">
                              <a href="#"><i class="fa fa-facebook"></i></a>
                              <a href="#"><i class="fa fa-twitter"></i></a>
                              <a href="#"><i class="fa fa-linkedin"></i></a>
                              <a href="#"><i class="fa fa-google-plus"></i></a>
                              <a href="#"><i class="fa fa-pinterest"></i></a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </article>
                  <!-- Start blog navigation -->
                <!--   <div class="blog-navigation-area">
                    <div class="blog-navigation-prev">
                      <a href="#">
                        <h5>All about writing story</h5>
                        <span>Previous Post</span>
                      </a>
                    </div>
                    <div class="blog-navigation-next">
                      <a href="#">
                        <h5>All about friends story</h5>
                        <span>Next Post</span>
                      </a>
                    </div>
                  </div> -->
                  <!-- Start Comment box -->
                  <div class="comments-box-area">
                    <h2>Leave a Comment</h2>
                    <p>Your email address will not be published.</p>
                    <form action="" class="comments-form">
                       <div class="form-group">                        
                        <input type="text" class="form-control" placeholder="Your Name">
                      </div>
                      <div class="form-group">                        
                        <input type="email" class="form-control" placeholder="Email">
                      </div>
                       <div class="form-group">                        
                        <textarea placeholder="Comment" rows="3" class="form-control"></textarea>
                      </div>
                      <button class="comment-btn">Submit Comment</button>
                    </form>
                  </div>
                </div>
              </div>
              <div class="col-md-2"></div>             
            </div>
          </div>
        </div>
      </div>
    </div>  
  </section>
  <!-- End blog archive -->

  <?php include('footer.php');?>