<?php include('header.php');?>
  <!-- Start single page header -->
  <section id="single-page-header">
    <div class="overlay">
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-sm-6 col-xs-12">
            <div class="single-page-header-left">
              <h2>Personal Loan</h2>
              <p></p>
            </div>
          </div>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <div class="single-page-header-right">
              <ol class="breadcrumb">
                <li><a href="#">Home</a></li>
                <li class="active">Personal Loan</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End single page header -->
  
  <!-- Start blog archive -->
  <section id="blog-archive">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="blog-archive-area">
            <div class="row">
              <div class="col-md-2"></div>
              <div class="col-md-8">
                <div class="blog-archive-left">
                  <!-- Start blog news single -->
                  <article class="blog-news-single">
                    <div class="blog-news-img">
                      <img src="assets/images/personalloan.png" alt="image">
                    </div>
                    <div class="blog-news-title">
                      <!-- <h2>All about writing story</h2>
                      <p>By <a class="blog-author" href="#">John Powell</a> <span class="blog-date">|18 October 2015</span></p> -->
                    </div>
                    <div class="blog-news-details blog-single-details">
                      <p>Dreaming of a vacation, a perfect wedding, home renovation or a much desired gadget,you no longer need to wait to realize your dreams. Make life picture perfect with Personal Loans.</p>
                      <blockquote>
                        <p>End use of the  Personal Loan can be House renovation, Holidays, Purchase of consumer durables, Education, Marriage, Short Term loan for equipment purchase, Short Term Working Capital, Any other personal emergency</p>
                      
                      </blockquote>
                      <p>Benefits of  Personal Loan</p>
                      <ul>
                        <li>Interest rate remains unchanged throughout the loan tenure</li>
                        <li>Simple documentation - It can be accessed with minimal paperwork and documentation and doesn’t take much time.</li>
                        <li>Quick processing</li>
                        <li>Direct credit of the loan amount through Fund Transfer (FT)</li>
                        <li>Simple repayment options of ECS, AD or PDC. You can also choose duration as per your choice and tenure starts from minimum 12 months to maximum 60 months</li>
                      </ul>
                     
                    
                    </div>
                  </article>
                  <!-- Start blog navigation -->
                <!--   <div class="blog-navigation-area">
                    <div class="blog-navigation-prev">
                      <a href="#">
                        <h5>All about writing story</h5>
                        <span>Previous Post</span>
                      </a>
                    </div>
                    <div class="blog-navigation-next">
                      <a href="#">
                        <h5>All about friends story</h5>
                        <span>Next Post</span>
                      </a>
                    </div>
                  </div> -->
                  <!-- Start Comment box -->
                  <div class="comments-box-area">
                    <h2>Leave a Comment</h2>
                    <p>Your email address will not be published.</p>
                    <form action="" class="comments-form">
                       <div class="form-group">                        
                        <input type="text" class="form-control" placeholder="Your Name">
                      </div>
                      <div class="form-group">                        
                        <input type="email" class="form-control" placeholder="Email">
                      </div>
                       <div class="form-group">                        
                        <textarea placeholder="Comment" rows="3" class="form-control"></textarea>
                      </div>
                      <button class="comment-btn">Submit Comment</button>
                    </form>
                  </div>
                </div>
              </div>
              <div class="col-md-2"></div>             
            </div>
          </div>
        </div>
      </div>
    </div>  
  </section>
  <!-- End blog archive -->

  <?php include('footer.php');?>