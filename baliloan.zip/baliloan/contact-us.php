<?php include('header.php'); ?>       
<section class="features-style-one">
    <div class="auto-container">
        <div class="row clearfix"> 
            <div class="col-md-12 col-sm-12 col-xs-12">
                
            </div>
            <div class="column features-column col-md-9 col-sm-6 col-xs-12">               
                        <div class="column blog-news-column">
                            <!--<article class="inner-box">-->
                                <div class="content-box">
                                     <ul class="post-info clearfix">
                                        <li><a href="http://www.baliloan.com/">Home</a></li>   
                                        <li> Contact us </li>
                                    </ul>
                                    <div class="text">
                                    	<h2>
	HEADQUARTERS</h2>
<table border="1" cellpadding="1" cellspacing="1" style="width: 500px">
	<tbody>
		<tr>
			<td>
				<strong>Address</strong></td>
			<td>
				<p>
					<b style="color: rgb(119, 119, 119); font-family: Calibri, sans-serif; font-size: 14.6667px;"><span style="border: 0px; font-family: Arial, sans-serif; font-size: 10pt; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;  background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;">BENSON ADI&nbsp;LOAN &amp; INVESTMENT .PT</span></b></p>
				<p>
					THE RITZ CARLTON -Tower A Lingkar Mega Kuningan Street, Kav. E 1.1 No. 1, South Jakarta, Indonesia 12950</p>
			</td>
		</tr>
		<tr>
			<td>
				<strong>Email</strong></td>
			<td>
				info@baliloan.com</td>
		</tr>
		<tr>
			<td>
				<strong>Phone</strong></td>
			<td>
				+6 221-719-716</td>
		</tr>
	</tbody>
</table>
<h2>
	Regions</h2>
<table border="1" cellpadding="1" cellspacing="1" style="width: 500px">
	<tbody>
		<tr>
			<td>
				<strong>INDONESIA</strong></td>
			<td>
				<p>
					<b font-size:="" pt="" style="color: rgb(119, 119, 119); font-family: "><span style="border: 0px; font-family: Arial, sans-serif; font-size: 10pt; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; line-height: 15.3333px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;">Head Office -&nbsp;</span></b><b style="color: rgb(119, 119, 119); font-family: Calibri, sans-serif; font-size: 14.6667px;"><span style="border: 0px; font-family: Arial, sans-serif; font-size: 10pt; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;">BENSON ADI LOAN &amp; INVESTMENT .PT</span></b></p>
				<p>
					The Ritz Carlton -Tower A Lingkar Mega Kuningan Street Kav. E 1.1 No. 1, South Jakarta, Indonesia</p>
			</td>
		</tr>
		<tr>
			<td>
				<strong>MALAYSIA</strong></td>
			<td>
				<p>
					<b font-size:="" pt="" style="color: rgb(119, 119, 119); font-family: "><span style="border: 0px; font-family: Arial, sans-serif; font-size: 10pt; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; line-height: 15.3333px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;">Head Office -&nbsp;</span></b><b style="color: rgb(119, 119, 119); font-family: Calibri, sans-serif; font-size: 14.6667px;"><span style="border: 0px; font-family: Arial, sans-serif; font-size: 10pt; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;">BENSON ADI LOAN &amp; INVESTMENT SDN BHD</span></b></p>
				<p>
					Vista Tower, 182 Jalan Tun Razak, Kuala Lumpur, Malaysia</p>
			</td>
		</tr>
		<tr>
			<td>
				<strong>THAILAND</strong></td>
			<td>
				<p>
					<b style="color: rgb(119, 119, 119); font-family: Calibri, sans-serif; font-size: 14.6667px;"><span style="border: 0px; font-family: Arial, sans-serif; font-size: 10pt; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; line-height: 15.3333px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;">Head Office -&nbsp;</span></b><b style="color: rgb(119, 119, 119); font-family: Calibri, sans-serif; font-size: 14.6667px;"><span style="border: 0px; font-family: Arial, sans-serif; font-size: 10pt; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;">BENSON ADI LOAN &amp; INVESTMENT PTE</span></b></p>
				<p>
					Northpoint Building, Chonburi Province, Mueang Pattaya, Thailand</p>
			</td>
		</tr>
		<tr>
			<td>
				<strong>INDIA</strong></td>
			<td>
				<p>
					<b font-size:="" pt="" style="color: rgb(119, 119, 119); font-family: "><span style="border: 0px; font-family: Arial, sans-serif; font-size: 10pt; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; line-height: 15.3333px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;">Head Office -&nbsp;</span></b><b style="color: rgb(119, 119, 119); font-family: Calibri, sans-serif; font-size: 14.6667px;"><span style="border: 0px; font-family: Arial, sans-serif; font-size: 10pt; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;">BENSON ADI LOAN &amp; INVESTMENT&nbsp;</span></b></p>
				<p>
					1179, Industrial Area, Mehatpur, Himanchal Pradesh, India</p>
			</td>
		</tr>
	</tbody>
</table>
<p>
	&nbsp;</p>
                                    </div>
                                  
                                </div>
                                
                               
                            <!--</article>-->
                        </div>
                    <!--</section>-->
               
            </div>
            <!--Features Column-->
            <!--Features Column-->
            <div class="column features-column col-md-3 col-sm-6 col-xs-12 padding-top">
                 <div class="default-form-style contact-form">
    <form id="enquiryfrom" name="enquiryfrom" action="http://www.baliloan.com/formsubmit.php" method="post">
        <p class="pheader"> <span class="q-text">INTERESTED?</span> Get Help from our Service</p>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="text" name="cat" value="" required="" placeholder="Service Name *">
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <textarea rows="2" class="height" required="" name="message" placeholder="Your Requirements" id="requirements"></textarea>
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="text" name="uoc_name" value="" required="" placeholder="Your Name *">
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="email" name="uoc_email" value="" required="" placeholder="Your Email *">
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="text" name="uoc_mobile" value="" required="" placeholder="Your Phone *">
       </div>
                   <input type="hidden" value="http://www.baliloan.com/contact-us.php" name="sno"/>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input name="submit" class="btn btn-block btn-info f_14" id="submit" value="Submit Now" type="submit">
       </div>    
    </form>
</div> 
                
            </div>
           
             
           
        </div>
         <div class="col-md-12" >&nbsp;</div>
    </div>
</section> 
<section class="features-style-one">
    &nbsp;
</section>  
<?php include('footer.php'); ?>