<?php include('header.php'); ?>         
<img src="http://www.baliloan.com/study/image/1481084254.jpg" width='100%'><section class="features-style-one">
    <div class="auto-container">
        <div class="row clearfix"> 
            <div class="col-md-12 col-sm-12 col-xs-12">
                
            </div>
            <div class="column features-column col-md-9 col-sm-6 col-xs-12">               
                        <div class="column blog-news-column">
                            <!--<article class="inner-box">-->
                                <div class="content-box">
                                     <ul class="post-info clearfix">
                                        <li><a href="http://www.baliloan.com/">Home</a></li>   
                                        <li> Property Finance </li>
                                    </ul>
                                    <div class="text">
                                    	<p 0px="" color:="" font-size:="" margin:="" outline:="" padding:="" pt="" style="border: 0px; font-family: " vertical-align:="">
	<em style="border: 0px; font-family: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">Buying your dream home is one of the most important decisions of your life and equally important is your choice of the finance company which can honestly guide and assist you throughout the home buying process. A company which can assure expertise, transparency, commitment, best-in-class services, full-fledged domain knowledge and simplified loan procedures till the complete repayment of the loan will simplify your home buying experience.</em></p>
<ul color:="" font-size:="" list-style:="" margin:="" outline:="" padding-left:="" padding-right:="" pt="" style="border: 0px; font-family: " vertical-align:="">
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Transparent processes and procedures</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		A wide network of offices across Country, for your convenience</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Easy and fast approvals of your home loan application</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Simple Documentation</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Free &amp; safe document storage</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Balance Transfer facility available with additional finance</li>
</ul>
<p 0px="" color:="" font-size:="" margin:="" outline:="" padding:="" pt="" style="border: 0px; font-family: " vertical-align:="">
	&nbsp;</p>
<p 0px="" color:="" font-size:="" margin:="" outline:="" padding:="" pt="" style="border: 0px; font-family: " vertical-align:="">
	<strong style="border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">DOCUMENTATION:</strong></p>
<ul color:="" font-size:="" list-style:="" margin:="" outline:="" padding-left:="" padding-right:="" pt="" style="border: 0px; font-family: " vertical-align:="">
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Application form with photograph .</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Age proof (PAN Card, Passport, any other certificate from a statutory authority)</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Residence Proof (Passport, Driving Licence, Telephone Bill, Election Card, any other certificate from a statutory authority)</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Salary slip of the last 3 months</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Form 16</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Last 3 years Income Tax returns</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Bank statements of the last 6 months</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Copy of Title Documents of the property, Approved Plan</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Processing fee cheque</li>
</ul>
<p 0px="" color:="" font-size:="" margin:="" outline:="" padding:="" pt="" style="border: 0px; font-family: " vertical-align:="">
	<strong style="border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">Self-Employed:</strong></p>
<ul color:="" font-size:="" list-style:="" margin:="" outline:="" padding-left:="" padding-right:="" pt="" style="border: 0px; font-family: " vertical-align:="">
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Application form with photograph .</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Age proof (PAN Card, Passport, any other certificate from a statutory authority)</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Residence Proof (Passport, Driving Licence, Telephone Bill, Election Card, any other certificate from a statutory authority)</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Income Tax returns of the last 3 years duly certified by a CA</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Profit &amp; Loss Account and Balance Sheet of the last 3 years</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Bank statements (self and business) of the last 6 months</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Copy of Title Documents of the property,</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Approved Plan Processing fee cheque.</li>
</ul>
<p 0px="" color:="" font-size:="" margin:="" outline:="" padding:="" pt="" style="border: 0px; font-family: " vertical-align:="">
	&nbsp;</p>
<p 0px="" color:="" font-size:="" margin:="" outline:="" padding:="" pt="" style="border: 0px; font-family: " vertical-align:="">
	<strong style="border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">FAQ&rsquo;S:</strong></p>
<p 0px="" color:="" font-size:="" margin:="" outline:="" padding:="" pt="" style="border: 0px; font-family: " vertical-align:="">
	&nbsp;</p>
<ul color:="" font-size:="" list-style:="" margin:="" outline:="" padding-left:="" padding-right:="" pt="" style="border: 0px; font-family: " vertical-align:="">
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		<strong style="border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">What are the borrower categories that can avail of the Finance?&nbsp;</strong><br />
		We offer Finance to salaried individuals, self-employed professionals (and self-employed non- professionals).</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		<strong style="border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">How is my Finance eligibility determined?&nbsp;</strong><br />
		The primary consideration in determining the Finance eligibility is that you should be comfortably able to repay the amount you borrow. Your repayment capacity is determined by taking into consideration factors such as income, age, qualifications, number of dependants, spouse&#39;s income, assets, liabilities, stability and continuity of occupation and savings history.</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		<strong style="border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">When can I take a home Finance?&nbsp;</strong><br />
		You can take a home loan before or after identifying the property you want to purchase.</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		<strong style="border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">Can I have a co-applicant for a home Finance?&nbsp;</strong><br />
		Yes, it is good to have a co-applicant. This can help you increase the loan amount you are eligible for as the income of the co-applicant is also taken into consideration.</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		<strong style="border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">Who can be a co-applicant to the Finance?&nbsp;</strong><br />
		You can include your spouse/ parents/ children as a co-applicant and their income will be considered to enhance your Finance amount. Further, in case there are any other co-owners, they also need to be co-applicants to the Finance.</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		<strong style="border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">What is the security that needs to be provided?&nbsp;</strong><br />
		Security for the Finance is a first mortgage of the property to be financed, normally by way of deposit of Title Deeds or other such collateral security as may be necessary. Please do ensure that the title to the property is clear, marketable and free from encumbrance. To elaborate, there should not be any existing mortgage, Finance or litigation, which is likely to affect the title to the property adversely.</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		<strong style="border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">What is an EMI?&nbsp;</strong><br />
		Your Finance is repaid through Equated Monthly Instalments (EMI), which include principal and interest components. EMI repayment starts from the subsequent month of the full Finance disbursement. The EMI is always paid up to the lender on a fixed date each month until the total amount due is paid up. The EMI facility helps the borrower plan his budget. The EMI is calculated taking into account the Finance amount, the time frame for repaying the Finance and the interest rate on the borrowed sum.</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		<strong style="border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">What is an amortization schedule?&nbsp;</strong><br />
		An amortization schedule is a table giving the reduction of your Finance amount by monthly instalments. The amortization schedule gives the breakup of every EMI towards repayment interest and outstanding principal of your Finance.</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		<strong style="border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">Can I avail a tax rebate on my home Finance?&nbsp;</strong><br />
		Tax Rebates are applicable as under the Income Tax Act.</li>
</ul>
                                    </div>
                                  
                                </div>
                                
                               
                            <!--</article>-->
                        </div>
                    <!--</section>-->
               
            </div>
            <!--Features Column-->
            <!--Features Column-->
            <div class="column features-column col-md-3 col-sm-6 col-xs-12 padding-top">
                 <div class="default-form-style contact-form">
    <form id="enquiryfrom" name="enquiryfrom" action="http://www.baliloan.com/formsubmit.php" method="post">
        <p class="pheader"> <span class="q-text">INTERESTED?</span> Get Help from our Service</p>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="text" name="cat" value="" required="" placeholder="Service Name *">
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <textarea rows="2" class="height" required="" name="message" placeholder="Your Requirements" id="requirements"></textarea>
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="text" name="uoc_name" value="" required="" placeholder="Your Name *">
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="email" name="uoc_email" value="" required="" placeholder="Your Email *">
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="text" name="uoc_mobile" value="" required="" placeholder="Your Phone *">
       </div>
                   <input type="hidden" value="http://www.baliloan.com/Property-Finance.php" name="sno"/>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input name="submit" class="btn btn-block btn-info f_14" id="submit" value="Submit Now" type="submit">
       </div>    
    </form>
</div> 
                
            </div>
           
             
           
        </div>
         <div class="col-md-12" >&nbsp;</div>
    </div>
</section> 
<section class="features-style-one">
    &nbsp;
</section>  
<?php include('footer.php'); ?>