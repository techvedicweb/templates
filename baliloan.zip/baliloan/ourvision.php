<?php include('header.php'); ?>        
<img src="http://www.baliloan.com/study/image/1480999264.png" width='100%'><section class="features-style-one">
    <div class="auto-container">
        <div class="row clearfix"> 
            <div class="col-md-12 col-sm-12 col-xs-12">
                
            </div>
            <div class="column features-column col-md-9 col-sm-6 col-xs-12">               
                        <div class="column blog-news-column">
                            <!--<article class="inner-box">-->
                                <div class="content-box">
                                     <ul class="post-info clearfix">
                                        <li><a href="http://www.baliloan.com/">Home</a></li>   
                                        <li> our vision </li>
                                    </ul>
                                    <div class="text">
                                    	<h2 0px="" color:="" font-size:="" font-weight:="" line-height:="" margin:="" outline:="" padding:="" pt="" style="border: 0px; font-family: " vertical-align:="">
	AREAS OF EXPERTISE</h2>
<ul 0px="" 20px="" color:="" font-size:="" list-style-image:="" list-style-position:="" margin:="" outline:="" padding-left:="" padding-right:="" pt="" style="border: 0px; font-family: " vertical-align:="">
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Agribusiness</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Financial Institutions</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Funds</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Health &amp; Education</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Infrastructure</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Manufacturing</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Oil, Gas &amp; Mining</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Public-Private Partnerships</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Retail, Tourism &amp; Property</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Telecommunications &amp; IT</li>
</ul>
<h2 0px="" color:="" font-size:="" font-weight:="" line-height:="" margin:="" outline:="" padding:="" pt="" style="border: 0px; font-family: " vertical-align:="">
	OTHER AREAS</h2>
<ul 0px="" 20px="" color:="" font-size:="" list-style-image:="" list-style-position:="" margin:="" outline:="" padding-left:="" padding-right:="" pt="" style="border: 0px; font-family: " vertical-align:="">
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Sustainability</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Corporate Governance</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Climate Business</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Gender</li>
</ul>
<p 0px="" color:="" font-size:="" margin:="" outline:="" padding:="" pt="" style="border: 0px; font-family: " vertical-align:="">
	For BALI Indonesia, our mission is to be recognised as the leader at partnering our clients and each other for mutual success.</p>
                                    </div>
                                  
                                </div>
                                
                               
                            <!--</article>-->
                        </div>
                    <!--</section>-->
               
            </div>
            <!--Features Column-->
            <!--Features Column-->
            <div class="column features-column col-md-3 col-sm-6 col-xs-12 padding-top">
                 <div class="default-form-style contact-form">
    <form id="enquiryfrom" name="enquiryfrom" action="http://www.baliloan.com/formsubmit.php" method="post">
        <p class="pheader"> <span class="q-text">INTERESTED?</span> Get Help from our Service</p>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="text" name="cat" value="" required="" placeholder="Service Name *">
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <textarea rows="2" class="height" required="" name="message" placeholder="Your Requirements" id="requirements"></textarea>
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="text" name="uoc_name" value="" required="" placeholder="Your Name *">
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="email" name="uoc_email" value="" required="" placeholder="Your Email *">
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="text" name="uoc_mobile" value="" required="" placeholder="Your Phone *">
       </div>
                   <input type="hidden" value="http://www.baliloan.com/ourvision.php" name="sno"/>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input name="submit" class="btn btn-block btn-info f_14" id="submit" value="Submit Now" type="submit">
       </div>    
    </form>
</div> 
                
            </div>
           
             
           
        </div>
         <div class="col-md-12" >&nbsp;</div>
    </div>
</section> 
<section class="features-style-one">
    &nbsp;
</section>  
<?php include('footer.php'); ?>