<html lang="en">
    <head>
        <meta charset="UTF-8">
                <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
                <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
                <meta http-equiv="X-UA-Compatible" content="IE=10,chrome=1"/>
                <title>Bali Loan</title>
                <meta name="description" content="Bali Loan"/>
                <meta name="keywords" content="Bali Loan"/>
                <meta name="GOOGLEBOT" content="index,follow,all"/>
                <meta name="YahooSeeker" content="index,follow"/>
                <meta name="MSNBOT" content="index,follow"/>
                <meta name="Robots" content="index,follow,all"/>
                <meta name="Author" content="http://www.baliloan.com/home.php"/>
                <meta name="Revisit-after" content="daily"/>
                <meta name="audience" content="all"/>
                <meta name="language" content="EN-US"/> 
                <link rel="publisher" href="#"/>
                <meta name="google-site-verification" content="HCpNSW-6SSIkmW5K5fXHWuCbYLtZbDhrvkfwEr3j8Rs" />
                <link rel="canonical" href="http://www.baliloan.com/home.php"/>
                <meta property="og:locale" content="en_US"/>
                <meta property="og:type" content="website"/>
                <meta property="og:title" content="Bali Loan"/>
                <meta property="og:description" content="Bali Loan"/>
                <meta property="og:url" content="http://www.baliloan.com/home.php"/>
                <meta property="og:site_name" content="Bali Loan"/>
        
        <link rel="stylesheet" href="http://www.baliloan.com/new/css/font-awesome.min.css" />
        <link rel="stylesheet" href="http://www.baliloan.com/new/css/bootstrap.css" /> 
        <link rel="stylesheet" href="http://www.baliloan.com/new/css/flaticon.css" /> 
        <link rel="stylesheet" href="http://www.baliloan.com/new/css/revolution-slider.css" /> 
        <link rel="stylesheet" href="http://www.baliloan.com/new/css/style.css" /> 
        <link rel="stylesheet" href="http://www.baliloan.com/new/css/responsive.css" /> 
    </head>
<body>
   
    <div class="page-wrapper">
        <h1 class="keyword">     </h1>
         
         
            <header class="main-header">
           <!-- Header Top -->
               
               <div class="header-upper">
                       <div class="auto-container">
                       <div class="clearfix">
                           
                        <div class="pull-left logo-outer">
                            <div class="col-md-12 visible-sm visible-xs">
                                <div class="col-xs-6">
                                    <div class="logo">
                                        <a href="http://www.baliloan.com/">
                                                                                        <img class="img-responsive" src="http://www.baliloan.com/study/image/1482926136.png" alt="Salesboss" title="Salesboss" >
                                        </a>
                                      </div>
                                </div>
                                <div class="col-xs-6"> 
                                    <!--<div class="upper-column info-box">-->
                                        
                                        <ul>
                                            <li><strong>Contact us</strong></li>
                                            <li><a href="#">  +6 221-719-716</a></li>
                                        </ul>
                                    <!--</div>-->
                                </div>
                            </div>
                               <div class="logo visible-lg visible-md">
                                   <a href="http://www.baliloan.com/">
                                                                                        <img src="http://www.baliloan.com/study/image/1482926136.png" alt="Salesboss" title="Salesboss" >
                                        </a>
                               </div>
                           
                        </div>

                           <div class="pull-right upper-right clearfix visible-lg visible-md">

                               <!--Info Box-->
                               <div class="upper-column info-box">
                                       <div class="icon-box"><span class="flaticon-telephone"></span></div>
                                   <ul>
                                       <li><strong>Contact us</strong></li>
                                       <li><a href="#">  +6 221-719-716</a></li>
                                   </ul>
                               </div>

                               <!--Info Box-->
                               <div class="upper-column info-box">
                                       <div class="icon-box"><span class="flaticon-location-1"></span></div>
                                   <ul>
                                       <li><strong>Our Address</strong></li>
                                       <li>THE RITZ CARLTON -Tower A Lingkar Mega Kuningan Street,Kav. E 1.1 No. 1, South Jakarta, Indonesia 12950</li>
                                   </ul>
                               </div>

                               <!--Info Box-->
<!--                               <div class="upper-column info-box">
                                       <div class="icon-box"><span class="flaticon-clock-2"></span></div>
                                   <ul>
                                       <li><strong>Working Hours</strong></li>
                                       <li>Mon - Sat : 9:00 am to 7:00 pm</li>
                                   </ul>
                               </div>-->



                           </div>

                       </div>
                   </div>
               </div>
               <div class="header-lower">
                       <div class="auto-container">
                       <div class="nav-outer clearfix">
                           <!-- Main Menu -->
                           <nav class="main-menu">
                               <div class="navbar-header">
                                   <!-- Toggle Button -->    	
                                   <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                   <span class="icon-bar"></span>
                                   <span class="icon-bar"></span>
                                   <span class="icon-bar"></span>
                                   </button>
                               </div>

                               <div class="navbar-collapse collapse clearfix">
                                   <ul class="navigation clearfix">
                                          
                                                <li class="dropdown">
                                                <a href="http://www.baliloan.com/home.php">Home</a>
                                             
                                            
                                            </li>   
                                       
                                                <li class="dropdown">
                                                <a href="http://www.baliloan.com/about-us.php">About Us</a>
                                             
                                            
                                            </li>   
                                       
                                                <li class="dropdown">
                                                <a href="#">Product & Services</a>
                                             
                                            
                                            <ul>                                                 <li><a href="http://www.baliloan.com/SME-Finance.php">SME Finance</a></li>
                                                    
                                                                                                 <li><a href="http://www.baliloan.com/Property-Finance.php">Property Finance</a></li>
                                                    
                                                                                                 <li><a href="http://www.baliloan.com/Vehicle-Finance.php">Vehicle-Finance</a></li>
                                                    
                                                                                                 <li><a href="http://www.baliloan.com/Consumer-Finance.php">Consumer-Finance</a></li>
                                                    
                                                </ul></li>   
                                       
                                                <li class="dropdown">
                                                <a href="http://www.baliloan.com/ourvision.php">our vision</a>
                                             
                                            
                                            </li>   
                                       
                                                <li class="dropdown">
                                                <a href="http://www.baliloan.com/contact-us.php">Contact us</a>
                                             
                                            
                                            </li>   
                                                                         

<!--                                     <li class="dropdown"><a href="about.html">About us</a>
                                    <ul>
                                        <li><a href="about.html">About Style One</a></li>
                                        <li><a href="about-2.html">About Style Two</a></li>
                                    </ul>
                                </li>-->
                                   </ul>
                               </div>
                           </nav><!-- Main Menu End-->

                               <!--<div class="get-btn"><a href="#" class="theme-btn appt-btn">Get An Appointment</a></div>-->

                       </div>
                   </div>
               </div> 
           </header>