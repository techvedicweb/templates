<?php include('header.php'); ?>       
<img src="http://www.baliloan.com/study/image/1480944579.png" width='100%'><section class="features-style-one">
    <div class="auto-container">
        <div class="row clearfix"> 
            <div class="col-md-12 col-sm-12 col-xs-12">
                
            </div>
            <div class="column features-column col-md-9 col-sm-6 col-xs-12">               
                        <div class="column blog-news-column">
                            <!--<article class="inner-box">-->
                                <div class="content-box">
                                     <ul class="post-info clearfix">
                                        <li><a href="http://www.baliloan.com/">Home</a></li>   
                                        <li> Bali Loan </li>
                                    </ul>
                                    <div class="text">
                                    	<p>
	<strong>From the smallest clients to the largest &ndash; public or private</strong></p>
<p>
	BALI is a worldwide network of commercial finance firms, serving local and international clients. We at BALI are always focused on client service through more than 164 offices in 4 countries around the world. Each BALI Member Firm is an independent legal entity in its own country. With the flexible personal characteristics of a local firm. BALI is a network with global expertise and a local focus.</p>
<p>
	BALI in Indonesia is a member of BALI International Limited, a UK company limited by guarantee, and forms part of the international BALI network of independent member firms. BALI Indonesia has served BALI&rsquo;s international clients doing business in Indonesia since 1992. This firm was founded by Mr. Benson Adi Tanubrata on 6 December 1979. As such, it is one of the oldest finance firms in Indonesia has and has given BALI an in-depth understanding of providing financing services in Indonesia.</p>
<p>
	We in BALI Indonesia firmly believe that building responsive and responsible relationships with our clients will help you to grow faster and stronger from the ground up. Our team consists of 23 partners and almost 4000 professional staff and our simple aim is to deliver to you the services that meet your needs. We are well prepared to assist you from ground level to achieve the highest success, whether you are a start-up or an established enterprise looking to take the next step up.</p>
<p>
	Our commitment is to assist our clients and our people to excel. Our focus is not on increasing the number of clients and people, but more on helping our clients, hand in hand, to improve and do better business, always supported by our qualified and dedicated professionals. Our goal is clear, and our people are guided by &lsquo;3 Cs&rsquo;: Community, Communication, and Commitment, which we consider to be a symbol of our strength and unity.</p>
<p>
	<strong>Our beliefs</strong></p>
<p>
	An important part of understanding the BALI&rsquo;s approach is rooted in key beliefs that all our people carry with them in their day to day work, and interaction with each other and with clients.</p>
<ul>
	<li>
		We believe that we are one</li>
	<li>
		We believe that local distinctiveness is our strength</li>
	<li>
		We believe that client proximity drives success</li>
	<li>
		We believe that integrity is absolute</li>
</ul>
<p>
	For BALI Indonesia, our mission is to be recognised as the leader at partnering our clients and each other for mutual success.</p>
<p>
	<strong>Terms &amp; Conditions</strong></p>
<p>
	BALI Indonesia, an Indonesian partnership, is a member of BALI International Limited, a UK company limited by guarantee, and forms part of the international BALI network of independent member firms. BALI is the brand name for the BALI network and for each of the BALI Member Firms. &copy; 2005 Benson Adi Loan &amp; Investment .PT &nbsp;All rights reserved.</p>
                                    </div>
                                  
                                </div>
                                
                               
                            <!--</article>-->
                        </div>
                    <!--</section>-->
               
            </div>
            <!--Features Column-->
            <!--Features Column-->
            <div class="column features-column col-md-3 col-sm-6 col-xs-12 padding-top">
                 <div class="default-form-style contact-form">
    <form id="enquiryfrom" name="enquiryfrom" action="http://www.baliloan.com/formsubmit.php" method="post">
        <p class="pheader"> <span class="q-text">INTERESTED?</span> Get Help from our Service</p>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="text" name="cat" value="" required="" placeholder="Service Name *">
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <textarea rows="2" class="height" required="" name="message" placeholder="Your Requirements" id="requirements"></textarea>
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="text" name="uoc_name" value="" required="" placeholder="Your Name *">
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="email" name="uoc_email" value="" required="" placeholder="Your Email *">
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="text" name="uoc_mobile" value="" required="" placeholder="Your Phone *">
       </div>
                   <input type="hidden" value="http://www.baliloan.com/about-us.php" name="sno"/>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input name="submit" class="btn btn-block btn-info f_14" id="submit" value="Submit Now" type="submit">
       </div>    
    </form>
</div> 
                
            </div>
           
             
           
        </div>
         <div class="col-md-12" >&nbsp;</div>
    </div>
</section> 
<section class="features-style-one">
    &nbsp;
</section>  
<?php include('footer.php'); ?>