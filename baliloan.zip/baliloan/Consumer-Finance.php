<?php include('header.php'); ?>       
<img src="http://www.baliloan.com/study/image/1481084348.jpg" width='100%'><section class="features-style-one">
    <div class="auto-container">
        <div class="row clearfix"> 
            <div class="col-md-12 col-sm-12 col-xs-12">
                
            </div>
            <div class="column features-column col-md-9 col-sm-6 col-xs-12">               
                        <div class="column blog-news-column">
                            <!--<article class="inner-box">-->
                                <div class="content-box">
                                     <ul class="post-info clearfix">
                                        <li><a href="http://www.baliloan.com/">Home</a></li>   
                                        <li> Consumer-Finance </li>
                                    </ul>
                                    <div class="text">
                                    	<div>
	We all have needs and aspirations that remain unfulfilled due to the gap that exists between dreams and reality. And this is where a Bali Loan Personal Finance can help in making a difference in your life. No matter what your financial needs are - unexpected expenses, a medical exigency, school or college admission, wedding in the family, home improvement or that long awaited vacation; whatever the occasion, our range of Personal Loans can help you meet your needs. The procedure is simple and quick. You do not have to hypothecate any collateral or property to avail this loan. All you have to do is to follow some simple steps and help our team understand your requirements.</div>
<div>
	A continuous relationship based funding model to meet finance needs as and when required through a variety of products &nbsp; &nbsp; &nbsp; &nbsp;</div>
<div>
	Flexibility with regards to the loan based on the requirement&nbsp;</div>
<div>
	&nbsp;</div>
<div>
	<strong>DOCUMENTATION:</strong></div>
<div>
	KYC or &#39;Know your Customer&#39; formalities and documents</div>
<div>
	Proof of Income and expenditure</div>
<div>
	Application Form and Legal formalities</div>
<div>
	<strong color:="" font-size:="" margin:="" outline:="" padding:="" pt="" style="border: 0px; font-family: " vertical-align:="">FAQ&rsquo;s:</strong></div>
<div>
	&nbsp;</div>
<ul 0px="" color:="" font-size:="" list-style:="" margin:="" outline:="" padding-left:="" padding-right:="" pt="" style="border: 0px; font-family: " vertical-align:="">
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		<strong style="border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">Who can apply for a Personal Finance?</strong><br />
		Bali Loan&nbsp;Personal Finance is available for salaried individuals as well as self-employed individuals.</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		<strong style="border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">Do I need to hypothecate my assets or provide any other collateral to avail a Personal Finance from Bali Loan?</strong><strong style="font-family: inherit; font-style: inherit; border: 0px; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">&nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</strong><br />
		You do not need to hypothecate any assets to avail a Personal Finance from Bali Loan.</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		<strong style="border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">What is the maximum loan amount I can avail?</strong><br />
		You can avail up to&nbsp;20 Lakhs if you are salaried and&nbsnbsp;`&nbsp;30 Lakhs if you are a self- employed businessman. The actual Finance amount eligibility will be calculated based on your income and other parameters that the Bali Loan&nbsp;Relationship Manager will explain.</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		<strong style="border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">What is the minimum and maximum Loan tenor I can avail?</strong><br />
		You can repay your loan over a period of 12 months to 48 months.</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		<strong style="border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">How much would I need to repay each month?</strong><br />
		At the time of booking of your loan, the EMI (Equated Monthly Installments) will be calculated based on the loan amount sanctioned, interest rate and the tenor.</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		<strong style="border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">What is an EMI?</strong><br />
		EMI or &#39;Equated Monthly Installment&#39; is the convenient monthly amount that you have to service to pay back the loan availed. The EMI consists of both the principal and interest components.</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		<strong style="border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">Can I foreclose or prepay my Finance?</strong><br />
		You can foreclose your loan after a minimum period of 6 Months.</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		<strong style="border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">Is there any advantage that I can get if I have already availed a Bali Loan&nbsp;earlier? &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</strong><br />
		<span style="font-family: inherit; font-style: inherit; font-weight: inherit;">Yes, if you are an existing customer of Bali Loan, you will get additional benefits on the processing time as well as the interest rate. What&#39;s more, you will be eligible for a pre-qualified Top Up on your existing Principal Outstanding.</span></li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		<strong style="border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">Why shouldn&#39;t I avail my sudden need for cash through a &#39;cash advance&#39; on my credit card?</strong><br />
		Your credit card can be an option, but withdrawing cash using a credit card can turn out to be very costly if you do not repay it quickly. Interest rates on credit card cash withdrawals can go as high as 40 per cent on an annual basis depending on the type of card you use and you also do not get the interest free period to pay back. In short, interest is charged from the moment you withdraw the cash. There is also an additional transaction charge that is levied on the withdrawal at the ATM. In comparison, a Personal Finance is cheaper and the repayment can be spread over a long period.</li>
</ul>
                                    </div>
                                  
                                </div>
                                
                               
                            <!--</article>-->
                        </div>
                    <!--</section>-->
               
            </div>
            <!--Features Column-->
            <!--Features Column-->
            <div class="column features-column col-md-3 col-sm-6 col-xs-12 padding-top">
                 <div class="default-form-style contact-form">
    <form id="enquiryfrom" name="enquiryfrom" action="http://www.baliloan.com/formsubmit.php" method="post">
        <p class="pheader"> <span class="q-text">INTERESTED?</span> Get Help from our Service</p>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="text" name="cat" value="" required="" placeholder="Service Name *">
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <textarea rows="2" class="height" required="" name="message" placeholder="Your Requirements" id="requirements"></textarea>
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="text" name="uoc_name" value="" required="" placeholder="Your Name *">
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="email" name="uoc_email" value="" required="" placeholder="Your Email *">
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="text" name="uoc_mobile" value="" required="" placeholder="Your Phone *">
       </div>
                   <input type="hidden" value="http://www.baliloan.com/Consumer-Finance.php" name="sno"/>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input name="submit" class="btn btn-block btn-info f_14" id="submit" value="Submit Now" type="submit">
       </div>    
    </form>
</div> 
                
            </div>
           
             
           
        </div>
         <div class="col-md-12" >&nbsp;</div>
    </div>
</section> 
<section class="features-style-one">
    &nbsp;
</section>  
<?php include('footer.php'); ?>