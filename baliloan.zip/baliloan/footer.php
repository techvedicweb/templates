<footer class="main-footer" style="background:#f5f5f5">
        
        <!--Footer Upper-->        
        <div class="footer-upper">
            <div class="auto-container"> 
                <div class="row clearfix">
                    <div class="col-md-12">
                    <div class="col-md-6">
                         <p class="pheader"> <span class="q-text">All </span> Review</p>
                        <marquee direction="up" height="170" scrolldelay="300" onmouseover="this.scrollAmount=0" onmouseout="this.scrollAmount=6" scrollamount="6" style="height: 170px;">
                                                                    <div align="center">
						<table border="0" width="100%" id="table19" height="58" cellspacing="0" cellpadding="0" style="margin:5; border-collapse: collapse; font-family: Verdana; font-size: 9pt; font-weight: bold; color:#000000" bordercolor="#04287B">
								<tbody><tr bgcolor="#A2C4FB">
							<td width="13" align="center" bgcolor="#003187">
							<img border="0" src="http://www.baliloan.com/new/arrow.jpg" width="12" height="11">&nbsp; </td>
										<td>
										<p style="margin: 0 10"><b>2016-12-30</b><br>
										</p><p style="margin: 0 10">
                                                                                    <a style="color:#fff;" href="#">ilooking for loan
 </a>  </p></td>
									</tr>
								  </tbody></table>				
						</div>
                                                                    
                                        <div align="center">
                                                 <table border="0" width="100%" id="table19" height="58" cellspacing="0" cellpadding="0" style="margin:5; border-collapse: collapse; font-family: Verdana; font-size: 9pt; font-weight: bold; color:#000000" bordercolor="#04287B">
									<tbody><tr bgcolor="#6598F5">
											<td width="13" align="center" bgcolor="#003187">
							<img border="0" src="http://www.baliloan.com/new/arrow.jpg" width="12" height="11">&nbsp; </td>
										<td>
										<p style="margin: 0 10"><b> 2016-12-30 </b><br> 
										</p><p style="margin: 0 10"> <font color="#000000">
										 <a style="color:#f5f5f5;" href="#">  ilooking for loan
</a></font> </p></td>
									</tr>
								  </tbody></table>				
						</div>
                            <p style="margin: 5"></p>
                                                                                <div align="center">
						<table border="0" width="100%" id="table19" height="58" cellspacing="0" cellpadding="0" style="margin:5; border-collapse: collapse; font-family: Verdana; font-size: 9pt; font-weight: bold; color:#000000" bordercolor="#04287B">
								<tbody><tr bgcolor="#A2C4FB">
							<td width="13" align="center" bgcolor="#003187">
							<img border="0" src="http://www.baliloan.com/new/arrow.jpg" width="12" height="11">&nbsp; </td>
										<td>
										<p style="margin: 0 10"><b>2017-01-03</b><br>
										</p><p style="margin: 0 10">
                                                                                    <a style="color:#fff;" href="#">I'm looking personal loan </a>  </p></td>
									</tr>
								  </tbody></table>				
						</div>
                                                                    
                                        <div align="center">
                                                 <table border="0" width="100%" id="table19" height="58" cellspacing="0" cellpadding="0" style="margin:5; border-collapse: collapse; font-family: Verdana; font-size: 9pt; font-weight: bold; color:#000000" bordercolor="#04287B">
									<tbody><tr bgcolor="#6598F5">
											<td width="13" align="center" bgcolor="#003187">
							<img border="0" src="http://www.baliloan.com/new/arrow.jpg" width="12" height="11">&nbsp; </td>
										<td>
										<p style="margin: 0 10"><b> 2017-01-06 </b><br> 
										</p><p style="margin: 0 10"> <font color="#000000">
										 <a style="color:#f5f5f5;" href="#">  Home loans</a></font> </p></td>
									</tr>
								  </tbody></table>				
						</div>
                            <p style="margin: 5"></p>
                                                                                <div align="center">
						<table border="0" width="100%" id="table19" height="58" cellspacing="0" cellpadding="0" style="margin:5; border-collapse: collapse; font-family: Verdana; font-size: 9pt; font-weight: bold; color:#000000" bordercolor="#04287B">
								<tbody><tr bgcolor="#A2C4FB">
							<td width="13" align="center" bgcolor="#003187">
							<img border="0" src="http://www.baliloan.com/new/arrow.jpg" width="12" height="11">&nbsp; </td>
										<td>
										<p style="margin: 0 10"><b>2017-01-17</b><br>
										</p><p style="margin: 0 10">
                                                                                    <a style="color:#fff;" href="#">I looking for Lone  </a>  </p></td>
									</tr>
								  </tbody></table>				
						</div>
                                                                    
                                        <div align="center">
                                                 <table border="0" width="100%" id="table19" height="58" cellspacing="0" cellpadding="0" style="margin:5; border-collapse: collapse; font-family: Verdana; font-size: 9pt; font-weight: bold; color:#000000" bordercolor="#04287B">
									<tbody><tr bgcolor="#6598F5">
											<td width="13" align="center" bgcolor="#003187">
							<img border="0" src="http://www.baliloan.com/new/arrow.jpg" width="12" height="11">&nbsp; </td>
										<td>
										<p style="margin: 0 10"><b> 2017-01-18 </b><br> 
										</p><p style="margin: 0 10"> <font color="#000000">
										 <a style="color:#f5f5f5;" href="#">  site enginiyar</a></font> </p></td>
									</tr>
								  </tbody></table>				
						</div>
                            <p style="margin: 5"></p>
                                                                                <div align="center">
						<table border="0" width="100%" id="table19" height="58" cellspacing="0" cellpadding="0" style="margin:5; border-collapse: collapse; font-family: Verdana; font-size: 9pt; font-weight: bold; color:#000000" bordercolor="#04287B">
								<tbody><tr bgcolor="#A2C4FB">
							<td width="13" align="center" bgcolor="#003187">
							<img border="0" src="http://www.baliloan.com/new/arrow.jpg" width="12" height="11">&nbsp; </td>
										<td>
										<p style="margin: 0 10"><b>2017-01-18</b><br>
										</p><p style="margin: 0 10">
                                                                                    <a style="color:#fff;" href="#">site enginiyar </a>  </p></td>
									</tr>
								  </tbody></table>				
						</div>
                                                                    
                                        <div align="center">
                                                 <table border="0" width="100%" id="table19" height="58" cellspacing="0" cellpadding="0" style="margin:5; border-collapse: collapse; font-family: Verdana; font-size: 9pt; font-weight: bold; color:#000000" bordercolor="#04287B">
									<tbody><tr bgcolor="#6598F5">
											<td width="13" align="center" bgcolor="#003187">
							<img border="0" src="http://www.baliloan.com/new/arrow.jpg" width="12" height="11">&nbsp; </td>
										<td>
										<p style="margin: 0 10"><b> 2017-01-18 </b><br> 
										</p><p style="margin: 0 10"> <font color="#000000">
										 <a style="color:#f5f5f5;" href="#">  site enginiyar</a></font> </p></td>
									</tr>
								  </tbody></table>				
						</div>
                            <p style="margin: 5"></p>
                                                                                <div align="center">
						<table border="0" width="100%" id="table19" height="58" cellspacing="0" cellpadding="0" style="margin:5; border-collapse: collapse; font-family: Verdana; font-size: 9pt; font-weight: bold; color:#000000" bordercolor="#04287B">
								<tbody><tr bgcolor="#A2C4FB">
							<td width="13" align="center" bgcolor="#003187">
							<img border="0" src="http://www.baliloan.com/new/arrow.jpg" width="12" height="11">&nbsp; </td>
										<td>
										<p style="margin: 0 10"><b>2017-01-18</b><br>
										</p><p style="margin: 0 10">
                                                                                    <a style="color:#fff;" href="#">lon </a>  </p></td>
									</tr>
								  </tbody></table>				
						</div>
                                                                    
                                        <div align="center">
                                                 <table border="0" width="100%" id="table19" height="58" cellspacing="0" cellpadding="0" style="margin:5; border-collapse: collapse; font-family: Verdana; font-size: 9pt; font-weight: bold; color:#000000" bordercolor="#04287B">
									<tbody><tr bgcolor="#6598F5">
											<td width="13" align="center" bgcolor="#003187">
							<img border="0" src="http://www.baliloan.com/new/arrow.jpg" width="12" height="11">&nbsp; </td>
										<td>
										<p style="margin: 0 10"><b> 2017-01-23 </b><br> 
										</p><p style="margin: 0 10"> <font color="#000000">
										 <a style="color:#f5f5f5;" href="#">  Sir I want parsnel lone 2lak</a></font> </p></td>
									</tr>
								  </tbody></table>				
						</div>
                            <p style="margin: 5"></p>
                                                                                <div align="center">
						<table border="0" width="100%" id="table19" height="58" cellspacing="0" cellpadding="0" style="margin:5; border-collapse: collapse; font-family: Verdana; font-size: 9pt; font-weight: bold; color:#000000" bordercolor="#04287B">
								<tbody><tr bgcolor="#A2C4FB">
							<td width="13" align="center" bgcolor="#003187">
							<img border="0" src="http://www.baliloan.com/new/arrow.jpg" width="12" height="11">&nbsp; </td>
										<td>
										<p style="margin: 0 10"><b>2017-01-23</b><br>
										</p><p style="margin: 0 10">
                                                                                    <a style="color:#fff;" href="#">15000 </a>  </p></td>
									</tr>
								  </tbody></table>				
						</div>
                                                                    
                                        <div align="center">
                                                 <table border="0" width="100%" id="table19" height="58" cellspacing="0" cellpadding="0" style="margin:5; border-collapse: collapse; font-family: Verdana; font-size: 9pt; font-weight: bold; color:#000000" bordercolor="#04287B">
									<tbody><tr bgcolor="#6598F5">
											<td width="13" align="center" bgcolor="#003187">
							<img border="0" src="http://www.baliloan.com/new/arrow.jpg" width="12" height="11">&nbsp; </td>
										<td>
										<p style="margin: 0 10"><b> 2017-01-30 </b><br> 
										</p><p style="margin: 0 10"> <font color="#000000">
										 <a style="color:#f5f5f5;" href="#">  Loan required 
</a></font> </p></td>
									</tr>
								  </tbody></table>				
						</div>
                            <p style="margin: 5"></p>
                                                                                <div align="center">
						<table border="0" width="100%" id="table19" height="58" cellspacing="0" cellpadding="0" style="margin:5; border-collapse: collapse; font-family: Verdana; font-size: 9pt; font-weight: bold; color:#000000" bordercolor="#04287B">
								<tbody><tr bgcolor="#A2C4FB">
							<td width="13" align="center" bgcolor="#003187">
							<img border="0" src="http://www.baliloan.com/new/arrow.jpg" width="12" height="11">&nbsp; </td>
										<td>
										<p style="margin: 0 10"><b>2017-01-30</b><br>
										</p><p style="margin: 0 10">
                                                                                    <a style="color:#fff;" href="#">Loan required 
 </a>  </p></td>
									</tr>
								  </tbody></table>				
						</div>
                                                                    
                                        <div align="center">
                                                 <table border="0" width="100%" id="table19" height="58" cellspacing="0" cellpadding="0" style="margin:5; border-collapse: collapse; font-family: Verdana; font-size: 9pt; font-weight: bold; color:#000000" bordercolor="#04287B">
									<tbody><tr bgcolor="#6598F5">
											<td width="13" align="center" bgcolor="#003187">
							<img border="0" src="http://www.baliloan.com/new/arrow.jpg" width="12" height="11">&nbsp; </td>
										<td>
										<p style="margin: 0 10"><b> 2017-01-30 </b><br> 
										</p><p style="margin: 0 10"> <font color="#000000">
										 <a style="color:#f5f5f5;" href="#">  Loan required 
</a></font> </p></td>
									</tr>
								  </tbody></table>				
						</div>
                            <p style="margin: 5"></p>
                                                                                <div align="center">
						<table border="0" width="100%" id="table19" height="58" cellspacing="0" cellpadding="0" style="margin:5; border-collapse: collapse; font-family: Verdana; font-size: 9pt; font-weight: bold; color:#000000" bordercolor="#04287B">
								<tbody><tr bgcolor="#A2C4FB">
							<td width="13" align="center" bgcolor="#003187">
							<img border="0" src="http://www.baliloan.com/new/arrow.jpg" width="12" height="11">&nbsp; </td>
										<td>
										<p style="margin: 0 10"><b>2017-01-30</b><br>
										</p><p style="margin: 0 10">
                                                                                    <a style="color:#fff;" href="#">Loan required 
 </a>  </p></td>
									</tr>
								  </tbody></table>				
						</div>
                                                                    
                                        <div align="center">
                                                 <table border="0" width="100%" id="table19" height="58" cellspacing="0" cellpadding="0" style="margin:5; border-collapse: collapse; font-family: Verdana; font-size: 9pt; font-weight: bold; color:#000000" bordercolor="#04287B">
									<tbody><tr bgcolor="#6598F5">
											<td width="13" align="center" bgcolor="#003187">
							<img border="0" src="http://www.baliloan.com/new/arrow.jpg" width="12" height="11">&nbsp; </td>
										<td>
										<p style="margin: 0 10"><b> 2017-01-30 </b><br> 
										</p><p style="margin: 0 10"> <font color="#000000">
										 <a style="color:#f5f5f5;" href="#">  Home</a></font> </p></td>
									</tr>
								  </tbody></table>				
						</div>
                            <p style="margin: 5"></p>
                                                                                <div align="center">
						<table border="0" width="100%" id="table19" height="58" cellspacing="0" cellpadding="0" style="margin:5; border-collapse: collapse; font-family: Verdana; font-size: 9pt; font-weight: bold; color:#000000" bordercolor="#04287B">
								<tbody><tr bgcolor="#A2C4FB">
							<td width="13" align="center" bgcolor="#003187">
							<img border="0" src="http://www.baliloan.com/new/arrow.jpg" width="12" height="11">&nbsp; </td>
										<td>
										<p style="margin: 0 10"><b>2017-01-31</b><br>
										</p><p style="margin: 0 10">
                                                                                    <a style="color:#fff;" href="#">Personal loan </a>  </p></td>
									</tr>
								  </tbody></table>				
						</div>
                                                                    
                                        <div align="center">
                                                 <table border="0" width="100%" id="table19" height="58" cellspacing="0" cellpadding="0" style="margin:5; border-collapse: collapse; font-family: Verdana; font-size: 9pt; font-weight: bold; color:#000000" bordercolor="#04287B">
									<tbody><tr bgcolor="#6598F5">
											<td width="13" align="center" bgcolor="#003187">
							<img border="0" src="http://www.baliloan.com/new/arrow.jpg" width="12" height="11">&nbsp; </td>
										<td>
										<p style="margin: 0 10"><b> 2017-02-01 </b><br> 
										</p><p style="margin: 0 10"> <font color="#000000">
										 <a style="color:#f5f5f5;" href="#">  Parsnal loan</a></font> </p></td>
									</tr>
								  </tbody></table>				
						</div>
                            <p style="margin: 5"></p>
                                                                                <div align="center">
						<table border="0" width="100%" id="table19" height="58" cellspacing="0" cellpadding="0" style="margin:5; border-collapse: collapse; font-family: Verdana; font-size: 9pt; font-weight: bold; color:#000000" bordercolor="#04287B">
								<tbody><tr bgcolor="#A2C4FB">
							<td width="13" align="center" bgcolor="#003187">
							<img border="0" src="http://www.baliloan.com/new/arrow.jpg" width="12" height="11">&nbsp; </td>
										<td>
										<p style="margin: 0 10"><b>2017-02-01</b><br>
										</p><p style="margin: 0 10">
                                                                                    <a style="color:#fff;" href="#">Parsnal loan </a>  </p></td>
									</tr>
								  </tbody></table>				
						</div>
                                                                    
                                        <div align="center">
                                                 <table border="0" width="100%" id="table19" height="58" cellspacing="0" cellpadding="0" style="margin:5; border-collapse: collapse; font-family: Verdana; font-size: 9pt; font-weight: bold; color:#000000" bordercolor="#04287B">
									<tbody><tr bgcolor="#6598F5">
											<td width="13" align="center" bgcolor="#003187">
							<img border="0" src="http://www.baliloan.com/new/arrow.jpg" width="12" height="11">&nbsp; </td>
										<td>
										<p style="margin: 0 10"><b> 2017-02-10 </b><br> 
										</p><p style="margin: 0 10"> <font color="#000000">
										 <a style="color:#f5f5f5;" href="#">  TV mechanical engineering </a></font> </p></td>
									</tr>
								  </tbody></table>				
						</div>
                            <p style="margin: 5"></p>
                                                                </marquee>
                    </div>
                        <div class="col-md-6">
                            <div class="default-form-style contact-form">
                                <form id="enquiryfrom" name="enquiryfrom" action="http://www.baliloan.com/review.php" method="post">
                                    <p class="pheader"> <span class="q-text">INTERESTED?</span> Get Review</p>
                                   <div class="form-group col-lg-6 col-md-6">
                                       <input type="text" name="name" value="" required="" placeholder="Name *">
                                   </div>
                                   <div class="form-group col-lg-6 col-md-6">
                                       <input type="text" name="phone" value=""  placeholder="Phone ">
                                   </div>
                                    <div class="form-group col-lg-12 col-md-12 col-xs-12">
                                       <input type="email" name="email" value="" required="" placeholder="Your Email *">
                                   </div>
                                   <div class="form-group col-lg-12 col-md-12 col-xs-12">
                                       <textarea rows="2" class="height" required="" name="message" placeholder="Your Review" id="requirements"></textarea>
                                   </div> 
                                   <div class="form-group col-lg-4 col-md-4 col-xs-12">
                                       <input name="submit" class="btn btn-block btn-info f_14" id="submit" value="Submit Now" type="submit">
                                   </div>    
                                </form>
                            </div> 
                        </div>
                </div>
                </div>
                
            </div>                
        </div>
  
     
        <div class="footer-bottom">
<!--            <div class="auto-container">
                <div class="row clearfix">--> 
                    <div class="col-md-12 col-sm-12 col-xs-12">
                                                <p> <a class='cscolor' href='#'>Copyright © 2016 Balifincorp.com. All Rights Reserved  </a></p>
                                               
                    </div>                     
<!--                </div>
            </div>-->
        </div>
        
    </footer>    
</div>
        <div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="txt">BL</span></div>
        <script src="http://www.baliloan.com/new/js/jquery.js"></script> 
        <script src="http://www.baliloan.com/new/js/bootstrap.min.js"></script>
        <script src="http://www.baliloan.com/new/js/revolution.min.js"></script>
        <script src="http://www.baliloan.com/new/js/jquery.fancybox.pack.js"></script>
        <script src="http://www.baliloan.com/new/js/bxslider.js"></script>
        <script src="http://www.baliloan.com/new/js/wow.js"></script>
        <script src="http://www.baliloan.com/new/js/script.js"></script>
    </body>
</html>