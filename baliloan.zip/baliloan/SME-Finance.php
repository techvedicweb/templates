<?php include('header.php'); ?>
<img src="http://www.baliloan.com/study/image/1480944261.jpg" width='100%'><section class="features-style-one">
    <div class="auto-container">
        <div class="row clearfix"> 
            <div class="col-md-12 col-sm-12 col-xs-12">
                
            </div>
            <div class="column features-column col-md-9 col-sm-6 col-xs-12">               
                        <div class="column blog-news-column">
                            <!--<article class="inner-box">-->
                                <div class="content-box">
                                     <ul class="post-info clearfix">
                                        <li><a href="http://www.baliloan.com/">Home</a></li>   
                                        <li> SME Finance </li>
                                    </ul>
                                    <div class="text">
                                    	<p -webkit-text-stroke-width:="" 0px="" background-color:="" color:="" font-size:="" font-style:="" font-variant-caps:="" font-variant-ligatures:="" font-weight:="" letter-spacing:="" margin:="" orphans:="" outline:="" padding:="" pt="" style="border: 0px; font-family: " text-align:="" text-indent:="" text-transform:="" vertical-align:="" white-space:="" widows:="" word-spacing:="">
	<em style="border: 0px; font-family: inherit; font-size: 13px; font-style: italic; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">Bali Loan strives to provide small to medium enterprises with a complete financial solution to maximize their business growth. We act as your partner to help support and grow your business to take it to the next level, delivering cost effective solutions across geographies with a flexibility that is unmatched by our competitors. With our wide network, we have the influence and expertise to help our customer reach new heights &ndash; shaping the industries of tomorrow.</em></p>
<p -webkit-text-stroke-width:="" 0px="" background-color:="" color:="" font-size:="" font-style:="" font-variant-caps:="" font-variant-ligatures:="" font-weight:="" letter-spacing:="" margin:="" orphans:="" outline:="" padding:="" pt="" style="border: 0px; font-family: " text-align:="" text-indent:="" text-transform:="" vertical-align:="" white-space:="" widows:="" word-spacing:="">
	<em style="border: 0px; font-family: inherit; font-size: 13px; font-style: italic; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">Your success is at the centre of what we do. We are dedicated to building and maintaining long-term partnerships with entrepreneurs from a wide range of industries and our ultimate goal is to provide you with a customized financial solution around your business, giving your growth ideas the attention they deserve.</em></p>
<p -webkit-text-stroke-width:="" 0px="" background-color:="" color:="" font-size:="" font-style:="" font-variant-caps:="" font-variant-ligatures:="" font-weight:="" letter-spacing:="" margin:="" orphans:="" outline:="" padding:="" pt="" style="border: 0px; font-family: " text-align:="" text-indent:="" text-transform:="" vertical-align:="" white-space:="" widows:="" word-spacing:="">
	&nbsp;</p>
<ul -webkit-text-stroke-width:="" background-color:="" color:="" font-size:="" font-style:="" font-variant-caps:="" font-variant-ligatures:="" font-weight:="" letter-spacing:="" list-style:="" margin:="" orphans:="" outline:="" padding:="" pt="" style="border: 0px; font-family: " text-align:="" text-indent:="" text-transform:="" vertical-align:="" white-space:="" widows:="" word-spacing:="">
	<li style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Choose from a variety of programs
		<ol style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; list-style: none;">
			<li style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
				Long Term Finance</li>
			<li style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
				Business Installment Finance</li>
		</ol>
	</li>
	<li style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Loans up to 80% of Asset/property value</li>
	<li style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Wide range of acceptable collaterals
		<ul style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; list-style: none;">
			<li style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
				Blend of Short Term and Long Term Finance to help customize the most preferred repayment options</li>
		</ul>
	</li>
	<li style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Benefit from high tenor Finance of up to 15 years</li>
</ul>
<p -webkit-text-stroke-width:="" 0px="" background-color:="" color:="" font-size:="" font-style:="" font-variant-caps:="" font-variant-ligatures:="" font-weight:="" letter-spacing:="" margin:="" orphans:="" outline:="" padding:="" pt="" style="border: 0px; font-family: " text-align:="" text-indent:="" text-transform:="" vertical-align:="" white-space:="" widows:="" word-spacing:="">
	<strong style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: bold; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">DOCUMENTATION:</strong></p>
<ul -webkit-text-stroke-width:="" background-color:="" color:="" font-size:="" font-style:="" font-variant-caps:="" font-variant-ligatures:="" font-weight:="" letter-spacing:="" list-style:="" margin:="" orphans:="" outline:="" padding:="" pt="" style="border: 0px; font-family: " text-align:="" text-indent:="" text-transform:="" vertical-align:="" white-space:="" widows:="" word-spacing:="">
	<li style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Financial statements of the last 3 years</li>
	<li style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Bank statements of the last 6 months</li>
	<li style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		KYC documents</li>
	<li style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Loan Repayment Details</li>
	<li style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Relevant collateral documents</li>
</ul>
<p -webkit-text-stroke-width:="" 0px="" background-color:="" color:="" font-size:="" font-style:="" font-variant-caps:="" font-variant-ligatures:="" font-weight:="" letter-spacing:="" margin:="" orphans:="" outline:="" padding:="" pt="" style="border: 0px; font-family: " text-align:="" text-indent:="" text-transform:="" vertical-align:="" white-space:="" widows:="" word-spacing:="">
	<strong style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: bold; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">FAQ&rsquo;S:</strong></p>
<ul -webkit-text-stroke-width:="" background-color:="" color:="" font-size:="" font-style:="" font-variant-caps:="" font-variant-ligatures:="" font-weight:="" letter-spacing:="" list-style:="" margin:="" orphans:="" outline:="" padding:="" pt="" style="border: 0px; font-family: " text-align:="" text-indent:="" text-transform:="" vertical-align:="" white-space:="" widows:="" word-spacing:="">
	<li style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		<strong style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: bold; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">Who can apply for a SME Finance?</strong><br />
		Manufacturers, Traders, Small &amp; Medium Enterprise Owners with a minimum turnover of&nbsp;`&nbsp;10 Crores and at least 5 years in business can apply for an SME Finance.</li>
	<li style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		<strong style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: bold; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">What are the products offered under SME Finance?</strong><br />
		Bali Loan&nbsp;offers SME Finance under 4 variants, namely, Long Term Finance, Business Installment Finance and Lease Rental Discounting.</li>
	<li style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		<strong style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: bold; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">What is a Long Term Finance?</strong><br />
		These are Finance that can be availed for meeting long term working capital or for purchase of equipment, plant &amp; machinery or Real Estate. We accept a broad suite of collaterals that range from commercial, residential and industrial property.</li>
	<li style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		<strong style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: bold; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">What is a Business Installment Finance?</strong><br />
		Business Installment Finance are Finance which are used to meet medium term working capital needs.</li>
	<li style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		<strong style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: bold; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">What is the selection criterion for SME Finance?</strong><br />
		Bali Loan&nbsp;assesses the business of the customer across 8 broad parameters. The criteria include: years in business, management experience, tangible net worth, credit history, revenue trends year-on-year, interest cover and obligations of all existing Finance.</li>
	<li style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		<strong style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: bold; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">What is acceptable as collateral for applying for a SME Finance?</strong><br />
		Bali Loan&nbsp;accepts
		<ol style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; list-style: none;">
			<li style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
				Residential property owned and occupied by the borrower / promoter</li>
			<li style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
				Ready commercial property (shop, offices, franchise outlets) owned and occupied by the borrower/ promoter (primary Collateral)</li>
			<li style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
				Ready residential / commercial properties which are partly rented and partly self - occupied</li>
			<li style="border: 0px; font-family: inherit; font-size: 13px; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
				Industrial property owned and occupied by the borrower</li>
		</ol>
	</li>
</ul>
<p -webkit-text-stroke-width:="" 0px="" background-color:="" color:="" font-size:="" font-style:="" font-variant-caps:="" font-variant-ligatures:="" font-weight:="" letter-spacing:="" margin:="" orphans:="" outline:="" padding:="" pt="" style="border: 0px; font-family: " text-align:="" text-indent:="" text-transform:="" vertical-align:="" white-space:="" widows:="" word-spacing:="">
	We do not accept under-construction properties as collateral.</p>
<p -webkit-text-stroke-width:="" 0px="" background-color:="" color:="" font-size:="" font-style:="" font-variant-caps:="" font-variant-ligatures:="" font-weight:="" letter-spacing:="" margin:="" orphans:="" outline:="" padding:="" pt="" style="border: 0px; font-family: " text-align:="" text-indent:="" text-transform:="" vertical-align:="" white-space:="" widows:="" word-spacing:="">
	We offer a maximum Finance to Value (FTV) of 80% based on the categorization of the collaterals. Please get in touch with our Relationship Manager for further details.</p>
                                    </div>
                                  
                                </div>
                                
                               
                            <!--</article>-->
                        </div>
                    <!--</section>-->
               
            </div>
            <!--Features Column-->
            <!--Features Column-->
            <div class="column features-column col-md-3 col-sm-6 col-xs-12 padding-top">
                 <div class="default-form-style contact-form">
    <form id="enquiryfrom" name="enquiryfrom" action="http://www.baliloan.com/formsubmit.php" method="post">
        <p class="pheader"> <span class="q-text">INTERESTED?</span> Get Help from our Service</p>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="text" name="cat" value="" required="" placeholder="Service Name *">
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <textarea rows="2" class="height" required="" name="message" placeholder="Your Requirements" id="requirements"></textarea>
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="text" name="uoc_name" value="" required="" placeholder="Your Name *">
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="email" name="uoc_email" value="" required="" placeholder="Your Email *">
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="text" name="uoc_mobile" value="" required="" placeholder="Your Phone *">
       </div>
                   <input type="hidden" value="http://www.baliloan.com/SME-Finance.php" name="sno"/>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input name="submit" class="btn btn-block btn-info f_14" id="submit" value="Submit Now" type="submit">
       </div>    
    </form>
</div> 
                
            </div>
           
             
           
        </div>
         <div class="col-md-12" >&nbsp;</div>
    </div>
</section> 
<section class="features-style-one">
    &nbsp;
</section>  
<?php include('footer.php'); ?>