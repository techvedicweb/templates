<?php include('header.php'); ?>
<img src="http://www.baliloan.com/study/image/1481084292.jpg" width='100%'><section class="features-style-one">
    <div class="auto-container">
        <div class="row clearfix"> 
            <div class="col-md-12 col-sm-12 col-xs-12">
                
            </div>
            <div class="column features-column col-md-9 col-sm-6 col-xs-12">               
                        <div class="column blog-news-column">
                            <!--<article class="inner-box">-->
                                <div class="content-box">
                                     <ul class="post-info clearfix">
                                        <li><a href="http://www.baliloan.com/">Home</a></li>   
                                        <li> Vehicle-Finance </li>
                                    </ul>
                                    <div class="text">
                                    	<p 0px="" color:="" font-size:="" margin:="" outline:="" padding:="" pt="" style="border: 0px; font-family: " vertical-align:="">
	<em style="border: 0px; font-family: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">We, at Bali Loan, believe in partnering in your growth. It is this belief that enables us to support small and medium transport businesses as their finance partner, and help them to grow their business. We offer Commercial &amp; Personal Vehicle finance on attractive and flexible terms for both New and Used vehicles across segments, ranging from first time buyers to large owners. The product offering covers small vehicles to tractor trailers and buses. The end use of the finance could be for chassis and body fabrication or Working capital requirements, and could even be used for balance transfer from other financiers. In short, our product offering ensures that we are capable of addressing each and every vehicle requirement of customers.</em></p>
<p 0px="" color:="" font-size:="" margin:="" outline:="" padding:="" pt="" style="border: 0px; font-family: " vertical-align:="">
	<span style="font-family: inherit; font-style: inherit; font-weight: inherit;">Finance starting from&nbsp;&nbsp;1 Lakh onwards</span></p>
<p 0px="" color:="" font-size:="" margin:="" outline:="" padding:="" pt="" style="border: 0px; font-family: " vertical-align:="">
	<span style="font-family: inherit; font-style: inherit; font-weight: inherit;">Flexible finance schemes for both New and Used vehicles</span></p>
<ul color:="" font-size:="" list-style:="" margin:="" outline:="" padding-left:="" padding-right:="" pt="" style="border: 0px; font-family: " vertical-align:="">
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Quick and hassle free process</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Minimum documentation</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Multiple repayment options</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Attractive interest rates</li>
</ul>
<p 0px="" color:="" font-size:="" margin:="" outline:="" padding:="" pt="" style="border: 0px; font-family: " vertical-align:="">
	&nbsp;</p>
<p 0px="" color:="" font-size:="" margin:="" outline:="" padding:="" pt="" style="border: 0px; font-family: " vertical-align:="">
	<strong style="border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">DOCUMENTATION:</strong></p>
<ul color:="" font-size:="" list-style:="" margin:="" outline:="" padding-left:="" padding-right:="" pt="" style="border: 0px; font-family: " vertical-align:="">
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Identity proof</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Address Proof</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Experience Proof</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Vehicle List/ Details</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Bank Statement for 6 Months</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		Past Track Record ( If any)</li>
</ul>
<p 0px="" color:="" font-size:="" margin:="" outline:="" padding:="" pt="" style="border: 0px; font-family: " vertical-align:="">
	&nbsp;</p>
<p 0px="" color:="" font-size:="" margin:="" outline:="" padding:="" pt="" style="border: 0px; font-family: " vertical-align:="">
	<strong style="border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">FAQ&rsquo;S:</strong></p>
<ul color:="" font-size:="" list-style:="" margin:="" outline:="" padding-left:="" padding-right:="" pt="" style="border: 0px; font-family: " vertical-align:="">
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		<strong style="border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">Are there any specific types of&nbsp; Vehicles for which finance is provided?</strong><br />
		At Bali Loan, we finance all types of Goods and Passenger carrying vehicles, right from under 1 ton GVW vehicles to vehicles having a Gross Vehicle Weight of over 40 Tons.</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		<strong>I have a working capital need for my business, can I take a&nbsp;finance<strong style="border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">&nbsp;on my&nbsp;</strong>finance&nbsp;- free vehicle?</strong><br />
		Yes, we provide refinance on a pre-owned vehicle.</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		<strong style="border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">Can I get a loan on a car that would be used with a commercial number plate. &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</strong>&nbsp; &nbsp; &nbsp; Unfortunately, we do not finance passenger cars having a commercial number plate.</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		<strong style="border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">My core business is not goods transportation, but I am looking to buy a vehicle which will help me reduce my dependency on a Transport Service provider.</strong><br />
		Yes, we would be happy to extend our services to you. We would request you to please contact our call center and our executive will get in touch with you soon.</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		<strong style="border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">What documents are required for financing my Vehicle?</strong><br />
		Please refer to our document checklist for the detailed list of document required for the finance sanctioning process.</li>
	<li style="border: 0px; font-family: inherit; font-style: inherit; font-weight: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">
		<strong style="border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline;">What is the rate of interest that I would be charged?</strong><br />
		The rate of interest depends on a lot of factors such as the number of vehicles owned by you, your turnover, your repayment Track record, etc. We would be able to confirm the rate of interest once we have studied your documents.</li>
</ul>
                                    </div>
                                  
                                </div>
                                
                               
                            <!--</article>-->
                        </div>
                    <!--</section>-->
               
            </div>
            <!--Features Column-->
            <!--Features Column-->
            <div class="column features-column col-md-3 col-sm-6 col-xs-12 padding-top">
                 <div class="default-form-style contact-form">
    <form id="enquiryfrom" name="enquiryfrom" action="http://www.baliloan.com/formsubmit.php" method="post">
        <p class="pheader"> <span class="q-text">INTERESTED?</span> Get Help from our Service</p>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="text" name="cat" value="" required="" placeholder="Service Name *">
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <textarea rows="2" class="height" required="" name="message" placeholder="Your Requirements" id="requirements"></textarea>
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="text" name="uoc_name" value="" required="" placeholder="Your Name *">
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="email" name="uoc_email" value="" required="" placeholder="Your Email *">
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="text" name="uoc_mobile" value="" required="" placeholder="Your Phone *">
       </div>
                   <input type="hidden" value="http://www.baliloan.com/Vehicle-Finance.php" name="sno"/>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input name="submit" class="btn btn-block btn-info f_14" id="submit" value="Submit Now" type="submit">
       </div>    
    </form>
</div> 
                
            </div>
           
             
           
        </div>
         <div class="col-md-12" >&nbsp;</div>
    </div>
</section> 
<section class="features-style-one">
    &nbsp;
</section>  
<?php include('footer.php'); ?>