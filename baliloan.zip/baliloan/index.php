<?php include('header.php'); ?>

<img src="http://www.baliloan.com/study/image/1480939637.jpg" width='100%'><section class="features-style-one">
    <div class="auto-container">
        <div class="row clearfix"> 
            <div class="col-md-12 col-sm-12 col-xs-12">
                
            </div>
            <div class="column features-column col-md-9 col-sm-6 col-xs-12">               
                        <div class="column blog-news-column">
                            <!--<article class="inner-box">-->
                                <div class="content-box">
                                     <ul class="post-info clearfix">
                                        <li><a href="http://www.baliloan.com/">Home</a></li>   
                                        <li> Bali Loan </li>
                                    </ul>
                                    <div class="text">
                                    	<p font-size:="" sans="" source="" style="box-sizing: border-box; margin: 0px 0px 10px; padding: 0px; border: none; outline: none; position: relative; line-height: 1.6em; color: rgb(119, 119, 119); font-family: ">
	<span style="box-sizing: border-box; margin: 0px; padding: 0px; border: none; outline: none; font-weight: 700;">From the smallest clients to the largest &ndash; public or private</span></p>
<p font-size:="" sans="" source="" style="box-sizing: border-box; margin: 0px 0px 10px; padding: 0px; border: none; outline: none; position: relative; line-height: 1.6em; color: rgb(119, 119, 119); font-family: ">
	Benson Adi Loan &amp; Investment .Pt is a worldwide network of commercial finance firms, serving local and international clients. We at BALI are always focused on client service through more than 164 offices in 4 countries around the world. Each BALI Member Firm is an independent legal entity in its own country. With the flexible personal characteristics of a local firm. BALI is a network with global expertise and a local focus.</p>
<p font-size:="" sans="" source="" style="box-sizing: border-box; margin: 0px 0px 10px; padding: 0px; border: none; outline: none; position: relative; line-height: 1.6em; color: rgb(119, 119, 119); font-family: ">
	BALI in Indonesia is a member of BALI International Limited, a UK company limited by guarantee, and forms part of the international BALI network of independent member firms. BALI Indonesia has served BALI&rsquo;s international clients doing business in Indonesia since 1992. This firm was founded by Mr. Benson Adi Tanubrata on 6 December 1979. As such, it is one of the oldest finance firms in Indonesia has and has given BALI an in-depth understanding of providing financing services in Indonesia.</p>
                                    </div>
                                  
                                </div>
                                
                               
                            <!--</article>-->
                        </div>
                    <!--</section>-->
               
            </div>
            <!--Features Column-->
            <!--Features Column-->
            <div class="column features-column col-md-3 col-sm-6 col-xs-12 padding-top">
                 <div class="default-form-style contact-form">
    <form id="enquiryfrom" name="enquiryfrom" action="http://www.baliloan.com/formsubmit.php" method="post">
        <p class="pheader"> <span class="q-text">INTERESTED?</span> Get Help from our Service</p>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="text" name="cat" value="" required="" placeholder="Service Name *">
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <textarea rows="2" class="height" required="" name="message" placeholder="Your Requirements" id="requirements"></textarea>
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="text" name="uoc_name" value="" required="" placeholder="Your Name *">
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="email" name="uoc_email" value="" required="" placeholder="Your Email *">
       </div>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input type="text" name="uoc_mobile" value="" required="" placeholder="Your Phone *">
       </div>
                   <input type="hidden" value="http://www.baliloan.com/home.php" name="sno"/>
       <div class="form-group col-lg-12 col-md-12 col-xs-12">
           <input name="submit" class="btn btn-block btn-info f_14" id="submit" value="Submit Now" type="submit">
       </div>    
    </form>
</div> 
                
            </div>
           
             
           
        </div>
         <div class="col-md-12" >&nbsp;</div>
    </div>
</section> 
<section class="features-style-one">
    &nbsp;
</section>  
<?php include('footer.php'); ?>