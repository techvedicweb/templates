<?php 
include('connection.php');
session_start();
//print_r($_REQUEST);
//print $_REQUEST['type'];
$school_id=$_SESSION['schooluserid'];
$srch=mysql_real_escape_string($_REQUEST['first']);
//echo $srch;
if($_REQUEST['type']=='num_of_vacancy_show'){
	//echo "SELECT userid,company_name FROM employer_registration where school_id='$school_id'  limit $srch";exit;
$sql=mysql_query("SELECT userid,company_name FROM employer_registration where school_id='$school_id' limit $srch");
}
else{
	
	$sql=mysql_query("SELECT userid,company_name FROM employer_registration where school_id='$school_id' && company_name LIKE '%$srch%'");
}
	echo "<table class='table'>
		<thead>
			<th>Name</th>
			<th>Exclusive?</th>
			<th>Vacancies</th>
			<th>Applications</th>
			<th>H&S Cert. Exp.</th>
		</thead>";
while($name=mysql_fetch_array($sql))
{
$employerid=$name['userid'];
	//echo $employerid;exit;
	if($_REQUEST['type']=='searchemployer'){
		
$all_vacancy=mysql_query("select count(userid) as numbofvacncy from create_vacancy where userid='$employerid' && (vacancy_title LIKE '%$srch%' || vacancy_location LIKE '%$srch%' || vacancy_description LIKE '%$srch%' || from_date1 LIKE '%$srch%' || to_date1 LIKE '%$srch%');");
		
	}	
	if($_REQUEST['type']=='num_of_vacancy_show'){
		
$all_vacancy=mysql_query("select count(userid) as numbofvacncy from create_vacancy where userid='$employerid'");
		
	}	
	
		
	
	if($all_vacancy){
	
	if($all_vacancy && mysql_num_rows($all_vacancy)>0){
while($row=mysql_fetch_array($all_vacancy)){
	
		$company_name=$name['company_name'];
		$number_ofvacancy=$row['numbofvacncy'];
		
		$all_vacancy01=mysql_query("select count(userid) as numbofvacncy from create_vacancy where userid='$employerid'");
		
		$rowcou=mysql_fetch_array($all_vacancy01);

		$all_vacancy1=mysql_query("select company_userid as appli from job_applied where company_userid='$employerid'");
		$row1=mysql_fetch_array($all_vacancy1);
		$all_vacancy3=mysql_query("select a.userid, a.id, b.vacancy_id from create_vacancy a, employer_schooll_vacancy b where a.userid='$employerid' && b.vacancy_id=a.id");
	
		?>
<tr><td><?php echo $name['company_name'];?></td>
			<td><?php if(mysql_num_rows($all_vacancy3)>0) {echo "Yes";} else{echo "No";}?></td>
			<td><?php echo $row['numbofvacncy'];?></td>
			<td><?php echo mysql_num_rows($all_vacancy1);?></td>
			<td><a href="employer_detail.php?empuserid=<?php echo $employerid;?>"><?php echo "View";?></a></td>
		</tr>
		<?php
	
 }
	}
	else{
	echo "<tr><td>No Result Found</td></tr>";
	}
	
}
else{
echo "Error in Query Pass".mysql_error();
}
}
echo "</table>";	


?>