<?php
include('connection.php');
$subuserid=$_GET['subuserid'];
//$time=$_GET['crt_time'];


$get_subuser=mysql_query("select subuserid from add_users where md5(id)='$subuserid'");
$sub_userid=mysql_fetch_array($get_subuser);
if($sub_userid['subuserid']!=""){
	$deletelogin=mysql_query("delete from login where userid='".$sub_userid['subuserid']."' and category='schooll_subuser'");
	$deleteadduser=mysql_query("delete from add_users where md5(id)='$subuserid'");
	//echo "location deleted";
	echo "<script>window.location='../schools/users.php'</script>";

}
elseif($sub_userid['subuserid']==""){
	$deleteadduser=mysql_query("delete from add_users where md5(id)='$subuserid'");
	//echo "location deleted";
	echo "<script>window.location='../schools/users.php'</script>";
}

else{
echo "Error in Location Delete".mysql_error();
}


?>