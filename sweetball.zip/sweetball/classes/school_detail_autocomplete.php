<?php
include('connection.php');
$name=$_POST['name'];
 $qry=mysql_query("select * from school_registration where school_name='$name' ");
 while($dteail=mysql_fetch_array($qry)){
    echo "<div  id='addressofschool'>".$dteail['school_address']."</div>";   
    echo "<span id='cityofschool'>".$dteail['school_city']."</span>";
}
?>