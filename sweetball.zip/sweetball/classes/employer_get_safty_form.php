<?php 
include('connection.php');
session_start();
class employerformDetails{


    public function getform_upload(){
      
  $current_userid= $_SESSION['employeruserid'];
  $curdate=date("Ymdhisa");
       $video="../employer/get_helth/".$current_userid.$curdate.'_'.$_FILES['ghelth_file']['name'];
  move_uploaded_file($_FILES['ghelth_file']['tmp_name'],$video);
         $videoname=$current_userid.$curdate.'_'.$_FILES['ghelth_file']['name'];
     $check_file=mysql_query("select * from employer_helth_form where userid='$current_userid'");
	 if(mysql_num_rows($check_file)>0)
	 {
      $media=mysql_query("update employer_helth_form set ghelth_file='$videoname' where userid='$current_userid'");
	 }
	 else{
		 
		  $media=mysql_query("insert into employer_helth_form set userid='$current_userid', ghelth_file='$videoname'");
	 }
  
  if($media){
        //  echo '<script>alert("Student Media File Uploaded Sucessfully!");</script>';
     echo '<script type="text/javascript">window.location ="../employer/get_health_safety.php";</script>';
        }
        else{
        
           echo '<script>alert("Error In employer Form Updatation !'.mysql_error().'");</script>';
        }     
  
  }
}

if(isset($_POST['helth_upload'])){
$cvupdate=new employerformDetails();
$cvupdate->getform_upload();
}


    ?>