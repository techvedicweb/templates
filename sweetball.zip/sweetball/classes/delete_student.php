<?php
include('connection.php');
$uid=$_GET['uid'];
//$time=$_GET['crt_time'];
//echo $uid;exit;

$get_student=mysql_query("select userid from student_profile where md5(id)='$uid'");
$sub_studnt=mysql_fetch_array($get_student);
if($sub_studnt['userid']!=""){
	$deletelogin=mysql_query("delete from login where userid='".$sub_studnt['userid']."' and category='Student'");
	$deleteadduser=mysql_query("delete from student_profile where md5(id)='$uid'");
	//echo "location deleted";
	echo "<script>window.location='../schools/manage_students.php'</script>";

}
elseif($sub_studnt['userid']==""){
	$deleteadduser=mysql_query("delete from student_profile where md5(id)='$uid'");
	//echo "location deleted";
	echo "<script>window.location='../schools/manage_students.php'</script>";
}

else{
echo "Error in Location Delete".mysql_error();
}


?>