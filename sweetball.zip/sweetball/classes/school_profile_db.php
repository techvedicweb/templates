<script>
	function addstd(){
		
		 var r = confirm("Add Another Student?");
    if (r == true) {	
       window.location ="../schools/add_student.php";
    } else {
		
		window.location ="../schools/manage_students.php";
    }
	
	}
	
	function updstd(){
		
		 var r = confirm("Profile Update Successfull");
    if (r == true) {	
       window.location ="../schools/edit_student.php";
    } else {
		
		window.location ="../schools/edit_students.php";
    }
	
	}
	
	function add_user(){
		
		 var r = confirm("Add Another User?");
    if (r == true) {	
       window.location ="../schools/add_users.php";
    } else {
		
		window.location ="../schools/users.php";
    }
	
	}
	
	
	function add_error(){
		
		 var r = confirm("Email ID Exist!");
    if (r == true) {	
       window.location ="../schools/add_student.php";
    } else {
		
		window.location ="../schools/manage_students.php";
    }
	
	}
	function add_error3(){
		
		 var r = confirm("Email ID Exist!");
    if (r == true) {	
       window.location ="../schools/add_users.php";
    } else {
		
		window.location ="../schools/users.php";
    }
	
	}
	
	
	function add_error4(){
		
		 var r = confirm("Email ID Exist!");
    if (r == true) {	
       window.location ="../schools/add_employer.php";
    } else {
		
		window.location ="../schools/manage_employers.php";
    }
	
	}
	
	function add_error5(){
		
		 var r = confirm("Invitation Exist!");
    if (r == true) {	
       window.location ="../schools/add_exclusive_employer.php";
    } else {
		
		window.location ="../schools/manage_exclusive_employers.php";
    }
	
	}
	
</script>


<?php
include('connection.php');
session_start();
class SchoolProfile {

 public function school_profile_complete(){

   $school_user=$_SESSION['schooluserid'];
  //$school_user;exit;
        $school_name=mysql_real_escape_string($_POST['school_name']);
        $school_address=mysql_real_escape_string($_POST['school_address']);
        $school_city=mysql_real_escape_string($_POST['school_city']);
        $school_postal_code=mysql_real_escape_string($_POST['school_postal_code']);
        $school_website=mysql_real_escape_string($_POST['school_website']);
          $contact=mysql_real_escape_string($_POST['contact']);
        $school_telephone=mysql_real_escape_string($_POST['school_telephone']);
	 
	 $first_name=mysql_real_escape_string($_POST['first_name']);
	 $last_name=mysql_real_escape_string($_POST['last_name']);
	 $region=mysql_real_escape_string($_POST['region']);
	 $school_title=mysql_real_escape_string($_POST['school_title']);
	 $email=mysql_real_escape_string($_POST['email']);
	 $ageof_range1=mysql_real_escape_string($_POST['ageof_range1']);
	 $ageof_range2=mysql_real_escape_string($_POST['ageof_range2']);
	 $work_exp = implode(',', $_POST['work_exp']);
	 
	  $admin_contact=mysql_real_escape_string($_POST['admin_contact']);
	  $admin_email=mysql_real_escape_string($_POST['admin_email']);
	  $admin_phone=mysql_real_escape_string($_POST['admin_phone']);
	 
	 
	 
	 
       if($_FILES['school_logo']['name']!=''){ 
		 $logo="../schools/logo/".$_FILES['school_logo']['name'];
	move_uploaded_file($_FILES['school_logo']['tmp_name'],$logo);
         $logoname=mysql_real_escape_string($_FILES['school_logo']['name']);  
		   
	   }
	 else{
		 
		 $logoname=mysql_real_escape_string($_POST['imageoldname']);
	 }
    
$school_profile=mysql_query("update school_registration set school_first_name='$first_name',school_last_name='$last_name',school_name_title='$school_title',school_email='$email',school_region='$region',school_name='$school_name',school_address='$school_address',school_city='$school_city',contact='$contact',school_telephone='$school_telephone',school_website='$school_website',school_postal_code='$school_postal_code',school_logo='$logoname',ageof_range1='$ageof_range1',ageof_range2='$ageof_range2',work_experience='$work_exp', admin_contact='$admin_contact',admin_email='$admin_email',admin_phone='$admin_phone' where userid='$school_user';");

    
       
      if($school_profile){
         // echo '<script>alert("School Profile Complete Detail Updated!");</script>';
		    echo '<script type="text/javascript">window.location ="../schools/school_profile.php";</script>';
        }
        else{
        
           echo '<script>alert("Error In School Profile Complete Detail Updetation !'.mysql_error().'");</script>';
        }
}
    
 public function add_student(){
	  $user=$_SESSION['schooluserid'];
      $user_query=mysql_query("select school_email,school_name from school_registration where userid='$user'");
	  $user_sch_email=mysql_fetch_array($user_query);
	  $sch_email=$user_sch_email['school_email'];
	  $sch_name=$user_sch_email['school_name'];
	  $message="";
 $first_name=mysql_real_escape_string($_POST['first_name']);
       $last_name=mysql_real_escape_string($_POST['last_name']);
       $email=mysql_real_escape_string($_POST['email']);
       $current_form=mysql_real_escape_string($_POST['current_form']);
       $gender=mysql_real_escape_string($_POST['gender']);
        $school_year=mysql_real_escape_string($_POST['school_year']);
		
			$parts001=explode('@',$email);
	  $uid=$parts001[0].rand ( 1 , 99 );
	  $pass=rand(10005000,20000500);
	  $mdpass=md5($pass);
	  //print($uid);exit;
	  $stuid=strtoupper($uid);
	  
	  $query_check=mysql_query("select * from login where userid='$stuid' or email='$email'");
	  $numrows_count=mysql_num_rows($query_check);
	  if($numrows_count>0){
		  
		 echo '<script>add_error();</script>';
 }
else{
      
      $add=mysql_query("insert into add_student (userid,first_name,last_name,email,current_form,gender,school_year,invited_status,add_date) values ('$user','$first_name','$last_name','$email','$current_form','$gender','$school_year',0,now())");
        if($add){
			 // echo '<script type="text/javascript">window.location ="../schools/manage_students.php";</script>';
			
			//..........email to student invitation
			$lastid=mysql_insert_id();
	  $login=mysql_query("insert into login (email,userid,password,category,email_confirmation) values('$email','$stuid','$mdpass','Student','false');");
	  
		$student_school=mysql_query("insert into student_school (userid) values('$stuid');");
        $student_preferences=mysql_query("insert into student_preferences (userid) values('$stuid');");
		$student_cv=mysql_query("insert into student_cv (userid) values('$stuid');");
		$student_achivment=mysql_query("insert into student_achievements (userid) values('$stuid');");
		
		$student_profile=mysql_query("insert into student_profile (first_name,last_name,email,userid,school_year,school_id,gender,t_c,joining_date) values('$first_name','$last_name','$email','$stuid','$school_year','$user','$gender',1,now());");
	   
	   
				$subject = 'Worktaster Student Invitation Mail';
$message .= "<p align='center'><a href='http://worktaster.com' target='_blank'><img src='https://www.worktaster.com/wp-content/themes/work_taster/img/logo.png' alt=''></a></p>";
$message .= "<p>Dear  $first_name  $last_name</p><h3 align='center'>Welcome To Worktaster</h3>
<p>You have been invited onto Worktaster by $sch_name</p>
<p>To activate your username please <br><a href='http://worktaster.com/user/email_confrim.php?userid=".$stuid."' target='_blank'>Click Here</a> using the following:"."\r\n\n";

$message .='<p>Your Username is: '.$stuid.'</p><p>Your Password is: '.$pass.'</p>

<p>By activating your account you agree to be bound by the Terms and Conditions for Employers on our website <a href="https://www.worktaster.com/terms-conditions/" target="_blank">Term & Conditions</a></p>
Worktaster Works ForStudents. Enjoy your Journey.<br />
Thankyou<br />
Worktaster Team.<p><span style="color:red;">The Team at</span> <span style="color:green;font-style: italic;">Worktaster</span></p>';

     // print $message;exit;

      //print $message;exit;
 $header= 'From: '.$sch_email . "\r\n" .
    'Reply-To:' .$sch_email. "\r\n" .
    'X-Mailer: PHP/' . phpversion();
        $header.= "MIME-Version: 1.0\r\n"; 
$header.= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; 
$header.= "X-Priority: 1\r\n";
/*

 $header= 'From: ' . "\r\n" .
    'Reply-To:  ' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();
        $header.= "MIME-Version: 1.0\r\n"; 
$header.= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; 
$header.= "X-Priority: 1\r\n"; 
*/
 mail($email, $subject, $message, $header);	
			echo '<script>addstd();</script>';
			
        }
        else{
        echo '<script>alert("Error In Add Student !'.mysql_error().'");</script>';
        }
  
  } 
}  
 public function upd_student(){
	  $user=$_SESSION['schooluserid'];
	   $uid=$_POST['uid'];
       $first_name=mysql_real_escape_string($_POST['first_name']);
       $last_name=mysql_real_escape_string($_POST['last_name']);
       $current_form=mysql_real_escape_string($_POST['current_form']);
       $gender=mysql_real_escape_string($_POST['gender']);
       $school_year=mysql_real_escape_string($_POST['school_year']);
      
      $student_profile=mysql_query("update student_profile set first_name='$first_name',last_name='$last_name',current_form='$current_form',gender='$gender',school_year='$school_year' where md5(id)='$uid'");
        if($student_profile){
			echo '<script>alert("Profile Update Successfull!");</script>';
		  echo '<script type="text/javascript">window.location ="../schools/edit_student.php?uid='.$uid.'";</script>';
		}
		
 }	
 
    public function Addemployer(){
        $school_user=$_SESSION['schooluserid'];
        $sir_title=mysql_real_escape_string($_POST['company_sir_title']);
        $company_fname=mysql_real_escape_string($_POST['company_f_name']);
        $company_lname=mysql_real_escape_string($_POST['company_l_name']);
         $company_email=mysql_real_escape_string($_POST['company_email']);
         $company_website=mysql_real_escape_string($_POST['company_website']);
        $company_telephone=mysql_real_escape_string($_POST['country_code'])." ".mysql_real_escape_string($_POST['company_telephone']);
        $company_title=mysql_real_escape_string($_POST['company_title']);
        $company_name=mysql_real_escape_string($_POST['company_name']);
        $company_address=mysql_real_escape_string($_POST['company_address']);
        $company_city=mysql_real_escape_string($_POST['company_city']);
        $company_postal_code=mysql_real_escape_string($_POST['company_postal_code']);
        $company_country=mysql_real_escape_string($_POST['company_country']);
		
		
		$message="";
		$category="Employer";
		
		$parts001=explode('@',$company_email);
		$uid=$parts001[0].rand ( 1 , 99 );
		$pass=rand(50005000,60000500);
		$mdpass=md5($pass);
		//print($uid);exit;
		$company_userid=strtoupper($uid);
	  
		$query_check=mysql_query("select * from login where userid='$company_userid' or email='$company_email'");
		$numrows_count=mysql_num_rows($query_check);
		if($numrows_count>0){
		  
		 echo '<script>add_error4();</script>';
		}
		
		 $logindetail=mysql_query("insert into login (userid,password,email,category,email_confirmation) values ('$company_userid','$mdpass','$company_email','$category','false');");
        
     

 if($logindetail){
	 
	 $employer_location=mysql_query("insert into employer_location(userid) values('$company_userid');");
      
        $add_employer=mysql_query("insert into employer_registration (userid,school_id,company_first_name,company_last_name,company_email,company_telephone,company_title,company_name,company_address,company_city,	company_website,company_country,join_date) values('$company_userid','$school_user','$company_fname','$company_lname','$company_email','$company_telephone','$company_title','$company_name','$company_address','$company_city','$company_website','$company_country',now());");
     
        

 if($add_employer){
	 $subject = 'Worktaster Employer Registration Mail';

$message ='<p>Welcome to Worktaster.  Thank you for registering for an account with us.  By activating your account you agree to be bound by the Terms and Conditions for Students on our website <a href="https://www.worktaster.com/terms-conditions/" target="_blank">Term & Conditions</a>.
We at Worktaster are committed to changing the lives of young people by improving access to employability and skills, providing transparent, fair access to work experience placements for everyone.
Worktaster Works For Students. Join the journey, activate your account today. To activate your account,</p> <p><a href="http://localhost/worktaster/user/email_confrim.php?userid='.$company_userid.'"> Please Click Here </a></p>
<p>Your Username is: '.$company_userid.'</p><p>Your Password is: '.$pass.'</p>
Thank you';
//print($message);exit;
      // print $message;exit;
 $header= 'From: '.$sch_email . "\r\n" .
    'Reply-To:' .$sch_email. "\r\n" .
    'X-Mailer: PHP/' . phpversion();
        $header.= "MIME-Version: 1.0\r\n"; 
$header.= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; 
$header.= "X-Priority: 1\r\n";
/*

 $header= 'From: ' . "\r\n" .
    'Reply-To:  ' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();
        $header.= "MIME-Version: 1.0\r\n"; 
$header.= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; 
$header.= "X-Priority: 1\r\n"; 
*/
 mail($user_email, $subject, $message, $header);	
	
      //echo '<script type="text/javascript">window.location ="../employer/employer_profile_edit.php";</script>';
          //echo '<script>alert("School Employer Added Sucessfully!");</script>';
	   echo '<script type="text/javascript">window.location ="../schools/manage_employers.php";</script>';

        }
        else{
        
           echo '<script>alert("School  Error In Employer Add !'.mysql_error().'");</script>';
        }
    
    }
	}
    
      public function Addexclusiveemployer(){
        $school_user=$_SESSION['schooluserid'];
		
		$employer_name=mysql_real_escape_string($_POST['employer_name']);
        $contact_f_name=mysql_real_escape_string($_POST['contact_f_name']);
        $contact_l_name=mysql_real_escape_string($_POST['contact_l_name']);
		$contact_email=mysql_real_escape_string($_POST['contact_email']);
		
		$user_query=mysql_query("select school_email,school_name,contact from school_registration where userid='$school_user'");
		$user_sch_email=mysql_fetch_array($user_query);
		$from_email=$user_sch_email['school_email'];
		$contact=$user_sch_email['contact'];
		$school_name=$user_sch_email['school_name'];
		
		$message="";
		$category="Employer";
		$cur_date=date("Ymdhisa");
		$parts001=explode('@',$contact_email);
		$uid=$parts001[0].$cur_date;
		$pass=rand(50005000,60000500);
		$mdpass=md5($pass);
		//print($uid);exit;
		$company_userid=strtoupper($uid);
	  
		$query_check=mysql_query("select * from login where userid='$company_userid' or email='$contact_email'");
		$numrows_count=mysql_num_rows($query_check);
		if($numrows_count>0){
		  
		 echo '<script>add_error5();</script>';
		}
		else{
		
		 $logindetail=mysql_query("insert into login (userid,password,email,category,email_confirmation) values ('$company_userid','$mdpass','$contact_email','$category','false');");
      
        $add_employer1=mysql_query("insert into exclusive_employer (school_id,excl_userid,employer_name,contact_firstname,contact_lastname,contact_email,added_date) values('$school_user','$company_userid','$employer_name','$contact_f_name','$contact_l_name','$contact_email',now());");
     
		$employer_location=mysql_query("insert into employer_location(userid) values('$company_userid');");
      
        $add_employer=mysql_query("insert into employer_registration (userid,school_id,company_first_name,company_last_name,company_name,company_email,join_date) values('$company_userid','$school_user','$contact_f_name','$contact_l_name','$employer_name','$contact_email',now());");
		
		 $exc_query=mysql_query("insert into add_exclusive_school(employer_id,school_id,status) values('$company_userid','$school_user',1);");
		}
	 if($add_employer){
	 $subject = 'Worktaster Exclusive Employer Invitation Mail';
$message .= "<p align='center'><a href='http://worktaster.com' target='_blank'><img src='https://www.worktaster.com/wp-content/themes/work_taster/img/logo.png' alt=''></a></p>";
$message .= "<p>Dear  $contact_f_name  $contact_l_name</p><h3 align='center'>Welcome To Worktaster</h3>
<p>You have been invited on Worktaster by $contact at $school_name</p>
<p>To activate your username please <a href='http://localhost/worktaster/user/email_confrim.php?userid=".$company_userid."'>Click Here</a> using the following:"."\r\n\n";

$message .='<p>Your Username is: '.$company_userid.'</p><p>Your Password is: '.$pass.'</p>

<p>Welcome to Worktaster. By activating your account you agree to be bound by the Terms and Conditions for Employers on our website <a href="https://www.worktaster.com/terms-conditions/" target="_blank">Term & Conditions</a> We at Worktaster are committed to changing the lives of young people by improving access to employability and skills, providing transparent, fair access to work experience placements for everyone. As an employer on Worktaster you will be able to use our one touch system for all the work experience placements you offer to local young people from $school_name. For more information on how Worktaster can work for you <a href="https://www.worktaster.com/about-us/" target="_blank">Click Here.</a></p>
Worktaster Works For Employers. Join the journey.<br />
If you have any questions <a href="https://www.worktaster.com/" target="_blank">Contact us.</a><br />
Thankyou<br />
Worktaster Team.<p><span style="color:red;">The Team at</span> <span style="color:green;font-style: italic;">Worktaster</span></p>';

	 /*
$subject = 'Worktaster Exclusive Employer Invitation Mail';
$message ='<p>Welcome to Worktaster.</p>
<p>You Are Invited on Workstaster<br><a href="http://localhost/worktaster/user/invitation.php?exclsv='.$lastid.'"> Please Click Here </a></p>
Thank you';
*/

print($message);exit;
      // print $message;exit;
 $header= 'From: '.$from_email . "\r\n" .
    'Reply-To:' .$from_email. "\r\n" .
    'X-Mailer: PHP/' . phpversion();
        $header.= "MIME-Version: 1.0\r\n"; 
$header.= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; 
$header.= "X-Priority: 1\r\n";
/*

 $header= 'From: ' . "\r\n" .
    'Reply-To:  ' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();
        $header.= "MIME-Version: 1.0\r\n"; 
$header.= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; 
$header.= "X-Priority: 1\r\n"; 
*/
 mail($to_email, $subject, $message, $header);	
	
      //echo '<script type="text/javascript">window.location ="../employer/employer_profile_edit.php";</script>';
          //echo '<script>alert("School Employer Added Sucessfully!");</script>';
	  // echo '<script type="text/javascript">window.location ="../schools/manage_exclusive_employers.php";</script>';

        }
        else{
        
           echo '<script>alert("School  Error In Employer Add !'.mysql_error().'");</script>';
        }
    
 
	  }
	
    public function AddUsers(){
	 $school_user=$_SESSION['schooluserid'];
		  //$user=$_SESSION['schooluserid'];
      $user_query=mysql_query("select school_email,contact from school_registration where userid='$school_user'");
	  $user_sch_email=mysql_fetch_array($user_query);
	  $sch_email=$user_sch_email['school_email'];
	   $sch_contact=$user_sch_email['contact'];
	   $sch_name=$user_sch_email['school_name'];
	  
        $salutation=mysql_real_escape_string($_POST['salutation']);
        $user_fname=mysql_real_escape_string($_POST['user_first_name']);
        $user_lname=mysql_real_escape_string($_POST['user_last_name']);
            $user_title=mysql_real_escape_string($_POST['user_job_title']);
          $user_email=mysql_real_escape_string($_POST['user_email']);
        $user_telephone=mysql_real_escape_string($_POST['user_telephone']);
		
		$message="";
		$category="schooll_subuser";
		
				$parts001=explode('@',$user_email);
	  $uid=$parts001[0].rand ( 1 , 99 );
	  $pass=rand(30005000,40000500);
	  $mdpass=md5($pass);
	  //print($uid);exit;
	  $stuid=strtoupper($uid);
	  
	  $query_check=mysql_query("select * from login where userid='$stuid' or email='$user_email'");
	  $numrows_count=mysql_num_rows($query_check);
	  if($numrows_count>0){
		  
		 echo '<script>add_error3();</script>';
 }
 else {
	 $login=mysql_query("insert into login (email,userid,password,category,email_confirmation) values('$user_email','$stuid','$mdpass','$category','false');");
		if($login){
    $add_users=mysql_query("insert into add_users (userid,subuserid,salutation,user_first_name,user_last_name,user_job_title,user_email,user_telephone,invited_status,add_date) values ('$school_user','$stuid','$salutation','$user_fname','$user_lname','$user_title','$user_email','$user_telephone',0,now())");
	$lastid=mysql_insert_id();

      //echo '<script type="text/javascript">window.location ="../employer/employer_profile_edit.php";</script>';
         // echo '<script>alert("School Users Added Sucessfully!");</script>';
		  //echo '<script type="text/javascript">window.location ="../schools/users.php";</script>';
		 
			
			 // echo '<script type="text/javascript">window.location ="../schools/manage_students.php";</script>';
			
			//..........email to student invitation
			$subject = 'Worktaster User Invitation Mail';
$message .= "<p align='center'><a href='http://worktaster.com' target='_blank'><img src='https://www.worktaster.com/wp-content/themes/work_taster/img/logo.png' alt=''></a></p>";
$message .= "<p>Dear  $user_fname  $user_lname</p><h3 align='center'>Welcome To Worktaster</h3>
<p>You have been invited onto Worktaster by $sch_name $sch_contact</p>
<p>To activate your username please <a href='http://worktaster.com/user/email_confrim.php?userid=".$stuid."' target='_blank'>Click Here</a> using the following:"."\r\n\n";

$message .='<p>Your Username is: '.$stuid.'</p><p>Your Password is: '.$pass.'</p>

<p>Welcome to Worktaster. By activating your account you agree to be bound by the Terms and Conditions on our website <a href="https://www.worktaster.com/terms-conditions/" target="_blank">Term & Conditions</a> We at Worktaster are committed to changing the lives of young people by improving access to employability and skills, providing transparent, fair access to work experience placements for everyone. For more information on how Worktaster can work for you <a href="https://www.worktaster.com/about-us/" target="_blank">Click Here.</a></p>
Worktaster Works ForSchools. Join the journey.<br />
If you have any questions <a href="https://www.worktaster.com/" target="_blank">contact us.</a><br />
Thankyou<br />
Worktaster Team.<p><span style="color:red;">The Team at</span> <span style="color:green;font-style: italic;">Worktaster</span></p>';

				/*$subject = 'Worktaster User Invitation Mail';
$message .= ("Dear  $user_fname  $user_lname,<br>Greetings!!!<br>
You Are Invited on Workstaster<br><a href='http://localhost/worktaster/user/invitation.php?acpt_user=".md5($lastid)."'>Click Here</a>");

$message .='<p>Your Username is: '.$stuid.'</p><p>Your Password is: '.$pass.'</p>

<p>To activate your account, <p><a href="http://localhost/worktaster/user/email_confrim.php?userid='.$stuid.'"> Please Click Here </a></p>
Thank you</p>';
*/
//print($message);exit;
      // print $message;exit;
 $header= 'From: '.$sch_email . "\r\n" .
    'Reply-To:' .$sch_email. "\r\n" .
    'X-Mailer: PHP/' . phpversion();
        $header.= "MIME-Version: 1.0\r\n"; 
$header.= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; 
$header.= "X-Priority: 1\r\n";
/*

 $header= 'From: ' . "\r\n" .
    'Reply-To:  ' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();
        $header.= "MIME-Version: 1.0\r\n"; 
$header.= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; 
$header.= "X-Priority: 1\r\n"; 
*/
 mail($user_email, $subject, $message, $header);	
			//echo '<script>add_user();</script>';

		}
        else{
        
           echo '<script>alert("Error In School User Add !'.mysql_error().'");</script>';
        }
    
    }
	}
    
}

if(isset($_POST['school_profile'])){
    $sc_pro_com= new SchoolProfile();
    $sc_pro_com->school_profile_complete();
}
if(isset($_POST['add_student'])){
    $sc_pro_com= new SchoolProfile();
    $sc_pro_com->add_student();
}
if(isset($_POST['upd_student'])){
    $sc_pro_com= new SchoolProfile();
    $sc_pro_com->upd_student();
}
if(isset($_POST['add_users'])){
    $sc_pro_com= new SchoolProfile();
    $sc_pro_com->AddUsers();
}

if(isset($_POST['add_employer'])){
    $sc_pro_com= new SchoolProfile();
    $sc_pro_com->Addemployer();
}
if(isset($_POST['add_exclusive_employer'])){
    $sc_pro_com= new SchoolProfile();
    $sc_pro_com->Addexclusiveemployer();
}





?>