-- phpMyAdmin SQL Dump
-- version 4.0.10.7
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Apr 12, 2016 at 03:06 AM
-- Server version: 5.5.48-cll
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `worktast_worktaster`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_employer`
--

CREATE TABLE IF NOT EXISTS `add_employer` (
  `userid` varchar(50) NOT NULL,
  `sir_title` varchar(10) NOT NULL,
  `company_first_name` varchar(100) NOT NULL,
  `company_last_name` varchar(100) NOT NULL,
  `company_email` varchar(50) NOT NULL,
  `company_telephone` varchar(20) NOT NULL,
  `company_title` varchar(250) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `company_address` varchar(400) NOT NULL,
  `company_city` varchar(70) NOT NULL,
  `company_website` varchar(100) NOT NULL,
  `company_postal_code` varchar(20) NOT NULL,
  `company_country` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `add_student`
--

CREATE TABLE IF NOT EXISTS `add_student` (
  `userid` varchar(50) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `current_form` varchar(100) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `school_year` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `add_student`
--

INSERT INTO `add_student` (`userid`, `first_name`, `last_name`, `current_form`, `gender`, `email`, `school_year`) VALUES
('bashstreet', 'Sally', 'Tomlinson', 'IT', 'Please Sel', 'sal@thetomlinsons.com', '18'),
('schoolmatin1234', 'Jack', 'Buck', 'A7', 'Male', 'jb@sch.ac.uk', '18');

-- --------------------------------------------------------

--
-- Table structure for table `add_users`
--

CREATE TABLE IF NOT EXISTS `add_users` (
  `userid` varchar(50) NOT NULL,
  `salutation` varchar(7) NOT NULL,
  `user_first_name` varchar(100) NOT NULL,
  `user_last_name` varchar(100) NOT NULL,
  `user_job_title` varchar(200) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_telephone` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `add_users`
--

INSERT INTO `add_users` (`userid`, `salutation`, `user_first_name`, `user_last_name`, `user_job_title`, `user_email`, `user_telephone`) VALUES
('schoolmatin1234', 'Mr', 'Mart2', 'Tomlinson', 'Second user', '2nd@thetomlinsons.com', '0123456789'),
('schoolmatin1234', 'Mr', 'Mart3', 'User', 'Teacher', 'Mart3@thetomlinsons.com', '0123456789');

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE IF NOT EXISTS `contactus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile_number` varchar(20) NOT NULL,
  `message` varchar(400) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `contactus`
--

INSERT INTO `contactus` (`id`, `name`, `email`, `mobile_number`, `message`) VALUES
(1, 'Helen Cunningham', 'helen.cunningham@solihull.ac.uk', '07904 956 269', 'Dear Work Taster Collegaues, Would it be possible for you to create a Registration function for ''Advisors'' . I am a careers advisor at Solihull College and would like to demonstrate the website to students. so would not want to Register as an organisation/ student or Employer. Or I will follow advice of you prefer me to set- up in one of existing categories. Many thanks for your support, Kind rega');

-- --------------------------------------------------------

--
-- Table structure for table `create_vacancy`
--

CREATE TABLE IF NOT EXISTS `create_vacancy` (
  `userid` varchar(50) NOT NULL,
  `vacancy_title` varchar(1000) NOT NULL,
  `vacancy_location` varchar(50) NOT NULL,
  `vacancy_description` varchar(1000) NOT NULL,
  `number_places` varchar(20) NOT NULL,
  `duration` varchar(30) NOT NULL,
  `from_date1` varchar(20) NOT NULL,
  `from_date2` varchar(20) NOT NULL,
  `from_date3` varchar(20) NOT NULL,
  `to_date1` varchar(20) NOT NULL,
  `to_date2` varchar(20) NOT NULL,
  `to_date3` varchar(20) NOT NULL,
  `restriction_gender` varchar(200) NOT NULL,
  `schooling_level` varchar(50) NOT NULL,
  `selected_school_name` varchar(500) NOT NULL,
  `automatic_date` datetime NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `create_vacancy`
--

INSERT INTO `create_vacancy` (`userid`, `vacancy_title`, `vacancy_location`, `vacancy_description`, `number_places`, `duration`, `from_date1`, `from_date2`, `from_date3`, `to_date1`, `to_date2`, `to_date3`, `restriction_gender`, `schooling_level`, `selected_school_name`, `automatic_date`, `id`) VALUES
('employersam', 'test', 'test', 'test', '12', '2 Weeks', '2016-05-11', '', '', '2016-05-19', '', '', '', 'Any', 'd', '2016-03-21 06:29:11', 1),
('employersam', 'Worktaster 16-18 Placement', 'Worktaster Solihull', 'Marketing and general duties', '2', '2 Weeks', '01/05/2016', '', '', '31/07/2016', '', '', '', 'A-Level students only', '', '2016-03-21 06:28:32', 2);

-- --------------------------------------------------------

--
-- Table structure for table `employer_location`
--

CREATE TABLE IF NOT EXISTS `employer_location` (
  `userid` varchar(50) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `type_of_location` varchar(50) NOT NULL,
  `location_name` varchar(100) NOT NULL,
  `contact_title` varchar(10) NOT NULL,
  `contact_first_name` varchar(100) NOT NULL,
  `contact_last_name` varchar(100) NOT NULL,
  `conatct_email` varchar(50) NOT NULL,
  `contact_telephone` varchar(20) NOT NULL,
  `location_address` varchar(400) NOT NULL,
  `location_city` varchar(100) NOT NULL,
  `location_postal_code` varchar(20) NOT NULL,
  `create_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employer_location`
--

INSERT INTO `employer_location` (`userid`, `company_name`, `type_of_location`, `location_name`, `contact_title`, `contact_first_name`, `contact_last_name`, `conatct_email`, `contact_telephone`, `location_address`, `location_city`, `location_postal_code`, `create_time`) VALUES
('employersam', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00'),
('BirminghamBeef', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00'),
('employersam', 'Worktaster Solihull', 'Branch', 'Solihull', 'Mrs', 'Sally', 'Worktaster', 'sally@worktaster.com', '123456789', 'Dorridge', 'Solihull', 'B94 6AE', '2016-03-14 00:54:08'),
('rair', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00'),
('Worktaster', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00'),
('XEDMAN', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00'),
('vibemart', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00'),
('sandraandara', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00'),
('TestBiz', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00'),
('testco2', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `employer_registration`
--

CREATE TABLE IF NOT EXISTS `employer_registration` (
  `userid` varchar(50) NOT NULL,
  `company_terms` varchar(10) NOT NULL,
  `company_first_name` varchar(200) NOT NULL,
  `company_last_name` varchar(200) NOT NULL,
  `company_email` varchar(100) NOT NULL,
  `company_name` varchar(500) NOT NULL,
  `company_address` varchar(5000) NOT NULL,
  `company_region` varchar(200) NOT NULL,
  `company_city` varchar(100) NOT NULL,
  `company_postal_code` varchar(20) NOT NULL,
  `company_telephone` varchar(20) NOT NULL,
  `company_title` varchar(250) NOT NULL,
  `company_website` varchar(100) NOT NULL,
  `logo` varchar(200) NOT NULL,
  `join_date` datetime NOT NULL,
  `company_description` varchar(2000) NOT NULL,
  `why_do_work_experience` varchar(2000) NOT NULL,
  UNIQUE KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employer_registration`
--

INSERT INTO `employer_registration` (`userid`, `company_terms`, `company_first_name`, `company_last_name`, `company_email`, `company_name`, `company_address`, `company_region`, `company_city`, `company_postal_code`, `company_telephone`, `company_title`, `company_website`, `logo`, `join_date`, `company_description`, `why_do_work_experience`) VALUES
('BirminghamBeef', 'checked', 'Mr B', 'Butcher', 'beef@thetomlinsons.com', 'BirminghamBeef', '1BeefRoad', 'WMids', 'Birmingham', 'B276PA', ' 0123456789', 'Owner', '', '', '2016-03-11 04:34:33', '', ''),
('employersam', 'checked', 'Sally', 'Worktaster', 'sally@worktaster.com', 'Worktaster Ltd', '     Solihull ', 'W Midlands', 'Solihull', 'B94 6AE', ' 0123 123 4567', 'Operations Director', 'www.worktaster.com', 'worktaster-logo-small.png', '2016-03-09 05:08:32', 'The new way place for work experience that''s easier and fairer', 'Itâ€™s WAY easier to get a job with work experience.\r\nWorktaster will help you.\r\n\r\n    Learn why you need work experience\r\n    Work out what youâ€™re good at\r\n    Find a career youâ€™ll love,\r\n    Browse work experience placements\r\n    Build a CV and profile that will show you at your best\r\n    Use the Worktaster knowledge base to get ahead\r\n    Worktaster will organise you, guide you, give you reminders  and make you look good\r\n\r\n'),
('sandraandara', 'checked', 'Mrs Sandra', 'Mutter', 'sandra@andaratravel.co.uk', 'Andara Travel Ltd', 'Box Trees Farm, Stratford Road', 'West Midlands', 'Hockley Heath, Solihull', 'B94 6EA', ' 01564784550', 'Director', '', '', '2016-03-31 09:39:13', '', ''),
('TestBiz', 'checked', 'Mr Test', 'Bizman', 'testBiz@thetomlinsons.com', 'TestBiz', '12ButcherStreet', 'W Mids', 'Birmingham', 'B10BB', ' 0123 123 4567', 'Manager', '', '', '2016-04-05 00:48:11', '', ''),
('testco2', 'checked', 'Mr B', 'Bizman', 'Testco2@thetomlinsons.com', 'TestCo2', '1 BeefRoad', 'W Mids', 'Birmingham', 'B938SY', ' 0123 123 4567', 'Manager', '', '', '2016-04-07 08:27:17', '', ''),
('vibemart', 'checked', 'Mr M', 'Tomlinson', 'martin.tomlinson@vibemarketing.co.uk', 'Vibe Innovation', 'Dorridge', 'W Mids', 'Solihull', 'B10BB', ' 123456789', 'Manager', '', '', '2016-03-23 02:47:08', '', ''),
('Worktaster', 'checked', 'Mrs Sally', 'Tomlinson', 'sally@worktaster.com', 'Worktaster Ltd', 'Stowe House\r\n1688 High Street\r\nKnowle\r\nSolhiull\r\nB93 0LY', 'W Mids', 'Solihull', 'B930LY', ' 07968442972', 'HR', 'www.worktaster.com', 'worktaster-logo.png', '2016-03-21 06:47:56', 'An online service which makes it easier and fairer for young people to get work experience', 'If you are interested in digital media, including social media, web sites and video.'),
('XEDMAN', 'checked', 'Mr test', 'testh', 'rair24@gmail.com', 'XED Management Solutions', 'C 318', 'Uttar Pradesh', 'Ghaziabad', '201002', ' +919818000264', 'Mr', '', '', '2016-03-23 02:19:09', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `enquiry`
--

CREATE TABLE IF NOT EXISTS `enquiry` (
  `name` varchar(300) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `school` varchar(100) NOT NULL,
  `message` varchar(3000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `enquiry`
--

INSERT INTO `enquiry` (`name`, `telephone`, `email`, `school`, `message`) VALUES
('', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `interview_invitation`
--

CREATE TABLE IF NOT EXISTS `interview_invitation` (
  `student_invite` varchar(50) NOT NULL,
  `employer_sent` varchar(50) NOT NULL,
  `proposed_interview_date` varchar(10) NOT NULL,
  `contact_form_confirmation` varchar(100) NOT NULL,
  `email_for_confirmation` varchar(50) NOT NULL,
  `telephone_for_confirmation` varchar(20) NOT NULL,
  `message` varchar(400) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `job_applied`
--

CREATE TABLE IF NOT EXISTS `job_applied` (
  `student_userid` varchar(100) NOT NULL,
  `cover_letter` varchar(800) NOT NULL,
  `send_media` varchar(10) NOT NULL,
  `company_userid` varchar(100) NOT NULL,
  `vacancy_time` datetime NOT NULL,
  `apply_time` varchar(100) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `job_applied`
--

INSERT INTO `job_applied` (`student_userid`, `cover_letter`, `send_media`, `company_userid`, `vacancy_time`, `apply_time`, `status`) VALUES
('studentmike1234', 'Please consider me for this role', 'yes', 'employersam', '2016-03-21 06:28:32', '2016-03-23 04:24:54', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `userid` varchar(50) NOT NULL,
  `password` varchar(200) NOT NULL,
  `email` varchar(50) NOT NULL,
  `category` varchar(20) NOT NULL,
  `email_confirmation` text NOT NULL,
  `last_login` datetime NOT NULL,
  `account_status` varchar(6) NOT NULL,
  UNIQUE KEY `userid` (`userid`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`userid`, `password`, `email`, `category`, `email_confirmation`, `last_login`, `account_status`) VALUES
('Admin', 'c93ccd78b2076528346216b3b2f701e6', 'info@employvirtually.com', 'Admin', 'true', '2016-04-01 04:37:40', ''),
('employersam', '25d55ad283aa400af464c76d713c07ad', 'sam.worktestor@gmail.com', 'Employer', 'true', '2016-04-11 22:52:09', 'true'),
('hcunningham', '89b60a46f1c4c566987dd17c87371db8', 'helen.cunningham@solihull.ac.uk', 'Student', 'false', '0000-00-00 00:00:00', 'true'),
('jcallum', '5f4dcc3b5aa765d61d8327deb882cf99', 'jack@cmavideo.co.uk', 'Student', 'true', '2016-03-23 01:46:33', 'true'),
('martingoogle', '65d1a891a5ca3c6eabe0c08f4893d2a8', 'martinrtomlinson@googlemail.com', 'Student', 'true', '2016-03-23 03:52:04', 'true'),
('Martman', '65d1a891a5ca3c6eabe0c08f4893d2a8', 'martint@thetomlinsons.com', 'Student', 'false', '0000-00-00 00:00:00', 'true'),
('Sallyworktaster', 'b57194a008d7df431d593eb141de87b3', 'Sally@thetomlinsons.com', 'Student', 'false', '0000-00-00 00:00:00', ''),
('sandraandara', '649691495c12409846aacf3db5821426', 'sandra@andaratravel.co.uk', 'Employer', 'false', '2016-04-01 05:05:03', 'true'),
('schoolmatin1234', '25d55ad283aa400af464c76d713c07ad', 'martin.worktaster@gmail.com', 'School', 'true', '2016-04-11 23:24:17', 'true'),
('shaunhindlesolihull', '5abe2662a134eb448720557da4d45d17', 'shaun.hindle@solihull.ac.uk', 'School', 'true', '2016-03-23 05:23:01', 'true'),
('solcoll1', 'cc0a5857e2d5d385b9440f7a5f5688b9', 'martin@worktaster.com', 'School', 'true', '2016-03-15 09:47:45', ''),
('solcoll2', 'cc0a5857e2d5d385b9440f7a5f5688b9', 'martin@thetomlinsons.com', 'School', 'true', '2016-03-21 07:50:20', 'true'),
('studentmart', '65d1a891a5ca3c6eabe0c08f4893d2a8', 'studentmart@thetomlinsons.com', 'Student', 'false', '0000-00-00 00:00:00', ''),
('studentmike1234', '25d55ad283aa400af464c76d713c07ad', 'mike.worktestor@gmail.com', 'Student', 'true', '2016-04-02 01:09:40', 'true'),
('TestBiz', '65d1a891a5ca3c6eabe0c08f4893d2a8', 'testBiz@thetomlinsons.com', 'Employer', 'false', '0000-00-00 00:00:00', ''),
('Testco', '65d1a891a5ca3c6eabe0c08f4893d2a8', 'testco@thetomlinsons.com', 'Employer', 'true', '2016-04-01 04:16:08', 'true'),
('testco2', '65d1a891a5ca3c6eabe0c08f4893d2a8', 'Testco2@thetomlinsons.com', 'Employer', 'false', '0000-00-00 00:00:00', ''),
('teststudent', '65d1a891a5ca3c6eabe0c08f4893d2a8', 'teststudent@thetomlinsons.com', 'Student', 'false', '0000-00-00 00:00:00', ''),
('teststudent2', '65d1a891a5ca3c6eabe0c08f4893d2a8', 'teststudent2@thetomlinsons.com', 'Student', 'false', '0000-00-00 00:00:00', ''),
('teststudent3', '65d1a891a5ca3c6eabe0c08f4893d2a8', 'teststudent3@thetomlinsons.com', 'Student', 'false', '0000-00-00 00:00:00', ''),
('teststudent4', '65d1a891a5ca3c6eabe0c08f4893d2a8', 'teststudent4@thetomlinsons.com', 'Student', 'false', '0000-00-00 00:00:00', ''),
('vibemart', '65d1a891a5ca3c6eabe0c08f4893d2a8', 'martin.tomlinson@vibemarketing.co.uk', 'Employer', 'false', '0000-00-00 00:00:00', 'true'),
('wmcg', '9c3c648ff23e611f0cc8e7a3d78c119c', 'wmcg68@gmail.com', 'Student', 'true', '0000-00-00 00:00:00', ''),
('Worktaster', 'b57194a008d7df431d593eb141de87b3', 'sally@worktaster.com', 'Employer', 'true', '2016-03-23 10:19:58', 'true'),
('XEDMAN', '25f9e794323b453885f5181f1b624d0b', 'rair24@gmail.com', 'Employer', 'false', '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `reject_applications`
--

CREATE TABLE IF NOT EXISTS `reject_applications` (
  `student_id` varchar(50) NOT NULL,
  `employer_id` varchar(50) NOT NULL,
  `rejection_message` varchar(500) NOT NULL,
  `rejection_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `school_registration`
--

CREATE TABLE IF NOT EXISTS `school_registration` (
  `userid` varchar(50) NOT NULL,
  `school_first_name` varchar(200) NOT NULL,
  `school_last_name` varchar(200) NOT NULL,
  `school_email` varchar(50) NOT NULL,
  `school_name` varchar(200) NOT NULL,
  `school_address` varchar(500) NOT NULL,
  `school_region` varchar(200) NOT NULL,
  `school_city` varchar(100) NOT NULL,
  `school_postal_code` varchar(20) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `school_telephone` varchar(20) NOT NULL,
  `school_title` varchar(250) NOT NULL,
  `school_terms` varchar(10) NOT NULL,
  `school_name_title` varchar(10) NOT NULL,
  `school_website` varchar(100) NOT NULL,
  `school_logo` varchar(100) NOT NULL,
  UNIQUE KEY `school_name` (`school_name`),
  UNIQUE KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `school_registration`
--

INSERT INTO `school_registration` (`userid`, `school_first_name`, `school_last_name`, `school_email`, `school_name`, `school_address`, `school_region`, `school_city`, `school_postal_code`, `contact`, `school_telephone`, `school_title`, `school_terms`, `school_name_title`, `school_website`, `school_logo`) VALUES
('bashstreet', 'Bea', 'Baker', 'bash@thetomlinsons.com', 'Bash Street School', '1BashStreet', 'WMids', 'Birmingham', 'B11AA', 'Bea Baker', '1564772158', 'Teacher', 'unchecked', 'Mrs', 'www.worktaster.com', 'small heath logo.jpg'),
('schoolmartin', 'Martin', 'M', 'martin.Worktaster@rediff.com', 'School', 'sc', 'Northern Ireland', 'Armagh', '223', '', '20 7123 4567', 'School Title', 'unchecked', 'Mrs', '', ''),
('shaunhindlesolihull', 'Shaun', 'Hindle', 'shaun.hindle@solihull.ac.uk', 'Solihull College', 'Blossomfield Road', 'West Midlands', 'Solihull', 'B91 1SB', '', '01216787308', 'Senior Director, Employment and Skills', 'unchecked', 'Mr', '', ''),
('schoolmatin1234', 'Martin', 'Worktaster', 'martin.worktaster@gmail.com', 'Test School', 'School Road', 'W Midlands', 'Solihull', 'B91 1AA', 'Martin Worktaster', '048022345', 'Title', 'unchecked', 'Careers Co', 'www.martonschool.org', 'learning logo.png');

-- --------------------------------------------------------

--
-- Table structure for table `std_references`
--

CREATE TABLE IF NOT EXISTS `std_references` (
  `username` varchar(50) NOT NULL,
  `ref_from` varchar(300) NOT NULL,
  `documents` varchar(300) NOT NULL,
  `add_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student_achievements`
--

CREATE TABLE IF NOT EXISTS `student_achievements` (
  `userid` varchar(50) NOT NULL,
  `achievement1` varchar(300) NOT NULL,
  `achievement2` varchar(300) NOT NULL,
  `achievement3` varchar(300) NOT NULL,
  `achievement4` varchar(300) NOT NULL,
  `interest1` varchar(300) NOT NULL,
  `interest2` varchar(300) NOT NULL,
  `interest3` varchar(300) NOT NULL,
  `interest4` varchar(300) NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_achievements`
--

INSERT INTO `student_achievements` (`userid`, `achievement1`, `achievement2`, `achievement3`, `achievement4`, `interest1`, `interest2`, `interest3`, `interest4`) VALUES
('Akhoney313', '', '', '', '', '', '', '', ''),
('bash2', '', '', '', '', '', '', '', ''),
('hcunningham', '', '', '', '', '', '', '', ''),
('jcallum', '', '', '', '', '', '', '', ''),
('martingoogle', '', '', '', '', '', '', '', ''),
('Martman', '', '', '', '', '', '', '', ''),
('pramo', '', '', '', '', '', '', '', ''),
('rair', '', '', '', '', '', '', '', ''),
('Sallyworktaster', '', '', '', '', '', '', '', ''),
('studentmart', '', '', '', '', '', '', '', ''),
('studentmike1234', 'Swimming 5 Miles', 'DofE Silver Award', 'Saturday Job Halfords', '', 'Swimming', 'Football', 'Theatre', ''),
('testeragains', '', '', '', '', '', '', '', ''),
('Teststudent', '', '', '', '', '', '', '', ''),
('teststudent2', '', '', '', '', '', '', '', ''),
('teststudent3', '', '', '', '', '', '', '', ''),
('teststudent4', '', '', '', '', '', '', '', ''),
('wmcg', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `student_cv`
--

CREATE TABLE IF NOT EXISTS `student_cv` (
  `userid` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `phone_code` varchar(10) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `website` varchar(100) NOT NULL,
  `cv` varchar(2000) NOT NULL,
  `cv_file` varchar(100) NOT NULL,
  `video` varchar(200) NOT NULL,
  `video1` varchar(200) NOT NULL,
  `school_name` varchar(100) NOT NULL,
  `school_address` varchar(400) NOT NULL,
  `school_city` varchar(100) NOT NULL,
  `school_region` varchar(50) NOT NULL,
  `school_postalcode` varchar(20) NOT NULL,
  `gcsc_school_start_month` varchar(20) NOT NULL,
  `gcsc_school_start_year` varchar(10) NOT NULL,
  `currently_studying` varchar(10) NOT NULL,
  `gcse_summary` varchar(300) NOT NULL,
  `subject1` varchar(50) NOT NULL,
  `subject2` varchar(50) NOT NULL,
  `subject3` varchar(50) NOT NULL,
  `subject4` varchar(50) NOT NULL,
  `subject5` varchar(50) NOT NULL,
  `subject6` varchar(50) NOT NULL,
  `subject7` varchar(50) NOT NULL,
  `subject8` varchar(50) NOT NULL,
  `subject9` varchar(50) NOT NULL,
  `subject10` varchar(50) NOT NULL,
  `subject11` varchar(50) NOT NULL,
  `expected_grade1` varchar(10) NOT NULL,
  `expected_grade2` varchar(10) NOT NULL,
  `expected_grade3` varchar(10) NOT NULL,
  `expected_grade4` varchar(10) NOT NULL,
  `expected_grade5` varchar(10) NOT NULL,
  `expected_grade6` varchar(10) NOT NULL,
  `expected_grade7` varchar(10) NOT NULL,
  `expected_grade8` varchar(10) NOT NULL,
  `expected_grade9` varchar(10) NOT NULL,
  `expected_grade10` varchar(10) NOT NULL,
  `expected_grade11` varchar(10) NOT NULL,
  `alevels_summary` varchar(300) NOT NULL,
  `alevel_subject1` varchar(50) NOT NULL,
  `alevel_subject2` varchar(50) NOT NULL,
  `alevel_subject3` varchar(50) NOT NULL,
  `alevel_subject4` varchar(50) NOT NULL,
  `alevel_subject5` varchar(50) NOT NULL,
  `alevel_expected_grade1` varchar(10) NOT NULL,
  `alevel_expected_grade2` varchar(10) NOT NULL,
  `alevel_expected_grade3` varchar(10) NOT NULL,
  `alevel_expected_grade4` varchar(10) NOT NULL,
  `alevel_expected_grade5` varchar(10) NOT NULL,
  `select_school_same` varchar(10) NOT NULL,
  `other_school_name` varchar(200) NOT NULL,
  `other_school_address` varchar(400) NOT NULL,
  `other_school_city` varchar(100) NOT NULL,
  `other_school_region` varchar(50) NOT NULL,
  `other_school_postalcode` varchar(20) NOT NULL,
  `other_school_start_month` varchar(20) NOT NULL,
  `other_school_start_year` varchar(20) NOT NULL,
  `other_school_end_month` varchar(20) NOT NULL,
  `other_school_end_year` varchar(20) NOT NULL,
  UNIQUE KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_cv`
--

INSERT INTO `student_cv` (`userid`, `first_name`, `last_name`, `phone_code`, `phone_number`, `email`, `website`, `cv`, `cv_file`, `video`, `video1`, `school_name`, `school_address`, `school_city`, `school_region`, `school_postalcode`, `gcsc_school_start_month`, `gcsc_school_start_year`, `currently_studying`, `gcse_summary`, `subject1`, `subject2`, `subject3`, `subject4`, `subject5`, `subject6`, `subject7`, `subject8`, `subject9`, `subject10`, `subject11`, `expected_grade1`, `expected_grade2`, `expected_grade3`, `expected_grade4`, `expected_grade5`, `expected_grade6`, `expected_grade7`, `expected_grade8`, `expected_grade9`, `expected_grade10`, `expected_grade11`, `alevels_summary`, `alevel_subject1`, `alevel_subject2`, `alevel_subject3`, `alevel_subject4`, `alevel_subject5`, `alevel_expected_grade1`, `alevel_expected_grade2`, `alevel_expected_grade3`, `alevel_expected_grade4`, `alevel_expected_grade5`, `select_school_same`, `other_school_name`, `other_school_address`, `other_school_city`, `other_school_region`, `other_school_postalcode`, `other_school_start_month`, `other_school_start_year`, `other_school_end_month`, `other_school_end_year`) VALUES
('Akhoney313', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('bash2', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('hcunningham', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('jcallum', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('martingoogle', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('Martman', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('pramo', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('rair', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'January', '2009', '2', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2', '', '', '', '', '', 'January', '2009', 'February', '2007'),
('Sallyworktaster', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('studentmart', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('studentmike1234', 'Mike ', 'Arbuthnot', '+44', '12345678', 'mike.worktaster@gmail.com', 'mikearbuthnot.org', 'A Year 12 Student at Solihull College, studying for A-levels.\r\n\r\nAt Uni I want to study Business, if possible at Nottingham trent or Loughborough.\r\n\r\nI am a sociable person with lots of friends but my main interest is swimming.  I swim for Solihull Barracudas swimming team, and I have a part-time job teaching swimming to 6-10 year-olds with Heather Bradbury.', 'MIKE ARBUTHNOT CV.docx', 'Naomi_Neuroscience.avi', '', 'Tudor Grange', 'Dingle lane', 'Solihull', 'W Mids', 'B91 3PD', 'January', '2009', '2', '', 'Maths', 'English', 'Geog', 'History', 'French', '', '', '', '', '', '', 'A*', 'B', 'B', 'C', 'A', '', '', '', '', '', '', 'I want to do business at Uni', 'History', 'Maths', 'Biology', 'History', 'Maths', 'a', 'a', 'a', 'a', 'a', '2', 'Tudor Grange', 'Dingle Lane', 'Solihull', 'W Mids', 'B91 3PD', 'September', '2009', 'March', '2009'),
('testeragains', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('Teststudent', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('teststudent2', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('teststudent3', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('teststudent4', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('wmcg', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `student_preferences`
--

CREATE TABLE IF NOT EXISTS `student_preferences` (
  `userid` varchar(50) NOT NULL,
  `all_jobs` varchar(8) NOT NULL,
  `banking_finance` varchar(8) NOT NULL,
  `retail` varchar(8) NOT NULL,
  `construction` varchar(8) NOT NULL,
  `legal` varchar(8) NOT NULL,
  `medical` varchar(8) NOT NULL,
  `other` varchar(8) NOT NULL,
  `newsletter` varchar(8) NOT NULL,
  `vacancies_distance` varchar(5) NOT NULL,
  UNIQUE KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_preferences`
--

INSERT INTO `student_preferences` (`userid`, `all_jobs`, `banking_finance`, `retail`, `construction`, `legal`, `medical`, `other`, `newsletter`, `vacancies_distance`) VALUES
('Akhoney313', 'yes', 'checked', 'checked', 'checked', 'checked', 'checked', 'checked', 'checked', '5'),
('bash2', '', '', '', '', '', '', '', '', ''),
('hcunningham', '', '', '', '', '', '', '', '', ''),
('jcallum', '', '', '', '', '', '', '', '', ''),
('martingoogle', '', '', '', '', '', '', '', '', ''),
('Martman', '', '', '', '', '', '', '', '', ''),
('pramo', '', '', '', '', '', '', '', '', ''),
('rair', '', '', '', '', '', '', '', '', ''),
('Sallyworktaster', '', '', '', '', '', '', '', '', ''),
('studentmart', '', '', '', '', '', '', '', '', ''),
('studentmike1234', '', '', '', '', '', '', '', '', ''),
('testeragains', '', '', '', '', '', '', '', '', ''),
('Teststudent', '', '', '', '', '', '', '', '', ''),
('teststudent2', '', '', '', '', '', '', '', '', ''),
('teststudent3', '', '', '', '', '', '', '', '', ''),
('teststudent4', '', '', '', '', '', '', '', '', ''),
('wmcg', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `student_profile`
--

CREATE TABLE IF NOT EXISTS `student_profile` (
  `userid` varchar(50) NOT NULL,
  `home_address` varchar(1000) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `school_year` varchar(3) NOT NULL,
  `dob_day` varchar(2) NOT NULL,
  `dob_month` varchar(20) NOT NULL,
  `dob_year` varchar(10) NOT NULL,
  `t_c` tinyint(1) NOT NULL,
  `title` varchar(20) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `city` varchar(50) NOT NULL,
  `region` varchar(50) NOT NULL,
  `postal_code` varchar(20) NOT NULL,
  `website` varchar(250) NOT NULL,
  `profile_picture` varchar(100) NOT NULL,
  `video` varchar(100) NOT NULL,
  `cv` varchar(100) NOT NULL,
  `joining_date` datetime NOT NULL,
  UNIQUE KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_profile`
--

INSERT INTO `student_profile` (`userid`, `home_address`, `phone`, `email`, `school_year`, `dob_day`, `dob_month`, `dob_year`, `t_c`, `title`, `first_name`, `last_name`, `gender`, `city`, `region`, `postal_code`, `website`, `profile_picture`, `video`, `cv`, `joining_date`) VALUES
('Akhoney313', '', '', 'abid313.afridi@gmail.com', '12', '', '', '', 1, 'Mr', 'Abid', 'Ali', 'Male', 'Birmingham', '', '', '', '', '', '', '2016-03-10 03:45:55'),
('bash2', '', '', 'bash2@thetomlinsons.com', '13', '', '', '', 1, '', 'Bea', 'Baker2', 'Female', '', '', '', '', '', '', '', '2016-03-11 04:07:38'),
('hcunningham', '', '', 'helen.cunningham@solihull.ac.uk', '18', '', '', '', 1, '', 'Helen', 'Cunningham', 'Female', '', '', '', '', '', '', '', '2016-03-22 08:06:26'),
('jcallum', '', '', 'jack@cmavideo.co.uk', '10', '', '', '', 1, '', 'Jack', 'Callum', 'Male', '', '', '', '', '', '', '', '2016-03-22 04:02:14'),
('martingoogle', '', '', 'martinrtomlinson@googlemail.com', '13', '', '', '', 1, '', 'Martin', 'Worktaster', 'Male', '', '', '', '', '', '', '', '2016-03-23 03:47:53'),
('Martman', '', '07974428441', 'martint@thetomlinsons.com', '12', '', '', '', 1, 'Mr', 'Martin', 'Tomlinson', 'Male', 'Dorridge', '', '', 'www.worktaster.com', '', '', '', '2016-03-15 03:19:11'),
('pramo', '', '', 'sweetball.pramod@gmal.com', '8', '', '', '', 1, '', 'test', 'testq', 'Male', '', '', '', '', '', '', '', '2016-03-17 05:28:26'),
('rair', '', '', 'rair24@gmail.com', '9', '', '', '', 1, '', 'Rob', 'Robs', 'Male', '', '', '', '', '', '', '', '2016-03-17 05:25:41'),
('Sallyworktaster', '', '', 'Sally@thetomlinsons.com', '7', '', '', '', 1, '', 'Sally', 'Tomlinson', 'Female', '', '', '', '', '', '', '', '2016-03-21 09:28:43'),
('studentmart', '', '', 'studentmart@thetomlinsons.com', '13', '', '', '', 1, '', 'Student', 'Mart', 'Male', '', '', '', '', '', '', '', '2016-03-23 02:38:17'),
('studentmike1234', '', '123456789', 'mike.worktaster@gmail.com', '11', '', '', '', 1, 'Mr', 'Mike', 'Arbuthnot', 'Male', 'Solihull', '', '', 'mikearbuthnot.org', 'Guy Tomlinson pic.jpeg', '', '', '2016-03-09 05:00:50'),
('testeragains', '', '', 'msdusad@gmail.com', '7', '', '', '', 1, '', 'tester', 'tr', 'Male', '', '', '', '', '', '', '', '2016-03-17 05:48:15'),
('Teststudent', '', '123456789', 'test@thetomlinsons.com', '12', '', '', '', 1, 'Mr', 'Test', 'Student', 'Female', 'Solihull', '', '', 'www.worktaster.com', '', '', '', '2016-03-10 09:52:16'),
('teststudent2', '', '', 'teststudent2@thetomlinsons.com', '12', '', '', '', 1, '', 'test', 'student2', 'Male', '', '', '', '', '', '', '', '2016-03-24 07:45:44'),
('teststudent3', '', '', 'teststudent3@thetomlinsons.com', '11', '', '', '', 1, '', 'Test', 'student3', 'Male', '', '', '', '', '', '', '', '2016-03-24 08:01:42'),
('teststudent4', '', '', 'teststudent4@thetomlinsons.com', '10', '', '', '', 1, '', 'student4', 'Test', 'Female', '', '', '', '', '', '', '', '2016-03-25 05:52:14'),
('wmcg', '', '', 'wmcg68@gmail.com', '12', '', '', '', 1, '', 'wayne', 'McGarvey', 'Male', '', '', '', '', '', '', '', '2016-04-05 12:47:54');

-- --------------------------------------------------------

--
-- Table structure for table `student_school`
--

CREATE TABLE IF NOT EXISTS `student_school` (
  `userid` varchar(50) NOT NULL,
  `school_name` varchar(300) NOT NULL,
  `school_address` varchar(2000) NOT NULL,
  `school_city` varchar(150) NOT NULL,
  `school_region` varchar(50) NOT NULL,
  `school_postalcode` varchar(20) NOT NULL,
  `school_contact_sr` varchar(20) NOT NULL,
  `school_contact_fname` varchar(100) NOT NULL,
  `school_contact_lname` varchar(100) NOT NULL,
  `school_phone` varchar(20) NOT NULL,
  `school_email` varchar(100) NOT NULL,
  `school_website` varchar(100) NOT NULL,
  `reference_by_school` varchar(400) NOT NULL,
  `attendance_record` varchar(10) NOT NULL,
  `ref_from` varchar(20) NOT NULL,
  `ref_to` varchar(20) NOT NULL,
  `ref_comment` varchar(300) NOT NULL,
  `ref_date` datetime NOT NULL,
  `reference_file` varchar(256) NOT NULL,
  UNIQUE KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_school`
--

INSERT INTO `student_school` (`userid`, `school_name`, `school_address`, `school_city`, `school_region`, `school_postalcode`, `school_contact_sr`, `school_contact_fname`, `school_contact_lname`, `school_phone`, `school_email`, `school_website`, `reference_by_school`, `attendance_record`, `ref_from`, `ref_to`, `ref_comment`, `ref_date`, `reference_file`) VALUES
('Akhoney313', 'School', 'Solihull College & University Centre\r\nWoodlands Campus, Auckland Dr, Solihull \r\nB36 0NF', 'BIrmingham', '', '', 'Mr', 'Abid', 'Ali', '', 'abid313.afridi@gmail.com', '', 'bashstreet', '', '01/01/2013', '01/05/2014', 'Abid has been an excellent pupil throughout', '2016-03-10 09:46:44', 'Checklist 5.jpg	'),
('bash2', 'Bash Street School', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', ''),
('hcunningham', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', ''),
('jcallum', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', ''),
('martingoogle', '', '', '', '', '', '', '', '', '', '', '', 'schoolmatin1234', '', '01/03/16', '08/03/15', 'lshafoi lahgoiagn alkhfglihlzknlka', '2016-03-29 05:04:09', 'English Christmas essay (1).docx	'),
('Martman', 'Martin School', '76 Glendon Way', 'Solihull', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', ''),
('Sallyworktaster', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', ''),
('studentmart', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', ''),
('studentmike1234', 'Martin School', 'Bash Street\r\n', 'Birmingham', '', '', 'Mr', 'John', 'Tomlinson', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', ''),
('Teststudent', 'Test School', 'Glendon Way', 'Solihull', '', '', 'Mr', 'Fahwad', 'Mahmood', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', ''),
('teststudent2', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', ''),
('teststudent3', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', ''),
('teststudent4', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', ''),
('wmcg', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
