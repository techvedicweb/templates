<?php 
include('../connection.php');
session_start();
//print_r($_REQUEST);exit;
$srch=mysql_real_escape_string($_REQUEST['first']);
$school_id=mysql_real_escape_string($_REQUEST['school_id']);
$sql=mysql_query("SELECT * FROM add_users where userid='$school_id'");
	echo "<table class='table'>
		<thead>
			<th>Name</th>
			<th>Job Title</th>
			<th>Email</th>
			<th>Phone</th>
			<th>Invitation</th>
			<th>Action</th>
		</thead>";
		if($sql && mysql_num_rows($sql)>0){
	
	if($_REQUEST['type']=='searchstudent'){
$all_vacancy=mysql_query("select * FROM add_users where userid='$school_id' and (user_first_name LIKE '%$srch%' || user_last_name LIKE '%$srch%')");
	
	}

	if($_REQUEST['type']=='school_coolage_year_search'){
		if($srch=="all"){
			$all_vacancy=mysql_query("select * FROM add_users where userid='$school_id'");
			}
			else{
$all_vacancy=mysql_query("select * FROM add_users where userid='$school_id' and school_year='$srch'");
			}
	
	}
	if($_REQUEST['type']=='invite_status'){
		if($srch=="all_invitation"){
			$all_vacancy=mysql_query("select * FROM add_users where userid='$school_id'");
			}
			else{
$all_vacancy=mysql_query("select * FROM add_users where userid='$school_id' and invited_status='$srch'");
			}
	
	}
	if($_REQUEST['type']=='ref_status'){
		if($srch=="all"){
			$all_vacancy=mysql_query("select * FROM add_users where userid='$school_id'");
			}
			else{
$all_vacancy=mysql_query("select * FROM add_users where userid='$school_id' and invited_status='$srch'");
			}
	
	}


	
	
		if($_REQUEST['type']=='limitofsch'){
$all_vacancy=mysql_query("select * FROM add_users where userid='$school_id' limit $srch");
	
	}
	
	
	
	
	if($all_vacancy){
	
	if($all_vacancy && mysql_num_rows($all_vacancy)>0){
while($row=mysql_fetch_array($all_vacancy)){
	//print_r($row);exit;
		
			echo '<tr><td>'.$row['salutation'].' '.$row['user_first_name'].' '.$row['user_last_name'].'</td></td>';
			echo '<td>'.$row['user_job_title'].'</td>';
			echo '<td>'.$row['user_email'].'</td>';
			echo '<td>'.$row['user_telephone'].'</td>';
?>
			<td><?php if($row['invited_status']!='0'){echo "Completed ";}
	else{ echo "Pending"; }?></td>
			<!--<td><?php echo $row['add_date'];?></td>-->
			<td><a href="../classes/delete_user.php?subuserid=<?php echo md5($row['id']);?>">Remove</a></td>
			</tr>
	
 <?php }
	}
	else{
	echo "<tr><td>No Result Found</td></tr>";
	}
	
}
else{
echo "Error in Query Pass".mysql_error();
}
echo "</table>";	

}
	else{
echo "No Record Found";

}

?>