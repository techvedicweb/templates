<script>
	function add_student_csv(){
		
		 var r = confirm("File data successfully imported to database!");
    if (r == true) {	
       window.location ="../../schools/manage_students.php";
    } else {
		
		window.location ="../../schools/student_csv_upload.php";
    }
	
	}
</script>
<?php
if(isset($_POST['add_csv_student'])){
	include('../connection.php');
session_start();
$user=$_SESSION['schooluserid'];
      $user_query=mysql_query("select school_email,school_name from school_registration where userid='$user'");
	  $user_sch_email=mysql_fetch_array($user_query);
	  $sch_email=$user_sch_email['school_email'];
	   $sch_name=$user_sch_email['school_name'];
	
	  if($_FILES['csv_file']['name']!=''){ 
		 $logo="csv/".$_FILES['csv_file']['name'];
	move_uploaded_file($_FILES['csv_file']['tmp_name'],$logo);
         $csv_file ="csv/".$_FILES['csv_file']['name'];
	   }

if (($handle = fopen($csv_file, "r")) !== FALSE) {
   fgetcsv($handle);   
   while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        $num = count($data);
        for ($c=0; $c < $num; $c++) {
          $col[$c] = $data[$c];
        }
 $col1 = mysql_real_escape_string($col[0]);
 $col2 = mysql_real_escape_string($col[1]);
 $col3 = mysql_real_escape_string($col[2]);
 $col4 = mysql_real_escape_string($col[3]);
 $col5 = mysql_real_escape_string($col[4]);
 //$col6 = mysql_real_escape_string($col[5]);
 
 //echo $col1.'<br>'.$col2.'<br>'.$col3.'<br>'.$col4.'<br>'.$col5;exit;
 
	   $parts001=explode('@',$col3);
	  $uid=$parts001[0].rand ( 1 , 99 );
	  $pass=rand(10005000,20000500);
	  $mdpass=md5($pass);
	  //print($uid);exit;
	  $stuid=strtoupper($uid);
 $query_check=mysql_query("select * from login where userid='$stuid' or email='$col3'");
	  $numrows_count=mysql_num_rows($query_check);
	  if($numrows_count>0){
		  $login=mysql_query("update login set email='$col3' where email='$col3'");
		  echo '<script>add_student_csv();</script>';
	  }
	  else{
		   $login=mysql_query("insert into login (email,userid,password,category,email_confirmation) values('$col3','$stuid','$mdpass','Student','false')");
      	
			$student_profile=mysql_query("insert into student_profile (first_name,last_name,email,userid,school_year,school_id,gender,t_c,invited_status,joining_date) values('$col1','$col2','$col3','$stuid','$col4','$user','$col5',1,0,now())");
			$lastid=mysql_insert_id();
	 
	  //echo $lastid;exit;
		$student_school=mysql_query("insert into student_school (userid) values('$stuid')");
        $student_preferences=mysql_query("insert into student_preferences (userid) values('$stuid')");
		$student_cv=mysql_query("insert into student_cv (userid) values('$stuid');");
		$student_achivment=mysql_query("insert into student_achievements (userid) values('$stuid')");

		
$subject = 'Worktaster Student Invitation Mail';
$message .= "<p align='center'><a href='http://worktaster.com' target='_blank'><img src='https://www.worktaster.com/wp-content/themes/work_taster/img/logo.png' alt=''></a></p>";
$message .= "<p>Dear  $col1  $col2</p><h3 align='center'>Welcome To Worktaster</h3>
<p>You have been invited onto Worktaster by $sch_name</p>
<p>To activate your username please <br><a href='http://worktaster.com/user/email_confrim.php?userid=".$stuid."' target='_blank'>Click Here</a> using the following:"."\r\n\n";

$message .='<p>Your Username is: '.$stuid.'</p><p>Your Password is: '.$pass.'</p>

<p>By activating your account you agree to be bound by the Terms and Conditions for Employers on our website <a href="https://www.worktaster.com/terms-conditions/" target="_blank">Term & Conditions</a></p>
Worktaster Works ForStudents. Enjoy your Journey.<br />
Thankyou<br />
Worktaster Team.<p><span style="color:red;">The Team at</span> <span style="color:green;font-style: italic;">Worktaster</span></p>';
      print $message;exit;
 $header= 'From: '.$sch_email . "\r\n" .
    'Reply-To:' .$sch_email. "\r\n" .
    'X-Mailer: PHP/' . phpversion();
        $header.= "MIME-Version: 1.0\r\n"; 
$header.= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; 
$header.= "X-Priority: 1\r\n";

 mail($col3, $subject, $message, $header);
		   //header("Location:../../schools/manage_students.php");
	//echo '<script>add_student_csv();</script>';
	   }
	   
 }
    fclose($handle);
}
	
	else{
	echo "File not Found";
	}



	
}
?>