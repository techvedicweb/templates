<?php 
include('../connection.php');
session_start();
//print_r($_REQUEST);
$srch=mysql_real_escape_string($_REQUEST['first']);
$school_id=mysql_real_escape_string($_REQUEST['school_id']);
$sql=mysql_query("SELECT * FROM add_student where userid='$school_id'");
	echo "<table class='table'>
		<thead>
			<th>Name</th>
			<th>year</th>
			<th>Activated?</th>
			<th>Profile Complete %</th>
			<th>Application Date</th>
			<th>Reference Y/N</th>
			<th>SEN?</th>
		</thead>";
		if($sql && mysql_num_rows($sql)>0){
	
	if($_REQUEST['type']=='searchstudent'){
$all_vacancy=mysql_query("select * FROM add_student where userid='$school_id' and (first_name LIKE '%$srch%' || last_name LIKE '%$srch%')");
	
	}

	if($_REQUEST['type']=='school_coolage_year_search'){
		if($srch=="all"){
			$all_vacancy=mysql_query("select * FROM add_student where userid='$school_id'");
			}
			else{
$all_vacancy=mysql_query("select * FROM add_student where userid='$school_id' and school_year='$srch'");
			}
	
	}
	if($_REQUEST['type']=='invite_status'){
		if($srch=="all_invitation"){
			$all_vacancy=mysql_query("select * FROM add_student where userid='$school_id'");
			}
			else{
$all_vacancy=mysql_query("select * FROM add_student where userid='$school_id' and invited_status='$srch'");
			}
	
	}
	if($_REQUEST['type']=='ref_status'){
		if($srch=="all"){
			$all_vacancy=mysql_query("select * FROM add_student where userid='$school_id'");
			}
			else{
$all_vacancy=mysql_query("select * FROM add_student where userid='$school_id' and invited_status='$srch'");
			}
	
	}


	
	
		if($_REQUEST['type']=='limitofsch'){
$all_vacancy=mysql_query("select * FROM add_student where userid='$school_id' limit $srch");
	
	}
	
	
	
	
	if($all_vacancy){
	
	if($all_vacancy && mysql_num_rows($all_vacancy)>0){
while($row=mysql_fetch_array($all_vacancy)){
	//print_r($row);exit;?>
		
			<tr><td><!--<a href="student_detail.php?userid=<?php echo $row['userid'];?>">--><?php echo $row['first_name']." ".$row['last_name'];?><!--</a>--></td>
			<td><?php if($row['school_year']!=""){echo $row['school_year'];}else{echo"Not Select";}?></td>
			<td><?php if($row['invited_status']!='0'){echo "Yes";}
	else{echo "No";}?></td>
			<td><?php if($row['first_name']!="" && $row['last_name']!="" && $row['school_year']!==""){ echo"50%"; } else{echo "30%";}?></td>
			
			<td><?php echo $row['add_date'];?></td>
			<td><?php if($row['invited_status']!='0'){echo "Y ";}
	else{echo "N";}?></td>
	<td><input type="checkbox"></td>
			
		</tr>
	
 <?php }
	}
	else{
	echo "<tr><td>No Result Found</td></tr>";
	}
	
}
else{
echo "Error in Query Pass".mysql_error();
}
echo "</table>";	

}
	else{
echo "No Record Found";

}

?>