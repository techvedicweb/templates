<script>
	function add_csv_emp(){
		
		 var r = confirm("File data successfully imported to database!");
    if (r == true) {	
       window.location ="../../schools/manage_exclusive_employers.php";
    } else {
		
		window.location ="../../schools/employer_exclusive_upload.php";
    }
	
	}
	
</script>
<?php
if(isset($_POST['add_csv_emp'])){
	include('../connection.php');
session_start();
$user=$_SESSION['schooluserid'];
//echo $user;exit;
      $user_query=mysql_query("select school_email,school_name from school_registration where userid='$user'");
	  $user_sch_email=mysql_fetch_array($user_query);
	  $sch_email=$user_sch_email['school_email'];
	   $sch_name=$user_sch_email['school_name'];
	   $message="";
		$category="Employer";
	
	  if($_FILES['csv_file']['name']!=''){ 
		 $logo="emp_csv/".$_FILES['csv_file']['name'];
	move_uploaded_file($_FILES['csv_file']['tmp_name'],$logo);
         $csv_file ="emp_csv/".$_FILES['csv_file']['name'];
	   }

if (($handle = fopen($csv_file, "r")) !== FALSE) {
   fgetcsv($handle); 
//$data = fgetcsv($handle, 1000, ",");
//print_r($data);exit;
   while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        $num = count($data);
        for ($c=0; $c < $num; $c++) {
          $col[$c] = $data[$c];
        }
 $col1 = mysql_real_escape_string($col[0]);
 $col2 = mysql_real_escape_string($col[1]);
 $col3 = mysql_real_escape_string($col[2]);
 $col4 = mysql_real_escape_string($col[3]);
// $col5 = mysql_real_escape_string($col[4]);
 //$col6 = mysql_real_escape_string($col[5]);
 
 //echo $col1.'<br>'.$col2.'<br>'.$col3.'<br>'.$col4.'<br>'.$col5;exit;
 
	   $parts001=explode('@',$col3);
	    $cur_date=date("Ymdhisa");
		$uid=$parts001[0].$cur_date;
		$pass=rand(50005000,60000500);
		$mdpass=md5($pass);
	  //print($uid);exit;
	  $company_userid=strtoupper($uid);
     $query_check=mysql_query("select * from login where userid='$company_userid' or email='$col3'");
	  $numrows_count=mysql_num_rows($query_check);
	 //echo $numrows_count;exit;
	  if($numrows_count==0){
		   $logindetail=mysql_query("insert into login (userid,password,email,category,email_confirmation) values ('$company_userid','$mdpass','$col3','$category','false');");
      
        /*$add_employer1=mysql_query("insert into exclusive_employer (school_id,excl_userid,employer_name,contact_firstname,contact_lastname,contact_email,added_date) values('$school_user','$company_userid','$employer_name','$contact_f_name','$contact_l_name','$contact_email',now());");*/
     
		$employer_location=mysql_query("insert into employer_location(userid) values('$company_userid');");
      
        $add_employer=mysql_query("insert into employer_registration(userid,school_id,company_first_name,company_last_name,company_name,company_email,join_date) values('$company_userid','$user','$col1','$col2','$col4','$col3',now());");
		
		 $exc_query=mysql_query("insert into add_exclusive_school(employer_id,school_id,status) values('$company_userid','$user',1);");

		
 $subject = 'Worktaster Exclusive Employer Invitation Mail';
$message .= "<p align='center'><a href='http://worktaster.com' target='_blank'><img src='https://www.worktaster.com/wp-content/themes/work_taster/img/logo.png' alt=''></a></p>";
$message .= "<p>Dear  $col1  $col2</p><h3 align='center'>Welcome To Worktaster</h3>
<p>You have been invited on Worktaster by $col1 at $sch_name</p>
<p>To activate your username please <a href='http://worktaster.com/user/email_confrim.php?userid=".$company_userid."'>Click Here</a> using the following:"."\r\n\n";

$message .='<p>Your Username is: '.$company_userid.'</p><p>Your Password is: '.$pass.'</p>

<p>Welcome to Worktaster. By activating your account you agree to be bound by the Terms and Conditions for Employers on our website <a href="https://www.worktaster.com/terms-conditions/" target="_blank">Term & Conditions</a> We at Worktaster are committed to changing the lives of young people by improving access to employability and skills, providing transparent, fair access to work experience placements for everyone. As an employer on Worktaster you will be able to use our one touch system for all the work experience placements you offer to local young people from $sch_name. For more information on how Worktaster can work for you <a href="https://www.worktaster.com/about-us/" target="_blank">Click Here.</a></p>
Worktaster Works For Employers. Join the journey.<br />
If you have any questions <a href="https://www.worktaster.com/" target="_blank">Contact us.</a><br />
Thankyou<br />
Worktaster Team.<p><span style="color:red;">The Team at</span> <span style="color:green;font-style: italic;">Worktaster</span></p>';
     // print $message;exit;
 $header= 'From: '.$sch_email . "\r\n" .
    'Reply-To:' .$sch_email. "\r\n" .
    'X-Mailer: PHP/' . phpversion();
        $header.= "MIME-Version: 1.0\r\n"; 
$header.= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; 
$header.= "X-Priority: 1\r\n";

 mail($col3, $subject, $message, $header);
 
		   //header("Location:../../schools/manage_students.php");
	echo '<script>add_csv_emp();</script>';
	   }
	   else{
	echo '<script>add_csv_emp();</script>';
	}
	   
 }
    fclose($handle);
}
	
	else{
	echo "File not Found";
	}



	
}
?>