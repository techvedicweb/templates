<script>
var index = 0,
    messg = [
        "Activated", 
        "Deactivated", 
    ];

$(".pushme").on("click", function() {
    $(this).text(function(index, text){
        index = $.inArray(text, messg);
        return messg[++index % messg.length];
    });
	
	$('body').on('click', function(e){
  
 $('.pushme').removeClass('').addClass('p-chnge');
    
  });
});
</script>

<div class="footer">
	<!---<div class="container">
    	<div class="col-md-8">
        	<h2>Pricing? Need help getting started? Call (000) 000-0000.</h2>
        </div>
        <div class="col-md-4 col-sm-8">
        	<div class="topRight pull-right">
                	<h4>Connect</h4>
					<ul class="">
						<li><a href="<?=$fetch_seting['facebook_url']?>" ><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
						<li><a href="<?=$fetch_seting['twiter_url']?>" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						<li><a href="<?=$fetch_seting['linkdin_url']?>" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
						<li><a href="<?=$fetch_seting['google_puluse_url']?>" target="_blank"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
					</ul>
				</div>
        </div>
    </div>-->
</div>
<div class="ftr-bottom">
	<div class="container">
    	<h2>&copy; 2016  Maker Place. All Rights Reserved</h2>
    </div>
</div>

<script>
$(document).ready(function(){
    $("#message_booking").click(function(){
        $("#message_booking").hide();
    });
});
</script>

<style>
.highlight{
	color:#F00;
	background:#F00;
}
</style>
<script>
$(document).ready(function(e) {
       $(".pushme").click(function(){
$(this).toggleClass("highlight");
})
   });
</script>		
</body>
</html>
