<?php include('header_top.php');?>
<?php include('header.php');?>
<div class="auto">
<div class="schedule">
	
	<div class="left">
		<?php include("sidebar.php");?>
    </div>
	<div class="right">
<?php 
if(isset($_POST['submit']))
{
$slot_id=$_POST['slot_id'];
$slot_date=$_POST['slot_date'];	
$slot_time=$_POST['slot_time'];	
$slot_name=$_POST['slot_name'];	
$slot_d=date('m/d/Y',strtotime($slot_date));
$slot_check=mysql_query("select * from mp_slot_details where slot_date='".$slot_date."'");
if(mysql_num_rows($slot_check)>5)
{
	echo "<h6>You Dont have permition to add more than 6 slots</h6>";
}
else{
$query_add="insert into mp_slot_details set slot_id='".$slot_id."', slot_date='".$slot_d."', slot_time='".$slot_time."', slot_detail='".$slot_name."'";
//echo $query_add;exit;
$ins_query=mysql_query($query_add);
echo"<h5>Data Inserted !</h5>";
}
}
?>

<div class="form-center">
<form action="" method="post">
<div class="in-pg">
<p>Select Name</p>
<select name="slot_id">
<option>Select One</option>
<?php 
$get_slot=mysql_query("select * from mp_slots order by id desc");
while($fetch_res=mysql_fetch_array($get_slot))
{
?>
<option value="<?=$fetch_res['id']?>"><?=$fetch_res['slot_name']?></option>
<?php
}
?>
</select>
</div>

<div class="in-pg">
<p>Select Date</p><input type="text" id="popupDatepicker" name="slot_date" required>
</div>

<div class="in-pg">
<p>Add Slot</p><input type="text" name="slot_name" required>
</div>

<!--Slect Time-->
<select name="slot_time" hidden>
<option value="1pm">1pm</option>
<option value="2pm">2pm</option>
<option value="3pm">3pm</option>
<option value="4pm">4pm</option>
<option value="5pm">5pm</option>
<option value="6pm">6pm</option>
</select>

<div class="in-pg">
<p></p>
<input type="submit" name="submit" required>
</div>
</form>
</div>
</div>
</div>
</div>
<?php include('footer.php');?>




