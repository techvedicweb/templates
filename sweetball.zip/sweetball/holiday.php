<?php include('header_top.php');?>
<?php include('header.php');?>
<?php
if(!isset($_SESSION['username']))
{
header("location:index.php");
}
?>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<div class="auto">
<div class="login">
    	<div class="form-design">
        	<h2><span>Add Holiday</span></h2>
            	<div class="form-center">
					<?php 
if(isset($_POST['submit']) && $_POST['submit']=='success')
{
$holidate=$_POST['holidate'];
if(isset($_POST['activation']))
{
$activation=$_POST['activation'];
}
else{
$activation=0;
}
$check_date=mysql_query("select * from mp_holyday where holydate='$holidate'");
if(mysql_num_rows($check_date)>0)
{
	$msg_exist="<div id='message_booking'><i class='fa fa-check' aria-hidden='true'></i>Date Exist!<i class='fa fa-times i-right' aria-hidden='true'></i></div>";
}
else{
$holiday_query=mysql_query("insert into mp_holyday set holydate='$holidate', status='$activation'");
if($holiday_query)
{
$msg_success="<div id='message_booking'><i class='fa fa-check' aria-hidden='true'></i>Holiday added Successfull <i class='fa fa-times i-right' aria-hidden='true'></i></div>";
}
else{
$msg_error="Error!";
}
}
}
if(isset($_REQUEST['hid']) && $_REQUEST['hid']!='' && isset($_POST['update']) )
{
$hid=$_REQUEST['hid'];
$holidate=$_POST['holidate'];
if(isset($_POST['activation']))
{
$activation=$_POST['activation'];
}
else{
$activation=0;
}
$holiday_query=mysql_query("update mp_holyday set holydate='$holidate', status='$activation' where id='$hid'");
if($holiday_query)
{
$msg_success="Holiday Update Successfull";
}
else{
$msg_error="Error!";
}
}
					
					
if(isset($_REQUEST['hid']) && $_REQUEST['hid']!='')
{
$hid=$_REQUEST['hid'];
$edit_query=mysql_query("select * from mp_holyday where id='$hid'");
$res_date=mysql_fetch_array($edit_query);
}
?>
					<?php 
					if(isset($msg_exist)){echo $msg_exist;}
					if(isset($msg_success)){echo $msg_success;}
					if(isset($msg_error)){echo $msg_error;}
					?>
                    <form action="" method="post" name="login_form" class="bb"> 
						<?php if(isset($_REQUEST['hid'])){?>
						<input type="hidden" name='update' value="success">
						<?php }else	{?>
						<input type="hidden" name='submit' value="success">
						<?php }?>
                    	<!--<div class="in-pg"><p>Tools Name:</p>
                        	<select name='tool_name' required>
							<option value="">Select Tool</option>
							<?php 
							$sql_slotname=mysql_query("select * from mp_slots order by id asc");
							while($fetch_slot_name=mysql_fetch_array($sql_slotname))
							{
							?>
                        	<option value="<?=$fetch_slot_name['id']?>"><?=$fetch_slot_name['slot_name']?></option>
							<?php 
							}	
							?>
                            </select>
                        	</div>-->
                    	<div class="in-pg"><p>Holiday Date:</p> <input type="" id="inlineDatepicker" placeholder="Date" name="holidate" id="password" value='<?php if(isset($res_date['holydate'])){ echo $res_date['holydate'];}?>' required/>
                        </div>
                        <div class="in-pg-1">
                        <input type="checkbox" name="activation" value="1" <?php if(isset($res_date['status']) && $res_date['status']=='1'){echo'checked';}?>> Activate
                        </div> 
						<input type="submit" name="button" value="<?php if(isset($_REQUEST['hid'])){echo'Update';}else{echo'Submit';}?>" class="bt-right"/>
						</div>
                    </form>
		
						<?php 
                        $get_holiday=mysql_query("select * from mp_holyday");
                        if(mysql_num_rows($get_holiday)>0)
                        {
                        echo'<div class="view1">
						<h2>Manage holiday</h2>
						<ul>
						<li class="e-h-b">Holiday</li>
						<li class="e-h">Status</li>
						<li class="e-h">Action</li>
						</ul>';
                        while($get_date=mysql_fetch_array($get_holiday))
                        {
                        echo'<ul>';
                        echo '<li>'.$get_date['holydate'].'</li>';
                            
                        if($get_date['status']=='0')
                        {
                        echo'<li><button class="pushme highlight p-chnge" onclick="holiday_status('.$get_date['id'].',1)">Activated</button>';
                        }
                        else{
                        echo'<li><button class="pushme" onclick="holiday_status('.$get_date['id'].',0)">Deactivated</button></li>';
                        }
                            
                        echo'<li><a href="holiday.php?hid='.$get_date['id'].'">Edit</a> / <a href="module/delete.php?del='.md5($get_date['id']).'">Delete</a></li>';
                        echo'</ul>';
                        }
                        echo'</div>';
                        }
                        ?>  
				</div>
		</div>
</div>
</div>
	<script>
function holiday_status(hid,st) {
	//alert(st);
  if (hid=="") {
    document.getElementById("getstatus").innerHTML="";
    return;
  } 
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("getstatus").innerHTML=this.responseText;
    }
  }
  xmlhttp.open("GET","holiday_status.php?hid="+hid+"&st="+st,true);
  xmlhttp.send();
}
</script>
<!--<div id="getstatus"><b>Person info will be listed here.</b></div>-->
<?php include('footer.php');?>
