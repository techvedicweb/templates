
<?php 
$uid=$_SESSION['username'];
$sql=mysql_query("SELECT * FROM mp_user WHERE username='$uid'");
?>
		<?php if(isset($_SESSION['username']) && $_SESSION['username']=='admin'){?><div id="inlineDatepicker"></div><?php } ?>
        <div class="menu">
        	<h3><i class="fa fa-cog" aria-hidden="true"></i>Tools Name</h3>
        	<ul class="scrollbar menu1" id="style-10">
			<?php 
			$sql_slotname=mysql_query("select * from mp_slots order by id asc");
			while($fetch_slot_name=mysql_fetch_array($sql_slotname))
			{
			?>
            <li><a href="pages.php?pageid=<?=$fetch_slot_name['id']?>"><?=$fetch_slot_name['slot_name']?> <i class="fa fa-cogs" aria-hidden="true"></i></a></li>
			<?php 
			}
			?>
            </ul>
        </div>
	