<div class="header widfloat sticky" data-spy="affix" data-offset-top="197">
	<div class="container">
    	<div class="navbar-header">
<?php if(isset($_SESSION['username']) && $_SESSION['username']!='')
{?> 
<a href="home.php"><img src="img/logo.png" class="logo" title="" alt="" data-pin-nopin="true"></a>
<?php 
}
else{
?>
<a href="index.php"><img src="img/logo.png" class="logo" title="" alt="" data-pin-nopin="true"></a>
<?php } ?>
        </div>
        <div class="bright pull-right">
        	<div class="sign">
			<?php if(isset($_SESSION['username']) && $_SESSION['username']!='')
{?>
        		<ul class="dropdown">
                <li><a href="home.php"><i class="fa fa-user" aria-hidden="true"></i><?=ucfirst($_SESSION['username'])?></a></li>
                <div class="dropdown-content">
					<?php
				if($_SESSION['username']=='admin')
				{
					echo '<a href="holiday.php">Add Holiday</a>';
					echo '<a href="maintanance.php">Maintenance</a>';
					echo '<a href="add_course.php">Add Course Name</a>';
					echo '<a href="add_machine.php">Add Tools Name</a>';
					echo '<a href="add_limitval.php">Booking Limit</a>';
				}?>
    				<a href="module/logout.php">Logout</a>
                    
    				
  				</div> 
            </ul>
<?php } ?>
            </div>
        </div>
    </div>
</div>
