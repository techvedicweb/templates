<?php include('header_top.php');?>
<?php include('header.php');?>
<div class="auto">
<div class="schedule">
	
	<div class="left">
		<?php include("sidebar.php");?>
    </div>
	
	<?php
    (int)$currentpage = (!empty($_GET["currentpage"]))?$_GET["currentpage"]:0;
    (int)$nextpage = $currentpage + 1;
    (int)$prevpage = $currentpage - 1;
?>
    <div class="right">
		<div id="exTab1" class="">	
			<ul  class="nav nav-pills">
                <li <?php if(isset($_REQUEST['bt']) && $_REQUEST['bt']=='01'){ echo "class='active'";}?>><a  href="<?php echo "{$_SERVER['PHP_SELF']}?bt=01&currentpage=$prevpage"; ?>" >Previous Week</a></li>
                <li <?php if(!isset($_REQUEST['bt'])){ echo "class='active'";}?>><a href="<?php echo "{$_SERVER['PHP_SELF']}";?>" >Current Week</a></li>
                <li <?php if(isset($_REQUEST['bt']) && $_REQUEST['bt']=='02'){ echo "class='active'";}?>><a href="<?php echo "{$_SERVER['PHP_SELF']}?bt=02&currentpage=$nextpage"; ?>" >Next Week</a></li>
			</ul>
			<?php
			$get_date=array();
			//$get_date_time=array();
            $ts = date(strtotime('last sunday'));
            //echo $currentpage;
            $ts += $currentpage * 86400 * 7;
            //echo $ts;
            $dow = date('w' , $ts);
            $offset = $dow;

            $ts = $ts - $offset * 86400;
            for ($x=0 ; $x<7 ; $x++,$ts += 86400) {
               $get_date[]=date("m/d/Y", $ts);
			   //$get_date_time[]=date("m/d/Y H:i:s", $ts);
            }
			//print_r($array);exit;
        ?>
			<div class="tab-content clearfix">
                <div class="tab-pane active" id="1a">
				<?php 
				//$pageid=$_GET['pageid'];
				?>
                    <h3>Plasma Cutter</h3>
                    <div class="celender">
                    	<div class="col-md-6">
                            <div class="col-md-3">
                            	<div class="w-bg">
                            	<h4>Time</h4>
                                </div>
                                <div class="brd-time">
								<?php 
								$sql_time=mysql_query("select * from mp_time order by id asc");
								while($fetch_time=mysql_fetch_array($sql_time))
								{
								?>
                                	<div class="time">
                                	<div class="time-left">
                                    	<p><?=$fetch_time['slot_time'];?></p>
                                    </div>
                                    <div class="time-right">
                                    	<div class="line"></div>
                                        <div class="line"></div>
                                        <div class="line"></div>
                                    </div>
                                </div>
								<?php }?>
								   
								   </div>
                            </div>
							
<script>
function isert_id(st,da,pageid) {
	//alert(st);
  if (st=="") {
    document.getElementById("txtHint").innerHTML="";
    return;
  } 
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("txtHint").innerHTML=this.responseText;
    }
  }
  xmlhttp.open("GET","book_slots.php?q="+st+"&d="+da+"&page="+pageid,true);
  xmlhttp.send();
}
</script>
<?php
/*$timezone = new DateTimeZone("Asia/Kolkata" );
$date = new DateTime();
$date->setTimezone($timezone );
echo  $date->format( 'H:i:s A  /  D, M jS, Y' );
*/
$date = date_default_timezone_set('Asia/Kolkata');
$today = date("m/d/Y g:i a");
//echo $today;
if(isset($_REQUEST['pageid']) && $_REQUEST['pageid'])
{
$page_id=$_REQUEST['pageid'];
}
else{
$page_id='';

}
?>
<!--<div id="txtHint"><b>Person info will be listed here.</b></div>-->
                            <div class="col-md-3">
                            	<div class="w-bg">
									<p>Sunday</p>
                                	<p><?=$get_date[0]?></p>
                            		
                                </div>
								<?php  
								$check_time1=$get_date[0].' 9:00 am';
								if ($check_time1 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid1=str_replace('/','',$get_date[0]).'_1';
								$sql_book1=mysql_query("select * from book_order where product_id='$pid1' and slot_date='".$get_date[0]."'");
								$fetch_user1=mysql_fetch_array($sql_book1);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book1)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book1)>0){ if($fetch_user1['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid1?>','<?=$get_date[0]?>','<?=$page_id?>')">
								
								 <?php if(mysql_num_rows($sql_book1)>0){ if($fetch_user1['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								 <?php if(mysql_num_rows($sql_book1)==0){echo"<p>Available</p>";}?>
                                </div>
								<?php 
								} 
								$check_time2=$get_date[0].' 11:00 am';
								if ($check_time2 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid2=str_replace('/','',$get_date[0]).'_2';
								$sql_book2=mysql_query("select * from book_order where product_id='$pid2' and slot_date='".$get_date[0]."'");
								$fetch_user2=mysql_fetch_array($sql_book2);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book2)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book2)>0){if($fetch_user2['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid2?>','<?=$get_date[0]?>')">
								
								<?php if(mysql_num_rows($sql_book2)>0){ if($fetch_user2['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book2)==0){echo"<p>Available</p>";}?>
                                </div>
								
								<?php 
								}
								$check_time3=$get_date[0].' 1:00 am';
								if ($check_time3 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid3=str_replace('/','',$get_date[0]).'_3';
								$sql_book3=mysql_query("select * from book_order where product_id='$pid3' and slot_date='".$get_date[0]."'");
								$fetch_user3=mysql_fetch_array($sql_book3);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book3)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book3)>0){if($fetch_user3['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid3?>','<?=$get_date[0]?>')">
								
								<?php if(mysql_num_rows($sql_book3)>0){ if($fetch_user3['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book3)==0){echo"<p>Available</p>";}?>
                                </div>
								
								<?php 
								}
								$check_time4=$get_date[0].' 3:00 am';
								if ($check_time4 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid4=str_replace('/','',$get_date[0]).'_4';
								$sql_book4=mysql_query("select * from book_order where product_id='$pid4' and slot_date='".$get_date[0]."'");
								$fetch_user4=mysql_fetch_array($sql_book4);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book4)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book4)>0){if($fetch_user4['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid4?>','<?=$get_date[0]?>')">
								
								<?php if(mysql_num_rows($sql_book4)>0){ if($fetch_user4['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book4)==0){echo"<p>Available</p>";}?>
                                </div>
								
								<?php 
								}
								$check_time5=$get_date[0].' 5:00 am';
								if ($check_time5 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid5=str_replace('/','',$get_date[0]).'_5';
								$sql_book5=mysql_query("select * from book_order where product_id='$pid5' and slot_date='".$get_date[0]."'");
								$fetch_user5=mysql_fetch_array($sql_book5);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book5)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book5)>0){ if($fetch_user5['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid5?>','<?=$get_date[0]?>')">
								
								<?php if(mysql_num_rows($sql_book5)>0){ if($fetch_user5['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book5)==0){echo"<p>Available</p>";}?>
								<?php  if ($get_date[0] < $today) { echo "Unbooked";}?>
                                </div>
								
								<?php 
								}
								$check_time6=$get_date[0].' 7:00 am';
								if ($check_time6 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid6=str_replace('/','',$get_date[0]).'_6';
								$sql_book6=mysql_query("select * from book_order where product_id='$pid6' and slot_date='".$get_date[0]."'");
								$fetch_user6=mysql_fetch_array($sql_book6);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book6)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book6)>0){ if($fetch_user6['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid6?>','<?=$get_date[0]?>')">
								
								<?php if(mysql_num_rows($sql_book6)>0){ if($fetch_user6['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book6)==0){echo"<p>Available</p>";}?>
								<?php  if ($get_date[0] < $today) { echo "Unbooked";}?>
                                </div>
								<?php 
								}
								?>
                             </div>
                            <div class="col-md-3">
                            	<div class="w-bg">
									<p>Monday</p>
                                	<p><?=$get_date[1]?></p>
                            		
                                </div>
                                <?php  
								$check_time7=$get_date[1].' 9:00 am';
								if ($check_time7 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid7=str_replace('/','',$get_date[1]).'_7';
								$sql_book7=mysql_query("select * from book_order where product_id='$pid7' and slot_date='".$get_date[1]."'");
								$fetch_user7=mysql_fetch_array($sql_book7);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book7)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book7)>0){ if($fetch_user7['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid7?>','<?=$get_date[1]?>')">
								
								 <?php if(mysql_num_rows($sql_book7)>0){ if($fetch_user7['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								 <?php if(mysql_num_rows($sql_book7)==0){echo"<p>Available</p>";}?>
                                </div>
								
								<?php 
								}
								$check_time8=$get_date[1].' 11:00 am';
								if ($check_time8 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid8=str_replace('/','',$get_date[1]).'_8';
								$sql_book8=mysql_query("select * from book_order where product_id='$pid8' and slot_date='".$get_date[1]."'");
								$fetch_user8=mysql_fetch_array($sql_book8);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book8)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book8)>0){if($fetch_user8['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid8?>','<?=$get_date[1]?>')">
								
								<?php if(mysql_num_rows($sql_book8)>0){ if($fetch_user8['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book8)==0){echo"<p>Available</p>";}?>
                                </div>
								
								<?php 
								}
								$check_time9=$get_date[1].' 1:00 am';
								if ($check_time9 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid9=str_replace('/','',$get_date[1]).'_9';
								$sql_book9=mysql_query("select * from book_order where product_id='$pid9' and slot_date='".$get_date[1]."'");
								$fetch_user9=mysql_fetch_array($sql_book9);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book9)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book9)>0){if($fetch_user9['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid9?>','<?=$get_date[1]?>')">
								
								<?php if(mysql_num_rows($sql_book9)>0){ if($fetch_user9['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book9)==0){echo"<p>Available</p>";}?>
                                </div>
								
								<?php 
								}
								$check_time10=$get_date[1].' 3:00 am';
								if ($check_time10 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid10=str_replace('/','',$get_date[1]).'_10';
								$sql_book10=mysql_query("select * from book_order where product_id='$pid10' and slot_date='".$get_date[1]."'");
								$fetch_user10=mysql_fetch_array($sql_book10);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book10)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book10)>0){if($fetch_user10['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid10?>','<?=$get_date[1]?>')">
								
								<?php if(mysql_num_rows($sql_book10)>0){ if($fetch_user10['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book10)==0){echo"<p>Available</p>";}?>
                                </div>
								
								<?php 
								}
								$check_time11=$get_date[1].' 5:00 am';
								if ($check_time11 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid11=str_replace('/','',$get_date[1]).'_11';
								$sql_book11=mysql_query("select * from book_order where product_id='$pid11' and slot_date='".$get_date[1]."'");
								$fetch_user11=mysql_fetch_array($sql_book11);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book11)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book11)>0){ if($fetch_user11['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid11?>','<?=$get_date[1]?>')">
								
								<?php if(mysql_num_rows($sql_book11)>0){ if($fetch_user11['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book11)==0){echo"<p>Available</p>";}?>
								
                                </div>
								
								<?php
								}
								$check_time12=$get_date[1].' 7:00 am';
								if ($check_time12 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid12=str_replace('/','',$get_date[1]).'_12';
								$sql_book12=mysql_query("select * from book_order where product_id='$pid12' and slot_date='".$get_date[1]."'");
								$fetch_user12=mysql_fetch_array($sql_book12);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book12)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book12)>0){ if($fetch_user12['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid12?>','<?=$get_date[1]?>')">
								
								<?php if(mysql_num_rows($sql_book12)>0){ if($fetch_user12['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book12)==0){echo"<p>Available</p>";}?>
                                </div>
							   <?php } ?>
								</div>
                            <div class="col-md-3">
                            	<div class="w-bg">
								<p>Tuesday</p>
                                	<p><?=$get_date[2]?></p>
                            		
                                </div>
                                <?php
								$check_time13=$get_date[2].' 9:00 am';
								if ($check_time13 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid13=str_replace('/','',$get_date[2]).'_13';
								$sql_book13=mysql_query("select * from book_order where product_id='$pid13' and slot_date='".$get_date[2]."'");
								$fetch_user13=mysql_fetch_array($sql_book13);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book13)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book13)>0){ if($fetch_user13['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid13?>','<?=$get_date[2]?>')">
								
								 <?php if(mysql_num_rows($sql_book13)>0){ if($fetch_user13['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								 <?php if(mysql_num_rows($sql_book13)==0){echo"<p>Available</p>";}?>
                                </div>
								
								<?php 
								}
								$check_time14=$get_date[2].' 11:00 am';
								if ($check_time14 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid14=str_replace('/','',$get_date[2]).'_14';
								$sql_book14=mysql_query("select * from book_order where product_id='$pid14' and slot_date='".$get_date[2]."'");
								$fetch_user14=mysql_fetch_array($sql_book14);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book14)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book14)>0){if($fetch_user14['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid14?>','<?=$get_date[2]?>')">
								
								<?php if(mysql_num_rows($sql_book14)>0){ if($fetch_user14['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book14)==0){echo"<p>Available</p>";}?>
                                </div>
								
								<?php 
								}
								$check_time15=$get_date[2].' 1:00 am';
								if ($check_time15 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid15=str_replace('/','',$get_date[2]).'_15';
								$sql_book15=mysql_query("select * from book_order where product_id='$pid15' and slot_date='".$get_date[2]."'");
								$fetch_user15=mysql_fetch_array($sql_book15);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book15)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book15)>0){if($fetch_user15['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid15?>','<?=$get_date[2]?>')">
								
								<?php if(mysql_num_rows($sql_book15)>0){ if($fetch_user15['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book15)==0){echo"<p>Available</p>";}?>
                                </div>
								
								<?php 
								}
								$check_time16=$get_date[2].' 3:00 am';
								if ($check_time16 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid16=str_replace('/','',$get_date[2]).'_16';
								$sql_book16=mysql_query("select * from book_order where product_id='$pid16' and slot_date='".$get_date[2]."'");
								$fetch_user16=mysql_fetch_array($sql_book16);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book16)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book16)>0){if($fetch_user16['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid16?>','<?=$get_date[2]?>')">
								
								<?php if(mysql_num_rows($sql_book16)>0){ if($fetch_user16['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book16)==0){echo"<p>Available</p>";}?>
                                </div>
								
								<?php 
								}
								$check_time17=$get_date[2].' 5:00 am';
								if ($check_time17 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid17=str_replace('/','',$get_date[2]).'_17';
								$sql_book17=mysql_query("select * from book_order where product_id='$pid17' and slot_date='".$get_date[2]."'");
								$fetch_user17=mysql_fetch_array($sql_book17);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book17)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book17)>0){ if($fetch_user17['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid17?>','<?=$get_date[2]?>')">
								
								<?php if(mysql_num_rows($sql_book17)>0){ if($fetch_user17['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book17)==0){echo"<p>Available</p>";}?>
								
                                </div>
								
								<?php 
								}
								$check_time18=$get_date[2].' 7:00 am';
								if ($check_time18 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid18=str_replace('/','',$get_date[2]).'_18';
								$sql_book18=mysql_query("select * from book_order where product_id='$pid18' and slot_date='".$get_date[2]."'");
								$fetch_user18=mysql_fetch_array($sql_book18);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book18)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book18)>0){ if($fetch_user18['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid18?>','<?=$get_date[2]?>')">
								
								<?php if(mysql_num_rows($sql_book18)>0){ if($fetch_user18['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book18)==0){echo"<p>Available</p>";}?>
                                </div>
								<?php 
								} 
								?>
							   </div>
                    </div>
						<div class="col-md-6">
                            <div class="col-md-3">
                            	<div class="w-bg">
								<p>Wednesday</p>
                                	<p><?=$get_date[3]?></p>
                            		
                                </div>
								<?php
								$check_time19=$get_date[3].' 9:00 am';
								if ($check_time19 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid19=str_replace('/','',$get_date[3]).'_19';
								$sql_book19=mysql_query("select * from book_order where product_id='$pid19' and slot_date='".$get_date[3]."'");
								$fetch_user19=mysql_fetch_array($sql_book19);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book19)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book19)>0){ if($fetch_user19['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid19?>','<?=$get_date[3]?>')">
								
								 <?php if(mysql_num_rows($sql_book19)>0){ if($fetch_user19['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								 <?php if(mysql_num_rows($sql_book19)==0){echo"<p>Available</p>";}?>
                                </div>
								
								<?php 
								}
								$check_time20=$get_date[3].' 11:00 am';
								if ($check_time20 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid20=str_replace('/','',$get_date[3]).'_20';
								$sql_book20=mysql_query("select * from book_order where product_id='$pid20' and slot_date='".$get_date[3]."'");
								$fetch_user20=mysql_fetch_array($sql_book20);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book20)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book20)>0){if($fetch_user20['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid20?>','<?=$get_date[3]?>')">
								
								<?php if(mysql_num_rows($sql_book20)>0){ if($fetch_user20['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book20)==0){echo"<p>Available</p>";}?>
                                </div>
								
								<?php
								}
								$check_time21=$get_date[3].' 1:00 am';
								if ($check_time21 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid21=str_replace('/','',$get_date[3]).'_21';
								$sql_book21=mysql_query("select * from book_order where product_id='$pid21' and slot_date='".$get_date[3]."'");
								$fetch_user21=mysql_fetch_array($sql_book21);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book21)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book21)>0){if($fetch_user21['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid21?>','<?=$get_date[3]?>')">
								
								<?php if(mysql_num_rows($sql_book21)>0){ if($fetch_user21['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book21)==0){echo"<p>Available</p>";}?>
                                </div>
								
								<?php
								}
								$check_time22=$get_date[3].' 3:00 am';
								if ($check_time22 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid22=str_replace('/','',$get_date[3]).'_22';
								$sql_book22=mysql_query("select * from book_order where product_id='$pid22' and slot_date='".$get_date[3]."'");
								$fetch_user22=mysql_fetch_array($sql_book22);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book22)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book22)>0){if($fetch_user22['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid22?>','<?=$get_date[3]?>')">
								
								<?php if(mysql_num_rows($sql_book22)>0){ if($fetch_user22['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book22)==0){echo"<p>Available</p>";}?>
                                </div>
								
								<?php
								}
								$check_time23=$get_date[3].' 5:00 am';
								if ($check_time23 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid23=str_replace('/','',$get_date[3]).'_23';
								$sql_book23=mysql_query("select * from book_order where product_id='$pid23' and slot_date='".$get_date[3]."'");
								$fetch_user23=mysql_fetch_array($sql_book23);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book23)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book23)>0){ if($fetch_user23['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid23?>','<?=$get_date[3]?>')">
								
								<?php if(mysql_num_rows($sql_book23)>0){ if($fetch_user23['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book23)==0){echo"<p>Available</p>";}?>
								
                                </div>
								
								<?php
								}
								$check_time24=$get_date[3].' 7:00 am';
								if ($check_time24 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid24=str_replace('/','',$get_date[3]).'_24';
								$sql_book24=mysql_query("select * from book_order where product_id='$pid24' and slot_date='".$get_date[3]."'");
								$fetch_user24=mysql_fetch_array($sql_book24);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book24)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book24)>0){ if($fetch_user24['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid24?>','<?=$get_date[3]?>')">
								
								<?php if(mysql_num_rows($sql_book24)>0){ if($fetch_user24['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book24)==0){echo"<p>Available</p>";}?>
                                </div>
								<?php 
								}
								?>
								</div>
                            <div class="col-md-3">
                            	<div class="w-bg">
								<p>Thursday</p>
                                	<p><?=$get_date[4]?></p>
                            		
                                </div>
                               <?php
								$check_time25=$get_date[4].' 9:00 am';
								if ($check_time25 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid25=str_replace('/','',$get_date[4]).'_25';
								$sql_book25=mysql_query("select * from book_order where product_id='$pid25' and slot_date='".$get_date[4]."'");
								$fetch_user25=mysql_fetch_array($sql_book25);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book25)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book25)>0){ if($fetch_user25['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid25?>','<?=$get_date[4]?>')">
								
								 <?php if(mysql_num_rows($sql_book25)>0){ if($fetch_user25['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								 <?php if(mysql_num_rows($sql_book25)==0){echo"<p>Available</p>";}?>
                                </div>
								
								<?php
								}
								$check_time26=$get_date[4].' 11:00 am';
								if ($check_time26 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid26=str_replace('/','',$get_date[4]).'_26';
								$sql_book26=mysql_query("select * from book_order where product_id='$pid26' and slot_date='".$get_date[4]."'");
								$fetch_user26=mysql_fetch_array($sql_book26);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book26)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book26)>0){if($fetch_user26['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid26?>','<?=$get_date[4]?>')">
								
								<?php if(mysql_num_rows($sql_book26)>0){ if($fetch_user26['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book26)==0){echo"<p>Available</p>";}?>
                                </div>
								
								<?php 
								}
								$check_time27=$get_date[4].' 1:00 am';
								if ($check_time27 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid27=str_replace('/','',$get_date[4]).'_27';
								$sql_book27=mysql_query("select * from book_order where product_id='$pid27' and slot_date='".$get_date[4]."'");
								$fetch_user27=mysql_fetch_array($sql_book27);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book27)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book27)>0){if($fetch_user27['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid27?>','<?=$get_date[4]?>')">
								
								<?php if(mysql_num_rows($sql_book27)>0){ if($fetch_user27['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book27)==0){echo"<p>Available</p>";}?>
                                </div>
								
								<?php
								}
								$check_time28=$get_date[4].' 3:00 am';
								if ($check_time28 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid28=str_replace('/','',$get_date[4]).'_28';
								$sql_book28=mysql_query("select * from book_order where product_id='$pid28' and slot_date='".$get_date[4]."'");
								$fetch_user28=mysql_fetch_array($sql_book28);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book28)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book28)>0){if($fetch_user28['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid28?>','<?=$get_date[4]?>')">
								
								<?php if(mysql_num_rows($sql_book28)>0){ if($fetch_user28['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book28)==0){echo"<p>Available</p>";}?>
                                </div>
								
								<?php
								}
								$check_time29=$get_date[4].' 5:00 am';
								if ($check_time29 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid29=str_replace('/','',$get_date[4]).'_29';
								$sql_book29=mysql_query("select * from book_order where product_id='$pid29' and slot_date='".$get_date[4]."'");
								$fetch_user29=mysql_fetch_array($sql_book29);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book29)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book29)>0){ if($fetch_user29['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid29?>','<?=$get_date[4]?>')">
								
								<?php if(mysql_num_rows($sql_book29)>0){ if($fetch_user29['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book29)==0){echo"<p>Available</p>";}?>
								
                                </div>
								
								<?php
								}
								$check_time30=$get_date[4].' 7:00 am';
								if ($check_time30 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid30=str_replace('/','',$get_date[4]).'_30';
								$sql_book30=mysql_query("select * from book_order where product_id='$pid30' and slot_date='".$get_date[4]."'");
								$fetch_user30=mysql_fetch_array($sql_book30);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book30)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book30)>0){ if($fetch_user30['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid30?>','<?=$get_date[4]?>')">
								
								<?php if(mysql_num_rows($sql_book30)>0){ if($fetch_user30['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book30)==0){echo"<p>Available</p>";}?>
                                </div>
								<?php 
								}
								?>
								</div>
                            <div class="col-md-3">
                            	<div class="w-bg">
								<p>Friday</p>
                                	<p><?=$get_date[5]?></p>
                            		
                                </div>
								<?php
								$check_time31=$get_date[5].' 09:00 am';
								if ($check_time31 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid31=str_replace('/','',$get_date[5]).'_31';
								$sql_book31=mysql_query("select * from book_order where product_id='$pid31' and slot_date='".$get_date[5]."'");
								$fetch_user31=mysql_fetch_array($sql_book31);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book31)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book31)>0){ if($fetch_user31['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid31?>','<?=$get_date[5]?>')">
								
								 <?php if(mysql_num_rows($sql_book31)>0){ if($fetch_user31['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								 <?php if(mysql_num_rows($sql_book31)==0){echo"<p>Available</p>";}?>
                                </div>
								<?php 
								}
								$check_time32=$get_date[5].' 11:00 am';
								if ($check_time32 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid32=str_replace('/','',$get_date[5]).'_32';
								$sql_book32=mysql_query("select * from book_order where product_id='$pid32' and slot_date='".$get_date[5]."'");
								$fetch_user32=mysql_fetch_array($sql_book32);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book32)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book32)>0){if($fetch_user32['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid32?>','<?=$get_date[5]?>')">
								
								<?php if(mysql_num_rows($sql_book32)>0){ if($fetch_user32['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book32)==0){echo"<p>Available</p>";}?>
                                </div>
								
								<?php
								}
								$check_time33=$get_date[5].' 1:00 am';
								if ($check_time33 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid33=str_replace('/','',$get_date[5]).'_33';
								$sql_book33=mysql_query("select * from book_order where product_id='$pid33' and slot_date='".$get_date[5]."'");
								$fetch_user33=mysql_fetch_array($sql_book33);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book33)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book33)>0){if($fetch_user33['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid33?>','<?=$get_date[5]?>')">
								
								<?php if(mysql_num_rows($sql_book33)>0){ if($fetch_user33['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book33)==0){echo"<p>Available</p>";}?>
                                </div>
								
								<?php
								}
								$check_time34=$get_date[5].' 3:00 am';
								if ($check_time34 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid34=str_replace('/','',$get_date[5]).'_34';
								$sql_book34=mysql_query("select * from book_order where product_id='$pid34' and slot_date='".$get_date[5]."'");
								$fetch_user34=mysql_fetch_array($sql_book34);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book34)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book34)>0){if($fetch_user34['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid34?>','<?=$get_date[5]?>')">
								
								<?php if(mysql_num_rows($sql_book34)>0){ if($fetch_user34['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book34)==0){echo"<p>Available</p>";}?>
                                </div>
								
								<?php
								}
								$check_time35=$get_date[5].' 5:00 am';
								if ($check_time35 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid35=str_replace('/','',$get_date[5]).'_35';
								$sql_book35=mysql_query("select * from book_order where product_id='$pid35' and slot_date='".$get_date[5]."'");
								$fetch_user35=mysql_fetch_array($sql_book35);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book35)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book35)>0){ if($fetch_user35['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid35?>','<?=$get_date[5]?>')">
								
								<?php if(mysql_num_rows($sql_book35)>0){ if($fetch_user35['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book35)==0){echo"<p>Available</p>";}?>
								
                                </div>
								
								<?php
								}
								$check_time36=$get_date[5].' 7:00 am';
								if ($check_time36 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid36=str_replace('/','',$get_date[5]).'_36';
								$sql_book36=mysql_query("select * from book_order where product_id='$pid36' and slot_date='".$get_date[5]."'");
								$fetch_user36=mysql_fetch_array($sql_book36);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book36)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book36)>0){ if($fetch_user36['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid36?>','<?=$get_date[5]?>')">
								
								<?php if(mysql_num_rows($sql_book36)>0){ if($fetch_user36['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book36)==0){echo"<p>Available</p>";}?>
                                </div>
								<?php 
								}
								?>
								</div>
                            <div class="col-md-3">
                            	<div class="w-bg">
                            		<p>Saturday</p>
                                	<p><?=$get_date[6]?></p>
                                </div>
                                
								<?php
								$check_time37=$get_date[6].' 9:00 am';
								if ($check_time37 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid37=str_replace('/','',$get_date[6]).'_37';
								$sql_book37=mysql_query("select * from book_order where product_id='$pid37' and slot_date='".$get_date[6]."'");
								$fetch_user37=mysql_fetch_array($sql_book37);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book37)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book37)>0){ if($fetch_user37['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid37?>','<?=$get_date[6]?>')">
								
								 <?php if(mysql_num_rows($sql_book37)>0){ if($fetch_user37['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								 <?php if(mysql_num_rows($sql_book37)==0){echo"<p>Available</p>";}?>
                                </div>
								
								<?php
								}
								$check_time38=$get_date[6].' 11:00 am';
								if ($check_time38 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid38=str_replace('/','',$get_date[6]).'_38';
								$sql_book38=mysql_query("select * from book_order where product_id='$pid38' and slot_date='".$get_date[6]."'");
								$fetch_user38=mysql_fetch_array($sql_book38);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book38)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book38)>0){if($fetch_user38['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid38?>','<?=$get_date[6]?>')">
								
								<?php if(mysql_num_rows($sql_book38)>0){ if($fetch_user38['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book38)==0){echo"<p>Available</p>";}?>
                                </div>
								
								<?php
								}
								$check_time39=$get_date[6].' 1:00 am';
								if ($check_time39 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid39=str_replace('/','',$get_date[6]).'_39';
								$sql_book39=mysql_query("select * from book_order where product_id='$pid39' and slot_date='".$get_date[6]."'");
								$fetch_user39=mysql_fetch_array($sql_book39);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book39)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book39)>0){if($fetch_user39['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid39?>','<?=$get_date[6]?>')">
								
								<?php if(mysql_num_rows($sql_book39)>0){ if($fetch_user39['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book39)==0){echo"<p>Available</p>";}?>
                                </div>
								
								<?php
								}
								$check_time40=$get_date[6].' 3:00 am';
								if ($check_time40 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid40=str_replace('/','',$get_date[6]).'_40';
								$sql_book40=mysql_query("select * from book_order where product_id='$pid40' and slot_date='".$get_date[6]."'");
								$fetch_user40=mysql_fetch_array($sql_book40);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book40)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book40)>0){if($fetch_user40['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid40?>','<?=$get_date[6]?>')">
								
								<?php if(mysql_num_rows($sql_book40)>0){ if($fetch_user40['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book40)==0){echo"<p>Available</p>";}?>
                                </div>
								
								<?php
								}
								$check_time41=$get_date[6].' 5:00 am';
								if ($check_time41 < $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid41=str_replace('/','',$get_date[6]).'_41';
								$sql_book41=mysql_query("select * from book_order where product_id='$pid41' and slot_date='".$get_date[6]."'");
								$fetch_user41=mysql_fetch_array($sql_book41);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book41)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book41)>0){ if($fetch_user41['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid41?>','<?=$get_date[6]?>')">
								
								<?php if(mysql_num_rows($sql_book41)>0){ if($fetch_user41['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book41)==0){echo"<p>Available</p>";}?>
                                </div>
								
								<?php
								}
								$check_time42=$get_date[6].' 7:00 am';
								if ($check_time42< $today) 
								{
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>No Permission</p>
									</div>
								<?php 
								}
								else{
								$pid42=str_replace('/','',$get_date[6]).'_42';
								$sql_book42=mysql_query("select * from book_order where product_id='$pid42' and slot_date='".$get_date[6]."'");
								$fetch_user42=mysql_fetch_array($sql_book42);
								?>
								<div data-toggle="" data-target="#myModal" class="<?php if(mysql_num_rows($sql_book42)>0){ echo"";}else{?>time-slot <?php }?>hover hover1 <?php if(mysql_num_rows($sql_book42)>0){ if($fetch_user42['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" onclick="isert_id('<?=$pid42?>','<?=$get_date[6]?>')">
								
								<?php if(mysql_num_rows($sql_book42)>0){ if($fetch_user42['userid']==$_SESSION['userid']){?><p>Booked</p><?php } else{ echo"<p>Unavailable</p>";}}?>
								<?php if(mysql_num_rows($sql_book42)==0){echo"<p>Available</p>";}?>
								
                                </div>
								<?php } ?>
								</div>
                          </div>
					</div>
				 </div>
			</div>
  		</div>
    </div>
	<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
<?//=$_REQUEST['reqid']?>
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Desmo</h4>
      </div>
      <form class="cnt-f">
            <div class="form-group">
              <label for="recipient-name" class="form-control-label">Recipient:</label>
              <input type="text" class="form-control" id="recipient-name">
            </div>
            <div class="form-group">
              <label for="message-text" class="form-control-label">Message:</label>
              <textarea class="form-control" id="message-text"></textarea>
            </div>
          </form>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
</div>
</div>
<?php include('footer.php');?>
