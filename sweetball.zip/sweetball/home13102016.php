<?php include('header_top.php');?>
<?php include('header.php');?>
<div class="schedule">
	<div class="left">
		<div id="inlineDatepicker"></div>
        <div class="menu">
        	<h3>Tools Name</h3>
        	<ul class="scrollbar" id="style-10">
			<?php 
	$tool_query="SELECT * from mp_slots";
	
	$num_rows=mysql_query($tool_query);
	//echo mysql_num_rows($num_rows);exit;
if(mysql_num_rows($num_rows)>0)
{
	while($tool_name=mysql_fetch_array($num_rows))
	{?>
            	<li><a href="<?=$tool_name['id']?>"><?=$tool_name['slot_name']?> <i class="fa fa-location-arrow" aria-hidden="true"></i></a></li>
<?php }} ?>
               <!-- <li><a href="#">Tormach Mill <i class="fa fa-location-arrow" aria-hidden="true"></i></a></li>
                <li><a href="#">Bridgeport 1 Mill <i class="fa fa-location-arrow" aria-hidden="true"></i></a></li>
                <li><a href="#">Bridgeport 2 Mill <i class="fa fa-location-arrow" aria-hidden="true"></i></a></li>
                <li><a href="#">CNC Router <i class="fa fa-location-arrow" aria-hidden="true"></i></a></li>
                <li><a href="#">Old 100 Watt Laser <i class="fa fa-location-arrow" aria-hidden="true"></i></a></li>
                <li><a href="#">New 100 Watt Laser<i class="fa fa-location-arrow" aria-hidden="true"></i></a></li>
                <li><a href="#">80 Watt Laser<i class="fa fa-location-arrow" aria-hidden="true"></i></a></li>
                <li><a href="#">Epilog Laser<i class="fa fa-location-arrow" aria-hidden="true"></i></a></li>
                <li><a href="#">Oxy Acetylene Torch<i class="fa fa-location-arrow" aria-hidden="true"></i></a></li>
                <li><a href="#">TIG 1 Welder<i class="fa fa-location-arrow" aria-hidden="true"></i></a></li>
                <li><a href="#">TIG 2 Welder<i class="fa fa-location-arrow" aria-hidden="true"></i></a></li>
                <li><a href="#">TIG 3 Welder<i class="fa fa-location-arrow" aria-hidden="true"></i></a></li>
                <li><a href="#">MIG 210 Welder<i class="fa fa-location-arrow" aria-hidden="true"></i></a></li>
                <li><a href="#">MIG 251 Welder<i class="fa fa-location-arrow" aria-hidden="true"></i></a></li>
                <li><a href="#">Jack ROBO 3D Printer<i class="fa fa-location-arrow" aria-hidden="true"></i></a></li>
                <li><a href="#">Jill ROBO 3D Printer<i class="fa fa-location-arrow" aria-hidden="true"></i></a></li>
                <li><a href="#">Dimension 3D Printer<i class="fa fa-location-arrow" aria-hidden="true"></i></a></li>
                <li><a href="#">Press Brake<i class="fa fa-location-arrow" aria-hidden="true"></i></a></li>
                <li><a href="#">Metal Lathe<i class="fa fa-location-arrow" aria-hidden="true"></i></a></li>
                <li><a href="#">Wood Lathe<i class="fa fa-location-arrow" aria-hidden="true"></i></a></li>
                <li><a href="#">Embroidery<i class="fa fa-location-arrow" aria-hidden="true"></i></a></li>
                <li><a href="#">Paint Booth<i class="fa fa-location-arrow" aria-hidden="true"></i></a></li>
                <li><a href="#">Photo Booth<i class="fa fa-location-arrow" aria-hidden="true"></i></a></li>
                <li><a href="#">SawStop Table Saw<i class="fa fa-location-arrow" aria-hidden="true"></i></a></li>
				-->
            </ul>
        </div>
    </div>
	<?php 
	
	function GetCurrentWeekDates()
{
    if (date('D') != 'Mon') {
        $startdate = date('m/d/Y', strtotime('last Monday'));
		
    } else {
        $startdate = date('m/d/Y');
		//echo $startdate;exit;
    }

//always next saturday
    if (date('D') != 'Sat') {
        $enddate = date('m/d/Y', strtotime('next Saturday'));
    } else {
        $enddate = date('m/d/Y');
    }

    $DateArray = array();
    $timestamp = strtotime($startdate);
    while ($startdate <= $enddate) {
        $startdate = date('m/d/Y', $timestamp);
		//echo $startdate;exit;
        $DateArray[] = $startdate;
        $timestamp = strtotime('+1 days', strtotime($startdate));
    }
    return $DateArray;
}
//print_r(GetCurrentWeekDates());
$arry[]='';
foreach(GetCurrentWeekDates() as $val_date)
{
	$arry[]=$val_date;
	
}
//print_r($arry);
//echo $arry[2];
?>
    <div class="right">
		<div id="exTab1" class="">	
			<ul  class="nav nav-pills">
                <li><a  href="#1a" data-toggle="tab">Previous Week</a></li>
                <li class="active"><a href="#2a" data-toggle="tab">Current Week</a></li>
                <li><a href="#3a" data-toggle="tab">Next Week</a></li>
			</ul>
			<div class="tab-content clearfix">
                <div class="tab-pane active" id="1a">
                    <h3>Plasma Cutter</h3>
                    <div class="celender">
                    	<div class="col-md-6">
                            <div class="col-md-3">
                            	<div class="w-bg">
                            	<h4>Time</h4>
                                </div>
                                <div class="brd-time">
                                	<div class="time">
                                	<div class="time-left">
                                    	<p>9<br /> AM</p>
                                    </div>
                                    <div class="time-right">
                                    	<div class="line"></div>
                                        <div class="line"></div>
                                        <div class="line"></div>
                                    </div>
                                </div>
                                    <div class="time">
                                        <div class="time-left">
                                            <p>11<br /> AM</p>
                                        </div>
                                        <div class="time-right">
                                            <div class="line"></div>
                                            <div class="line"></div>
                                            <div class="line"></div>
                                        </div>
                                    </div>
                                	<div class="time">
                                	<div class="time-left">
                                    	<p>1<br /> PM</p>
                                    </div>
                                    <div class="time-right">
                                    	<div class="line"></div>
                                        <div class="line"></div>
                                        <div class="line"></div>
                                    </div>
                                </div>
                                	<div class="time">
                                	<div class="time-left">
                                    	<p>3<br /> PM</p>
                                    </div>
                                    <div class="time-right">
                                    	<div class="line"></div>
                                        <div class="line"></div>
                                        <div class="line"></div>
                                    </div>
                                </div>
                                	<div class="time">
                                	<div class="time-left">
                                    	<p>5<br /> PM</p>
                                    </div>
                                    <div class="time-right">
                                    	<div class="line"></div>
                                        <div class="line"></div>
                                        <div class="line"></div>
                                    </div>
                                </div>
                                	<div class="time">
                                	<div class="time-left">
                                    	<p>7<br /> PM</p>
                                    </div>
                                    <div class="time-right">
                                    	<div class="line"></div>
                                        <div class="line"></div>
                                        <div class="line"></div>
                                    </div>
                                </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                            	<div class="w-bg">
                            		<p>Monday</p>
                                	<p><?=$arry[1]?></p>
                                </div>
								
								<?php
							$slot_query=mysql_query("select * from mp_slot_details where slot_detail IN ($arry[1]) group by slot_id");
							if($slot_query){
							while($slot_det=mysql_fetch_array($slot_query))
							{
								if($slot_det['slot_detail']!="")
								{
								?>
							 
							<option value="<?php echo $slot_det['slot_detail']; ?>"><?php echo $slot_det['slot_detail']; ?>
							</option>
								<?php } } }?>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                
								
								<div class="time-slot hover">
                                </div>
                             </div>
                            <div class="col-md-3">
                            	<div class="w-bg">
                            		<p>Tuesday</p>
                                	<p><?=$arry[2]?></p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                            </div>
                            <div class="col-md-3">
                            	<div class="w-bg">
                            		<p>Wednesday</p>
                                	<p><?=$arry[3]?></p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="col-md-3">
                            	<div class="w-bg">
                            		<p>Thursday</p>
                                	<p><?=$arry[4]?></p>
                                </div>
								<div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                            </div>
                            <div class="col-md-3">
                            	<div class="w-bg">
                            		<p>Friday</p>
                                	<p><?=$arry[5]?></p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                            </div>
                            <div class="col-md-3">
                            	<div class="w-bg">
                            		<p>Saturday</p>
                                	<p><?=$arry[6]?></p>
                                </div>
								<div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                            </div>
                            <div class="col-md-3">
                            	<div class="w-bg">
                            		<p>Sunday</p>
                                	<p><?=$arry[7]?></p>
                                </div>
								<div class="time-slot hover">
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                            </div>
                          </div>
                    </div>
                </div>
				<div class="tab-pane" id="2a">
          			<h3>Plasma Cutter</h3>
                    <div class="celender">
                    	<div class="col-md-6">
                            <div class="col-md-3">
                            	<div class="w-bg">
                            	<h4>Time</h4>
                                </div>
                                <div class="brd-time">
                                	<div class="time">
                                	<div class="time-left">
                                    	<p>9<br /> AM</p>
                                    </div>
                                    <div class="time-right">
                                    	<div class="line"></div>
                                        <div class="line"></div>
                                        <div class="line"></div>
                                    </div>
                                </div>
                                    <div class="time">
                                        <div class="time-left">
                                            <p>11<br /> AM</p>
                                        </div>
                                        <div class="time-right">
                                            <div class="line"></div>
                                            <div class="line"></div>
                                            <div class="line"></div>
                                        </div>
                                    </div>
                                	<div class="time">
                                	<div class="time-left">
                                    	<p>1<br /> PM</p>
                                    </div>
                                    <div class="time-right">
                                    	<div class="line"></div>
                                        <div class="line"></div>
                                        <div class="line"></div>
                                    </div>
                                </div>
                                	<div class="time">
                                	<div class="time-left">
                                    	<p>3<br /> PM</p>
                                    </div>
                                    <div class="time-right">
                                    	<div class="line"></div>
                                        <div class="line"></div>
                                        <div class="line"></div>
                                    </div>
                                </div>
                                	<div class="time">
                                	<div class="time-left">
                                    	<p>5<br /> PM</p>
                                    </div>
                                    <div class="time-right">
                                    	<div class="line"></div>
                                        <div class="line"></div>
                                        <div class="line"></div>
                                    </div>
                                </div>
                                	<div class="time">
                                	<div class="time-left">
                                    	<p>7<br /> PM</p>
                                    </div>
                                    <div class="time-right">
                                    	<div class="line"></div>
                                        <div class="line"></div>
                                        <div class="line"></div>
                                    </div>
                                </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                            	<div class="w-bg">
                            		<p>Monday</p>
                                	<p>10/3/2016</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                             </div>
                            <div class="col-md-3">
                            	<div class="w-bg">
                            		<p>Tuesday</p>
                                	<p>10/4/2016</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                            </div>
                            <div class="col-md-3">
                            	<div class="w-bg">
                            		<p>Wednesday</p>
                                	<p>10/5/2016</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="col-md-3">
                            	<div class="w-bg">
                            		<p>Thursday</p>
                                	<p>10/6/2016</p>
                                </div>
								<div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                            </div>
                            <div class="col-md-3">
                            	<div class="w-bg">
                            		<p>Friday</p>
                                	<p>10/7/2016</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                            </div>
                            <div class="col-md-3">
                            	<div class="w-bg">
                            		<p>Saturday</p>
                                	<p>10/8/2016</p>
                                </div>
								<div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                            </div>
                            <div class="col-md-3">
                            	<div class="w-bg">
                            		<p>Sunday</p>
                                	<p>10/9/2016</p>
                                </div>
								<div class="time-slot hover">
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                            </div>
                          </div>
                    </div>
                </div>
                <div class="tab-pane" id="3a">
                  <h3>Plasma Cutter</h3>
                    <div class="celender">
                    	<div class="col-md-6">
                            <div class="col-md-3">
                            	<div class="w-bg">
                            	<h4>Time</h4>
                                </div>
                                <div class="brd-time">
                                	<div class="time">
                                	<div class="time-left">
                                    	<p>9<br /> AM</p>
                                    </div>
                                    <div class="time-right">
                                    	<div class="line"></div>
                                        <div class="line"></div>
                                        <div class="line"></div>
                                    </div>
                                </div>
                                    <div class="time">
                                        <div class="time-left">
                                            <p>11<br /> AM</p>
                                        </div>
                                        <div class="time-right">
                                            <div class="line"></div>
                                            <div class="line"></div>
                                            <div class="line"></div>
                                        </div>
                                    </div>
                                	<div class="time">
                                	<div class="time-left">
                                    	<p>1<br /> PM</p>
                                    </div>
                                    <div class="time-right">
                                    	<div class="line"></div>
                                        <div class="line"></div>
                                        <div class="line"></div>
                                    </div>
                                </div>
                                	<div class="time">
                                	<div class="time-left">
                                    	<p>3<br /> PM</p>
                                    </div>
                                    <div class="time-right">
                                    	<div class="line"></div>
                                        <div class="line"></div>
                                        <div class="line"></div>
                                    </div>
                                </div>
                                	<div class="time">
                                	<div class="time-left">
                                    	<p>5<br /> PM</p>
                                    </div>
                                    <div class="time-right">
                                    	<div class="line"></div>
                                        <div class="line"></div>
                                        <div class="line"></div>
                                    </div>
                                </div>
                                	<div class="time">
                                	<div class="time-left">
                                    	<p>7<br /> PM</p>
                                    </div>
                                    <div class="time-right">
                                    	<div class="line"></div>
                                        <div class="line"></div>
                                        <div class="line"></div>
                                    </div>
                                </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                            	<div class="w-bg">
                            		<p>Monday</p>
                                	<p>10/3/2016</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                             </div>
                            <div class="col-md-3">
                            	<div class="w-bg">
                            		<p>Tuesday</p>
                                	<p>10/4/2016</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                            </div>
                            <div class="col-md-3">
                            	<div class="w-bg">
                            		<p>Wednesday</p>
                                	<p>10/5/2016</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="col-md-3">
                            	<div class="w-bg">
                            		<p>Thursday</p>
                                	<p>10/6/2016</p>
                                </div>
								<div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                            </div>
                            <div class="col-md-3">
                            	<div class="w-bg">
                            		<p>Friday</p>
                                	<p>10/7/2016</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                            </div>
                            <div class="col-md-3">
                            	<div class="w-bg">
                            		<p>Saturday</p>
                                	<p>10/8/2016</p>
                                </div>
								<div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                            </div>
                            <div class="col-md-3">
                            	<div class="w-bg">
                            		<p>Sunday</p>
                                	<p>10/9/2016</p>
                                </div>
								<div class="time-slot hover">
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div data-toggle="modal" data-target="#myModal" class="time-slot hover hover1">
                                	<p>9:00 AM</p>
                                    <p>to</p>
                                    <p>11:00 AM</p>
                                </div>
                                <div class="time-slot hover">
                                </div>
                            </div>
                          </div>
                    </div>
                </div>
                </div>
			</div>
  		</div>
    </div>
	<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Desmo</h4>
      </div>
      <form class="cnt-f">
            <div class="form-group">
              <label for="recipient-name" class="form-control-label">Recipient:</label>
              <input type="text" class="form-control" id="recipient-name">
            </div>
            <div class="form-group">
              <label for="message-text" class="form-control-label">Message:</label>
              <textarea class="form-control" id="message-text"></textarea>
            </div>
          </form>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<?php include('footer.php');?>
