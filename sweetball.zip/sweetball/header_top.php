<?php 
include('module/config.php');
include('module/functions.php');
@session_start();
ob_start();
if(isset($_SESSION['username']) && $_SESSION['username']!='')
{
	//header("location:home.php");
}
$sql_seting=mysql_query("select * from mp_general_seting");
$fetch_seting=mysql_fetch_array($sql_seting);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Maker Place</title>
<link href="https://fonts.googleapis.com/css?family=PT+Sans" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" />
<link href="css/datepick.css" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="js/jquery.plugin.js"></script>
<script src="js/jquery.datepick.js"></script>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>




		<link href="css/introLoader.css" rel="stylesheet">
		<script src="js/jquery.easing.1.3.js"></script>
        <script src="js/spin.min.js"></script>
        <script src="js/jquery.introLoader.min.js"></script>
        




<script>
$(document).ready(function(){
  $('.nav-pills li').click(function(){
    $('.nav-pills li').removeClass("active");
    $(this).addClass("active");
});
});
</script>


<script>
$(function() {
	$('#popupDatepicker').datepick();
	$('#inlineDatepicker').datepick({onSelect: showDate});
});

function showDate(date) {
	alert('The date chosen is ' + date);
}
</script>
<script>
  $( function() {
    $( "#popupDatepicker" ).datepick();
  } );
  </script>
<script>

$(document).ready(function(e) {
       $(".time-slot").click(function(){
$(this).toggleClass("red");
})
   });
</script>
<script>
$(document).ready(function(){
    $("#message_booking").click(function(){
        $("#message_booking").hide();
    });
});
</script>
<script>
$("input[type='button']").toggle(function (){
           $(this).val("Pause");
        }, function(){
        $(this).val("Play");
});
</script>

<?php //include('footer.php');?>

</head>

<body>

<div class="topbar widfloat">
<div class="container">
	<div class="">
		<div class="topLeft pull-left">
			<ul>
            	<?php if($fetch_seting['contact_number']!=''){?><li><i class="fa fa-mobile" aria-hidden="true"></i><?=$fetch_seting['contact_number']?></li><?php } ?>
				<?php if($fetch_seting['email_id']!=''){?><li><i class="fa fa-envelope-o" aria-hidden="true"></i><?=$fetch_seting['email_id']?></li><?php } ?>
			</ul>
		</div>
		<div class="topRight pull-right">
			<ul class="hidden-xs">
				<li><a href="<?=$fetch_seting['facebook_url']?>" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
				<li><a href="<?=$fetch_seting['twiter_url']?>" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
				<li><a href="<?=$fetch_seting['linkdin_url']?>" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
				<li><a href="<?=$fetch_seting['google_puluse_url']?>" target="_blank"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
				<li><a href="<?=$fetch_seting['pinterest_url']?>" target="_blank"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a></li>
			</ul>
		</div>
	</div>
</div>
</div>


