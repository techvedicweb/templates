<?php 
include('module/config.php');
session_start();
$userid=$_SESSION['userid'];
$pageid=$_GET['pageid'];
$bt=$_GET['bt'];
$currentpage=$_GET['currentpage'];
$slot_id=$_GET['q'];
$slot_date=$_GET['d'];
$start_dt=$_GET['start_dt'];
$end_dt=$_GET['end_dt'];
//echo  $slot_date;exit;
$pg=$_GET['pg'];
//echo $pg;exit;
//echo $slot_id.' '.$slot_date;
$check_user_num=mysql_query("select * from book_order where userid='$userid' and page_id='$pg' and slot_date BETWEEN '$start_dt' AND '$end_dt'");
$check_booking=mysql_query("select * from book_order where product_id='$slot_id' and slot_date='$slot_date' and page_id='$pg'");
if(mysql_num_rows($check_booking)>0)
{
	$check_id=mysql_fetch_array($check_booking);
	if($userid=='1'){
	
		$query_exc=mysql_query("delete from book_order where order_id='".$check_id['order_id']."'");
		echo "<div class='alrt'><a href='home.php'><i class='fa fa-check' aria-hidden='true'></i>Booking Update<i class='fa fa-times i-right' aria-hidden='true'></i></a></div>";
	?><meta http-equiv="refresh" content="1; url=http://sweetballinfra.com/dev/makerplace/home.php?pageid=<?=$pageid?>&bt=<?=$bt?>&currentpage=<?=$currentpage?>" />
	<?php }
	else{
	echo "<div class='alrt'><a href='home.php'><i class='fa fa-check' aria-hidden='true'></i>Allready Booked<i class='fa fa-times i-right' aria-hidden='true'></i></a></div>";
?>
		<meta http-equiv="refresh" content="1; url=http://sweetballinfra.com/dev/makerplace/home.php?pageid=<?=$pageid?>&bt=<?=$bt?>&currentpage=<?=$currentpage?>" />
		<?php
	}
}

else if(mysql_num_rows($check_user_num)>2){
echo "<div class='alrt'><a href='home.php'><i class='fa fa-check' aria-hidden='true'></i>Not Alowed<i class='fa fa-times i-right' aria-hidden='true'></i></a></div>";
		?>
		<meta http-equiv="refresh" content="1; url=http://sweetballinfra.com/dev/makerplace/home.php?pageid=<?=$pageid?>&bt=<?=$bt?>&currentpage=<?=$currentpage?>" />
	<?php	
}
else{
$query_exc=mysql_query("Insert into book_order set product_id='$slot_id', slot_date='$slot_date', userid='$userid', page_id='$pg', order_date=now()");
if($query_exc)
{
	echo "<div class='alrt'><a href='home.php'><i class='fa fa-check' aria-hidden='true'></i>Booking Successful<i class='fa fa-times i-right' aria-hidden='true'></i></a></div>";
		?>
		<meta http-equiv="refresh" content="1; url=http://sweetballinfra.com/dev/makerplace/home.php?pageid=<?=$pageid?>&bt=<?=$bt?>&currentpage=<?=$currentpage?>" />
		<?php
}
}
?>

