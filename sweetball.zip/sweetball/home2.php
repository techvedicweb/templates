<?php 
$current_date = date('Y-m-d');
echo $current_date.'<br>';
echo strtotime($current_date).'<br><br>';
for($i=1;$i<=7;$i++)
{
 $tomorrow = date("Y-m-d", strtotime("+$i day")).'<br/>';
 /*if($i==1){echo 'Monday';}
 if($i==2){echo 'Tuesday';}
 if($i==3){echo 'Wednesday';}
 if($i==4){echo 'Thursday';}
 if($i==5){echo 'Friday';}
 if($i==6){echo 'Saturday';}
 if($i==7){echo 'Sunday';}*/
echo date("l", strtotime("+$i day")).'<br />';
 echo '<br />'.$tomorrow;
}
?>
<br/><br/><br/><br/>
<?php 
$day_of_week = date('N', strtotime('2016-10-01'));

$given_date = strtotime(date("01-10-2016"));

$first_of_week =  date('Y-m-d', strtotime("- {$day_of_week} day", $given_date));

$first_of_week = strtotime($first_of_week);

for($i=0 ;$i<=6; $i++) {
    $week_array[] = date('Y-m-d', strtotime("+ {$i} day", $first_of_week));
}

print_r($week_array);?>


<br/>
<?php
function GetCurrentWeekDates()
{
    if (date('D') != 'Mon') {
        $startdate = date('Y-m-d', strtotime('last Monday'));
		
    } else {
        $startdate = date('Y-m-d');
		//echo $startdate;exit;
    }

//always next saturday
    if (date('D') != 'Sat') {
        $enddate = date('Y-m-d', strtotime('next Saturday'));
    } else {
        $enddate = date('Y-m-d');
    }

    $DateArray = array();
    $timestamp = strtotime($startdate);
    while ($startdate <= $enddate) {
        $startdate = date('Y-m-d', $timestamp);
		//echo $startdate;exit;
        $DateArray[] = $startdate;
        $timestamp = strtotime('+1 days', strtotime($startdate));
    }
    return $DateArray;
}
print_r(GetCurrentWeekDates());
?>