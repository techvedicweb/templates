<?php
include('module/config.php');
include('module/functions.php');
//session_start();
	if(isset( $_REQUEST["taskid"] ) && !empty( $_REQUEST["taskid"] ) ){
        $taskid = $_REQUEST['taskid'];
		//echo '<script>alert("School Profile Complete Detail Updated!");</script>';exit;
        $sql="select * from book_order where order_id='$taskid'";
	}
	else{
		$sql="select * from book_order";
	}
	$result=mysql_query($sql);
	$results = array();
	while($row = mysql_fetch_array($result)) {
			$results['booking_id'] = $row['order_id'];
			$results['old_proid'] = $row['product_id'];
			$results['old_date'] = $row['slot_date'];
			$results['old_userid'] = $row['userid'];
			$results['old_username'] = get_user_name($row['userid']);
			//$results['old_userid'] = $row['userid'];
			
			$results['old_pageid'] = $row['page_id'];
		$val_num=substr($row['product_id'], strpos($row['product_id'], "_") + 1);
		if($val_num==1){ $results['slot_time']='9 AM'; }
		if($val_num==2){ $results['slot_time']='11 AM'; }
		if($val_num==3){ $results['slot_time']='1 PM'; }
		if($val_num==4){ $results['slot_time']='3 PM'; }
		if($val_num==5){ $results['slot_time']='5 PM'; }
		if($val_num==6){ $results['slot_time']='7 PM'; }
		
			
			
	}
//echo $results['old_date'];exit;
	echo json_encode($results,JSON_UNESCAPED_SLASHES);
?>
