<?php include('header_top.php');?>
<?php include('header.php');?>
<?php
if(!isset($_SESSION['username']))
{
header("location:index.php");
}
?>
<div class="auto">
<div class="schedule">
	
	<div class="left">
		<?php include("sidebar.php");?>
    </div>
	
	<?php
    (int)$currentpage = (!empty($_GET["currentpage"]))?$_GET["currentpage"]:0;
    (int)$nextpage = $currentpage + 1;
    (int)$prevpage = $currentpage - 1;
?>
    <div class="right" id="show_date">
		<?php 
				if(isset($_REQUEST['pageid']) && $_REQUEST['pageid']!='')
				{
				$page_pageid=$_REQUEST['pageid'];
				}
				else{
					$page_pageid=1;
				}
				?>
    	<div id="element" class="introLoading"></div>
        <script>
			$(function() {
				$("#element").introLoader();
            });
		</script>
		<div id="exTab1" class="">	
			<ul  class="nav nav-pills">
                <li <?php if($_REQUEST['bt']=='01'){ echo "class='active'";}?>><a  href="<?php echo "{$_SERVER['PHP_SELF']}?pageid=".$page_pageid."&bt=01&currentpage=$prevpage"; ?>" class="pr-none">Previous Week</a></li>
                <li <?php if(!isset($_REQUEST['bt'])){ echo "class='active'";}?>><a href="<?php echo "{$_SERVER['PHP_SELF']}";?>" >Current Week</a></li>
                <li <?php if($_REQUEST['bt']=='02'){ echo "class='active'";}?>><a href="<?php echo "{$_SERVER['PHP_SELF']}?pageid=".$page_pageid."&bt=02&currentpage=$nextpage"; ?>" >Next Week<i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
			</ul>
			<?php
			 $ts = date(strtotime('last sunday'));
            $ts += $currentpage * 86400 * 7;
            $dow = date('w' , $ts);
            $offset = $dow;

            $ts = $ts - $offset * 86400;
            for ($x=0 ; $x<7 ; $x++,$ts += 86400) {
               $get_date[]=date("m/d/Y", $ts);
			   //$get_date_time[]=date("m/d/Y H:i:s", $ts);
            }
			//print_r($get_date);exit;
        ?>
			<div class="tab-content clearfix">
            	<div id="message_booking"></div>
                <div class="tab-pane active" id="1a">
				<?php 
				if(isset($_REQUEST['pageid']) && $_REQUEST['pageid']!='')
				{
				$pageid=$_REQUEST['pageid'];
				//echo $pageid;
				echo '<h3>'.GetPageTitle($pageid).'</h3>';
				}
				else{
					$pageid=1;
					echo '<h3>'.GetPageTitle(1).'</h3>';
				}
				?>
                    <div class="celender">
                    	<div class="col-md-6">
                            <div class="col-md-3">
                            	<div class="w-bg">
                            	<h4>Time</h4>
                                </div>
                                <div class="brd-time">
								<?php 
								$sql_time=mysql_query("select * from mp_time order by id asc");
								while($fetch_time=mysql_fetch_array($sql_time))
								{
								?>
                                	<div class="time">
                                	<div class="time-left">
                                    	<p><?=$fetch_time['slot_time'];?></p>
                                    </div>
                                    <div class="time-right">
                                    	<div class="line"></div>
                                        <div class="line"></div>
                                        <div class="line"></div>
                                    </div>
                                </div>
								<?php }?>
								   
								   </div>
                            </div>
<?php
if(isset($_REQUEST['pageid']) && isset($_REQUEST['bt']) && isset($_REQUEST['currentpage']))
{
$pageid=$_REQUEST['pageid'];
$bt=$_REQUEST['bt'];
$currentpage=$_REQUEST['currentpage'];
}
?>				
<script>
function isert_id(st,da,pg) {
	//alert(st);
	var pageid = "<?php echo $pageid;?>";
	var bt = "<?php echo $bt;?>";
	var currentpage = "<?php echo $currentpage;?>";
	//alert(cururl);
  if (st=="") {
    document.getElementById("message_booking").innerHTML="";
    return;
  } 
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("message_booking").innerHTML=this.responseText;
    }
  }
  xmlhttp.open("GET","book_slots.php?q="+st+"&d="+da+"&pg="+pg+"&pageid="+pageid+"&bt="+bt+"&currentpage="+currentpage+"&start_dt="+<?=$get_date[0]?>+"&end_dt="+<?=$get_date[6]?>,true);
  xmlhttp.send();
}
</script>
<?php
/*$timezone = new DateTimeZone("Asia/Kolkata" );
$date = new DateTime();
$date->setTimezone($timezone );
echo  $date->format( 'H:i:s A  /  D, M jS, Y' );
*/
$date = date_default_timezone_set('Asia/Kolkata');
$today = strtotime(date("m/d/Y g:i a"));
$cur_day=date("d");
$cur_month=date("m");
$cur_year=date("Y");

//echo $today;
// $checkdate_array=array($get_date[0],$get_date[1],$get_date[2],$get_date[3],$get_date[4],$get_date[5],$get_date[6]);
$edit_limqu=mysql_query("select * from mp_booking_limit where id=1");
$res_limval=mysql_fetch_array($edit_limqu);		   
			   
			   
$sql_conu_book=mysql_query("select slot_date from book_order where userid='".$_SESSION['userid']."' and slot_date BETWEEN '".$get_date[0]."' AND '".$get_date[6]."'");
if($_SESSION['userid']==1)
{
$booking_limval='2000000000000';
}
else{
$booking_limval=$res_limval['limval'];
}
?>
							<!--<div id="show_date"></div>-->
<!--<div id="txtHint"><b>Person info will be listed here.</b></div>-->
                           <div class="col-md-3">
                            	<div class="w-bg">
									<p>Sunday</p>
                                	<p><?=$get_date[0]?></p>
                            		
                                </div>
								<?php 
								$sql_holyday1=mysql_query("select * from mp_holyday where holydate='".$get_date[0]."' and status='1'");
								if(mysql_num_rows($sql_holyday1)>0)
								{
									echo '<p class="holyday">holiday</p>';
								
								}
								
								
								else{ 
									$sql_maintenance1=mysql_query("select * from mp_maintenance where maintenance='".$get_date[0]."' and machine_id='$pageid' and status='1'");
								if(mysql_num_rows($sql_maintenance1)>0)
								{
									echo '<p class="maintenance">Maintenance</p>';
								}
									else{
								$check_time1=strtotime($get_date[0].' 09:00 am');
								//echo $today;
								if ($check_time1 < $today) 
								{
								$pid1=str_replace('/','',$get_date[0]).'_1';
								$sql_book1=mysql_query("select * from book_order where product_id='$pid1' and slot_date='".$get_date[0]."' and page_id='$pageid'");
								$fetch_user1=mysql_fetch_array($sql_book1);
								$query_exc1=mysql_query("delete from book_order where order_id='".$fetch_user1['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid1=str_replace('/','',$get_date[0]).'_1';
								$sql_book1=mysql_query("select * from book_order where product_id='$pid1' and slot_date='".$get_date[0]."' and page_id='$pageid'");
								$fetch_user1=mysql_fetch_array($sql_book1);
								$num_rows1=mysql_num_rows($sql_book1);
								if($num_rows1>0)
								{
								
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user1['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user1['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book1)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book1)>0){ if($fetch_user1['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book1)==0){?>onclick="isert_id('<?=$pid1?>','<?=$get_date[0]?>','<?=$pageid?>')"<?php } ?>>
								<?php 
									
								if(mysql_num_rows($sql_book1)>0)
								{ 
								if($fetch_user1['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user1['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p class="BookedBy" id="BookedBy">Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user1['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								//}
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid1?>','<?=$get_date[0]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								} 
								$check_time2=strtotime($get_date[0].' 11:00 am');
								if ($check_time2 < $today) 
								{
								$pid2=str_replace('/','',$get_date[0]).'_2';
								$sql_book2=mysql_query("select * from book_order where product_id='$pid2' and slot_date='".$get_date[0]."' and page_id='$pageid'");
								$fetch_user2=mysql_fetch_array($sql_book2);
								$query_exc2=mysql_query("delete from book_order where order_id='".$fetch_user2['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid2=str_replace('/','',$get_date[0]).'_2';
								$sql_book2=mysql_query("select * from book_order where product_id='$pid2' and slot_date='".$get_date[0]."' and page_id='$pageid'");
								$fetch_user2=mysql_fetch_array($sql_book2);
								$num_rows2=mysql_num_rows($sql_book2);
								if($num_rows2>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user2['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user2['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book2)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book2)>0){ if($fetch_user2['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book2)==0){?>onclick="isert_id('<?=$pid2?>','<?=$get_date[0]?>','<?=$pageid?>')"<?php }?>>
								<?php 
								if(mysql_num_rows($sql_book2)>0)
								{ 
								if($fetch_user2['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user2['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user2['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div <?php if($_SESSION['userid']=='1'){?>data-toggle="modal" id='<?=$fetch_user2['order_id']?>'<?php }?> data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid2?>','<?=$get_date[0]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								$check_time3=strtotime($get_date[0].' 01:00 pm');
								if ($check_time3 < $today) 
								{
								$pid3=str_replace('/','',$get_date[0]).'_3';
								$sql_book3=mysql_query("select * from book_order where product_id='$pid3' and slot_date='".$get_date[0]."' and page_id='$pageid'");
								$fetch_user3=mysql_fetch_array($sql_book3);
								$query_exc3=mysql_query("delete from book_order where order_id='".$fetch_user3['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid3=str_replace('/','',$get_date[0]).'_3';
								$sql_book3=mysql_query("select * from book_order where product_id='$pid3' and slot_date='".$get_date[0]."' and page_id='$pageid'");
								$fetch_user3=mysql_fetch_array($sql_book3);
								$num_rows3=mysql_num_rows($sql_book3);
								if($num_rows3>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user3['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user3['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book3)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book3)>0){ if($fetch_user3['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book3)==0){?>onclick="isert_id('<?=$pid3?>','<?=$get_date[0]?>','<?=$pageid?>')"<?php } ?>>
								<?php 
								if(mysql_num_rows($sql_book3)>0)
								{ 
								if($fetch_user3['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user3['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user3['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid3?>','<?=$get_date[0]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								$check_time4=strtotime($get_date[0].' 03:00 pm');
								if ($check_time4 < $today) 
								{
								$pid4=str_replace('/','',$get_date[0]).'_4';
								$sql_book4=mysql_query("select * from book_order where product_id='$pid4' and slot_date='".$get_date[0]."' and page_id='$pageid'");
								$fetch_user4=mysql_fetch_array($sql_book4);
								$query_exc4=mysql_query("delete from book_order where order_id='".$fetch_user4['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid4=str_replace('/','',$get_date[0]).'_4';
								$sql_book4=mysql_query("select * from book_order where product_id='$pid4' and slot_date='".$get_date[0]."' and page_id='$pageid'");
								$fetch_user4=mysql_fetch_array($sql_book4);
								$num_rows4=mysql_num_rows($sql_book4);
								if($num_rows4>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user4['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user4['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book4)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book4)>0){ if($fetch_user4['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book4)==0){?>onclick="isert_id('<?=$pid4?>','<?=$get_date[0]?>','<?=$pageid?>')"<?php }?>>
								<?php 
								if(mysql_num_rows($sql_book1)>0)
								{ 
								if($fetch_user4['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user4['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user4['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid4?>','<?=$get_date[0]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								$check_time5=strtotime($get_date[0].' 05:00 pm');
								if ($check_time5 < $today) 
								{
								$pid5=str_replace('/','',$get_date[0]).'_5';
								$sql_book5=mysql_query("select * from book_order where product_id='$pid5' and slot_date='".$get_date[0]."' and page_id='$pageid'");
								$fetch_user5=mysql_fetch_array($sql_book5);
								$query_exc5=mysql_query("delete from book_order where order_id='".$fetch_user5['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid5=str_replace('/','',$get_date[0]).'_5';
								$sql_book5=mysql_query("select * from book_order where product_id='$pid5' and slot_date='".$get_date[0]."' and page_id='$pageid'");
								$fetch_user5=mysql_fetch_array($sql_book5);
								$num_rows5=mysql_num_rows($sql_book5);
								if($num_rows5>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user5['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user5['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book5)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book5)>0){ if($fetch_user5['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book5)==0){?>onclick="isert_id('<?=$pid5?>','<?=$get_date[0]?>','<?=$pageid?>')"<?php }?>>
								<?php 
								if(mysql_num_rows($sql_book5)>0)
								{ 
								if($fetch_user5['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user5['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user5['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid5?>','<?=$get_date[0]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								$check_time6=strtotime($get_date[0].' 07:00 pm');
								if ($check_time6 < $today) 
								{
								$pid6=str_replace('/','',$get_date[0]).'_6';
								$sql_book6=mysql_query("select * from book_order where product_id='$pid6' and slot_date='".$get_date[0]."' and page_id='$pageid'");
								$fetch_user6=mysql_fetch_array($sql_book6);
								$query_exc6=mysql_query("delete from book_order where order_id='".$fetch_user6['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid6=str_replace('/','',$get_date[0]).'_6';
								$sql_book6=mysql_query("select * from book_order where product_id='$pid6' and slot_date='".$get_date[0]."' and page_id='$pageid'");
								$fetch_user6=mysql_fetch_array($sql_book6);
								$num_rows6=mysql_num_rows($sql_book6);
								if($num_rows6>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user6['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user6['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book6)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book6)>0){ if($fetch_user6['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book6)==0){?>onclick="isert_id('<?=$pid6?>','<?=$get_date[0]?>','<?=$pageid?>')"<?php }?>>
								<?php 
								if(mysql_num_rows($sql_book6)>0)
								{ 
								if($fetch_user6['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user6['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user6['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid6?>','<?=$get_date[0]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								}
								}
								?>
                             </div>
                            <div class="col-md-3">
                            	<div class="w-bg">
									<p>Monday</p>
                                	<p><?=$get_date[1]?></p>
                            		
                                </div>
                                <?php 
								$sql_holyday2=mysql_query("select * from mp_holyday where holydate='".$get_date[1]."' and status='1'");
								if(mysql_num_rows($sql_holyday2)>0)
								{
									echo '<p class="holyday">holiday</p>';
								}
								else{ 
									$sql_maintenance2=mysql_query("select * from mp_maintenance where maintenance='".$get_date[1]."' and machine_id='$pageid' and status='1'");
								if(mysql_num_rows($sql_maintenance2)>0)
								{
									echo '<p class="maintenance">Maintenance</p>';
								}
									else{
								$check_time7=strtotime($get_date[1].' 09:00 am');
								if ($check_time7 < $today) 
								{
								$pid7=str_replace('/','',$get_date[1]).'_1';
								$sql_book7=mysql_query("select * from book_order where product_id='$pid7' and slot_date='".$get_date[1]."' and page_id='$pageid'");
								$fetch_user7=mysql_fetch_array($sql_book7);
								$query_exc7=mysql_query("delete from book_order where order_id='".$fetch_user7['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid7=str_replace('/','',$get_date[1]).'_1';
								$sql_book7=mysql_query("select * from book_order where product_id='$pid7' and slot_date='".$get_date[1]."' and page_id='$pageid'");
								$fetch_user7=mysql_fetch_array($sql_book7);
								$num_rows7=mysql_num_rows($sql_book7);
								if($num_rows7>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user7['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user7['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book7)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book7)>0){ if($fetch_user7['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book7)==0){?>onclick="isert_id('<?=$pid7?>','<?=$get_date[1]?>','<?=$pageid?>')"<?php }?>>
								<?php 
								if(mysql_num_rows($sql_book7)>0)
								{ 
								if($fetch_user7['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user7['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user7['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid7?>','<?=$get_date[1]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								$check_time8=strtotime($get_date[1].' 11:00 am');
								if ($check_time8 < $today) 
								{
								$pid8=str_replace('/','',$get_date[1]).'_2';
								$sql_book8=mysql_query("select * from book_order where product_id='$pid8' and slot_date='".$get_date[1]."' and page_id='$pageid'");
								$fetch_user8=mysql_fetch_array($sql_book8);
								$query_exc8=mysql_query("delete from book_order where order_id='".$fetch_user8['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid8=str_replace('/','',$get_date[1]).'_2';
								$sql_book8=mysql_query("select * from book_order where product_id='$pid8' and slot_date='".$get_date[1]."' and page_id='$pageid'");
								$fetch_user8=mysql_fetch_array($sql_book8);
								$num_rows8=mysql_num_rows($sql_book8);
								if($num_rows8>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user8['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user8['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book8)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book8)>0){ if($fetch_user8['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book8)==0){?>onclick="isert_id('<?=$pid8?>','<?=$get_date[1]?>','<?=$pageid?>')"<?php }?>><?php 
								if(mysql_num_rows($sql_book8)>0)
								{ 
								if($fetch_user8['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user8['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user8['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid8?>','<?=$get_date[1]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								$check_time9=strtotime($get_date[1].' 01:00 pm');
								if ($check_time9 < $today) 
								{
								$pid9=str_replace('/','',$get_date[1]).'_3';
								$sql_book9=mysql_query("select * from book_order where product_id='$pid9' and slot_date='".$get_date[1]."' and page_id='$pageid'");
								$fetch_user9=mysql_fetch_array($sql_book9);
								$query_exc9=mysql_query("delete from book_order where order_id='".$fetch_user9['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid9=str_replace('/','',$get_date[1]).'_3';
								$sql_book9=mysql_query("select * from book_order where product_id='$pid9' and slot_date='".$get_date[1]."' and page_id='$pageid'");
								$fetch_user9=mysql_fetch_array($sql_book9);
								$num_rows9=mysql_num_rows($sql_book9);
								if($num_rows9>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user9['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user9['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book9)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book9)>0){ if($fetch_user9['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book9)==0){?>onclick="isert_id('<?=$pid9?>','<?=$get_date[1]?>','<?=$pageid?>')"<?php }?>><?php 
								if(mysql_num_rows($sql_book9)>0)
								{ 
								if($fetch_user9['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user9['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user9['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid9?>','<?=$get_date[1]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								$check_time10=strtotime($get_date[1].' 03:00 pm');
								if ($check_time10 < $today) 
								{
								$pid10=str_replace('/','',$get_date[1]).'_4';
								$sql_book10=mysql_query("select * from book_order where product_id='$pid10' and slot_date='".$get_date[1]."' and page_id='$pageid'");
								$fetch_user10=mysql_fetch_array($sql_book10);
								$query_exc10=mysql_query("delete from book_order where order_id='".$fetch_user10['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid10=str_replace('/','',$get_date[1]).'_4';
								$sql_book10=mysql_query("select * from book_order where product_id='$pid10' and slot_date='".$get_date[1]."' and page_id='$pageid'");
								$fetch_user10=mysql_fetch_array($sql_book10);
								$num_rows10=mysql_num_rows($sql_book10);
								if($num_rows10>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user10['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user10['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book10)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book10)>0){ if($fetch_user10['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book10)==0){?>onclick="isert_id('<?=$pid10?>','<?=$get_date[1]?>','<?=$pageid?>')"<?php }?>>
								<?php 
								if(mysql_num_rows($sql_book10)>0)
								{ 
								if($fetch_user10['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user10['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user10['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid10?>','<?=$get_date[1]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								$check_time11=strtotime($get_date[1].' 05:00 pm');
								if ($check_time11 < $today) 
								{
								$pid11=str_replace('/','',$get_date[1]).'_5';
								$sql_book11=mysql_query("select * from book_order where product_id='$pid11' and slot_date='".$get_date[1]."' and page_id='$pageid'");
								$fetch_user11=mysql_fetch_array($sql_book11);
								$query_exc11=mysql_query("delete from book_order where order_id='".$fetch_user11['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid11=str_replace('/','',$get_date[1]).'_5';
								$sql_book11=mysql_query("select * from book_order where product_id='$pid11' and slot_date='".$get_date[1]."' and page_id='$pageid'");
								$fetch_user11=mysql_fetch_array($sql_book11);
								$num_rows11=mysql_num_rows($sql_book11);
								if($num_rows11>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user11['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user11['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book11)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book11)>0){ if($fetch_user11['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book11)==0){?>onclick="isert_id('<?=$pid11?>','<?=$get_date[1]?>','<?=$pageid?>')"<?php }?>>
								<?php 
								if(mysql_num_rows($sql_book11)>0)
								{ 
								if($fetch_user11['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user11['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user11['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid11?>','<?=$get_date[1]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								$check_time12=strtotime($get_date[1].' 07:00 pm');
								if ($check_time12 < $today) 
								{
								$pid12=str_replace('/','',$get_date[1]).'_6';
								$sql_book12=mysql_query("select * from book_order where product_id='$pid12' and slot_date='".$get_date[1]."' and page_id='$pageid'");
								$fetch_user12=mysql_fetch_array($sql_book12);
								$query_exc12=mysql_query("delete from book_order where order_id='".$fetch_user12['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid12=str_replace('/','',$get_date[1]).'_6';
								$sql_book12=mysql_query("select * from book_order where product_id='$pid12' and slot_date='".$get_date[1]."' and page_id='$pageid'");
								$fetch_user12=mysql_fetch_array($sql_book12);
								$num_rows12=mysql_num_rows($sql_book12);
								if($num_rows12>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user12['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user12['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book12)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book12)>0){ if($fetch_user12['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book12)==0){?>onclick="isert_id('<?=$pid12?>','<?=$get_date[1]?>','<?=$pageid?>')"<?php }?>>
								<?php 
								if(mysql_num_rows($sql_book12)>0)
								{ 
								if($fetch_user12['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user12['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user12['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid12?>','<?=$get_date[1]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								} 
								}
								}
								}
								?>
								</div>
                            <div class="col-md-3">
                            	<div class="w-bg">
								<p>Tuesday</p>
                                	<p><?=$get_date[2]?></p>
                            		
                                </div>
                                <?php 
								$sql_holyday3=mysql_query("select * from mp_holyday where holydate='".$get_date[2]."' and status='1'");
								if(mysql_num_rows($sql_holyday3)>0)
								{
									echo '<p class="holyday">holiday</p>';
								}
								else{ 
									$sql_maintenance3=mysql_query("select * from mp_maintenance where maintenance='".$get_date[2]."' and machine_id='$pageid' and status='1'");
								if(mysql_num_rows($sql_maintenance3)>0)
								{
									echo '<p class="maintenance">Maintenance</p>';
								}
									else{
								$check_time13=strtotime($get_date[2].' 09:00 am');
								if ($check_time13 < $today) 
								{
								$pid13=str_replace('/','',$get_date[2]).'_1';
								$sql_book13=mysql_query("select * from book_order where product_id='$pid13' and slot_date='".$get_date[2]."' and page_id='$pageid'");
								$fetch_user13=mysql_fetch_array($sql_book13);
								$query_exc13=mysql_query("delete from book_order where order_id='".$fetch_user13['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid13=str_replace('/','',$get_date[2]).'_1';
								$sql_book13=mysql_query("select * from book_order where product_id='$pid13' and slot_date='".$get_date[2]."' and page_id='$pageid'");
								$fetch_user13=mysql_fetch_array($sql_book13);
								$num_rows13=mysql_num_rows($sql_book13);
								if($num_rows13>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user13['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user13['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book13)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book13)>0){ if($fetch_user13['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book13)==0){?>onclick="isert_id('<?=$pid13?>','<?=$get_date[2]?>','<?=$pageid?>')"<?php }?>>
								<?php 
								if(mysql_num_rows($sql_book13)>0)
								{ 
								if($fetch_user13['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user13['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user13['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid13?>','<?=$get_date[2]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								} 
								}
								$check_time14=strtotime($get_date[2].' 11:00 am');
								if ($check_time14 < $today) 
								{
								$pid14=str_replace('/','',$get_date[2]).'_2';
								$sql_book14=mysql_query("select * from book_order where product_id='$pid14' and slot_date='".$get_date[2]."' and page_id='$pageid'");
								$fetch_user14=mysql_fetch_array($sql_book14);
								$query_exc14=mysql_query("delete from book_order where order_id='".$fetch_user14['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid14=str_replace('/','',$get_date[2]).'_2';
								$sql_book14=mysql_query("select * from book_order where product_id='$pid14' and slot_date='".$get_date[2]."' and page_id='$pageid'");
								$fetch_user14=mysql_fetch_array($sql_book14);
								$num_rows14=mysql_num_rows($sql_book14);
								if($num_rows14>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user14['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user14['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book14)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book14)>0){ if($fetch_user14['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book14)==0){?>onclick="isert_id('<?=$pid14?>','<?=$get_date[2]?>','<?=$pageid?>')"<?php }?>>
								<?php 
								if(mysql_num_rows($sql_book14)>0)
								{ 
								if($fetch_user14['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user14['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user14['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid14?>','<?=$get_date[2]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}  
								}
								$check_time15=strtotime($get_date[2].' 01:00 pm');
								if ($check_time15 < $today) 
								{
								$pid15=str_replace('/','',$get_date[2]).'_3';
								$sql_book15=mysql_query("select * from book_order where product_id='$pid15' and slot_date='".$get_date[2]."' and page_id='$pageid'");
								$fetch_user15=mysql_fetch_array($sql_book15);
								$query_exc15=mysql_query("delete from book_order where order_id='".$fetch_user15['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid15=str_replace('/','',$get_date[2]).'_3';
								$sql_book15=mysql_query("select * from book_order where product_id='$pid15' and slot_date='".$get_date[2]."' and page_id='$pageid'");
								$fetch_user15=mysql_fetch_array($sql_book15);
								$num_rows15=mysql_num_rows($sql_book15);
								if($num_rows15>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user15['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user15['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book15)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book15)>0){ if($fetch_user15['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book15)==0){?>onclick="isert_id('<?=$pid15?>','<?=$get_date[2]?>','<?=$pageid?>')"<?php }?>>																   
								<?php 
								if(mysql_num_rows($sql_book15)>0)
								{ 
								if($fetch_user15['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user15['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user15['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid15?>','<?=$get_date[2]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								} 
								}
								$check_time16=strtotime($get_date[2].' 03:00 pm');
								if ($check_time16 < $today) 
								{
								$pid16=str_replace('/','',$get_date[2]).'_4';
								$sql_book16=mysql_query("select * from book_order where product_id='$pid16' and slot_date='".$get_date[2]."' and page_id='$pageid'");
								$fetch_user16=mysql_fetch_array($sql_book16);
								$query_exc16=mysql_query("delete from book_order where order_id='".$fetch_user16['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid16=str_replace('/','',$get_date[2]).'_4';
								$sql_book16=mysql_query("select * from book_order where product_id='$pid16' and slot_date='".$get_date[2]."' and page_id='$pageid'");
								$fetch_user16=mysql_fetch_array($sql_book16);
								$num_rows16=mysql_num_rows($sql_book16);
								if($num_rows16>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user16['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user16['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book16)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book16)>0){ if($fetch_user16['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book16)==0){?>onclick="isert_id('<?=$pid16?>','<?=$get_date[2]?>','<?=$pageid?>')"<?php }?>>
								<?php 
								if(mysql_num_rows($sql_book16)>0)
								{ 
								if($fetch_user16['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user16['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user16['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid16?>','<?=$get_date[2]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}  
								}
								$check_time17=strtotime($get_date[2].' 05:00 pm');
								if ($check_time17 < $today) 
								{
								$pid17=str_replace('/','',$get_date[2]).'_5';
								$sql_book17=mysql_query("select * from book_order where product_id='$pid17' and slot_date='".$get_date[2]."' and page_id='$pageid'");
								$fetch_user17=mysql_fetch_array($sql_book17);
								$query_exc17=mysql_query("delete from book_order where order_id='".$fetch_user17['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid17=str_replace('/','',$get_date[2]).'_5';
								$sql_book17=mysql_query("select * from book_order where product_id='$pid17' and slot_date='".$get_date[2]."' and page_id='$pageid'");
								$fetch_user17=mysql_fetch_array($sql_book17);
								$num_rows17=mysql_num_rows($sql_book17);
								if($num_rows17>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user17['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user17['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book17)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book17)>0){ if($fetch_user17['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book17)==0){?>onclick="isert_id('<?=$pid17?>','<?=$get_date[2]?>','<?=$pageid?>')"<?php }?>>
								<?php 
								if(mysql_num_rows($sql_book17)>0)
								{ 
								if($fetch_user17['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user17['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user17['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid17?>','<?=$get_date[2]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								} 
								}
								$check_time18=strtotime($get_date[2].' 07:00 pm');
								if ($check_time18 < $today) 
								{
								$pid18=str_replace('/','',$get_date[2]).'_6';
								$sql_book18=mysql_query("select * from book_order where product_id='$pid18' and slot_date='".$get_date[2]."' and page_id='$pageid'");
								$fetch_user18=mysql_fetch_array($sql_book18);
								$query_exc18=mysql_query("delete from book_order where order_id='".$fetch_user18['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid18=str_replace('/','',$get_date[2]).'_6';
								$sql_book18=mysql_query("select * from book_order where product_id='$pid18' and slot_date='".$get_date[2]."' and page_id='$pageid'");
								$fetch_user18=mysql_fetch_array($sql_book18);
								$num_rows18=mysql_num_rows($sql_book18);
								if($num_rows18>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user18['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user18['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book18)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book18)>0){ if($fetch_user18['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book18)==0){?>onclick="isert_id('<?=$pid18?>','<?=$get_date[2]?>','<?=$pageid?>')"<?php }?>>					
								<?php 
								if(mysql_num_rows($sql_book18)>0)
								{ 
								if($fetch_user18['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user18['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user18['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid18?>','<?=$get_date[2]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}  
								} 
								}
								}
								?>
							   </div>
                    </div>
						<div class="col-md-6">
                            <div class="col-md-3">
                            	<div class="w-bg">
								<p>Wednesday</p>
                                	<p><?=$get_date[3]?></p>
                            		
                                </div>
								<?php 
								$sql_holyday4=mysql_query("select * from mp_holyday where holydate='".$get_date[3]."' and status='1'");
								if(mysql_num_rows($sql_holyday4)>0)
								{
									echo '<p class="holyday">holiday</p>';
								}
								else{ 
								$sql_maintenance4=mysql_query("select * from mp_maintenance where maintenance='".$get_date[3]."' and machine_id='$pageid' and status='1'");
								if(mysql_num_rows($sql_maintenance4)>0)
								{
									echo '<p class="maintenance">Maintenance</p>';
								}
									else{
								$check_time19=strtotime($get_date[3].' 09:00 am');
								if ($check_time19 < $today) 
								{
								$pid19=str_replace('/','',$get_date[3]).'_1';
								$sql_book19=mysql_query("select * from book_order where product_id='$pid19' and slot_date='".$get_date[3]."' and page_id='$pageid'");
								$fetch_user19=mysql_fetch_array($sql_book19);
								$query_exc19=mysql_query("delete from book_order where order_id='".$fetch_user19['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid19=str_replace('/','',$get_date[3]).'_1';
								$sql_book19=mysql_query("select * from book_order where product_id='$pid19' and slot_date='".$get_date[3]."' and page_id='$pageid'");
								$fetch_user19=mysql_fetch_array($sql_book19);
								$num_rows19=mysql_num_rows($sql_book19);
								if($num_rows19>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user19['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user19['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book19)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book19)>0){ if($fetch_user19['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book19)==0){?>onclick="isert_id('<?=$pid19?>','<?=$get_date[3]?>','<?=$pageid?>')"<?php }?>>
								<?php 
								if(mysql_num_rows($sql_book19)>0)
								{ 
								if($fetch_user19['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user19['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user19['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid19?>','<?=$get_date[3]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								$check_time20=strtotime($get_date[3].' 11:00 am');
								if ($check_time20 < $today) 
								{
								$pid20=str_replace('/','',$get_date[3]).'_2';
								$sql_book20=mysql_query("select * from book_order where product_id='$pid20' and slot_date='".$get_date[3]."' and page_id='$pageid'");
								$fetch_user20=mysql_fetch_array($sql_book20);
								$query_exc20=mysql_query("delete from book_order where order_id='".$fetch_user20['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid20=str_replace('/','',$get_date[3]).'_2';
								$sql_book20=mysql_query("select * from book_order where product_id='$pid20' and slot_date='".$get_date[3]."' and page_id='$pageid'");
								$fetch_user20=mysql_fetch_array($sql_book20);
								$num_rows20=mysql_num_rows($sql_book20);
								if($num_rows20>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user20['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user20['order_id']?>' data-target="#myModal" class="<?php if(mysql_num_rows($sql_book20)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book20)>0){ if($fetch_user20['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book20)==0){?>onclick="isert_id('<?=$pid20?>','<?=$get_date[3]?>','<?=$pageid?>')"<?php }?>>																   
								<?php 
								if(mysql_num_rows($sql_book20)>0)
								{ 
								if($fetch_user20['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user20['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user20['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid20?>','<?=$get_date[3]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								$check_time21=strtotime($get_date[3].' 01:00 pm');
								if ($check_time21 < $today) 
								{
								$pid21=str_replace('/','',$get_date[3]).'_3';
								$sql_book21=mysql_query("select * from book_order where product_id='$pid21' and slot_date='".$get_date[3]."' and page_id='$pageid'");
								$fetch_user21=mysql_fetch_array($sql_book21);
								$query_exc21=mysql_query("delete from book_order where order_id='".$fetch_user21['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid21=str_replace('/','',$get_date[3]).'_3';
								$sql_book21=mysql_query("select * from book_order where product_id='$pid21' and slot_date='".$get_date[3]."' and page_id='$pageid'");
								$fetch_user21=mysql_fetch_array($sql_book21);
								$num_rows21=mysql_num_rows($sql_book21);
								if($num_rows21>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user21['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user21['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book21)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book21)>0){ if($fetch_user21['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book21)==0){?>onclick="isert_id('<?=$pid21?>','<?=$get_date[3]?>','<?=$pageid?>')"<?php }?>>
								<?php 
								if(mysql_num_rows($sql_book21)>0)
								{ 
								if($fetch_user21['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user21['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user21['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid21?>','<?=$get_date[3]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								$check_time22=strtotime($get_date[3].' 03:00 pm');
								if ($check_time22 < $today) 
								{
								$pid22=str_replace('/','',$get_date[3]).'_4';
								$sql_book22=mysql_query("select * from book_order where product_id='$pid22' and slot_date='".$get_date[3]."' and page_id='$pageid'");
								$fetch_user22=mysql_fetch_array($sql_book22);
								$query_exc22=mysql_query("delete from book_order where order_id='".$fetch_user22['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid22=str_replace('/','',$get_date[3]).'_4';
								$sql_book22=mysql_query("select * from book_order where product_id='$pid22' and slot_date='".$get_date[3]."' and page_id='$pageid'");
								$fetch_user22=mysql_fetch_array($sql_book22);
								$num_rows22=mysql_num_rows($sql_book22);
								if($num_rows22>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user22['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user22['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book22)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book22)>0){ if($fetch_user22['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book22)==0){?>onclick="isert_id('<?=$pid22?>','<?=$get_date[3]?>','<?=$pageid?>')"<?php }?>>
								<?php 
								if(mysql_num_rows($sql_book22)>0)
								{ 
								if($fetch_user22['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user22['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user22['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid22?>','<?=$get_date[3]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								$check_time23=strtotime($get_date[3].' 05:00 pm');
								if ($check_time23 < $today) 
								{
								$pid23=str_replace('/','',$get_date[3]).'_5';
								$sql_book23=mysql_query("select * from book_order where product_id='$pid23' and slot_date='".$get_date[3]."' and page_id='$pageid'");
								$fetch_user23=mysql_fetch_array($sql_book23);
								$query_exc23=mysql_query("delete from book_order where order_id='".$fetch_user23['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid23=str_replace('/','',$get_date[3]).'_5';
								$sql_book23=mysql_query("select * from book_order where product_id='$pid23' and slot_date='".$get_date[3]."' and page_id='$pageid'");
								$fetch_user23=mysql_fetch_array($sql_book23);
								$num_rows23=mysql_num_rows($sql_book23);
								if($num_rows23>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user23['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user23['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book23)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book23)>0){ if($fetch_user23['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book23)==0){?>onclick="isert_id('<?=$pid23?>','<?=$get_date[3]?>','<?=$pageid?>')"<?php }?>>																   
								<?php 
								if(mysql_num_rows($sql_book23)>0)
								{ 
								if($fetch_user23['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user23['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user23['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid23?>','<?=$get_date[3]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								$check_time24=strtotime($get_date[3].' 07:00 pm');
								if ($check_time24 < $today) 
								{
								$pid24=str_replace('/','',$get_date[3]).'_6';
								$sql_book24=mysql_query("select * from book_order where product_id='$pid24' and slot_date='".$get_date[3]."' and page_id='$pageid'");
								$fetch_user24=mysql_fetch_array($sql_book24);
								$query_exc24=mysql_query("delete from book_order where order_id='".$fetch_user24['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid24=str_replace('/','',$get_date[3]).'_6';
								$sql_book24=mysql_query("select * from book_order where product_id='$pid24' and slot_date='".$get_date[3]."' and page_id='$pageid'");
								$fetch_user24=mysql_fetch_array($sql_book24);
								$num_rows24=mysql_num_rows($sql_book24);
								if($num_rows24>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user24['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user24['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book24)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book24)>0){ if($fetch_user24['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book24)==0){?>onclick="isert_id('<?=$pid24?>','<?=$get_date[3]?>','<?=$pageid?>')"<?php }?>>
								<?php 
								if(mysql_num_rows($sql_book24)>0)
								{ 
								if($fetch_user24['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user24['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user24['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid24?>','<?=$get_date[3]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								}
								}
								?>
								</div>
                            <div class="col-md-3">
                            	<div class="w-bg">
								<p>Thursday</p>
                                	<p><?=$get_date[4]?></p>
                            		
                                </div>
    							<?php 
								$sql_holyday5=mysql_query("select * from mp_holyday where holydate='".$get_date[4]."' and status='1'");
								if(mysql_num_rows($sql_holyday5)>0)
								{
									echo '<p class="holyday">holiday</p>';
								}
								else{ 
								$sql_maintenance5=mysql_query("select * from mp_maintenance where maintenance='".$get_date[4]."' and machine_id='$pageid' and status='1'");
								if(mysql_num_rows($sql_maintenance5)>0)
								{
									echo '<p class="maintenance">Maintenance</p>';
								}
									else{
								$check_time25=strtotime($get_date[4].' 09:00 am');
								if ($check_time25 < $today) 
								{
								$pid25=str_replace('/','',$get_date[4]).'_1';
								$sql_book25=mysql_query("select * from book_order where product_id='$pid25' and slot_date='".$get_date[4]."' and page_id='$pageid'");
								$fetch_user25=mysql_fetch_array($sql_book25);
								$query_exc25=mysql_query("delete from book_order where order_id='".$fetch_user25['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid25=str_replace('/','',$get_date[4]).'_1';
								$sql_book25=mysql_query("select * from book_order where product_id='$pid25' and slot_date='".$get_date[4]."' and page_id='$pageid'");
								$fetch_user25=mysql_fetch_array($sql_book25);
								$num_rows25=mysql_num_rows($sql_book25);
								if($num_rows25>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user25['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user25['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book25)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book25)>0){ if($fetch_user25['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book25)==0){?>onclick="isert_id('<?=$pid25?>','<?=$get_date[4]?>','<?=$pageid?>')"<?php }?>>
								<?php 
								if(mysql_num_rows($sql_book25)>0)
								{ 
								if($fetch_user25['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user25['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user25['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid25?>','<?=$get_date[4]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								$check_time26=strtotime($get_date[4].' 11:00 am');
								if ($check_time26 < $today) 
								{
								$pid26=str_replace('/','',$get_date[4]).'_2';
								$sql_book26=mysql_query("select * from book_order where product_id='$pid26' and slot_date='".$get_date[4]."' and page_id='$pageid'");
								$fetch_user26=mysql_fetch_array($sql_book26);
								$query_exc26=mysql_query("delete from book_order where order_id='".$fetch_user26['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid26=str_replace('/','',$get_date[4]).'_2';
								$sql_book26=mysql_query("select * from book_order where product_id='$pid26' and slot_date='".$get_date[4]."' and page_id='$pageid'");
								$fetch_user26=mysql_fetch_array($sql_book26);
								$num_rows26=mysql_num_rows($sql_book26);
								if($num_rows26>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user26['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user26['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book26)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book26)>0){ if($fetch_user26['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book26)==0){?>onclick="isert_id('<?=$pid26?>','<?=$get_date[4]?>','<?=$pageid?>')"<?php }?>>
								<?php 
								if(mysql_num_rows($sql_book26)>0)
								{ 
								if($fetch_user26['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user26['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user26['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid26?>','<?=$get_date[4]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								$check_time27=strtotime($get_date[4].' 01:00 pm');
								if ($check_time27 < $today) 
								{
								$pid27=str_replace('/','',$get_date[4]).'_3';
								$sql_book27=mysql_query("select * from book_order where product_id='$pid27' and slot_date='".$get_date[4]."' and page_id='$pageid'");
								$fetch_user27=mysql_fetch_array($sql_book27);
								$query_exc27=mysql_query("delete from book_order where order_id='".$fetch_user27['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid27=str_replace('/','',$get_date[4]).'_3';
								$sql_book27=mysql_query("select * from book_order where product_id='$pid27' and slot_date='".$get_date[4]."' and page_id='$pageid'");
								$fetch_user27=mysql_fetch_array($sql_book27);
								$num_rows27=mysql_num_rows($sql_book27);
								if($num_rows27>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user27['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user27['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book27)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book27)>0){ if($fetch_user27['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book27)==0){?>onclick="isert_id('<?=$pid27?>','<?=$get_date[4]?>','<?=$pageid?>')"<?php }?>>
								<?php 
								if(mysql_num_rows($sql_book27)>0)
								{ 
								if($fetch_user27['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user27['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user27['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid27?>','<?=$get_date[4]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								$check_time28=strtotime($get_date[4].' 03:00 pm');
								if ($check_time28 < $today) 
								{
								$pid28=str_replace('/','',$get_date[4]).'_4';
								$sql_book28=mysql_query("select * from book_order where product_id='$pid28' and slot_date='".$get_date[4]."' and page_id='$pageid'");
								$fetch_user28=mysql_fetch_array($sql_book28);
								$query_exc28=mysql_query("delete from book_order where order_id='".$fetch_user28['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid28=str_replace('/','',$get_date[4]).'_4';
								$sql_book28=mysql_query("select * from book_order where product_id='$pid28' and slot_date='".$get_date[4]."' and page_id='$pageid'");
								$fetch_user28=mysql_fetch_array($sql_book28);
								$num_rows28=mysql_num_rows($sql_book28);
								if($num_rows28>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user28['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user28['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book28)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book28)>0){ if($fetch_user28['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book28)==0){?>onclick="isert_id('<?=$pid28?>','<?=$get_date[4]?>','<?=$pageid?>')"<?php }?>>
								<?php 
								if(mysql_num_rows($sql_book28)>0)
								{ 
								if($fetch_user28['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user28['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user28['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid28?>','<?=$get_date[4]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								$check_time29=strtotime($get_date[4].' 05:00 pm');
								if ($check_time29 < $today) 
								{
								$pid29=str_replace('/','',$get_date[4]).'_5';
								$sql_book29=mysql_query("select * from book_order where product_id='$pid29' and slot_date='".$get_date[4]."' and page_id='$pageid'");
								$fetch_user29=mysql_fetch_array($sql_book29);
								$query_exc29=mysql_query("delete from book_order where order_id='".$fetch_user29['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid29=str_replace('/','',$get_date[4]).'_5';
								$sql_book29=mysql_query("select * from book_order where product_id='$pid29' and slot_date='".$get_date[4]."' and page_id='$pageid'");
								$fetch_user29=mysql_fetch_array($sql_book29);
								$num_rows29=mysql_num_rows($sql_book29);
								if($num_rows29>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user29['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user29['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book29)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book29)>0){ if($fetch_user29['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book29)==0){?>onclick="isert_id('<?=$pid29?>','<?=$get_date[4]?>','<?=$pageid?>')"<?php }?>>
								<?php 
								if(mysql_num_rows($sql_book29)>0)
								{ 
								if($fetch_user29['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user29['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user29['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid29?>','<?=$get_date[4]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								$check_time30=strtotime($get_date[4].' 07:00 pm');
								if ($check_time30 < $today) 
								{
								$pid30=str_replace('/','',$get_date[4]).'_6';
								$sql_book30=mysql_query("select * from book_order where product_id='$pid30' and slot_date='".$get_date[4]."' and page_id='$pageid'");
								$fetch_user30=mysql_fetch_array($sql_book30);
								$query_exc30=mysql_query("delete from book_order where order_id='".$fetch_user30['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid30=str_replace('/','',$get_date[4]).'_6';
								$sql_book30=mysql_query("select * from book_order where product_id='$pid30' and slot_date='".$get_date[4]."' and page_id='$pageid'");
								$fetch_user30=mysql_fetch_array($sql_book30);
								$num_rows30=mysql_num_rows($sql_book30);
								if($num_rows30>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user30['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user30['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book30)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book30)>0){ if($fetch_user30['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book30)==0){?>onclick="isert_id('<?=$pid30?>','<?=$get_date[4]?>','<?=$pageid?>')"<?php }?>>
								<?php 
								if(mysql_num_rows($sql_book30)>0)
								{ 
								if($fetch_user30['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user30['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user30['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid30?>','<?=$get_date[4]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								}
								}
								?>
								</div>
                            <div class="col-md-3">
                            	<div class="w-bg">
								<p>Friday</p>
                                	<p><?=$get_date[5]?></p>
                            		
                                </div>
								<?php
								$sql_holyday6=mysql_query("select * from mp_holyday where holydate='".$get_date[5]."' and status='1'");
								if(mysql_num_rows($sql_holyday6)>0)
								{
									echo '<p class="holyday">holiday</p>';
								}
								else{ 
									$sql_maintenance6=mysql_query("select * from mp_maintenance where maintenance='".$get_date[5]."' and machine_id='$pageid' and status='1'");
								if(mysql_num_rows($sql_maintenance6)>0)
								{
									echo '<p class="maintenance">Maintenance</p>';
								}
									else{
								$check_time31=strtotime($get_date[5].' 09:00 am');
								if ($check_time31 < $today) 
								{
								$pid31=str_replace('/','',$get_date[5]).'_1';
								$sql_book31=mysql_query("select * from book_order where product_id='$pid31' and slot_date='".$get_date[5]."' and page_id='$pageid'");
								$fetch_user31=mysql_fetch_array($sql_book31);
								$query_exc31=mysql_query("delete from book_order where order_id='".$fetch_user31['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid31=str_replace('/','',$get_date[5]).'_1';
								$sql_book31=mysql_query("select * from book_order where product_id='$pid31' and slot_date='".$get_date[5]."' and page_id='$pageid'");
								$fetch_user31=mysql_fetch_array($sql_book31);
								$num_rows31=mysql_num_rows($sql_book31);
								if($num_rows31>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user31['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user31['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book31)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book31)>0){ if($fetch_user31['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book31)==0){?>onclick="isert_id('<?=$pid31?>','<?=$get_date[5]?>','<?=$pageid?>')"<?php }?>>
								<?php 
								if(mysql_num_rows($sql_book31)>0)
								{ 
								if($fetch_user31['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user31['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user31['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid31?>','<?=$get_date[5]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								$check_time32=strtotime($get_date[5].' 11:00 am');
								if ($check_time32 < $today) 
								{
								$pid32=str_replace('/','',$get_date[5]).'_2';
								$sql_book32=mysql_query("select * from book_order where product_id='$pid32' and slot_date='".$get_date[5]."' and page_id='$pageid'");
								$fetch_user32=mysql_fetch_array($sql_book32);
								$query_exc32=mysql_query("delete from book_order where order_id='".$fetch_user32['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid32=str_replace('/','',$get_date[5]).'_2';
								$sql_book32=mysql_query("select * from book_order where product_id='$pid32' and slot_date='".$get_date[5]."' and page_id='$pageid'");
								$fetch_user32=mysql_fetch_array($sql_book32);
								$num_rows32=mysql_num_rows($sql_book32);
								if($num_rows32>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user32['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user32['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book32)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book32)>0){ if($fetch_user32['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book32)==0){?>onclick="isert_id('<?=$pid32?>','<?=$get_date[5]?>','<?=$pageid?>')"<?php }?>>
								<?php 
								if(mysql_num_rows($sql_book32)>0)
								{ 
								if($fetch_user32['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user32['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user32['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid32?>','<?=$get_date[5]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								$check_time33=strtotime($get_date[5].' 01:00 pm');
								if ($check_time33 < $today) 
								{
								$pid33=str_replace('/','',$get_date[5]).'_3';
								$sql_book33=mysql_query("select * from book_order where product_id='$pid33' and slot_date='".$get_date[5]."' and page_id='$pageid'");
								$fetch_user33=mysql_fetch_array($sql_book33);
								$query_exc33=mysql_query("delete from book_order where order_id='".$fetch_user33['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid33=str_replace('/','',$get_date[5]).'_3';
								$sql_book33=mysql_query("select * from book_order where product_id='$pid33' and slot_date='".$get_date[5]."' and page_id='$pageid'");
								$fetch_user33=mysql_fetch_array($sql_book33);
								$num_rows33=mysql_num_rows($sql_book33);
								if($num_rows33>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user33['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user33['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book33)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book33)>0){ if($fetch_user33['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book33)==0){?>onclick="isert_id('<?=$pid33?>','<?=$get_date[5]?>','<?=$pageid?>')"<?php }?>>
								<?php 
								if(mysql_num_rows($sql_book33)>0)
								{ 
								if($fetch_user33['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user33['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user33['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid33?>','<?=$get_date[5]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								$check_time34=strtotime($get_date[5].' 03:00 pm');
								if ($check_time34 < $today) 
								{
								$pid34=str_replace('/','',$get_date[5]).'_4';
								$sql_book34=mysql_query("select * from book_order where product_id='$pid34' and slot_date='".$get_date[5]."' and page_id='$pageid'");
								$fetch_user34=mysql_fetch_array($sql_book34);
								$query_exc34=mysql_query("delete from book_order where order_id='".$fetch_user34['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid34=str_replace('/','',$get_date[5]).'_4';
								$sql_book34=mysql_query("select * from book_order where product_id='$pid34' and slot_date='".$get_date[5]."' and page_id='$pageid'");
								$fetch_user34=mysql_fetch_array($sql_book34);
								$num_rows34=mysql_num_rows($sql_book34);
								if($num_rows34>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user34['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user34['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book34)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book34)>0){ if($fetch_user34['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book34)==0){?>onclick="isert_id('<?=$pid34?>','<?=$get_date[5]?>','<?=$pageid?>')"<?php }?>>
								<?php 
								if(mysql_num_rows($sql_book34)>0)
								{ 
								if($fetch_user34['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user34['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user34['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid34?>','<?=$get_date[5]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								$check_time35=strtotime($get_date[5].' 05:00 pm');
								if ($check_time35 < $today) 
								{
								$pid35=str_replace('/','',$get_date[5]).'_5';
								$sql_book35=mysql_query("select * from book_order where product_id='$pid35' and slot_date='".$get_date[5]."' and page_id='$pageid'");
								$fetch_user35=mysql_fetch_array($sql_book35);
								$query_exc35=mysql_query("delete from book_order where order_id='".$fetch_user35['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid35=str_replace('/','',$get_date[5]).'_5';
								$sql_book35=mysql_query("select * from book_order where product_id='$pid35' and slot_date='".$get_date[5]."' and page_id='$pageid'");
								$fetch_user35=mysql_fetch_array($sql_book35);
								$num_rows35=mysql_num_rows($sql_book35);
								if($num_rows35>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user35['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user35['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book35)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book35)>0){ if($fetch_user35['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book35)==0){?>onclick="isert_id('<?=$pid35?>','<?=$get_date[5]?>','<?=$pageid?>')"<?php }?>>
								<?php 
								if(mysql_num_rows($sql_book35)>0)
								{ 
								if($fetch_user35['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user35['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user35['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid35?>','<?=$get_date[5]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								$check_time36=strtotime($get_date[5].' 07:00 pm');
								if ($check_time36 < $today) 
								{
								$pid36=str_replace('/','',$get_date[5]).'_6';
								$sql_book36=mysql_query("select * from book_order where product_id='$pid36' and slot_date='".$get_date[5]."' and page_id='$pageid'");
								$fetch_user36=mysql_fetch_array($sql_book36);
								$query_exc36=mysql_query("delete from book_order where order_id='".$fetch_user36['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid36=str_replace('/','',$get_date[5]).'_6';
								$sql_book36=mysql_query("select * from book_order where product_id='$pid36' and slot_date='".$get_date[5]."' and page_id='$pageid'");
								$fetch_user36=mysql_fetch_array($sql_book36);
								$num_rows36=mysql_num_rows($sql_book36);
								if($num_rows36>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user36['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user36['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book36)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book36)>0){ if($fetch_user36['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book36)==0){?>onclick="isert_id('<?=$pid36?>','<?=$get_date[5]?>','<?=$pageid?>')"<?php }?>>
								<?php 
								if(mysql_num_rows($sql_book36)>0)
								{ 
								if($fetch_user36['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user36['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user36['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid30?>','<?=$get_date[4]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								}
								}
								?>
								</div>
                            <div class="col-md-3">
                            	<div class="w-bg">
                            		<p>Saturday</p>
                                	<p><?=$get_date[6]?></p>
                                </div>
                                
								<?php
								$sql_holyday7=mysql_query("select * from mp_holyday where holydate='".$get_date[6]."' and status='1'");
								if(mysql_num_rows($sql_holyday7)>0)
								{
									echo '<p class="holyday">holiday</p>';
								}
								else{ 
								$sql_maintenance7=mysql_query("select * from mp_maintenance where maintenance='".$get_date[6]."' and machine_id='$pageid' and status='1'");
								if(mysql_num_rows($sql_maintenance7)>0)
								{
									echo '<p class="maintenance">Maintenance</p>';
								}
									else{
								$check_time37=strtotime($get_date[6].' 09:00 am');
								if ($check_time37 < $today) 
								{
								$pid37=str_replace('/','',$get_date[6]).'_1';
								$sql_book37=mysql_query("select * from book_order where product_id='$pid37' and slot_date='".$get_date[6]."' and page_id='$pageid'");
								$fetch_user37=mysql_fetch_array($sql_book37);
								$query_exc37=mysql_query("delete from book_order where order_id='".$fetch_user37['order_id']."'");
								?>
								<div data-toggle="" data-target="#myModal" class="hover hover1">
								<p>Expired</p>
								</div>
								<?php 
								}
								else{
								$pid37=str_replace('/','',$get_date[6]).'_1';
								$sql_book37=mysql_query("select * from book_order where product_id='$pid37' and slot_date='".$get_date[6]."' and page_id='$pageid'");
								$fetch_user37=mysql_fetch_array($sql_book37);
								$num_rows37=mysql_num_rows($sql_book37);
								if($num_rows37>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user37['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?>id='<?=$fetch_user37['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book37)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book37)>0){ if($fetch_user37['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book37)==0){?>onclick="isert_id('<?=$pid37?>','<?=$get_date[6]?>','<?=$pageid?>')"<?php }?>>
								<?php 
								if(mysql_num_rows($sql_book37)>0)
								{ 
								if($fetch_user37['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user37['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user37['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid37?>','<?=$get_date[6]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								$check_time38=strtotime($get_date[6].' 11:00 am');
								if ($check_time38 < $today) 
								{
								$pid38=str_replace('/','',$get_date[6]).'_2';
								$sql_book38=mysql_query("select * from book_order where product_id='$pid38' and slot_date='".$get_date[6]."' and page_id='$pageid'");
								$fetch_user38=mysql_fetch_array($sql_book38);
								$query_exc38=mysql_query("delete from book_order where order_id='".$fetch_user38['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid38=str_replace('/','',$get_date[6]).'_2';
								$sql_book38=mysql_query("select * from book_order where product_id='$pid38' and slot_date='".$get_date[6]."' and page_id='$pageid'");
								$fetch_user38=mysql_fetch_array($sql_book38);
								$num_rows38=mysql_num_rows($sql_book38);
								if($num_rows38>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user38['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user38['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book38)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book38)>0){ if($fetch_user38['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book38)==0){?>onclick="isert_id('<?=$pid38?>','<?=$get_date[6]?>','<?=$pageid?>')"<?php }?>>																   
								<?php 
								if(mysql_num_rows($sql_book38)>0)
								{ 
								if($fetch_user38['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user38['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user38['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid38?>','<?=$get_date[6]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								$check_time39=strtotime($get_date[6].' 01:00 pm');
								if ($check_time39 < $today) 
								{
								$pid39=str_replace('/','',$get_date[6]).'_3';
								$sql_book39=mysql_query("select * from book_order where product_id='$pid39' and slot_date='".$get_date[6]."'");
								$fetch_user39=mysql_fetch_array($sql_book39);
								$query_exc39=mysql_query("delete from book_order where order_id='".$fetch_user39['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid39=str_replace('/','',$get_date[6]).'_3';
								$sql_book39=mysql_query("select * from book_order where product_id='$pid39' and slot_date='".$get_date[6]."'");
								$fetch_user39=mysql_fetch_array($sql_book39);
								$num_rows39=mysql_num_rows($sql_book39);
								if($num_rows39>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user39['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user39['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book39)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book39)>0){ if($fetch_user39['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book39)==0){?>onclick="isert_id('<?=$pid39?>','<?=$get_date[6]?>','<?=$pageid?>')"<?php }?>>																   
								<?php 
								if(mysql_num_rows($sql_book39)>0)
								{ 
								if($fetch_user39['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user39['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user39['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid39?>','<?=$get_date[6]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								$check_time40=strtotime($get_date[6].' 03:00 pm');
								if ($check_time40 < $today) 
								{
								$pid40=str_replace('/','',$get_date[6]).'_4';
								$sql_book40=mysql_query("select * from book_order where product_id='$pid40' and slot_date='".$get_date[6]."'");
								$fetch_user40=mysql_fetch_array($sql_book40);
								$query_exc40=mysql_query("delete from book_order where order_id='".$fetch_user40['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid40=str_replace('/','',$get_date[6]).'_4';
								$sql_book40=mysql_query("select * from book_order where product_id='$pid40' and slot_date='".$get_date[6]."'");
								$fetch_user40=mysql_fetch_array($sql_book40);
								$num_rows40=mysql_num_rows($sql_book40);
								if($num_rows40>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user40['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user40['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book40)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book40)>0){ if($fetch_user40['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book40)==0){?>onclick="isert_id('<?=$pid40?>','<?=$get_date[6]?>','<?=$pageid?>')"<?php }?>>
								<?php 
								if(mysql_num_rows($sql_book40)>0)
								{ 
								if($fetch_user40['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user40['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user40['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid40?>','<?=$get_date[6]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								$check_time41=strtotime($get_date[6].' 05:00 pm');
								if ($check_time41 < $today) 
								{
								$pid41=str_replace('/','',$get_date[6]).'_5';
								$sql_book41=mysql_query("select * from book_order where product_id='$pid41' and slot_date='".$get_date[6]."'");
								$fetch_user41=mysql_fetch_array($sql_book41);
								$query_exc41=mysql_query("delete from book_order where order_id='".$fetch_user41['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid41=str_replace('/','',$get_date[6]).'_5';
								$sql_book41=mysql_query("select * from book_order where product_id='$pid41' and slot_date='".$get_date[6]."'");
								$fetch_user41=mysql_fetch_array($sql_book41);
								$num_rows41=mysql_num_rows($sql_book41);
								if($num_rows41>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user41['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user41['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book41)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book41)>0){ if($fetch_user41['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book41)==0){?>onclick="isert_id('<?=$pid41?>','<?=$get_date[6]?>','<?=$pageid?>')"<?php }?>>																   
								<?php 
								if(mysql_num_rows($sql_book41)>0)
								{ 
								if($fetch_user41['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user41['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user41['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)==$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid41?>','<?=$get_date[6]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php 
								}
								}
								$check_time42=strtotime($get_date[6].' 07:00 pm');
								if ($check_time42< $today) 
								{
								$pid42=str_replace('/','',$get_date[6]).'_6';
								$sql_book42=mysql_query("select * from book_order where product_id='$pid42' and slot_date='".$get_date[6]."'");
								$fetch_user42=mysql_fetch_array($sql_book42);
								$query_exc42=mysql_query("delete from book_order where order_id='".$fetch_user42['order_id']."'");
								?>
									<div data-toggle="" data-target="#myModal" class="hover hover1">
									<p>Expired</p>
									</div>
								<?php 
								}
								else{
								$pid42=str_replace('/','',$get_date[6]).'_6';
								$sql_book42=mysql_query("select * from book_order where product_id='$pid42' and slot_date='".$get_date[6]."'");
								$fetch_user42=mysql_fetch_array($sql_book42);
								$num_rows42=mysql_num_rows($sql_book42);
								if($num_rows42>0)
								{
								?>
								<div <?php if($_SESSION['userid']!=$fetch_user42['userid'] && $_SESSION['userid']!='1'){}else{?>data-toggle="modal" <?php }?> id='<?=$fetch_user42['order_id']?>'<?php //}?> data-target="#myModal" class="<?php if(mysql_num_rows($sql_book42)>0){ echo"";}else{?>time-slot <?php }?>div_id hover hover1 <?php if(mysql_num_rows($sql_book42)>0){ if($fetch_user42['userid']==$_SESSION['userid']){?>green<?php } else{ echo"red1";}}?>" <?php if(mysql_num_rows($sql_book42)==0){?>onclick="isert_id('<?=$pid42?>','<?=$get_date[6]?>','<?=$pageid?>')"<?php }?>>																   
								<?php 
								if(mysql_num_rows($sql_book42)>0)
								{ 
								if($fetch_user42['userid']==$_SESSION['userid'])
								{
								?>
								<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '.get_user_name($fetch_user42['userid']);}?></p>
								<?php 
								} 
								else
								{
									if($_SESSION['userid']=='1'){?>
										<p>Booked <?php if($_SESSION['userid']=='1') {echo 'By '. get_user_name($fetch_user42['userid']);}?></p>
									<?php }
									if($_SESSION['userid']!='1'){
										echo"<p>Unavailable</p>";
									}
								}
								}
								?>
                                </div>
								<?php 
								}
								else
								{
								?>
								<div data-toggle="" data-target="#myModal" class="time-slot hover hover1" onclick="<?php if(mysql_num_rows($sql_conu_book)>=$booking_limval){?>alert('Only <?=$booking_limval?> booking allowed.');<?php } else{?>isert_id('<?=$pid42?>','<?=$get_date[6]?>','<?=$pageid?>')<?php }?>">
								 <p>Available</p>
                                </div>

								<?php  
								} 
								} 
								}
								}
								?>
								</div>
                          </div>
				
						</div>
				 </div>
			</div>
  		</div>
    </div>
	<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
<?//=$_REQUEST['reqid']?>
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
		  
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Slot Details: (<span id="Slot_date_head"></span>)</h4>
		  
      </div>
      <form class="cnt-f" method="post">
		  
		  <input type="hidden" class="form-control" name="booking_id" id="booking_id" value="">
		   <input type="hidden" class="form-control" name="old_pageid" id="old_pageid" value="">
		  <br />
            <div class="form-group">
			<div class="radio">
				 <label for="recipient-name" class="form-control-label">
				 <div class="r-tag"><input type="radio" name="updcl" id="updcl" value="cancel" checked><p>Cancel</p></div>
				 <div class="r-tag"><?php if($_SESSION['userid']=='1'){?><input type="radio" name="updcl" id="updcl" value="update"><p>Update</p><?php }?></div>
				 </label>
			</div>
			</div>
			
			<div id="competeyes" style="display:none">
			<div class="form-group">
				<div class="radio">
				  <label for="recipient-name" class="form-control-label">Added Date:</label>
				  <input type="text" class="form-control" id="popupDatepicker" name="old_date" id="old_date" value="">
				</div>
			</div>
			
		   <div class="form-group">
              <label for="recipient-name" class="form-control-label">Time:</label>
			    <input type="hidden" name="old_proid" id="old_proid" value="">
              <select name="slot_number" id="slot_number">
				  <option value="0" id="slot_time"></option>
				  <option value='1'>9 AM</option>
				  <option value='2'>11 AM</option>
				  <option value='3'>1 PM</option>
				  <option value='4'>3 PM</option>
				  <option value='5'>5 PM</option>
				  <option value='6'>7 PM</option>
			</select>
            </div>
			
		   <div class="form-group">
              <label for="recipient-name" class="form-control-label">Username:</label>
			   <input type="hidden" name="old_userid" id="old_userid" value="">
			   <select  name="old_user" id="old_user">
				   
	<?php 
	 echo'<option id="old_username" value="0">Username</option>';
	$sql_user="select * from mp_user";
	$result_user=mysql_query($sql_user);
	//$results = array();
	while($row_user = mysql_fetch_array($result_user)) {
				  echo'<option value="'.$row_user['id'].'">'.$row_user['username'].'</option>';
	}  ?>
			   </select>
            </div>
		</div>
		  <!--
            <div class="form-group">
              <label for="message-text" class="form-control-label">Message:</label>
              <textarea class="form-control" id="message-text"></textarea>
            </div>-->
		  <div class="modal-footer">
        <button type="button" id="submit" class="btn btn-default">Submit</button>
      </div>
	  
          </form>
     <!-- <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>-->
    </div>

  </div>
</div>
</div>
</div>

<script>
	

$(document).ready(function(){

	$('#submit').click(function() {
	var booking_id = $('#booking_id').val();
		//alert(task_id);
	var upd_type = $("input[name='updcl']:checked").val();
		//alert(upd_type);
	var old_pageid = $('#old_pageid').val();
	var old_date = $('#popupDatepicker').val();
	
	var old_userid = $('#old_userid').val();
	var old_user = $('#old_user').val();
	var old_proid = $('#old_proid').val();
		//alert(old_userid);
	if(upd_type === "") {
            alert('Please Select Radio button'); 
		return false;
        }
	/*else if(old_user === "") {
            alert('Please Select Username'); 
		return false;
        }*/
	var slot_number = $('#slot_number').val();
	var data = {'booking_id':booking_id,'upd_type':upd_type,'old_pageid':old_pageid,'old_proid':old_proid,'old_date':old_date,'old_user':old_user,'old_userid':old_userid,'slot_number':slot_number};
		//alert(data);
	$.ajax({
                type:'POST',
                url:'update_slot.php',
                data:data,
                success:function(data){
					//alert(data);
					if(data == 1){
					alert("You have successfully update");
					 window.location ="http://sweetballinfra.com/dev/makerplace/home.php?pageid=<?=$pageid?>&bt=<?=$bt?>&currentpage=<?=$currentpage?>";
					}
					else if(data == 2){
					alert("You have successfully Cancel");
					window.location ="http://sweetballinfra.com/dev/makerplace/home.php?pageid=<?=$pageid?>&bt=<?=$bt?>&currentpage=<?=$currentpage?>";
					}
					else if(data == 4){
					alert("Holiday");
					window.location ="http://sweetballinfra.com/dev/makerplace/home.php?pageid=<?=$pageid?>&bt=<?=$bt?>&currentpage=<?=$currentpage?>";
					}
					else if(data == 5){
					alert("Maintenance");
					window.location ="http://sweetballinfra.com/dev/makerplace/home.php?pageid=<?=$pageid?>&bt=<?=$bt?>&currentpage=<?=$currentpage?>";
					}
					else{
					alert("Date exist!, Please Cancel then Update!");
						window.location ="http://sweetballinfra.com/dev/makerplace/home.php?pageid=<?=$pageid?>&bt=<?=$bt?>&currentpage=<?=$currentpage?>";
					}
				}
		});
});
	
	
  $('.div_id').click(function() { 
	var taskid = $(this).attr("id");
		//alert(taskid);
		 //var rowid1 = $(this).attr("id");
	//alert(rowid1);
		// var task = $(this).attr("id");
		//alert(rowid);
        $.ajax({
            type : 'post',
            url : 'getTaskData.php', //Here you will fetch records 
            //data :  'rowid='+ rowid, //Pass $id
           // success : function(data){
            //$('.modal-title').html(data);//Show fetched data from database
			 data:{'taskid':taskid},
              success:function(data){
				var splite =data.split(',');
					//alert(data);
					//Task Id
					value = splite[0].split(':');
					value1 = value[1].split('"');
					$("#booking_id").val(value1[1]);
				  //Slot ID
					value = splite[1].split(':');
					value1 = value[1].split('"');
					$("#old_proid").val(value1[1]);
					// old_date
					value = splite[2].split(':');
					value1 = value[1].split('"');
				  //alert(value);
					$("#popupDatepicker").val(value1[1]);
				  	$("#Slot_date_head").html(value1[1]);
					// old_userid
					value = splite[3].split(':');
					value1 = value[1].split('"');
					$("#old_userid").val(value1[1]);
					// old_pageid
					value = splite[4].split(':');
					value1 = value[1].split('"');
					$("#old_username").html(value1[1]);
				  
				 	value = splite[5].split(':');
					value1 = value[1].split('"');
					$("#old_pageid").val(value1[1]);
				 	
				  	value = splite[6].split(':');
					value1 = value[1].split('"');
					$("#slot_time").html(value1[1]);
            }
        });
     });
	var id = $("#old_userid option:selected").attr("id")
});
</script>
<script>

$('input[name="updcl"]').bind('change',function(){
    var showOrHide = ($(this).val() == 'update') ? true : false;
    $('#competeyes').toggle(showOrHide);
 });

</script>

<script>
  $( function() {
    $( "#popupDatepicker" ).datepick();
  } );
  </script>

<script>
$(function() {
	$('#popupDatepicker').datepick();
	$('#inlineDatepicker').datepick({onSelect: showDate});
});

function showDate(date) {
	//alert(st);
	//alert(date);
  if (date=="") {
    document.getElementById("show_date").innerHTML="";
    return;
  } 
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("show_date").innerHTML=this.responseText;
    }
  }
  xmlhttp.open("GET","ajaxpage.php?date="+date,true);
  xmlhttp.send();

	
}
</script>

<?php include('footer.php');?>
