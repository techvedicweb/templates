<?php include('header_top.php');?>
<?php include('header.php');?>
<?php
if(!isset($_SESSION['username']))
{
header("location:index.php");
}
?>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<div class="auto">
<div class="login">
    	<div class="form-design">
        	<h2><span>Update Booking Limit</span></h2>
            	<div class="form-center">
					<?php 
if(isset($_POST['update']) && $_POST['update']=='success')
{
$limitnum=$_POST['limitnum'];
$holiday_query=mysql_query("update mp_booking_limit set limval='$limitnum' where id=1");
if($holiday_query)
{
$msg_success="Limit Update Successfull";
}
else{
$msg_error="Error!";
}
}
					
$edit_query=mysql_query("select * from mp_booking_limit where id=1");
$res_date=mysql_fetch_array($edit_query);

?>
					<?php 
					if(isset($msg_exist)){echo $msg_exist;}
					if(isset($msg_success)){echo $msg_success;}
					if(isset($msg_error)){echo $msg_error;}
					?>
                    <form action="" method="post" name="login_form" class="bb"> 
						
						<input type="hidden" name='update' value="success">
						
                    
                    	<div class="in-pg"><p>Enter Booking Limit:</p> <input type="number" placeholder="Number" name="limitnum" id="password" value='<?=$res_date['limval']?>' required/>
                        </div>
                       
						<input type="submit" name="button" value="Update" class="bt-right"/>
						</div>
                    </form>
		
						
				</div>
		</div>
</div>


<!--<div id="getstatus"><b>Person info will be listed here.</b></div>-->
<?php include('footer.php');?>
