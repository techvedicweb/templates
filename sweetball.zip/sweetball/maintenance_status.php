<?php 
include('module/config.php');
$userid=$_SESSION['userid'];

$hid=$_GET['hid'];
$st=$_GET['st'];

//echo $hid.'  '.$st;

$check_query=mysql_query("select * from mp_maintenance where id='$hid'");
if(mysql_num_rows($check_query)>0)
{
	
		$query_exc=mysql_query("update mp_maintenance set status='$st' where id='$hid'");
if($query_exc)
{
	echo "Status updated Successfull";
 //echo '<script type="text/javascript">window.location ="../schools/school_profile.php";</script>';
}
}


?>