<?php
	include('module/config.php');
	$booking_id = "";
	$upd_type = "";
	$old_pageid = "";
	$old_date = "";
	$old_user = "";
	$new_date='';
	$slo_n="";
	$sql = "";
//echo $_REQUEST["booking_id"];
	if(isset($_REQUEST["booking_id"]) && !empty($_REQUEST["booking_id"]) && $_REQUEST["upd_type"]=='update'){
		//print_r($_REQUEST);exit;
        $booking_id = $_REQUEST['booking_id'];
        $upd_type = $_REQUEST['upd_type'];
		$old_pageid = $_REQUEST['old_pageid'];
		$old_date = $_REQUEST['old_date'];
	
		if($_REQUEST['slot_number']=='0')
		{
		$slot_num=$_REQUEST['old_proid'];
		}
		else{
		$slo_n=$_REQUEST['slot_number'];
		$slot_num=str_replace('/','',$old_date).'_'.$slo_n;
		}
		if($_REQUEST['old_user']=='0')
		{
		$old_user = $_REQUEST['old_userid'];
		}
		else{
		$old_user=$_REQUEST['old_user'];
		}
		
		/*
		$check_query=mysql_query("select * from book_order where product_id='".$slot_num."' and slot_date='".$old_date."'");
		
		$sql_holyday1="select * from mp_holyday where holydate='".$old_date."' and status='1'";
		$exc_holi=mysql_query($sql_holyday1);
		$query_er=mysql_fetch_array($exc_holi);
		
		$sql_man1="select * from mp_maintenance where machine_id='".$old_date."' and maintenance='".$old_pageid."' and status='1'";
		$exc_man=mysql_query($sql_man1);
		$query_man=mysql_fetch_array($exc_man);
		
		$date = date_default_timezone_set('Asia/Kolkata');
		$today = date("m/d/Y g:i a");
		
		$check_time1=$old_date.' 09:00 am';
		$check_time2=$old_date.' 11:00 am';
		$check_time3=$old_date.' 01:00 am';
		$check_time4=$old_date.' 03:00 am';
		$check_time5=$old_date.' 05:00 am';
		$check_time6=$old_date.' 07:00 am';

		if ($check_time1 < $today) 
		{
			echo 0;
		}
		elseif ($check_time2 < $today) 
		{
			echo 0;
		}
		elseif ($check_time3 < $today) 
		{
			echo 0;
		}
		elseif ($check_time4 < $today) 
		{
			echo 0;
		}
		elseif ($check_time5 < $today) 
		{
			echo 0;
		}
		elseif ($check_time6 < $today) 
		{
			echo 0;
		}
		
		elseif(mysql_num_rows($check_query)>0){
		echo 0;
		}
		
	//echo $query_er['holydate'];
		elseif($query_er['holydate']!='')
		{
				echo 4;
		}
			//echo $query_er['holydate'];
		elseif($query_man['maintenance']!='')
		{
			echo 5;
		}
		else{
			*/
								
		$sql = "update book_order set product_id='".$slot_num."', slot_date='".$old_date."', userid='".$old_user."', page_id='".$old_pageid."', order_date=now() where 
		order_id='".$booking_id."'";
		//echo $sql;exit;
	$result=mysql_query($sql);
	if($result)
	echo 1;
	}
	//}
	if(isset($_REQUEST["booking_id"]) && !empty($_REQUEST["booking_id"]) && $_REQUEST["upd_type"]=='cancel'){
		//print_r($_REQUEST);exit;
        $booking_id = $_REQUEST['booking_id'];
		$sql = "delete from book_order where order_id='".$booking_id."'";
	$result=mysql_query($sql);
	
	echo 2;
	}
?>
