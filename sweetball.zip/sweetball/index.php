<?php include('header_top.php');?>
<?php include('header.php');?>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<div class="auto">
<div class="login">
    	<div class="form-design">
        	<h2><span>ADMIN LOGIN</span></h2>
            	<div class="form-center">
                    <form action="module/login.php" method="post" name="login_form" class="bb">                      
                    	<div class="in-pg"><p>Username:</p> <input type="text" placeholder="Username" name="userid" required /></div>
                    	<div class="in-pg"><p>Password:</p> <input type="password" placeholder="Password" name="password" id="password" required/></div>
                    	<p></p><input type="submit" name="user_login" value="Login" class="bt-right"/> 
<p></p><a href="login.php">Login With WildApricot</a>
                    </form>

				</div>
		</div>
</div>
</div>
<?php //include('footer.php');?>
<div class="ftr-bottom">
    <div class="container">
        <h2>&copy; 2016  Maker Place. All Rights Reserved</h2>
    </div>
</div>
</body>
</html>
