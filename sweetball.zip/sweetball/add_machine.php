<?php include('header_top.php');?>
<?php include('header.php');?>
<?php
if(!isset($_SESSION['username']))
{
header("location:index.php");
}
?>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<div class="auto">
<div class="login">
    	<div class="form-design">
        	<h2><span>Add Tools Name</span></h2>
            	<div class="form-center">
					<?php 
if(isset($_POST['submit']) && $_POST['submit']=='success')
{
$tool_name=$_POST['tool_name'];
$course_id=$_POST['course_id'];
$check_date=mysql_query("select * from mp_slots where slot_name='$tool_name'");
if(mysql_num_rows($check_date)>0)
{
	$msg_exist="<div id='message_booking'><i class='fa fa-check' aria-hidden='true'></i>Date Exist!<i class='fa fa-times i-right' aria-hidden='true'></i></div>";
}
else{
$holiday_query=mysql_query("insert into mp_slots set slot_name='$tool_name',course_id='$course_id'");
if($holiday_query)
{
$msg_success="<div id='message_booking'><i class='fa fa-check' aria-hidden='true'></i>Tool Name added Successfull <i class='fa fa-times i-right' aria-hidden='true'></i></div>";
}
else{
$msg_error="Error!";
}
}
}
if(isset($_REQUEST['hid']) && $_REQUEST['hid']!='' && isset($_POST['update']) )
{
$hid=$_REQUEST['hid'];
$tool_name=$_POST['tool_name'];
$course_id=$_POST['course_id'];
$holiday_query=mysql_query("update mp_slots set slot_name='$tool_name',course_id='$course_id' where id='$hid'");
if($holiday_query)
{
$msg_success="<div id='message_booking'><i class='fa fa-check' aria-hidden='true'></i>One record Update successfull<i class='fa fa-times i-right' aria-hidden='true'></i></div>";
}
else{
$msg_error="Error!";
}
}
					
					
if(isset($_REQUEST['hid']) && $_REQUEST['hid']!='')
{
$hid=$_REQUEST['hid'];
$edit_query=mysql_query("select * from mp_slots where id='$hid'");
$res_date=mysql_fetch_array($edit_query);
}
?>
					<?php 
					if(isset($msg_exist)){echo $msg_exist;}
					if(isset($msg_success)){echo $msg_success;}
					if(isset($msg_error)){echo $msg_error;}
					?>
                    <form action="" method="post" name="login_form" class="bb"> 
						<?php if(isset($_REQUEST['hid'])){?>
						<input type="hidden" name='update' value="success">
						<?php }else	{?>
						<input type="hidden" name='submit' value="success">
						<?php }?>
                    	
                    	<div class="in-pg"><p>Tool Name:</p> <input type="text" id="" placeholder="Tool Name" name="tool_name"  value='<?php if(isset($res_date['slot_name'])){ echo $res_date['slot_name'];}?>' required/></div>
                       <div class="in-pg"><p>Course Name:</p>
                        	<select name='course_id' required>
							<option value="">Select Course</option>
							<?php 
							$sql_course_name=mysql_query("select * from mp_courses order by id asc");
							while($fetch_course_name=mysql_fetch_array($sql_course_name))
							{
							?>
                        	<option value="<?=$fetch_course_name['id']?>" <?php if(isset($res_date['course_id']) && $res_date['course_id']==$fetch_course_name['id']){echo'selected';}?>><?=$fetch_course_name['course_name']?></option>
							<?php 
							}	
							?>
                            </select>
                        	</div>
						<div class="in-pg"><p></p> 
					<!--	<input type="checkbox" name="activation" value="1" <?php if(isset($res_date['status']) && $res_date['status']=='1'){echo'checked';}?>> Activate -->
						<input type="submit" name="button" value="<?php if(isset($_REQUEST['hid'])){echo'Update';}else{echo'Add Tool';}?>" class="bt-right"/>
						</div>
                    </form>
				</div>
			<!--<li class="e-h">Action</li>
echo'<li><a href="add_machine.php?hid='.$get_date['id'].'">Edit</a> / <a href="module/delete.php?del_mach='.md5($get_date['id']).'">Delete</a></li>';

-->
<!--<li class="e-h">Course Name</li>-->
                        <?php 
$get_holiday=mysql_query("select * from mp_slots");
if(mysql_num_rows($get_holiday)>0)
{
 echo'<div class="view2">
						<h2>Manage Tools Name</h2>
						<ul>
						<li class="e-h-b-n">Tool Name</li>
						<li class="e-h">Action</li>
						
						</ul>';
while($get_date=mysql_fetch_array($get_holiday))
{
$guery_crs=mysql_query("select * from mp_courses where id='".$get_date['course_id']."'");
$get_crs=mysql_fetch_array($guery_crs);
echo'<ul>';
echo '<li>'.$get_date['slot_name'].'</li>';
//echo '<li>'.$get_crs['course_name'].'</li>';
/*	
if($get_date['status']=='0')
{
echo'<td><a href="javascript:void(0)" onclick="holiday_status('.$get_date['id'].',1)">Active</a></td>';
}
else{
echo'<td><a href="javascript:void(0)" onclick="holiday_status('.$get_date['id'].',0)">InActive</a></td>';
}
	*/
echo'<li><a href="add_machine.php?hid='.$get_date['id'].'">Edit</a> / <a href="module/delete.php?del_mach='.md5($get_date['id']).'">Delete</a></li>';

echo'</ul>';
}
echo'</div>';
}
?>
</div>
</div>


<?php include('footer.php');?>
