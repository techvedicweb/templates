<?php
$root_url='http://localhost/maker';

function check_user($uid) 
{
	//echo "SELECT * FROM sm_users WHERE userid='$uid'";
$user_query=mysql_query("SELECT * FROM sm_users WHERE userid='$uid'");
if(mysql_num_rows($user_query)>0)
{
 return true;
}
}

function get_user_name($uid) 
{
	//echo "SELECT * FROM sm_users WHERE userid='$uid'";
$user_query=mysql_query("SELECT * FROM mp_user WHERE id='$uid'");
while($result_user=mysql_fetch_array($user_query))
{
 return $result_user['username'];
}
}




function GetPageTitle($pageid) 
{
$query="SELECT * FROM mp_slots WHERE id='$pageid';";
$runquery=mysql_query($query);
$num_rows=mysql_num_rows($runquery);
if($num_rows>0)
{
	$result=mysql_fetch_assoc($runquery);
	if($result['slot_name']!="")
	{
	return $result['slot_name'];
	}
}
else
{
	return false;
}
}
?>