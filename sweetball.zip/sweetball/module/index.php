<?php include('header_top.php');?>
<?php include('header.php');?>

<div class="login">
	<div class="container">
    	<div class="form-design">
        	<h2><span>ADMIN LOGIN</span></h2>
            	<div class="form-center">
                    <form action="../module/login.php" method="post" name="login_form">                      
                    	<div class="in-pg"><p>Username:</p> <input type="text" placeholder="Username" name="userid" /></div>
                    	<div class="in-pg"><p>Password:</p> <input type="password" placeholder="Password" name="password" id="password"/></div>
                    <input type="submit" name="user_login" value="Login"/> 
                    </form>
				</div>
		</div>
	</div>
</div>

<?php include('footer.php');?>