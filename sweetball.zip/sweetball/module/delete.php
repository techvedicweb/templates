<?php
include('config.php');
$root_url='http://localhost/maker';

if(isset($_GET['del']))
{
$del=$_GET['del'];
$qry=mysql_query("delete from mp_holyday where md5(id)='$del';");
if($qry){
	
	echo "<script>alert('Delete Successfull!')</script>";

	echo "<script>window.location='../holiday.php'</script>";

}


else{
echo "Error in empoyer Delete".mysql_error();
}
}
if(isset($_GET['delmt']))
{
$delmt=$_GET['delmt'];
$qry=mysql_query("delete from mp_maintenance where md5(id)='$delmt';");
if($qry){
	
	echo "<script>alert('Delete Successfull!')</script>";

	echo "<script>window.location='../maintanance.php'</script>";

}


else{
echo "Error in empoyer Delete".mysql_error();
}
}

if(isset($_GET['del_mach']))
{
$del_mach=$_GET['del_mach'];
$qry=mysql_query("delete from mp_slots where md5(id)='$del_mach';");
if($qry){
	
	echo "<script>alert('Delete Successfull!')</script>";

	echo "<script>window.location='../add_machine.php'</script>";

}


else{
echo "Error in empoyer Delete".mysql_error();
}
}

if(isset($_GET['del_crs']))
{
$del_crs=$_GET['del_crs'];
$qry=mysql_query("delete from mp_courses where md5(id)='$del_crs';");
if($qry){
	
	echo "<script>alert('Delete Successfull!')</script>";

	echo "<script>window.location='../add_course.php'</script>";

}


else{
echo "Error in empoyer Delete".mysql_error();
}
}

?>