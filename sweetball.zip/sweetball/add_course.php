<?php include('header_top.php');?>
<?php include('header.php');?>
<?php
if(!isset($_SESSION['username']))
{
header("location:index.php");
}
?>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<div class="auto">
<div class="login">
    	<div class="form-design">
        	<h2><span>Add Course Name</span></h2>
            	<div class="form-center">
					<?php 
if(isset($_POST['submit']) && $_POST['submit']=='success')
{
$course_name=$_POST['course_name'];
	
$check_date=mysql_query("select * from mp_courses where course_name='$course_name'");
if(mysql_num_rows($check_date)>0)
{
	$msg_exist="<div id='message_booking'><i class='fa fa-check' aria-hidden='true'></i>Date Exist!<i class='fa fa-times i-right' aria-hidden='true'></i></div>";
}
else{
$holiday_query=mysql_query("insert into mp_courses set course_name='$course_name'");
if($holiday_query)
{
$msg_success="<div id='message_booking'><i class='fa fa-check' aria-hidden='true'></i>Course Name added Successfull <i class='fa fa-times i-right' aria-hidden='true'></i></div>";
}
else{
$msg_error="Error!";
}
}
}
if(isset($_REQUEST['hid']) && $_REQUEST['hid']!='' && isset($_POST['update']) )
{
$hid=$_REQUEST['hid'];
$course_name=$_POST['course_name'];

$holiday_query=mysql_query("update mp_courses set course_name='$course_name' where id='$hid'");
if($holiday_query)
{
$msg_success="<div id='message_booking'><i class='fa fa-check' aria-hidden='true'></i>One record Update successfull<i class='fa fa-times i-right' aria-hidden='true'></i></div>";
}
else{
$msg_error="Error!";
}
}
					
					
if(isset($_REQUEST['hid']) && $_REQUEST['hid']!='')
{
$hid=$_REQUEST['hid'];
$edit_query=mysql_query("select * from mp_courses where id='$hid'");
$res_date=mysql_fetch_array($edit_query);
}
?>
					<?php 
					if(isset($msg_exist)){echo $msg_exist;}
					if(isset($msg_success)){echo $msg_success;}
					if(isset($msg_error)){echo $msg_error;}
					?>
                    <form action="" method="post" name="login_form" class="bb"> 
						<?php if(isset($_REQUEST['hid'])){?>
						<input type="hidden" name='update' value="success">
						<?php }else	{?>
						<input type="hidden" name='submit' value="success">
						<?php }?>
                    	<!--<div class="in-pg"><p>Tools Name:</p>
                        	<select name='course_name' required>
							<option value="">Select Tool</option>
							<?php 
							$sql_slotname=mysql_query("select * from mp_courses order by id asc");
							while($fetch_course_name=mysql_fetch_array($sql_slotname))
							{
							?>
                        	<option value="<?=$fetch_course_name['id']?>"><?=$fetch_course_name['course_name']?></option>
							<?php 
							}	
							?>
                            </select>
                        	</div>-->
                    	<div class="in-pg"><p>Course Name:</p> <input type="text" id="" placeholder="Course Name" name="course_name"  value='<?php if(isset($res_date['course_name'])){ echo $res_date['course_name'];}?>' required/></div>
                        <div class="in-pg"><p></p> 
					<!--	<input type="checkbox" name="activation" value="1" <?php if(isset($res_date['status']) && $res_date['status']=='1'){echo'checked';}?>> Activate -->
						<input type="submit" name="button" value="<?php if(isset($_REQUEST['hid'])){echo'Update';}else{echo'Add';}?>" class="bt-right"/>
						</div>
                    </form>
				</div>
                        <?php 
$get_holiday=mysql_query("select * from mp_courses");
if(mysql_num_rows($get_holiday)>0)
{
 echo'<div class="view2">
						<h2>Manage Course Name</h2>
						<ul>
						<li class="e-h-b-n">Course Name</li>
						<li class="e-h">Action</li>
						</ul>';
while($get_date=mysql_fetch_array($get_holiday))
{
echo'<ul>';
echo '<li>'.$get_date['course_name'].'</li>';
/*	
if($get_date['status']=='0')
{
echo'<td><a href="javascript:void(0)" onclick="holiday_status('.$get_date['id'].',1)">Active</a></td>';
}
else{
echo'<td><a href="javascript:void(0)" onclick="holiday_status('.$get_date['id'].',0)">InActive</a></td>';
}
	*/
echo'<li><a href="add_course.php?hid='.$get_date['id'].'">Edit</a> / <a href="module/delete.php?del_crs='.md5($get_date['id']).'">Delete</a></li>';
echo'</ul>';
}
echo'</div>';
}
?>
</div>
</div>


<?php include('footer.php');?>
