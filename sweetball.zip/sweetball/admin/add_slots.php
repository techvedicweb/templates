<?php include('header_top.php');?>
<?php include('header.php');?>

<?php 
session_start();
include('../module/config.php');
if(isset($_POST['submit']))
{
$slot_id=$_POST['slot_id'];
$slot_date=$_POST['slot_date'];	
$slot_time=$_POST['slot_time'];	
$slot_name=$_POST['slot_name'];	
$slot_d=date('m/d/Y',strtotime($slot_date));
$slot_check=mysql_query("select * from mp_slot_details where slot_date='".$slot_date."'");
if(mysql_num_rows($slot_check)>5)
{
	echo "You Dont have permition to add more than 6 slots";
}
else{
$query_add="insert into mp_slot_details set slot_id='".$slot_id."', slot_date='".$slot_d."', slot_time='".$slot_time."', slot_detail='".$slot_name."'";
//echo $query_add;exit;
$ins_query=mysql_query($query_add);
echo"Data Inserted!";
}
}
?>

<div class="form-center">
<form action="" method="post">
<div class="in-pg"
<p>Select Name</p>
<select name="slot_id">
<?php 
$get_slot=mysql_query("select * from mp_slots order by id desc");
while($fetch_res=mysql_fetch_array($get_slot))
{
?>
<option value="<?=$fetch_res['id']?>"><?=$fetch_res['slot_name']?></option>
<?php
}
?>
</select>
</div>

<div class="in-pg">
<p>Select Date</p><input type="text" name="slot_date">
</div>

<div class="in-pg">
<p>Slot</p><input type="text" name="slot_name">
</div>

<!--Slect Time-->
<select name="slot_time" hidden>
<option value="1pm">1pm</option>
<option value="2pm">2pm</option>
<option value="3pm">3pm</option>
<option value="4pm">4pm</option>
<option value="5pm">5pm</option>
<option value="6pm">6pm</option>
</select>


<input type="submit" name="submit">
</form>
</div>
<?php include('footer.php');?>




