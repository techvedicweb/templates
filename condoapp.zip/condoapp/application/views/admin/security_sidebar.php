        <!-- sidebar left start-->
        <div class="sidebar-left">
            <!--responsive view logo start-->
            <div class="logo dark-logo-bg visible-xs-* visible-sm-*">
                <a href="<?=base_url('admin/dashboard')?>">                    
                    <span class="brand-name">CONDO ADMIN</span>
                </a>
            </div>
            <!--responsive view logo end-->

            <div class="sidebar-left-info">
                <!-- visible small devices start-->
                <div class=" search-field">  </div>
                <!-- visible small devices end-->

                <!--sidebar nav start-->
                <ul class="nav nav-pills nav-stacked side-navigation">
                    
					
					
<?php
$dashcss='';
if($this->uri->segment(2)=='dashboard'){
	$dashcss='id="nav-on"';
}

$edtprofcss='';
if($this->uri->segment(2)=='editprofile'){
	$edtprofcss='id="nav-on"';
}


$chpass='';
if($this->uri->segment(2)=='changepass'){
	$chpass='id="nav-on"';
}

?>					
					
					
					
					
                    <li class="nav-active" <?=$dashcss  ?> >
					<a href="<?=base_url().$this->uri->segment(1).'/dashboard'   ?>"><i class="fa fa-home"></i> <span>
					Dashboard</span></a>
					</li>
                    

					

                </ul>
                <!--sidebar nav end-->

               
            </div>
        </div>
        <!-- sidebar left end-->