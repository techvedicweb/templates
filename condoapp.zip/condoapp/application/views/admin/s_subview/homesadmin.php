            <!-- page head start-->
            <div class="page-head">
                <h3>
                    Dashboard
                </h3>
                <span class="sub-title">Welcome to DASHBOARD</span>
                
			
			</div>
            <!-- page head end-->

			
 	<div class="err">
	<?php
		$err = $this->session->flashdata('error');
		if(!empty($err))
			echo '<div class="alert alert-warning">'.$err.'</div>';
		$scs = $this->session->flashdata('success');
		if(!empty($scs))
			echo '<div class="alert alert-success">'.$scs.'</div>';
		if(validation_errors())
		{
			echo '<div class="alert alert-warning">';
			if(form_error('agentslist'))
				echo 'Select Atleast One Employee';
			else
				echo validation_errors();
			echo '</div>';
		}
	?>
	</div>			
			
			
			
			
			
			
            <!--body wrapper start-->
            <div class="wrapper">
			 
			 
			  <div class="row">
            <div class="col-lg-12">
            <section class="panel">
            <header class="panel-heading head-border">
                List Of Active Bookings
				
				
				
				
            </header>
			<div class="table-responsive">
            <!--<table class="table table-striped custom-table table-hover">-->
            <table class="table convert-data-table data-table">
                <thead>
                <tr>
                    <!--<th style="min-width:110px;"><i class="fa fa-bookmark-o"></i> CONDO </th>
                    <th style="min-width:110px;"><i class="fa fa-bookmark-o"></i> Booked By</th>
                    <th> </th>
                    <th style="min-width:110px;"><i class="fa fa-bookmark-o"></i> Created By</th>
                    <th style="min-width:110px;"><i class="fa fa-bookmark-o"></i> Status</th>
                    <th style="min-width:110px;" class="hidden-xs"><i class="fa fa-cogs"></i> Action</th>-->
					
					
					
					<th style="min-width:110px;"><i class="fa fa-bookmark-o"></i> Booking Id </th>
					<th style="min-width:122px;"><i class="fa fa-bookmark-o"></i> Unit Number </th>
					<th> </th>
                    <th  style="min-width:125px;"><i class="fa fa-bookmark-o"></i> Guest Name</th>
                    <th  style="min-width:200px;"><i class="fa fa-bookmark-o"></i> Check In / Check Out</th>
                    <th  style="min-width:150px;"><i class="fa fa-bookmark-o"></i> Point Of Contact</th>
                    <th style="min-width:110px;"><i class="fa fa-bookmark-o"></i> Status</th>
					
					
					
					
					
                </tr>
                </thead>
                <tbody>
				<?=$alldf ?>
				
                
				
				
                </tbody>
            </table>
            </div>
			
			</section>
            </div>
            </div>
				
				
			 
			 
			 
			 
			 
			 
			 
			 

			   </div>
            <!--body wrapper end-->
			
			



