<?php
$form_hding = '--';
if($this->uri->segment(2)=='userlist'){
	//print_result($datan);
	$form_hding = 'List Of '.$this->uri->segment(3).' Users';
}
?>

			
 	<div class="err">
	<?php
		$err = $this->session->flashdata('error');
		if(!empty($err))
			echo '<div class="alert alert-warning">'.$err.'</div>';
		$scs = $this->session->flashdata('success');
		if(!empty($scs))
			echo '<div class="alert alert-success">'.$scs.'</div>';
		if(validation_errors())
		{
			echo '<div class="alert alert-warning">';
			if(form_error('agentslist'))
				echo 'Select Atleast ----';
			else
				echo validation_errors();
			echo '</div>';
		}
	?>
	</div>			
			


 
 <!-- page head start-->
            <div class="page-head" style="display:block; min-height:70px;">
                <h3 style="float:left;">User Manager</h3>
				
				
			</div>
            <!-- page head end-->
            <!--body wrapper start-->
            <div class="wrapper">
                <div class="row">
            <div class="col-lg-12">
            <section class="panel">
            <header class="panel-heading head-border">
                <?=$form_hding ?>
				<?php
				if($this->uri->segment(3)=='APPROVED'){
				?>
				<span class="tools pull-right">
						<form method="post">
							<button type="submit" name="export" title="export"  					  
							class="btn btn-info"><i class="fa fa-file-excel-o"></i> Export Excel</button>
						</form>
				
				</span>
				<?php
				}
				?>
				
				
            </header>
			<div class="table-responsive">
            <!--<table class="table table-striped custom-table table-hover">-->
            <table class="table convert-data-table data-table">
                <thead>
                <tr>
                    <th><i class="fa fa-bookmark-o"></i>User Name</th>
                    <th><i class="fa fa-bookmark-o"></i>User Email</th>
                    <th><i class="fa fa-bookmark-o"></i>User Type</th>
                    
                    <th class="hidden-xs"><i class="fa fa-cogs"></i> Action</th>
                </tr>
                </thead>
                <tbody>
				<?=$alldf ?>
				
                
				
				
                </tbody>
            </table>
            </div>
			
			</section>
            </div>
            </div>
				
				
            </div>
            <!--body wrapper end-->
