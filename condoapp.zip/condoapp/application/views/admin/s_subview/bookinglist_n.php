

			
		
			


 
 <!-- page head start-->
            <div class="page-head" style="display:block; min-height:70px;">
                <h3 style="float:left;">BOOKING MANAGER</h3>
				
				
			</div>
			
			
 	<div class="err">
	<?php
		$err = $this->session->flashdata('error');
		if(!empty($err))
			echo '<div class="alert alert-warning">'.$err.'</div>';
		$scs = $this->session->flashdata('success');
		if(!empty($scs))
			echo '<div class="alert alert-success">'.$scs.'</div>';
		if(validation_errors())
		{
			echo '<div class="alert alert-warning">';
			if(form_error('agentslist'))
				echo 'Select Atleast ----';
			else
				echo validation_errors();
			echo '</div>';
		}
	?>
	</div>				
			
			
			
            <!-- page head end-->
            <!--body wrapper start-->
            <div class="wrapper">
                <div class="row">
            <div class="col-lg-12">
            <section class="panel">
            <header class="panel-heading head-border">
                List Of Bookings
            </header>
			
			
			
			
			
			
			
			
			
			<div class="table-responsive">
            <!--<table class="table table-striped custom-table table-hover">-->
            <table class="table table-striped custom-table table-hover">
                <thead>
                <tr>
				
<?php
$condo_link= base_url().$this->uri->segment(1).'/'.$this->uri->segment(2).'/SORTY/cn_name/ASC';
if($this->uri->segment(3)=='SORTY' && $this->uri->segment(4)=='cn_name' && $this->uri->segment(5)=='ASC'){
	$condo_link =base_url().$this->uri->segment(1).'/'.$this->uri->segment(2).'/SORTY/cn_name/DESC';	
}
?>				
                    
                   <!-- <th><i class="fa fa-bookmark-o"></i> Booking Id </th>
					<th><i class="fa fa-bookmark-o"></i><a href="<?=$condo_link  ?>"> Unit Number </a></th>
					<th> </th>
                    <th><i class="fa fa-bookmark-o"></i> Guest Name</th>
                    <th><i class="fa fa-bookmark-o"></i> Check In / Check Out</th>
                    <th><i class="fa fa-bookmark-o"></i> Point Of Contact</th>
                    <th><i class="fa fa-bookmark-o"></i> Status</th>					
                    <th><i class="fa fa-cogs"></i> Action</th>	-->


					<th style="min-width:110px;"><i class="fa fa-bookmark-o"></i> Booking Id </th>
					<th style="min-width:122px;"><i class="fa fa-bookmark-o"></i><a href="<?=$condo_link  ?>"> Unit Number </a></th>
					<th> </th>
                    <th  style="min-width:125px;"><i class="fa fa-bookmark-o"></i> Guest Name</th>
                    <th  style="min-width:200px;"><i class="fa fa-bookmark-o"></i> Check In / Check Out</th>
                    <th  style="min-width:150px;"><i class="fa fa-bookmark-o"></i> Point Of Contact</th>
                    <th style="min-width:110px;"><i class="fa fa-bookmark-o"></i> Status</th>

					
                    
                </tr>
                </thead>
                <tbody>
				<?=$alldf ?>
				
                
				
				
                </tbody>
            </table>
			
			
			
			
            </div>
			
			</section>
            </div>
            </div>
				
				
            </div>
            <!--body wrapper end-->
			


	