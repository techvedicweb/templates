
 <!-- page head start-->
            <div class="page-head" style="display:block; min-height:70px;">
                <h3 style="float:left;">Rejection</h3>
				
				
			</div>
			
			
 	<div class="err">
	<?php
		$err = $this->session->flashdata('error');
		if(!empty($err))
			echo '<div class="alert alert-warning">'.$err.'</div>';
		$scs = $this->session->flashdata('success');
		if(!empty($scs))
			echo '<div class="alert alert-success">'.$scs.'</div>';
		if(validation_errors())
		{
			echo '<div class="alert alert-warning">';
			if(form_error('agentslist'))
				echo 'Select Atleast One Employee';
			else
				echo validation_errors();
			echo '</div>';
		}
	?>
	</div>			
			

			
            <!-- page head end-->
            <!--body wrapper start-->
            <div class="wrapper">
				
			
				<div class="row">
					<div class="col-lg-11">
					
					 <form  role="form" method="post" onsubmit="return confirm('Are you sure to reject?');"  >
					 <input type="hidden" name="backurl" value="<?=$_SERVER['HTTP_REFERER'];  ?>"  />
                                        <div class="row">
                                            <div class="form-group">
                                                <div class="col-md-6" style="margin-bottom:10px;">
													<label class="control-label">Rejecting For</label>
                                                    <select required class="form-control"  name="rejection_cause">
														<option value="">Select the cause</option>
														<option value="Profile picture">Profile picture</option>
														<option value="Owner record do not match">Owner record do not match</option>
														<option value="Other">Other</option>
													</select>
                                                </div>
												
												
												<div class="col-md-12">
													<label class="control-label">In depth Reason</label>
                                                    <textarea required  class="form-control" name="rejection_detail"></textarea>
                                                </div>
												
												
                                            </div>
											
											
											
											<div class="form-group" >
                                                
                                                <div class="col-md-12" style="margin-top:5px;">
                                                    <button type="submit" style="float:right;" name="editprofile" class="btn btn-primary">Reject</button>
                                                </div>
                                            </div>
										
										
										</div>
                                    </form>
									
									
			
		   
		   
		   
		   
		   
		   
					</div>
				
				
				</div>
            </div>
            <!--body wrapper end-->

			
			


