<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Admin Template">
    <meta name="keywords" content="admin dashboard, admin, flat, flat ui, ui kit, app, web app, responsive">
    
    <title>ADMIN PANEL</title>

    <!-- Base Styles -->
    <link href="<?=base_url('nassets/css/style.css')?>" rel="stylesheet">
    <link href="<?=base_url('nassets/css/style-responsive.css')?>" rel="stylesheet">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.min.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->


</head>

  <body class="login-body">
  
  
<div class="err">
	<?php
		$err = $this->session->flashdata('error');
		if(!empty($err))
			echo '<div class="alert alert-warning">'.$err.'</div>';
		$scs = $this->session->flashdata('success');
		if(!empty($scs))
			echo '<div class="alert alert-success">'.$scs.'</div>';
		if(validation_errors())
		{
			echo '<div class="alert alert-warning">';
			if(form_error('agentslist'))
				echo 'Select Atleast One Employee';
			else
				echo validation_errors();
			echo '</div>';
		}
	?>
</div>
    
  
  
  
  
  
      <h2 class="form-heading">login</h2>
      <div class="container log-row">
          <form class="form-signin" method='post' action="<?=base_url().uri_string();  ?>">
              <div class="login-wrap">
                  <input type="text" class="form-control" placeholder="User ID" name='user_id'  id='user_id' autofocus>
                  <input type="password" class="form-control" name='password'  id='password' placeholder="Password">
                  <button class="btn btn-lg btn-success btn-block" name='login' type="submit">LOGIN</button>
                  
              </div>
		</form>
              <!-- Modal -->
              <div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="forgotPass" class="modal fade">
                  <div class="modal-dialog">
                      <div class="modal-content">
						<form name="fpass" method='post' action="<?=base_url('admin/forgotpassword');  ?>" >
                          <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                              <h4 class="modal-title">Forgot Password ?</h4>
                          </div>
                          <div class="modal-body">
                              <p>Enter your e-mail address below.</p>
                              <input required type="text" name="user_email" placeholder="Email" autocomplete="off" class="form-control placeholder-no-fix">

                          </div>
                          <div class="modal-footer">
                              <button data-dismiss="modal" class="btn btn-default" type="button">Cancel</button>
                              <button class="btn btn-success" type="submit">Submit</button>
                          </div>
						 <form>
                      </div>
                  </div>
              </div>
              <!-- modal -->

          
		  <div style="width:240px; margin:10px  auto; text-align:center; color:rgba(34, 34, 34, 0.71);;">
		  
		 
		  <a style="color:rgba(34, 34, 34, 0.71); text-decoration: Underline;" data-toggle="modal" href="#forgotPass">Forgot Password?</a>
		  <br>
		  Dont have an account?<a style=" color:rgba(34, 34, 34, 0.71); text-decoration: Underline;" href="<?=base_url('admin/register/');  ?>">Sign Up</a>
		  
		  </div>
		  
		  
      </div>

      <!--jquery-1.10.2.min-->
      <script src="<?=base_url('nassets/js/jquery-1.11.1.min.js')?>"></script>
      <!--Bootstrap Js-->
      <script src="<?=base_url('nassets/js/bootstrap.min.js')?>"></script>
      <script src="<?=base_url('nassets/js/respond.min.js')?>"></script>
  </body>
</html>
