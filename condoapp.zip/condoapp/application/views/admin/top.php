     

        <!-- body content start-->
        <div class="body-content">

            <!-- header section start-->
            <div class="header-section">

                <!--logo and logo icon start-->
                <div class="logo dark-logo-bg hidden-xs hidden-sm">
                    <a href="<?=base_url('admin/dashboard')?>">
                        <span class="brand-name">CONDO APP</span>
                    </a>
                </div>

                <div class="icon-logo dark-logo-bg hidden-xs hidden-sm">
                    <a href="<?=base_url('admin/dashboard')?>">
                        <span class="brand-name">C A</span>
                    </a>
                </div>
                <!--logo and logo icon end-->

                <!--toggle button start-->
                <a class="toggle-btn"><i class="fa fa-outdent"></i></a>
                <!--toggle button end-->

				
				
				
               
                <div class="notification-wrap">
                
				
				
				
				
				
				


                <!--right notification start-->
                <div class="right-notification">
                    <ul class="notification-menu">
                      
                        <li>
                            <a href="javascript:;" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                                <img src="<?=$mypic ?>" alt=""><?=$myinfo->user_name.' '.$myinfo->user_mname.' '.$myinfo->user_lname.' ';  ?>
                                <span class=" fa fa-angle-down"></span>
                            </a>
                            <ul class="dropdown-menu dropdown-usermenu purple pull-right">
                                
								<?php if($myinfo->user_typ!='Security'){?><li><a href="<?=base_url().$this->uri->segment(1).'/changepass'   ?>" ><i class="fa fa-lock pull-right"></i>  Change Password</a></li><?php }?>
								<li><a  href="<?=base_url().$this->uri->segment(1).'/editprofile'   ?>" ><i class="fa fa-lock pull-right"></i>  Edit Profile</a></li>
                                <li><a href="<?=base_url().$this->uri->segment(1).'/logout'   ?>"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
                            </ul>
                        </li>
                       <!--<li>
                            <div class="sb-toggle-right">
                                <i class="fa fa-indent"></i>
                            </div>
                        </li>-->

                    </ul>
                </div>
                <!--right notification end-->
                </div>

            </div>
            <!-- header section end-->