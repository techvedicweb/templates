<?php
$form_hding = '--';
$label_one='--';
if($this->uri->segment(2)=='condolist'){
	//print_result($datan);
	$form_hding = 'List Of Condos';
	$label_one='Unit Number';
}




?>


	<link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.6/themes/base/jquery-ui.css" type="text/css" media="all" />
        <link rel="stylesheet" href="http://static.jquery.com/ui/css/demo-docs-theme/ui.theme.css" type="text/   css" media="all" />
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.3/jquery.min.js" type="text/javascript"></script>
        <script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.6/jquery-ui.min.js" type="text/javascript"></script>
        
          
        <style>
            /* Autocomplete
            ----------------------------------*/
            .ui-autocomplete { position: absolute; cursor: default; }   
            .ui-autocomplete-loading { background: white url('http://jquery-ui.googlecode.com/svn/tags/1.8.2/themes/flick/images/ui-anim_basic_16x16.gif') right center no-repeat; }*/
  
            /* workarounds */
            * html .ui-autocomplete { width:1px; } /* without this, the menu expands to 100% in IE6 */
  
            /* Menu
            ----------------------------------*/
            .ui-menu {
                list-style:none;
                padding: 2px;
                margin: 0;
                display:block;
            }
            .ui-menu .ui-menu {
                margin-top: -3px;
            }
            .ui-menu .ui-menu-item {
                margin:0;
                padding: 0;
                zoom: 1;
                float: left;
                clear: left;
                width: 100%;
                font-size:80%;
            }
            .ui-menu .ui-menu-item a {
                text-decoration:none;
                display:block;
                padding:.2em .4em;
                line-height:1.5;
                zoom:1;
            }
            .ui-menu .ui-menu-item a.ui-state-hover,
            .ui-menu .ui-menu-item a.ui-state-active {
                font-weight: normal;
                margin: -1px;
            }
        </style>
          
        <script type="text/javascript">
        $(this).ready( function() {
            $("#id").autocomplete({
                minLength: 1,
                source: 
                function(req, add){
                    $.ajax({
                        url: "<?php echo base_url(); ?>manager/lookup",
                        dataType: 'json',
                        type: 'POST',
                        data: req,
                        success:    
                        function(data){
                            if(data.response =="true"){
                                add(data.message);
                            }
                        },
                    });
                },
            select: 
                function(event, ui) {
                    $("#result").append(
                        "<li>"+ ui.item.value + "</li>"
                    );                  
                },      
            });
        });
        </script>




			
 	<div class="err">
	<?php
		$err = $this->session->flashdata('error');
		if(!empty($err))
			echo '<div class="alert alert-warning">'.$err.'</div>';
		$scs = $this->session->flashdata('success');
		if(!empty($scs))
			echo '<div class="alert alert-success">'.$scs.'</div>';
		if(validation_errors())
		{
			echo '<div class="alert alert-warning">';
			if(form_error('agentslist'))
				echo 'Select Atleast ----';
			else
				echo validation_errors();
			echo '</div>';
		}
	?>
	</div>			
			


 
 <!-- page head start-->
            <div class="page-head" style="display:block; min-height:70px;">
                <h3 style="float:left;">CONDO MANAGER</h3>
				
			</div>
            <!-- page head end-->
            <!--body wrapper start-->
            <div class="wrapper">
                <div class="row">
            <div class="col-lg-12">
			
			
			<section class="panel">
                        <header class="panel-heading">
                            Add CONDO</b>
                        </header>
                        <div class="panel-body">
                            <form class="form-horizontal" enctype="multipart/form-data"  role="form" method="post">
								
								<div class="form-group">
                                    <label  class="col-lg-2">Select Your Owner</label>
                                    <div class="col-lg-10">
										
										<input type="text" name="printable_name" id="id"  class="form-control"  />
										<ul>
											<div id="result"></div>
										</ul>
									
                                    </div>
                                </div>
								
								
								<div class="form-group">
                                    <label  class="col-lg-2">Select Your Owner</label>
                                    <div class="col-lg-10">
									<!--class="js-example-basic-single form-control"-->
                                        <select required name="owner_id"  id="owner_id" class="form-control" >
											<option value="">Select Owner</option>
											<?php
											foreach($allowner as $aowner){
												echo '<option value="'.$aowner->user_id.'">'.$aowner->user_name.' '.$aowner->user_lname.'</option>';
											}
											
											?>
										</select>
                                    </div>
                                </div>
								
								
								
								
								
								
								
								
								
								
								<div class="form-group">
                                    <label  class="col-lg-2">Unit Number</label>
                                    <div class="col-lg-10">
                                        <input required type="text" name="cn_name"  id="cn_name" class="form-control" 
										placeholder="Provide Unit Number" value="" onkeypress="return isNumber(event,this)" maxlength="4" >
                                    </div>
                                </div>
								
								
                               
							    <button type="submit" style="float:right;" class="btn btn-primary">ADD</button>
                            </form>
                        </div>
                    </section>
			
			
			
			
			
			
			
            <section class="panel">
            <header class="panel-heading head-border">
                <?=$form_hding ?>
				<span class="tools pull-right">
					
					<select id="dynamic_select" onchange="if (this.value) window.location.href=this.value"  class="form-control input-sm" style="float:right;">
						<option <?=($this->uri->segment(3)=='ALL'  || $this->uri->segment(3)== NULL )?'selected':''  ?>  value="<?=base_url().$this->uri->segment(1).'/condolist'   ?>">ALL CONDO</option>
						<option <?=($this->uri->segment(3)=='PENDING' )?'selected':''  ?> value="<?=base_url().$this->uri->segment(1).'/condolist'   ?>/PENDING">PENDING</option>
						<option <?=($this->uri->segment(3)=='APPROVED' )?'selected':''  ?> value="<?=base_url().$this->uri->segment(1).'/condolist'   ?>/APPROVED">APPROVED</option>
						<option <?=($this->uri->segment(3)=='DISABLED' )?'selected':''  ?> value="<?=base_url().$this->uri->segment(1).'/condolist'   ?>/DISABLED">DISABLED</option>
					</select>
				</span>
				
				
				
            </header>
			<div class="table-responsive">
            <!--<table class="table table-striped custom-table table-hover">-->
            <table class="table table-striped custom-table table-hover">
                <thead>
                <tr>
                    <th><i class="fa fa-bookmark-o"></i> <?=$label_one ?></th>
                    <th><i class="fa fa-bookmark-o"></i> Created On</th>
                    <th><i class="fa fa-bookmark-o"></i> Created By</th>
                    <th><i class="fa fa-bookmark-o"></i> Status</th>
                    
                </tr>
                </thead>
                <tbody>
				<?=$alldf ?>
				
                
				
				
                </tbody>
            </table>
            </div>
			
			</section>
            </div>
            </div>
				
				
            </div>
            <!--body wrapper end-->
