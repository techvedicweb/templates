<?php
$form_hding = '--';
$label_one='--';
if($this->uri->segment(2)=='condolist'){
	//print_result($datan);
	$form_hding = 'List Of Condos';
	$label_one='Unit Number';
}




?>




			
 	<div class="err">
	<?php
		$err = $this->session->flashdata('error');
		if(!empty($err))
			echo '<div class="alert alert-warning">'.$err.'</div>';
		$scs = $this->session->flashdata('success');
		if(!empty($scs))
			echo '<div class="alert alert-success">'.$scs.'</div>';
		if(validation_errors())
		{
			echo '<div class="alert alert-warning">';
			if(form_error('agentslist'))
				echo 'Select Atleast ----';
			else
				echo validation_errors();
			echo '</div>';
		}
	?>
	</div>			
			


 
 <!-- page head start-->
            <div class="page-head" style="display:block; min-height:70px;">
                <h3 style="float:left;">Condo Manager</h3>
				
			</div>
            <!-- page head end-->
            <!--body wrapper start-->
            <div class="wrapper">
                <div class="row">
            <div class="col-lg-12">
			
			
			<section class="panel">
                        <header class="panel-heading">
                            Add CONDO</b>
                        </header>
                        <div class="panel-body">
                            <form class="form-horizontal" enctype="multipart/form-data"  role="form" method="post">
								
								<div class="form-group">
                                    <label  class="col-lg-2">Select Your Owner</label>
                                    <div class="col-lg-10">
										
										<input type="text" name="owner_id" id="tag"  class="form-control"  />
										
									
                                    </div>
                                </div>
								
								<!--
								<div class="form-group">
                                    <label  class="col-lg-2">Select Your Owner</label>
                                    <div class="col-lg-10">
									
                                        <select required name="owner_id"  id="owner_id" class="form-control" >
											<option value="">Select Owner</option>
											<?php
											foreach($allowner as $aowner){
												echo '<option value="'.$aowner->user_id.'">'.$aowner->user_name.' '.$aowner->user_lname.'</option>';
											}
											
											?>
										</select>
                                    </div>
                                </div>
								-->
								
								
								
								
								
								
								
								
								
								<div class="form-group">
                                    <label  class="col-lg-2">Unit Number</label>
                                    <div class="col-lg-10">
                                        <input required type="text" name="cn_name"  id="cn_name" class="form-control" 
										placeholder="Provide Unit Number" value="" onkeypress="return isNumber(event,this)" maxlength="4" >
                                    </div>
                                </div>
								
								
                               
							    <button type="submit" style="float:right;" class="btn btn-primary">ADD</button>
                            </form>
                        </div>
                    </section>
			
			
			
			
			
			
			
            <section class="panel">
            <header class="panel-heading head-border">
                <?=$form_hding ?>
				<span class="tools pull-right">
					
					<select id="dynamic_select" onchange="if (this.value) window.location.href=this.value"  class="form-control input-sm" style="float:right;">
						<option <?=($this->uri->segment(3)=='ALL'  || $this->uri->segment(3)== NULL )?'selected':''  ?>  value="<?=base_url().$this->uri->segment(1).'/condolist'   ?>">ALL CONDO</option>
						<option <?=($this->uri->segment(3)=='PENDING' )?'selected':''  ?> value="<?=base_url().$this->uri->segment(1).'/condolist'   ?>/PENDING">PENDING</option>
						<option <?=($this->uri->segment(3)=='APPROVED' )?'selected':''  ?> value="<?=base_url().$this->uri->segment(1).'/condolist'   ?>/APPROVED">APPROVED</option>
						<option <?=($this->uri->segment(3)=='DISABLED' )?'selected':''  ?> value="<?=base_url().$this->uri->segment(1).'/condolist'   ?>/DISABLED">DISABLED</option>
					</select>
				</span>
				
				
				
            </header>
			<div class="table-responsive">
            <!--<table class="table table-striped custom-table table-hover">-->
            <table class="table table-striped custom-table table-hover">
                <thead>
                <tr>
                    <th><i class="fa fa-bookmark-o"></i> <?=$label_one ?></th>
                    <th><i class="fa fa-bookmark-o"></i> Created On</th>
                    <th><i class="fa fa-bookmark-o"></i> Created By</th>
                    <th><i class="fa fa-bookmark-o"></i> Status</th>
                    
                </tr>
                </thead>
                <tbody>
				<?=$alldf ?>
				
                
				
				
                </tbody>
            </table>
            </div>
			
			</section>
            </div>
            </div>
				
				
            </div>
            <!--body wrapper end-->
