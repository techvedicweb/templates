<?php 
$this->load->view('admin/header');
if($this->session->userdata('user_typ')=='Admin'){
	$this->load->view('admin/sadmin_sidebar');
}elseif($this->session->userdata('user_typ')=='Security'){
	$this->load->view('admin/security_sidebar');
}else{
	$this->load->view('admin/sidebar');
}

$this->load->view('admin/top');

?>

 		
		<?php $this->load->view($sub_view); ?> 


<?php 
$this->load->view('admin/footer'); 
?>