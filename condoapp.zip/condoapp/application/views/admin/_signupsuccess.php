<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Admin Template">
    <meta name="keywords" content="admin dashboard, admin, flat, flat ui, ui kit, app, web app, responsive">
    
    <title>ADMIN PANEL</title>

    <!-- Base Styles -->
    <link href="<?=base_url('nassets/css/style.css')?>" rel="stylesheet">
    <link href="<?=base_url('nassets/css/style-responsive.css')?>" rel="stylesheet">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.min.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->


</head>

  <body class="login-body">
  
  

 
 <style>
.form-group{
	margin-bottom:0;
}
.showhide{
	display:none;
}
#errmsg{
	color:#ff0000;
}
.bbox{
	border:1px solid #ccc;
	margin-bottom:10px;
}
</style>
 
  
  
  
  
  
      <h2 class="form-heading">Sign Up</h2>
      <div class="container log-row">
         
		 
			<?php
			if($success=='yes'){
				?>
					<div style="width:100%; padding:50px; margin-top:50px;" class="alert alert-success">
					<h3 style="line-height:130%;">
					Thank you for submitting your application for our short term rentals platform. 
					Our team will review your application. You will receive an email notification confirming your account. <br />
					For immediate questions you may visit our offices . <br />
					You can also submit your inquiries to <a href="mailto:str@grandcondominium.com" >str@grandcondominium.com</a> <br />
					We try to reply to all inquiries within 24 hours.<br />
					</h3>
					
					</div>
				
				
				
				<?php
			}
			
			?>
		 
		 
		 
		 
			<div style="width:48px; margin:10px  auto;">
		  <a style="text-align:center;  color:rgba(34, 34, 34, 0.71);" href="<?=base_url('admin/login/');  ?>">Log In</a>
		  </div>
	  
	  
	  </div>

      <!--jquery-1.10.2.min-->
      <script src="<?=base_url('nassets/js/jquery-1.11.1.min.js')?>"></script>
      <!--Bootstrap Js-->
      <script src="<?=base_url('nassets/js/bootstrap.min.js')?>"></script>
      <script src="<?=base_url('nassets/js/respond.min.js')?>"></script>
	  
<script>
   
function isNumber(evt) {
	    evt = (evt) ? evt : window.event;
	    var charCode = (evt.which) ? evt.which : evt.keyCode;
	    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
	        return false;
	    }
	    return true;
	}
$('#mpos').change(function(){
	var vv = $("#mpos").val();
	$('#manager, #owner').hide();
	if(vv=='Manager'){
		$('#manager').show();
	}
	if(vv=='Owner'){
		$('#owner').show();
	}
});
$('#loginbtn').click(function(){
    //console.log($('.validatedForm').valid());
	$( "#errmsg" ).html( "" );
	var p =  $( "#user_password" ).val();
	var rp =  $( "#rp_password" ).val();
	
	if(p!=''  && rp!=''){
		if(p!=rp){
			//$( "#errmsg" ).val()="sdfgdfghdfgh";
			$( "#errmsg" ).html( "Password Mismatch" );
		}
	}
	
	
	
});


</script>
  </body>
</html>
