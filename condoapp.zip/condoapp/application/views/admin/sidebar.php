<style>
.nav-active a{
	/*color:#e4e4e4 !important;*/
}

</style> 

 <!-- sidebar left start-->
        <div class="sidebar-left">
            <!--responsive view logo start-->
            <div class="logo dark-logo-bg visible-xs-* visible-sm-*">
                <a href="<?=base_url('admin/dashboard')?>">                    
                    <span class="brand-name">CALLSCRIPT</span>
                </a>
            </div>
            <!--responsive view logo end-->

            <div class="sidebar-left-info">
                <!-- visible small devices start-->
                <div class=" search-field">  </div>
                <!-- visible small devices end-->

                <!--sidebar nav start--><?php //echo $this->session->userdata('name');?>
                <ul class="nav nav-pills nav-stacked side-navigation">
<?php
$dashcss='';
if($this->uri->segment(2)=='dashboard'){
	$dashcss='id="nav-on"';
}

$edtprofcss='';
if($this->uri->segment(2)=='editprofile'){
	$edtprofcss='id="nav-on"';
}


$chpass='';
if($this->uri->segment(2)=='changepass'){
	$chpass='id="nav-on"';
}

?>


				
                    <li  class="nav-active"  <?=$dashcss  ?>  >
					<a href="<?=base_url().$this->uri->segment(1).'/dashboard'   ?>"><i class="fa fa-home"></i> <span>Dashboard</span></a></li>
                    

<?php
$linkm1 = array("condolist", "addcondo", "editcondo");
$classm1 = 'class="menu-list  "';
if (in_array($this->uri->segment(2), $linkm1)){
	$classm1 = 'class="menu-list  nav-active"';	
}

$linkn1 = array("bookinglist", "addbooking" , "editbooking");
$classn1 = 'class="menu-list  "';
if (in_array($this->uri->segment(2), $linkn1)){
	$classn1 = 'class="menu-list  nav-active"';	
}




$linkmn1 = array("addcondo", "editcondo");
$pgcls ='';
if (in_array($this->uri->segment(2), $linkmn1)){
	$pgcls = 'class="active"';	
}

$linkmn2 = array("addbooking", "editbooking", "tnc", "card", "booksuccess");
$pgclsv ='';
if (in_array($this->uri->segment(2), $linkmn2)){
	$pgclsv = 'class="active"';	
}

?>	
					<li class="menu-list  nav-active" ><a href=""><i class="fa fa-cogs"></i> <span>Condo Management</span></a>
                        <ul class="child-list">
                            <!--<li <?=$pgcls ?> ><a href="<?=base_url().$this->uri->segment(1).'/addcondo'   ?>">Add Condo</a></li>-->
                            <li <?=($this->uri->segment(2)=='condolist')?'class="active"':''  ?> >
								<a href="<?=base_url().$this->uri->segment(1).'/condolist'   ?>">Add Condo</a>
							</li>
                        </ul>
                    </li>
					
					
					<li class="menu-list  nav-active" ><a href=""><i class="fa fa-cogs"></i> <span>Booking Management</span></a>
                        <ul class="child-list">
                            <li <?=$pgclsv ?> ><a href="<?=base_url().$this->uri->segment(1).'/addbooking'   ?>" >Add Booking</a></li>
                            <li <?=($this->uri->segment(2)=='bookinglist')?'class="active"':''  ?> >
								<a href="<?=base_url().$this->uri->segment(1).'/bookinglist'   ?>">Booking List</a>
							</li>
                        </ul>
                    </li>
					
					<li class=" nav-active" <?=$edtprofcss;  ?> ><a  href="<?=base_url().$this->uri->segment(1).'/editprofile'   ?>"><i class="fa fa-user"></i> 
					<span>Edit Profile</span></a></li>
					
					<li class=" nav-active" <?=$chpass;  ?> ><a  href="<?=base_url().$this->uri->segment(1).'/changepass'   ?>"><i class="fa fa-user"></i> 
					<span>Change password</span></a></li>
					
					
					
					

                </ul>
                <!--sidebar nav end-->

               
            </div>
        </div>
        <!-- sidebar left end-->