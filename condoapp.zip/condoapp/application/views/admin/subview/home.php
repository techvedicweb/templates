            <!-- page head start-->
            <div class="page-head">
                <h3>
                    Dashboard
                </h3>
                <span class="sub-title">Welcome to DASHBOARD</span>
                
			
			</div>
            <!-- page head end-->

			
 	<div class="err">
	<?php
		$err = $this->session->flashdata('error');
		if(!empty($err))
			echo '<div class="alert alert-warning">'.$err.'</div>';
		$scs = $this->session->flashdata('success');
		if(!empty($scs))
			echo '<div class="alert alert-success">'.$scs.'</div>';
		if(validation_errors())
		{
			echo '<div class="alert alert-warning">';
			if(form_error('agentslist'))
				echo 'Select Atleast One Employee';
			else
				echo validation_errors();
			echo '</div>';
		}
	?>
	</div>			
			
			
            <!--body wrapper start-->
            <div class="wrapper">
               
				
				
				
				
                <div class="row">
				<div class="col-md-3" style="display:none;">
                    <section class="panel post-wrap pro-box team-member">
                        <aside class="bg-primary v-align">
                            <div class="panel-body text-center">
                                <div class="team-member-wrap">
                                    <div class="team-member-info">
                                        <div class="action-set">
                                            <a href="javascript:;" class="tooltips" data-original-title="Profile Info" data-toggle="tooltip" data-placement="top">
                                                <i class="fa fa-reorder"></i>
                                            </a>
                                        </div>
                                        <div class="team-title">
                                            <a href="javascript:;" class="m-name">
                <?=$myinfo->user_name.' '.$myinfo->user_mname.' '.$myinfo->user_lname;  ?>
                                            </a>
                                            <span class="sub-title"> <?=$this->session->userdata('user_typ');  ?></span>
                                        </div>

                                        <div class="call-info" style="margin: 22px 0;">
                                            <a data-toggle="modal" href="#myModal" title="Change Password">
                                                <i class="fa fa-lock"></i>
                                            </a>
                                            <img src="<?=$mypic ?>" alt="" />
                                            <a  data-toggle="modal" href="#myModalimg" title="Change Profile Pic">
                                                <i class="fa fa-photo"></i>
                                            </a>
											
											
											
											
											
											
											
                                        </div>
                                        <div class="status">
                                            <h5>Address</h5>
                                            <span><?=$myinfo->address.' '.$myinfo->city.' '.$myinfo->state.' '.$myinfo->country.''.$myinfo->zip ?> </span>
											<h5>Phone</h5>
                                            <span><?=$myinfo->phone ?> </span>
											<h5>Email</h5>
                                            <span><?=$myinfo->user_email ?> </span>
											
											
											

                                    </div>
                                </div>
                            </div>
                            </div>
                        </aside>
						<?php
						$hideit="";
						if($this->session->userdata('user_typ')=='Manager'){
							$hideit='style="display:none;"';
						}
						?>
                        <aside <?=$hideit  ?> style="display:none;">
                            <header class="panel-heading head-border">
                                MANAGERS UNDER YOU
                            </header>
                            <div class="post-info">
                                <ul class="team-list cycle-pager external" id='no-template-pager'>
                                   <?php
								   if(count($managers)>0){
									   $cn = 0;
									   foreach($managers as $m)
									   {
										$cn ++;						
										if($m->thumbnail==''){
											$mpic =  base_url('nassets/img/avatar-mini.jpg');
										}else{
											$mpic = base_url('nassets/img/profpic').'/'.$m->thumbnail;
										}   
										if($m->status=='I'){
											$sts =  ' (Pending) ';
											$stsval = 'Pending';
										}else{
											$sts =  "";
											$stsval = 'Approved';
										}   
										   
										   
								   ?>
								   <li>
                                        <a data-toggle="modal" href="#mngr<?=$cn  ?>" >
                                            <span class="thumb-small">
                                                <img class="circle" src="<?=$mpic ?>" alt=""/>
                                            </span>
                                            <span class="name"><?=$m->user_name.' '.$m->user_mname.' '.$m->user_lname; ?> <?=$sts   ?></span>
											
                                        </a>
                                    </li>
<!-- Modal FOR CHANGE Profile Pic-->
                        <div class="modal fade" id="mngr<?=$cn  ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="margin-top:10%;">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                        <h4 class="modal-title">Manager Details</h4>
                                    </div>
                                    <div class="modal-body">
									 <p>
									 NAME:   <?=$m->user_name.' '.$m->user_mname.' '.$m->user_lname; ?> <br>
									 EMAIL:   <?=$m->user_email; ?> <br>
									 PHONE:   <?=$m->phone; ?> <br>
									 ADDRESS: <?=$m->address.' '.$m->city.' '.$m->state .' '.$m->country.' '.$m->zip; ?> <br>
									 Status: <?=$stsval ?> <br>
									 </p>
									 <?php
									 if($stsval == 'Pending'){
									?>
									<form role="form" method="post" style=" margin-bottom:20px;">
									<input type="hidden" name="user_id" value="<?=$m->user_id  ?>" />	
									<button type="submit" style="float:left;" name="approval" class="btn btn-primary">Approve</button>
									</form>									
										 
										 
									<?php
									 }
									 ?>
									 
									
									</div>
                                    <div class="modal-footer">
                                        <button data-dismiss="modal" class="btn btn-default" type="button">Close</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- modal -->									
									
									<?php
										}
								   }else{
									   echo "No manager under you. Ask your manager to register under you.";
								   }
									
									?>
									
                                </ul>
                               
                            </div>
                        </aside>
                    </section>
                </div>
                <div class="col-md-12">
                    <section class="panel">
                        <header class="panel-heading head-border">
                            Latest Booking List
                        </header>
                       <div class="table-responsive">
						<!--<table class="table table-striped custom-table table-hover">-->
						<table class="table table-striped custom-table table-hover">
							<thead>
							<tr>


<?php
$condo_link= base_url().$this->uri->segment(1).'/'.$this->uri->segment(2).'/SORTY/cn_name/ASC';
if($this->uri->segment(3)=='SORTY' && $this->uri->segment(4)=='cn_name' && $this->uri->segment(5)=='ASC'){
	$condo_link =base_url().$this->uri->segment(1).'/'.$this->uri->segment(2).'/SORTY/cn_name/DESC';	
}
?>

							
								<th><i class="fa fa-bookmark-o"></i> Booking Id </th>
								<th><i class="fa fa-bookmark-o"></i><a href="<?=$condo_link  ?>"> Unit Number </a></th>
								<th> </th>
								<th><i class="fa fa-bookmark-o"></i> Guest Name</th>
								<th><i class="fa fa-bookmark-o"></i> Check In / Check Out</th>
								<th><i class="fa fa-bookmark-o"></i> Point Of Contact</th>
								<th><i class="fa fa-bookmark-o"></i> Status</th>					
								
							</tr>
							</thead>
							<tbody>
							<?=$alldf ?>
							
							
							
							
							</tbody>
						</table>
						</div>
                    </section>
                </div>
				
				
				
				</div>

            </div>
            <!--body wrapper end-->
			
			

						
						<!-- Modal FOR CHANGE Profile Pic-->
                        <div class="modal fade" id="myModalimg" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="margin-top:10%;">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                        <h4 class="modal-title">Change Profile Picture</h4>
                                    </div>
                                    <div class="modal-body">
									 <form enctype="multipart/form-data" role="form" method="post" action="<?=base_url().$this->uri->segment(1).'/dashboard'   ?>">
                                        <div class="row">
                                            <div class="form-group">
                                                <label class="control-label col-md-4">Select Profile Pic</label>
                                                <div class="col-md-8">
                                                    <input type="file" name="thumb" class="form-control"   required />
                                                </div>
                                            </div>
										
                                            <div class="form-group" >
                                                
                                                <div class="col-md-12" style="margin-top:5px;">
                                                    <button type="submit" style="float:right;" name="profpic" class="btn btn-primary">Change</button>
                                                </div>
                                            </div>
										
										
										</div>
                                    </form>
									
									
									</div>
                                    <div class="modal-footer">
                                        <button data-dismiss="modal" class="btn btn-default" type="button">Close</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- modal -->

