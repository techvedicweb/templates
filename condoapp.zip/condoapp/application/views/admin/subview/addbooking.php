<style>
#parkingbox{display:none;}

</style>
 <!-- page head start-->
            <div class="page-head" style="display:block; min-height:70px;">
                <h3 style="float:left;">Booking Manager</h3>
				
				
				<a style="float:right;" href="<?=base_url().$this->uri->segment(1).'/condolist'   ?>" class="btn btn-primary">Back to Booking List</a>
				
			</div>
			
			
 	<div class="err">
	<?php
		$err = $this->session->flashdata('error');
		if(!empty($err))
			echo '<div class="alert alert-warning">'.$err.'</div>';
		$scs = $this->session->flashdata('success');
		if(!empty($scs))
			echo '<div class="alert alert-success">'.$scs.'</div>';
		if(validation_errors())
		{
			echo '<div class="alert alert-warning">';
			if(form_error('agentslist'))
				echo 'Select Atleast One Employee';
			else
				echo validation_errors();
			echo '</div>';
		}
	?>
	</div>			
			

			
            <!-- page head end-->
            <!--body wrapper start-->
            <div class="wrapper">
				<div class="row">
					<div class="alert alert-info fade in">
                        <strong>After submitting your request, please allow up to a 72 hour time period for approval.</strong> 
                    </div>
				</div>
			
			
			
			
				<div class="row">
					<div class="col-lg-11">
					
					<form class="form-horizontal" enctype="multipart/form-data" onsubmit="return frmvalidate()" role="form" method="post">
					
					
					<section class="panel">
                        <header class="panel-heading">
                            Add Booking</b>
                        </header>
                        <div class="panel-body">
								<div class="form-group">
                                    <div class="col-lg-6">
										<label >Choose Condo</label>
                                        <select name="condo_id" required class="form-control" >
											<option value="">Select Condo</option>
											<?=$allselect  ?>
										</select>
                                    </div>
									<div class="col-lg-6">
										<label >Point Of Contact</label>
                                        <select name="poc_id" required class="form-control" >
											<option value="<?=$this->session->userdata('user_id')  ?>">Owner</option>
											<?=$allmngr  ?>
										</select>
                                    </div>
									
									
									
									
									
									
									
									
                                </div>
                        </div>
                    </section>
					
					
					
					
					
					
					<section class="panel">
                        <div class="panel-body">
								<div class="form-group">
                                    <div class="col-lg-6" style="margin-bottom:12px;">
										<label >Guest First Name</label>
                                        <input required type="text" name="party_name"  class="form-control" 
										placeholder="Provide First Name" value="" maxlength="80" >
                                    </div>
									<div class="col-lg-6" style="margin-bottom:12px;">
										<label >Guest Last Name</label>
                                        <input required type="text" name="party_lname"  class="form-control" 
										placeholder="Provide Last Name" value="" maxlength="80" >
                                    </div>
									
									<div class="col-lg-6" style="margin-bottom:12px;">
										<label >Guest Email</label>
                                        <input required type="email" name="email"  class="form-control" 
										placeholder="Provide Email" value="" maxlength="80" >
                                    </div>
									<div class="col-lg-6">
										<label >Guest Phone</label>
                                        <input required type="phone" name="phone"  class="form-control"  onkeypress="return isNumber(event,this)" maxlength="10" minlength="10"
										placeholder="Provide Phone" value="" >
                                    </div>
									<div class="col-lg-12">
										<label >Guest Picture</label>
                                        <input type="file" name="thumb" class="form-control" style="margin-bottom: 10px;"   required />
										<span style="font-size;14px; background:#ffee09;  padding:3px 8px; font-style:italic;">
										Picture must show a clear headshot of the guest. Pictures with sunglasses or headwear will not be approved
										</span>
                                    </div>
									
									
                                </div>
						</div>
                    </section>

					<section class="panel">
                        <div class="panel-body">
								<div class="form-group">
                                   <div class="col-lg-12">
										<label >Move In date</label>  
<span style="font-size;14px; background:#ffee09; padding:3px 8px; margin:8px 0; font-style:italic;">
All reservations need to be processed with a minimum of 3 days in advance. 
Also, a minimum 2 night stay and maximum 30 day stay for all bookings.</span>											
										<div class="input-group input-large" style="margin-top: 10px;" >
											<input required type="text" class="form-control dpd1"  id="dpd1" name="book_st_dt" placeholder="Check In" />
											<span class="input-group-addon">To</span>
											<input  required type="text" class="form-control dpd2" id="dpd2"  name="book_end_dt"  placeholder="Check Out" />
										</div>
										<span id="dayerr" style="color:#ff0000;"></span>
                                    </div>   
									
									
									<div class="col-lg-12" id="parkingbox">
											
                                    <label class="checkbox-custom check-success">
                                        <input type="checkbox" value="yes" name="isparking" id="checkbox2"> <label for="checkbox2">
										The selected days qualify for 1 parking decal during the booking period. Please select this option to redeem parking privileges. <br>
										A additional $15 fee will be added to your transaction.</label>
                                    </label>
                                
									</div>
									
									
									
									
                                </div>
						</div>
                    </section>

					
					<section class="panel">
                        <div class="panel-body">			
								<div class="form-group">
                                    <div class="col-lg-12">
										<label >Comments</label>
                                        <textarea name="description" class="form-control" maxlength="250"></textarea>
                                    </div>
                                </div>
							    <button type="submit" style="float:right;" class="btn btn-primary">Continue</button>
                        </div>
                    </section>
				 </form>
		   
		   
					</div>
				</div>
            </div>
            <!--body wrapper end-->

			
			


