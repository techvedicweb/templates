
 <!-- page head start-->
            <div class="page-head" style="display:block; min-height:70px;">
                <h3 style="float:left;">Booking Manager</h3>
				
				
			</div>
			
			

			
            <!-- page head end-->
            <!--body wrapper start-->
            <div class="wrapper">
				
			
				<div class="row">
					<div class="col-lg-11">
					
					<form class="form-horizontal" enctype="multipart/form-data" role="form" method="post">
					
					
					<section class="panel">
                        <header class="panel-heading">
                            PAYMENT TRANSACTION </b>
                        </header>
                        <div class="panel-body">
						<?php
							if($tran_typ =='success'){
						?>
								<h3 class="alert alert-info fade in" style="font-size:28px; line-height:180%;"> Your transaction was successfully processed! <br>
								Please allow up to <strong>72hrs</strong> for your booking to be approved <br>
								For immediate assistance, you may reach us at the condo association office
								</h3>
						<?php
						}else{
						?>
								<h3 class="alert alert-info fade in" style="font-size:28px; line-height:180%;"> Your last transaction was failed! <br>
								<strong>For:</strong>  <?=$tran_msg ?>
								</h3>
						
						
						<?php
						}
						?>
						
						</div>
                    </section>
					
				 </form>
			
		   
		   
		   
		   
		   
		   
					</div>
				
				
				</div>
            </div>
            <!--body wrapper end-->

			
			


