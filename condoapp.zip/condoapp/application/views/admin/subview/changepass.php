
 <!-- page head start-->
            <div class="page-head" style="display:block; min-height:70px;">
                <h3 style="float:left;">Change Password</h3>
				
				
			</div>
			
			
 	<div class="err">
	<?php
		$err = $this->session->flashdata('error');
		if(!empty($err))
			echo '<div class="alert alert-warning">'.$err.'</div>';
		$scs = $this->session->flashdata('success');
		if(!empty($scs))
			echo '<div class="alert alert-success">'.$scs.'</div>';
		if(validation_errors())
		{
			echo '<div class="alert alert-warning">';
			if(form_error('agentslist'))
				echo 'Select Atleast One Employee';
			else
				echo validation_errors();
			echo '</div>';
		}
	?>
	</div>			
			

			
            <!-- page head end-->
            <!--body wrapper start-->
            <div class="wrapper">
				
			
				<div class="row">
					<div class="col-lg-5">
					 <form  role="form" method="post" >
                                        <div class="row">
                                            <div class="form-group">
                                                <label class="control-label col-md-12">Old Password</label>
                                                <div class="col-md-12">
                                                    <input type="password" class="form-control" name="oldp" />
                                                </div>
                                            </div>
											<div class="form-group ">
                                                <label class="control-label col-md-12">New Password</label>
                                                <div class="col-md-12" style="margin-top:5px;">
                                                    <input type="password" class="form-control" name="newp" />
                                                </div>
                                            </div>
											<div class="form-group ">
                                                <label class="control-label col-md-12">Repeat Password</label>
                                                <div class="col-md-12" style="margin-top:5px;">
                                                    <input type="password" class="form-control" name="repeatp" />
                                                </div>
                                            </div>
                                            <div class="form-group" >
                                                
                                                <div class="col-md-12" style="margin-top:5px;">
                                                    <button type="submit" style="float:right;" name="changepassword" class="btn btn-primary">Change Password</button>
                                                </div>
                                            </div>
										
										
										</div>
                                    </form>
		   
		   
		   
		   
		   
		   
					</div>
				
				
				</div>
            </div>
            <!--body wrapper end-->

			
			


