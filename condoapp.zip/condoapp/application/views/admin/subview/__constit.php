<?php
$form_hding = '--';
$label_one='--';
$btn_nm='--';
if($this->uri->segment(1)=='action'  &&$this->uri->segment(2)=='constit'){
	$exval ="";
	if($s_state!=""){
		$exval = "For ".$s_state->statename ."  [<a href='".base_url("action/allconstit/")."'>View All</a>]";
	}
	
	
	$form_hding = 'List Of Constituency '.$exval;
	$label_one='State Name';
	$btn_nm='Add';
	$form_head='Add Constituency';
}

if($this->uri->segment(1)=='action'  &&$this->uri->segment(2)=='edit_state'){
	$form_hding = 'List Of Constituency';
	
	$btn_nm='Update';
	$form_head='Edit Constituency';
}


?> 
 <!-- page head start-->
            <div class="page-head" style="display:block; min-height:70px;">
                <h3 style="float:left;">CONSTITUENCY MANAGER</h3>
				<a style="float:right;" href="<?=base_url('admin/dashboard/')?>" class="btn btn-primary">DASHBOARD</a>
			</div>
			
			
			
 	<div class="err">
	<?php
		$err = $this->session->flashdata('error');
		if(!empty($err))
			echo '<div class="alert alert-warning">'.$err.'</div>';
		$scs = $this->session->flashdata('success');
		if(!empty($scs))
			echo '<div class="alert alert-success">'.$scs.'</div>';
		if(validation_errors())
		{
			echo '<div class="alert alert-warning">';
			if(form_error('agentslist'))
				echo 'Select Atleast One Employee';
			else
				echo validation_errors();
			echo '</div>';
		}
	?>
	</div>			
			

				
			
			
            <!-- page head end-->
            <!--body wrapper start-->
            <div class="wrapper">
        <div class="row">
			<div class="col-lg-4">
					<section class="panel">
                        <header class="panel-heading">
                           <?=$form_head  ?></b>
                        </header>
                        <div class="panel-body">
                            <form class="form-horizontal" role="form" method="post" style="padding:2px 10px;">
							   
							  <div class="form-group">
                                        States
										<select class="form-control" name="stateid">
											<?php
											foreach($allst as $a){
												?><option value="<?=$a->statename  ?>"><?=$a->statename  ?></option><?php
											}
											?>
										
										
										
										
										</select>
                                </div>
								
								<div class="form-group">
                                        Constituency Name
                                        <input required type="text" name="cityname"  id="cityname" class="form-control" 
										placeholder="Constituency Name" value="<?=(isset($thisdata))?$thisdata->cityname:''   ?>" >
                                </div>
							    <button type="submit" name="addcity" style="float:right;" class="btn btn-primary"><?=$btn_nm  ?></button>
                            </form>
                        </div>
                    </section>
			</div>
            <div class="col-lg-8">
            <section class="panel">
            <header class="panel-heading head-border">
                <?=$form_hding ?>
            </header>
			<div class="table-responsive">
            <table class="table table-striped custom-table table-hover">
                <thead>
                <tr>
                    <th><i class="fa fa-bookmark-o"></i> State</th>
                    <th><i class="fa fa-bookmark-o"></i> Constituency</th>
                    <th class="hidden-xs"><i class="fa fa-cogs"></i> Action</th>
                </tr>
                </thead>
                <tbody>
				<?=$alldf ?>
				
                
				
				
                </tbody>
            </table>
            
			<h4 class="paging"><?php echo $links; ?></h4>
			
			
			</div>
			
			</section>
            </div>
        </div>
				
				
            </div>
            <!--body wrapper end-->