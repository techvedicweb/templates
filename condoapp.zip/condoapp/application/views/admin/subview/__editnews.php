<style>
.dyna{
	margin-top:10px; padding-bottom:30px;
}
.dyna li{
	margin-bottom:5px;
}
</style>

<script src="<?=base_url('nassets/ck/ckeditor.js')?>"></script>
 <!-- page head start-->
            <div class="page-head" style="display:block; min-height:70px;">
                <h3 style="float:left;">NEWS MANAGER</h3>
				
				
				<a style="float:right;" href="<?=base_url('action/newslist')?>" class="btn btn-primary">Back to News List</a>
				
			</div>
			
			
 	<div class="err">
	<?php
		$err = $this->session->flashdata('error');
		if(!empty($err))
			echo '<div class="alert alert-warning">'.$err.'</div>';
		$scs = $this->session->flashdata('success');
		if(!empty($scs))
			echo '<div class="alert alert-success">'.$scs.'</div>';
		if(validation_errors())
		{
			echo '<div class="alert alert-warning">';
			if(form_error('agentslist'))
				echo 'Select Atleast One Employee';
			else
				echo validation_errors();
			echo '</div>';
		}
	?>
	</div>			
			

			
            <!-- page head end-->
            <!--body wrapper start-->
            <div class="wrapper">
				<div class="row">
					<div class="col-lg-11">
					<section class="panel">
                        <header class="panel-heading">
                            Edit News</b>
                        </header>
                        <div class="panel-body">
                            <form class="form-horizontal" role="form" method="post">
							   
							  
								
								<div class="form-group">
                                    <label  class="col-lg-1">News Heading</label>
                                    <div class="col-lg-5">
                                        <input required type="text" name="page_heading"  id="page_heading" class="form-control" 
										placeholder="Heading Of The page" value="<?=$this_pages->page_heading ?>" >
                                    </div>
									<label  class="col-lg-1">News Thumbnail</label>
                                    <div class="col-lg-5">
										<input type="file" name="thumb" class="form-control"    />
                                    </div>
									
									
									
                                </div>
								<div class="form-group">
                                    <label  class="col-lg-1">Content</label>
                                    <div class="col-lg-11">
										<textarea  id="editor" name="page_txt" id="page_txt" class="form-control editorz" placeholder="Page Content" ><?=$this_pages->page_txt ?></textarea>
                                    </div>
                                </div>
								
								<div class="form-group">
                                    <label  class="col-lg-1">Meta Title</label>
                                    <div class="col-lg-11">
                                        <input required type="text" name="meta_title"  id="meta_title" class="form-control" 
										placeholder="Heading Of The page" value="<?=$this_pages->meta_title ?>" >
                                    </div>
                                </div>
								
								<div class="form-group">
                                    <label  class="col-lg-1">Meta Description</label>
                                    <div class="col-lg-11">
                                        <input required type="text" name="meta_desc"  id="meta_desc" class="form-control" 
										placeholder="Heading Of The page" value="<?=$this_pages->meta_desc ?>" >
                                    </div>
                                </div>
								
								<div class="form-group">
                                    <label  class="col-lg-1">Meta Keywords</label>
                                    <div class="col-lg-11">
                                        <input required type="text" name="meta_keyword"  id="meta_keyword" class="form-control" 
										placeholder="Heading Of The page" value="<?=$this_pages->meta_keyword ?>" >
                                    </div>
                                </div>
								
                               
							    <button type="submit" style="float:right;" class="btn btn-primary">UPDATE</button>
                            </form>
                        </div>
                    </section>
               
            
			
		   
		   
		   
		   
		   
		   
					</div>
				
				
				</div>
            </div>
            <!--body wrapper end-->

			
 <script>
CKEDITOR.replace( 'editor', {
	uiColor: '#f1f1f1',
	removeButtons: ('About')
});
</script>				
			
			
			
			