            <!-- page head start-->
            <div class="page-head">
                <h3>
                    Dashboard
                </h3>
                <span class="sub-title">Welcome to DASHBOARD</span>
                
			
			</div>
            <!-- page head end-->

			
 	<div class="err">
	<?php
		$err = $this->session->flashdata('error');
		if(!empty($err))
			echo '<div class="alert alert-warning">'.$err.'</div>';
		$scs = $this->session->flashdata('success');
		if(!empty($scs))
			echo '<div class="alert alert-success">'.$scs.'</div>';
		if(validation_errors())
		{
			echo '<div class="alert alert-warning">';
			if(form_error('agentslist'))
				echo 'Select Atleast One Employee';
			else
				echo validation_errors();
			echo '</div>';
		}
	?>
	</div>			
			
			
			
			
			
			
            <!--body wrapper start-->
            <div class="wrapper">
			   YOUR ACCOUNT HAS NOT YET BEEN APPROVED BY THE ADMINISTARORS

			   </div>
            <!--body wrapper end-->
			
			



