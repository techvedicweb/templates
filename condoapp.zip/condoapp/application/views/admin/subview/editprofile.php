
 <!-- page head start-->
            <div class="page-head" style="display:block; min-height:70px;">
                <h3 style="float:left;">Edit Profile</h3>
				
				
			</div>
			
			
 	<div class="err">
	<?php
		$err = $this->session->flashdata('error');
		if(!empty($err))
			echo '<div class="alert alert-warning">'.$err.'</div>';
		$scs = $this->session->flashdata('success');
		if(!empty($scs))
			echo '<div class="alert alert-success">'.$scs.'</div>';
		if(validation_errors())
		{
			echo '<div class="alert alert-warning">';
			if(form_error('agentslist'))
				echo 'Select Atleast One Employee';
			else
				echo validation_errors();
			echo '</div>';
		}
	?>
	</div>			
			

			
            <!-- page head end-->
            <!--body wrapper start-->
            <div class="wrapper">
				
			
				<div class="row">
					<div class="col-lg-11">
					
					 <form  role="form" method="post"  >
                                        <div class="row">
                                            <div class="form-group">
                                                <div class="col-md-6">
													<label class="control-label">First Name</label>
                                                    <input required type="text" class="form-control" name="user_name" value="<?=$myinfo->user_name ?>" />
                                                </div>
												<div class="col-md-6" style="display:none;">
													<label class="control-label">Middle Name</label>
                                                    <input type="text" class="form-control" name="user_mname" value="<?=$myinfo->user_mname ?>" />
                                                </div>
												<div class="col-md-6">
													<label class="control-label">Last Name</label>
                                                    <input required type="text" class="form-control" name="user_lname" value="<?=$myinfo->user_lname ?>" />
                                                </div>
                                            
                                                <div class="col-md-6">
													<label class="control-label">Phone</label>
                                                    <input required  onkeypress="return isNumber(event,this)" type="text" class="form-control" name="phone" value="<?=$myinfo->phone ?>" />
                                                </div>
												<div class="col-md-6">
													<label class="control-label">Address</label>
                                                    <input required type="text" class="form-control" name="address" value="<?=$myinfo->address ?>" />
                                                </div>
                                            
                                                <div class="col-md-6">
													<label class="control-label">City</label>
                                                    <input type="text" class="form-control" name="city" value="<?=$myinfo->city ?>" />
                                                </div>
												<div class="col-md-6">
													<label class="control-label">State</label>
                                                    <input type="text" class="form-control" name="state" value="<?=$myinfo->state ?>" />
                                                </div>
												<div class="col-md-6">
													<label class="control-label">Country</label>
                                                    <input type="text" class="form-control" name="country" value="<?=$myinfo->country ?>" />
                                                </div>
												<div class="col-md-6">
													<label class="control-label">Zip</label>
                                                    <input type="text" class="form-control"  onkeypress="return isNumber(event,this)" name="zip" value="<?=$myinfo->zip ?>" />
                                                </div>
                                            </div>
											
											
											
											<div class="form-group" >
                                                
                                                <div class="col-md-12" style="margin-top:5px;">
                                                    <button type="submit" style="float:right;" name="editprofile" class="btn btn-primary">Update</button>
                                                </div>
                                            </div>
										
										
										</div>
                                    </form>
									
									
			
		   
		   
		   
		   
		   
		   
					</div>
				
				
				</div>
            </div>
            <!--body wrapper end-->

			
			


