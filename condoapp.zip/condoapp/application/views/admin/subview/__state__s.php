<?php
$form_hding = '--';
$label_one='--';
$btn_nm='--';
if($this->uri->segment(1)=='action'  &&$this->uri->segment(2)=='states'){
	$form_hding = 'List Of States';
	$label_one='State Name';
	$btn_nm='Add';
	$form_head='Add State';
}

if($this->uri->segment(1)=='action'  &&$this->uri->segment(2)=='edit_state'){
	$form_hding = 'List Of States';
	$label_one='State Name';
	$btn_nm='Update';
	$form_head='Edit State';
}


?> 
 <!-- page head start-->
            <div class="page-head" style="display:block; min-height:70px;">
                <h3 style="float:left;">STATE MANAGER</h3>
				<a style="float:right;" href="<?=base_url('admin/dashboard/')?>" class="btn btn-primary">DASHBOARD</a>
			</div>
			
			
			
 	<div class="err">
	<?php
		$err = $this->session->flashdata('error');
		if(!empty($err))
			echo '<div class="alert alert-warning">'.$err.'</div>';
		$scs = $this->session->flashdata('success');
		if(!empty($scs))
			echo '<div class="alert alert-success">'.$scs.'</div>';
		if(validation_errors())
		{
			echo '<div class="alert alert-warning">';
			if(form_error('agentslist'))
				echo 'Select Atleast One Employee';
			else
				echo validation_errors();
			echo '</div>';
		}
	?>
	</div>			
			

				
			
			
            <!-- page head end-->
            <!--body wrapper start-->
            <div class="wrapper">
        <div class="row">
			<div class="col-lg-4">
					<section class="panel">
                        <header class="panel-heading">
                           <?=$form_head  ?></b>
                        </header>
                        <div class="panel-body">
                            <form class="form-horizontal" role="form" method="post" style="padding:2px 10px;">
							   
							  
								
								<div class="form-group">
                                        State Name
                                        <input required type="text" name="state"  id="state" class="form-control" 
										placeholder="State Name" value="<?=(isset($thisdata))?$thisdata->statename:''   ?>" >
                                </div>
							    <button type="submit" style="float:right;" class="btn btn-primary"><?=$btn_nm  ?></button>
                            </form>
                        </div>
                    </section>
			</div>
            <div class="col-lg-8">
            <section class="panel">
            <header class="panel-heading head-border">
                <?=$form_hding ?>
            </header>
			<div class="table-responsive">
            <table class="table table-striped custom-table table-hover">
                <thead>
                <tr>
                    <th><i class="fa fa-bookmark-o"></i> <?=$label_one ?></th>
                    <th class="hidden-xs"><i class="fa fa-cogs"></i> Action</th>
                </tr>
                </thead>
                <tbody>
				<?=$alldf ?>
				
                
				
				
                </tbody>
            </table>
            </div>
			
			</section>
            </div>
        </div>
				
				
            </div>
            <!--body wrapper end-->