<?php
$form_hding = '--';
$label_one='--';
if($this->uri->segment(1)=='action'  &&$this->uri->segment(2)=='newslist'){
	//print_result($datan);
	$form_hding = 'List Of NEWS';
	$label_one='News Headlines';
}




?> 
 <!-- page head start-->
            <div class="page-head" style="display:block; min-height:70px;">
                <h3 style="float:left;">NEWS MANAGER</h3>
				<a style="float:right;" href="<?=base_url('action/addnews/')?>" class="btn btn-primary">ADD NEWS</a>
				
			</div>
			
			
			
 	<div class="err">
	<?php
		$err = $this->session->flashdata('error');
		if(!empty($err))
			echo '<div class="alert alert-warning">'.$err.'</div>';
		$scs = $this->session->flashdata('success');
		if(!empty($scs))
			echo '<div class="alert alert-success">'.$scs.'</div>';
		if(validation_errors())
		{
			echo '<div class="alert alert-warning">';
			if(form_error('agentslist'))
				echo 'Select Atleast One Employee';
			else
				echo validation_errors();
			echo '</div>';
		}
	?>
	</div>			
			
		
			
			
            <!-- page head end-->
            <!--body wrapper start-->
            <div class="wrapper">
                <div class="row">
            <div class="col-lg-12">
            <section class="panel">
            <header class="panel-heading head-border">
                <?=$form_hding ?>
            </header>
			<div class="table-responsive">
            <table class="table table-striped custom-table table-hover">
                <thead>
                <tr>
                    <th><i class="fa fa-bookmark-o"></i> <?=$label_one ?></th>
                    <th class="hidden-xs"><i class="fa fa-cogs"></i> Action</th>
                </tr>
                </thead>
                <tbody>
				<?=$alldf ?>
				
                
				
				
                </tbody>
            </table>
            </div>
			
			</section>
            </div>
            </div>
				
				
            </div>
            <!--body wrapper end-->