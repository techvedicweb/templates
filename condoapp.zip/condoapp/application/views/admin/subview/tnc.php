
 <!-- page head start-->
            <div class="page-head" style="display:block; min-height:70px;">
                <h3 style="float:left;">Booking Manager</h3>
				
			</div>
			
			
 	<div class="err">
	<?php
		$err = $this->session->flashdata('error');
		if(!empty($err))
			echo '<div class="alert alert-warning">'.$err.'</div>';
		$scs = $this->session->flashdata('success');
		if(!empty($scs))
			echo '<div class="alert alert-success">'.$scs.'</div>';
		if(validation_errors())
		{
			echo '<div class="alert alert-warning">';
			if(form_error('agentslist'))
				echo 'Select Atleast One Employee';
			else
				echo validation_errors();
			echo '</div>';
		}
	?>
	</div>			
			

			
            <!-- page head end-->
            <!--body wrapper start-->
            <div class="wrapper">
				
			
				<div class="row">
					<div class="col-lg-11">
					
					<form class="form-horizontal" enctype="multipart/form-data" role="form" method="post">
					
					
					<section class="panel">
                        <header class="panel-heading">
                            TERMS AND CONDITION</b>
                        </header>
                        <div class="panel-body">
								<div class="form-group">
                                    
									<div class="col-lg-12" >
									
<h3>SHORT TERM RENTAL ACKNOWLEDGMENT </h3>
Dear Condominium Guest:<br><br>
The Grand Condominium is home to many families. Our Goal is to make sure all residents are able to have the quiet enjoyment of their homes. The following rules and regulations are in place to ensure the coexistences of both residents of the building and our guests.
<br><br>
<ul>
<li>Parties and or gathering of any kind are not permitted in the rentals.</li>
<li>Maximum capacity of our 1 bedroom condos is three (3) persons and 2-bedroom condos five (5) persons.</li>
<li>Pet belonging to guests are not permitted. </li>
<li>You will receive 2 keys for your unit, 2 key fobs and one parking hang tag. You will 
for forfeit your deposit if these items are not returned upon departure.</li>
<li>You are permitted to self-park one vehicle on the FF level. Display the hang tag on the rearview mirror. Vehicles without the hang tag 
displayed may be towed away from the Parking garage at your expense.</li>
<li>All condos are non-smoking units. If you smoke we kindly ask that you smoke only on the balcony. Do not throw cigarette butts out of 
your balcony.</li>
<li>Any and all activity that causes excessive noise or nuisance is strictly prohibited.</li>
<li>Your unit will be inspected prior to departure. Should any damages occur, a damage fee will be assessed, and you will be held 
responsible. You will also be held responsible for the replacement of any missing items or removal of excessive smoke odor in the unit.</li>
</ul>
<br><br>

Thank you in advance for your cooperation and we hope your stay with us is an enjoyable one.<br>

<form method="post"  >

	<div class="col-lg-9">
		<label class="checkbox-custom check-success">
			<input required type="checkbox" value=" " id="checkbox3"> <label for="checkbox3">I Agree to the terms and conditions.</label>
		</label>
		
	</div>
	<div class="col-lg-9">
	 <button type="submit" style="float:left;" disabled name="continue" id="continue" class="btn btn-primary">CONTINUE</button>	
	 <a style="float:left; margin-left:10px;" href="<?=base_url("admin/dashboard/") ?>"  class="btn btn-default">DECLINE</a>	
	</div>
</form>	




									
										
										
                                    </div>
									
									<?php
									//$vv = $this->session->userdata('allpost');
									//print_result($vv);
									?>
									
									
									
									
									
									
                                </div>
                        </div>
                    </section>
					
				 </form>
			
		   
		   
		   
		   
		   
		   
					</div>
				
				
				</div>
            </div>
            <!--body wrapper end-->

			
			


