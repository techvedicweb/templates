<style>
.dyna{
	margin-top:10px; padding-bottom:30px;
}
.dyna li{
	margin-bottom:5px;
}
</style>

<script src="<?=base_url('nassets/ck/ckeditor.js')?>"></script>
 <!-- page head start-->
            <div class="page-head" style="display:block; min-height:70px;">
                <h3 style="float:left;">Condo  Manager</h3>
				<a style="float:right;" href="<?=base_url('admin/condolist')?>" class="btn btn-primary">Back to Condo List</a>
			</div>
			
			
 	<div class="err">
	<?php
		$err = $this->session->flashdata('error');
		if(!empty($err))
			echo '<div class="alert alert-warning">'.$err.'</div>';
		$scs = $this->session->flashdata('success');
		if(!empty($scs))
			echo '<div class="alert alert-success">'.$scs.'</div>';
		if(validation_errors())
		{
			echo '<div class="alert alert-warning">';
			if(form_error('agentslist'))
				echo 'Select Atleast One Employee';
			else
				echo validation_errors();
			echo '</div>';
		}
	?>
	</div>			
			

			
            <!-- page head end-->
            <!--body wrapper start-->
            <div class="wrapper">
				<div class="row">
					<div class="col-lg-7">
					<section class="panel">
                        <header class="panel-heading">
                            Edit Condo</b>
                        </header>
                        <div class="panel-body">
                            <form class="form-horizontal" role="form" method="post">
							   
							  
								<div class="form-group">
                                    <label  class="col-lg-3">Unit NAME</label>
                                    <div class="col-lg-9">
                                        <input required type="text" name="cn_name"  id="cn_name" class="form-control" 
										placeholder="Name Of Condo" value="<?=$this_pages->cn_name;  ?>" >
                                    </div>
                                </div>
								
							    <button type="submit" style="float:right;" class="btn btn-primary">UPDATE</button>
                            </form>
                        </div>
                    </section>
               
            
			
		   
		   
		   
		   
		   
		   
					</div>
				
				
				</div>
            </div>
            <!--body wrapper end-->

			
 <script>
CKEDITOR.replace( 'editor', {
	uiColor: '#f1f1f1',
	removeButtons: ('About')
});
</script>				
			
			
			
			