
 <!-- page head start-->
            <div class="page-head" style="display:block; min-height:70px;">
                <h3 style="float:left;">Booking Manager</h3>
				
				
				<a style="float:right;" href="<?=base_url().$this->uri->segment(1).'/condolist'   ?>" class="btn btn-primary">Back to Booking List</a>
				
			</div>
			
			
 	<div class="err">
	<?php
		$err = $this->session->flashdata('error');
		if(!empty($err))
			echo '<div class="alert alert-warning">'.$err.'</div>';
		$scs = $this->session->flashdata('success');
		if(!empty($scs))
			echo '<div class="alert alert-success">'.$scs.'</div>';
		if(validation_errors())
		{
			echo '<div class="alert alert-warning">';
			if(form_error('agentslist'))
				echo 'Select Atleast One Employee';
			else
				echo validation_errors();
			echo '</div>';
		}
	?>
	</div>			
			

			
            <!-- page head end-->
            <!--body wrapper start-->
            <div class="wrapper">
				<div class="row">
					<div class="col-lg-11">
					<section class="panel">
                        <header class="panel-heading">
                            Edit Booking</b>
                        </header>
                        <div class="panel-body">
                            <form class="form-horizontal"  role="form" method="post">
								
								<div class="form-group">
                                    <div class="col-lg-6">
										<label >Choose Condo</label><br>
                                        <?=$condonm  ?>
                                    </div>
									<div class="col-lg-6">
										<label >Book For Date Rangest</label> <br>                                       
										FROM: <?=date('M d Y',strtotime($dbook->book_st_dt)).' to '.date('M d Y',strtotime($dbook->book_end_dt))  ?>
                                    </div>
									
									
									
									
									
                                </div>
								<div class="form-group">
                                    <div class="col-lg-6">
										<label >Enter Name</label>
                                        <input required type="text" name="party_name"  class="form-control" 
										placeholder="Provide Name" value="<?=$dbook->party_name  ?>" maxlength="80" >
                                    </div>
									<div class="col-lg-3">
										<label >Email</label>
                                        <input required type="email" name="email"  class="form-control" 
										placeholder="Provide Email" value="<?=$dbook->email  ?>" maxlength="80" >
                                    </div>
									<div class="col-lg-3">
										<label >Phone</label>
                                        <input required type="phone" name="phone"  class="form-control"  onkeypress="return isNumber(event,this)" maxlength="16"
										placeholder="Provide Phone" value="<?=$dbook->phone  ?>" >
                                    </div>
                                </div>
								<div class="form-group">
                                    <div class="col-lg-4">
										<label >Address</label>
                                        <input required type="text" name="address"  maxlength="150" class="form-control" 
										placeholder="Provide Address" value="<?=$dbook->address  ?>" >
                                    </div>
									<div class="col-lg-2">
										<label >City</label>
                                        <input  type="text" name="city"  class="form-control"  maxlength="50"
										placeholder="Provide City" value="<?=$dbook->city  ?>" >
                                    </div>
									<div class="col-lg-2">
										<label >State</label>
                                        <input  type="text" name="state"  class="form-control" maxlength="40"
										placeholder="Provide state" value="<?=$dbook->state  ?>" >
                                    </div>
									<div class="col-lg-2">
										<label >Country</label>
                                        <input  type="text" name="country"  class="form-control" maxlength="50"
										placeholder="Provide country" value="<?=$dbook->country  ?>" >
                                    </div>
									<div class="col-lg-2">
										<label >Zip</label>
                                        <input  type="text" name="zip"  class="form-control" onkeypress="return isNumber(event,this)" 
										placeholder="Provide zip" maxlength="6" value="<?=$dbook->zip  ?>" >
                                    </div>
                                </div>
								
								
                               
							    <button type="submit" style="float:right;" class="btn btn-primary">UPDATE</button>
                            </form>
                        </div>
                    </section>
               
            
			
		   
		   
		   
		   
		   
		   
					</div>
				
				
				</div>
            </div>
            <!--body wrapper end-->

			
			


