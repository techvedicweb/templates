        <!-- sidebar left start-->
        <div class="sidebar-left">
            <!--responsive view logo start-->
            <div class="logo dark-logo-bg visible-xs-* visible-sm-*">
                <a href="<?=base_url('admin/dashboard')?>">                    
                    <span class="brand-name">CONDO ADMIN</span>
                </a>
            </div>
            <!--responsive view logo end-->

            <div class="sidebar-left-info">
                <!-- visible small devices start-->
                <div class=" search-field">  </div>
                <!-- visible small devices end-->

                <!--sidebar nav start-->
                <ul class="nav nav-pills nav-stacked side-navigation">
 

<?php
$dashcss='';
if($this->uri->segment(2)=='dashboard'){
	$dashcss='id="nav-on"';
}

$edtprofcss='';
if($this->uri->segment(2)=='editprofile'){
	$edtprofcss='id="nav-on"';
}


$chpass='';
if($this->uri->segment(2)=='changepass'){
	$chpass='id="nav-on"';
}

?>


 
                    <li class="nav-active" <?=$dashcss  ?> >
					<a href="<?=base_url().$this->uri->segment(1).'/dashboard'   ?>"><i class="fa fa-home"></i> <span>Dashboard</span></a></li>
                    

<?php
$linkm1 = array("condolist", "addcondo", "editcondo");
$classm1 = 'class="menu-list  "';
if (in_array($this->uri->segment(2), $linkm1)){
	$classm1 = 'class="menu-list  nav-active"';	
}

$linkn1 = array("bookinglist", "addbooking" , "editbooking");
$classn1 = 'class="menu-list  "';
if (in_array($this->uri->segment(2), $linkn1)){
	$classn1 = 'class="menu-list  nav-active"';	
}




$linkmn1 = array("addcondo", "editcondo");
$pgcls ='';
if (in_array($this->uri->segment(2), $linkmn1)){
	$pgcls = 'class="active"';	
}

$linkmn2 = array("addbooking", "editbooking");
$pgclsv ='';
if (in_array($this->uri->segment(2), $linkmn2)){
	$pgclsv = 'class="active"';	
}

?>	
					<li class="menu-list  nav-active" ><a href=""><i class="fa fa-cogs"></i> <span>Users</span></a>
                        <ul class="child-list">
                            <li <?=($this->uri->segment(2)=='userlist' && $this->uri->segment(3)=='PENDING')?'class="active"':''  ?> >
								<a href="<?=base_url().$this->uri->segment(1).'/userlist/PENDING'   ?>">Pending User List</a>
							</li>
	<li <?=($this->uri->segment(2)=='userlist' && $this->uri->segment(3)=='APPROVED' && $this->uri->segment(4)=='Manager')?'class="active"':''  ?> >
		<a href="<?=base_url().$this->uri->segment(1).'/userlist/APPROVED/Manager'   ?>">Approved Managers</a>
	</li>
	<li <?=($this->uri->segment(2)=='userlist' && $this->uri->segment(3)=='APPROVED' && $this->uri->segment(4)=='Owner')?'class="active"':''  ?> >
		<a href="<?=base_url().$this->uri->segment(1).'/userlist/APPROVED/Owner'   ?>">Approved Owners</a>
	</li>
	
                        </ul>
                    </li>
					
					<li class="menu-list  nav-active" ><a href=""><i class="fa fa-cogs"></i> <span>Units</span></a>
                        <ul class="child-list">
                            <li <?=($this->uri->segment(2)=='condolist' && $this->uri->segment(3)=='PENDING')?'class="active"':''  ?> >
								<a href="<?=base_url().$this->uri->segment(1).'/condolist/PENDING'   ?>">Pending Units</a>
							</li>
							<li <?=($this->uri->segment(2)=='condolist' && $this->uri->segment(3)=='APPROVED')?'class="active"':''  ?> >
								<a href="<?=base_url().$this->uri->segment(1).'/condolist/APPROVED'   ?>">Approved Units</a>
							</li>
							<!--<li <?=($this->uri->segment(2)=='condomlist' && $this->uri->segment(3)=='PENDING')?'class="active"':''  ?> >
								<a href="<?=base_url().$this->uri->segment(1).'/condomlist/PENDING'   ?>">Pending Units (Managers)</a>
							</li>
							<li <?=($this->uri->segment(2)=='condomlist' && $this->uri->segment(3)=='APPROVED')?'class="active"':''  ?> >
								<a href="<?=base_url().$this->uri->segment(1).'/condomlist/APPROVED'   ?>">Approved Units (Managers)</a>
							</li>-->
                        </ul>
                    </li>
					
					
					<li class="menu-list  nav-active" ><a href=""><i class="fa fa-cogs"></i> <span>Bookings</span></a>
                        <ul class="child-list">
                            
                            <li <?=($this->uri->segment(2)=='bookinglist' && $this->uri->segment(3)=='PENDING')?'class="active"':''  ?> >
								<a href="<?=base_url().$this->uri->segment(1).'/bookinglist/PENDING'   ?>">Pending Booking List</a>
							</li>
							<li <?=($this->uri->segment(2)=='bookinglist' && $this->uri->segment(3)=='APPROVED')?'class="active"':''  ?> >
								<a href="<?=base_url().$this->uri->segment(1).'/bookinglist/APPROVED'   ?>">Approved Booking List</a>
							</li>
                        </ul>
                    </li>
					
					
					
					
					
					

                </ul>
                <!--sidebar nav end-->

               
            </div>
        </div>
        <!-- sidebar left end-->