<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Admin Template">
    <meta name="keywords" content="admin dashboard, admin, flat, flat ui, ui kit, app, web app, responsive">
    
    <title>The Grand | Active Rentals</title>

    <!-- Base Styles -->
    <link href="<?=base_url('nassets/css/style.css')?>" rel="stylesheet">
    <link href="<?=base_url('nassets/css/style-responsive.css')?>" rel="stylesheet">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.min.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->

	
<link rel="stylesheet" href="<?=base_url('nassets/image_mag/magnific-popup.css')?>">

<style>

/* padding-bottom and top for image */
.mfp-no-margins img.mfp-img {
	padding: 0;
}
/* position of shadow behind the image */
.mfp-no-margins .mfp-figure:after {
	top: 0;
	bottom: 0;
}
/* padding for main container */
.mfp-no-margins .mfp-container {
	padding: 0;
}


/* 

for zoom animation 
uncomment this part if you haven't added this code anywhere else

*/
/*

.mfp-with-zoom .mfp-container,
.mfp-with-zoom.mfp-bg {
	opacity: 0;
	-webkit-backface-visibility: hidden;
	-webkit-transition: all 0.3s ease-out; 
	-moz-transition: all 0.3s ease-out; 
	-o-transition: all 0.3s ease-out; 
	transition: all 0.3s ease-out;
}

.mfp-with-zoom.mfp-ready .mfp-container {
		opacity: 1;
}
.mfp-with-zoom.mfp-ready.mfp-bg {
		opacity: 0.8;
}

.mfp-with-zoom.mfp-removing .mfp-container, 
.mfp-with-zoom.mfp-removing.mfp-bg {
	opacity: 0;
}
*/



.side-navigation > li.nav-active > a:after{
	display:none;
}
.btn-primary, .btn-primary:hover {
	background-color: #985019;
    border-color: #985019;
    color: #FFFFFF;
}
.side-navigation > li.nav-active > a{
	color: #dc6409;
}
</style>
	
	
</head>

  <body class="login-body">
  
  
<div class="err">
	<?php
		$err = $this->session->flashdata('error');
		if(!empty($err))
			echo '<div class="alert alert-warning">'.$err.'</div>';
		$scs = $this->session->flashdata('success');
		if(!empty($scs))
			echo '<div class="alert alert-success">'.$scs.'</div>';
		if(validation_errors())
		{
			echo '<div class="alert alert-warning">';
			if(form_error('agentslist'))
				echo 'Select Atleast One Employee';
			else
				echo validation_errors();
			echo '</div>';
		}
	?>
</div>
      <h2 class="form-heading">Active Short Term Rentals</h2>
      <div class="container log-row">
        







 <div class="wrapper">
 

 <div class="row">
				<div class="col-lg-12">
					<form class="tools pull-left" style="margin-bottom:8px;" method="post"  >
						<div class="input-group col-md-12">
							
							<input  class="form-control" type="text" name="searchterm" placeholder="Guest Name / Email / Booking Agent" /> 
							<span class="input-group-btn">
								<button name="searchbtn"  class="btn btn-success" type="submit"><i class="fa fa-search fa-fw"></i> Search</button>
							</span>
						</div>
					</form>
				</div>
				
</div>
 
 
 
 
 
 
 
 
 
 
                <div class="row">
            <div class="col-lg-12">
            <section class="panel">
            <header class="panel-heading head-border">
                List Of Bookings
				<span class="tools pull-right">
					
					<select id="dynamic_select" onchange="if (this.value) window.location.href=this.value"  class="form-control input-sm" style="float:right;">
						<option <?=($this->uri->segment(3)=='ALL')?'selected':''  ?>  value="<?=base_url().$this->uri->segment(1).'/publiclist/ALL'   ?>">ALL BOOKINGS</option>
						<option <?=($this->uri->segment(3)=='PENDING' )?'selected':''  ?> value="<?=base_url().$this->uri->segment(1).'/publiclist'   ?>/PENDING">PENDING</option>
						<option <?=($this->uri->segment(3)=='APPROVED' || $this->uri->segment(3)== NULL  )?'selected':''  ?> value="<?=base_url().$this->uri->segment(1).'/publiclist'   ?>/APPROVED">APPROVED</option>
					</select>
				</span>
				
				
				
            </header>
			<div class="table-responsive">
            <!--<table class="table table-striped custom-table table-hover">-->
            <table class="table table-striped custom-table table-hover">
			
<?php
$guest_nm_link=base_url().$this->uri->segment(1).'/publiclist/SORTY/party_name/ASC';
if($this->uri->segment(3)=='SORTY' && $this->uri->segment(4)=='party_name' && $this->uri->segment(5)=='ASC'){
	$guest_nm_link= base_url().$this->uri->segment(1).'/publiclist/SORTY/party_name/DESC';	
}

$email_link=base_url().$this->uri->segment(1).'/publiclist/SORTY/email/ASC';
if($this->uri->segment(3)=='SORTY' && $this->uri->segment(4)=='email' && $this->uri->segment(5)=='ASC'){
	$email_link=base_url().$this->uri->segment(1).'/publiclist/SORTY/email/DESC';	
}

$checkin_link= base_url().$this->uri->segment(1).'/publiclist/SORTY/book_st_dt/ASC';
if($this->uri->segment(3)=='SORTY' && $this->uri->segment(4)=='book_st_dt' && $this->uri->segment(5)=='ASC'){
	$checkin_link=base_url().$this->uri->segment(1).'/publiclist/SORTY/book_st_dt/DESC';	
}

$checkout_link= base_url().$this->uri->segment(1).'/publiclist/SORTY/book_end_dt/ASC';
if($this->uri->segment(3)=='SORTY' && $this->uri->segment(4)=='book_end_dt' && $this->uri->segment(5)=='ASC'){
	$checkout_link =base_url().$this->uri->segment(1).'/publiclist/SORTY/book_end_dt/DESC';	
}

$condo_link= base_url().$this->uri->segment(1).'/publiclist/SORTY/cn_name/ASC';
if($this->uri->segment(3)=='SORTY' && $this->uri->segment(4)=='cn_name' && $this->uri->segment(5)=='ASC'){
	$condo_link =base_url().$this->uri->segment(1).'/publiclist/SORTY/cn_name/DESC';	
}





?>			
			
			
                <thead>
                <tr>
                    
                    <th style="min-width:122px;"><i class="fa fa-bookmark-o"></i><a href="<?=$condo_link  ?>"> Unit Number </a></th>
					<th> </th>
                    <th style="min-width:125px;"><i class="fa fa-bookmark-o"></i> <a href="<?=$guest_nm_link  ?>">Guest Name</a></th>
                    <th style="min-width:125px;"><i class="fa fa-bookmark-o"></i> <a href="<?=$email_link  ?>">Guest Email</a></th>
					<th style="min-width:150px;"><i class="fa fa-bookmark-o"></i> Point Of Contact</th>
                    <th style="min-width:200px;"><i class="fa fa-bookmark-o"></i>  <a href="<?=$checkin_link  ?>">Check In</a> / <a href="<?=$checkout_link  ?>">Check Out</a></th>
                    <th style="min-width:110px;"><i class="fa fa-bookmark-o"></i> Status</th>







					
                    
                </tr>
                </thead>
                <tbody>
				<?=$alldf ?>
				
                
				
				
                </tbody>
            </table>
			
			
			
			
            </div>
			
			</section>
            </div>
            </div>
				
				
            </div>
            <!--body wrapper end-->		
              

         
		 
		  
		  
      </div>
      <!--jquery-1.10.2.min-->
      <script src="<?=base_url('nassets/js/jquery-1.11.1.min.js')?>"></script>
      <!--Bootstrap Js-->
      <script src="<?=base_url('nassets/js/bootstrap.min.js')?>"></script>
      <script src="<?=base_url('nassets/js/respond.min.js')?>"></script>
	  
	  
	  <script src="<?=base_url('nassets/image_mag/jquery.magnific-popup.js')?>"></script>
<script>
$(document).ready(function() {

	$('.image-popup-vertical-fit').magnificPopup({
		type: 'image',
		closeOnContentClick: true,
		mainClass: 'mfp-img-mobile',
		image: {
			verticalFit: true
		}
		
	});

	$('.image-popup-fit-width').magnificPopup({
		type: 'image',
		closeOnContentClick: true,
		image: {
			verticalFit: false
		}
	});

	$('.image-popup-no-margins').magnificPopup({
		type: 'image',
		closeOnContentClick: true,
		closeBtnInside: false,
		fixedContentPos: true,
		mainClass: 'mfp-no-margins mfp-with-zoom', // class to remove default margin from left and right side
		image: {
			verticalFit: true
		},
		zoom: {
			enabled: true,
			duration: 300 // don't foget to change the duration also in CSS
		}
	});

});


</script>


	  
  </body>
  </html>
