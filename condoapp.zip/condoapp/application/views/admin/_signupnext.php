<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Admin Template">
    <meta name="keywords" content="admin dashboard, admin, flat, flat ui, ui kit, app, web app, responsive">
    
    <title>ADMIN PANEL</title>

    <!-- Base Styles -->
    <link href="<?=base_url('nassets/css/style.css')?>" rel="stylesheet">
    <link href="<?=base_url('nassets/css/style-responsive.css')?>" rel="stylesheet">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.min.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->


</head>

  <body class="login-body">
  
  
<div class="err">
	<?php
		$err = $this->session->flashdata('error');
		if(!empty($err))
			echo '<div class="alert alert-warning">'.$err.'</div>';
		$scs = $this->session->flashdata('success');
		if(!empty($scs))
			echo '<div class="alert alert-success">'.$scs.'</div>';
		if(validation_errors())
		{
			echo '<div class="alert alert-warning">';
			if(form_error('agentslist'))
				echo 'Select Atleast One Employee';
			else
				echo validation_errors();
			echo '</div>';
		}
	?>
</div>
 
 
 <style>
.form-group{
	margin-bottom:0;
}
.showhide{
	display:none;
}
#errmsg{
	color:#ff0000;
}
.bbox{
	/*border:1px solid #ccc;*/
	margin-bottom:10px;
}
</style>
 
  
  
  
  
  
      <h2 class="form-heading">Sign Up</h2>
      <div class="container log-row">
          <form class="form-signin"  enctype="multipart/form-data" role="form" style="max-width:660px;" method='post' action="<?=base_url().uri_string();  ?>">
		 
              <div class="login-wrap">
                 
				  

<?php
if($user_typ=='Owner'){
?>				  
				  
				  <div class="form-group row" id="owner" style="background:#efefef; padding:5px 25px;">
				  
				  <h2>Primary Unit</h2>
				  <h5>Please enter the unit you would like assigned to your account.</h5>
				  
				  
					<div class="col-lg-12 bbox">
						<label>Unit Number </label>
						<input type="text" required class="form-control" placeholder="Add Unit (Mandatory)" name='unit[]'    >
					</div>
					
					
					<div style="height:15px; margin-top:15px; border-top:1px solid #ccc; clear:both;"></div>



					
				  <h2>Additional Units</h2>
				  <h5>You may add up to 4 additional units during account sign up. Account holders with more than 5 units, may add additional units in your dashboard after your account is approved.</h5>
					
					
					
					
					
					<div class="col-lg-12 bbox">
						<label>Unit Number </label>
						<input type="text" class="form-control" placeholder="Add Unit (Optional)" name='unit[]'    >
					</div>
					<div class="col-lg-12 bbox">
						<label>Unit Number </label>
						<input type="text" class="form-control" placeholder="Add Unit (Optional)" name='unit[]'    >
					</div>
					<div class="col-lg-12 bbox">
						<label>Unit Number </label>
						<input type="text" class="form-control" placeholder="Add Unit (Optional)" name='unit[]'    >
					</div>
					<div class="col-lg-12 bbox">
						<label>Unit Number </label>
						<input type="text" class="form-control" placeholder="Add Unit (Optional)" name='unit[]'    >
					</div>
				  </div>
				 
<?php
}else{
?>				  
				  
				  <div class="form-group row" id="manager" style="background:#efefef; padding:5px 25px;">
				 <h2>Primary Unit</h2>
				  <h5>Please enter the unit you would like assigned to your account.</h5>
				  
				  
				
				  
				  
				  <div class="row bbox">

					<div class="col-lg-8">
						<label>Owner Email </label>
						<input type="text" name="oemail[]" id="tag"  class="form-control"  />
						
					</div>
					<div class="col-lg-4">
						<label>Unit Number </label>
						<input required type="text" class="form-control" placeholder="Unit Number" name='unitm[]'    >
					</div>
					</div>
					<!----------->
					
					<div style="height:15px; margin-top:15px; border-top:1px solid #ccc; clear:both;"></div>


	
					
				  <h2>Additional Units</h2>
				  <h5>You may add up to 4 additional units during account sign up. Account holders with more than 5 units, may add additional units in your dashboard after your account is approved.</h5>
					
					
				  
					
					
					
					
					<div class="row bbox">
					<div class="col-lg-8">
						<label>Owner Email </label>
						<input type="text" name="oemail[]" id="tag1"  class="form-control"  />
					</div>
					<div class="col-lg-4">
						<label>Unit Number </label>
						<input type="text" class="form-control" placeholder="Unit Number" name='unitm[]'    >
					</div>
					</div>
					<!----------->
					<div class="row bbox">
					
					<div class="col-lg-8">
						<label>Owner Email </label>
						<input type="text" name="oemail[]" id="tag2"  class="form-control"  />
						
					</div>
					<div class="col-lg-4">
						<label>Unit Number </label>
						<input type="text" class="form-control" placeholder="unit Number" name='unitm[]'    >
					</div>
					
					</div>
					<!----------->
					
					<div class="row bbox">
					<div class="col-lg-8">
						<label>Owner Email </label>
						<input type="text" name="oemail[]" id="tag3"  class="form-control"  />
					</div>
					<div class="col-lg-4">
						<label>Unit Number </label>
						<input type="text" class="form-control" placeholder="Unit Number" name='unitm[]'    >
					</div>
					</div>
					<!----------->
					<div class="row bbox">
					
					<div class="col-lg-8">
						<label>Owner Email </label>
						<input type="text" name="oemail[]" id="tag4"  class="form-control"  />
					</div>
					<div class="col-lg-4">
						<label>Unit Number </label>
						<input type="text" class="form-control" placeholder="Unit Number" name='unitm[]'    >
					</div>
					
				  </div>
				  </div>
				  
<?php
}
?>				  
				  
				  
				  
				  
				 <div class="form-group row">
					<p id="errmsg"></p>
				 </div>
				  
				  
				  
				   <div class="form-group row">
					
					<div class="col-lg-12">
						<button class="btn btn-lg btn-success btn-block" name='login' id="loginbtn" type="submit">Submit</button>
					</div>
					
				  </div>
				  
				  
				 
                  
                  
              </div>

              

          </form>
		
		<div style="width:48px; margin:10px  auto;">
		  <a style="text-align:center;  color:rgba(34, 34, 34, 0.71);" href="<?=base_url('admin/login/');  ?>">Log In</a>
		  </div>
	  
	  
	  </div>

	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  

<!-- Placed js at the end of the document so the pages load faster -->
<script src="<?=base_url('nassets/js/jquery-1.10.2.min.js')?>"></script>

<script src="<?=base_url('nassets')?>/js/jquery-ui/jquery-ui-1.10.1.custom.min.js"></script>
<script src="<?=base_url('nassets')?>/js/jquery-migrate.js"></script>
<script src="<?=base_url('nassets')?>/js/bootstrap.min.js"></script>
<script src="<?=base_url('nassets')?>/js/modernizr.min.js"></script>






<!--jquery-ui-->
<script src="<?=base_url('nassets/js/jquery-ui/jquery-ui-1.10.1.custom.min.js')?>" type="text/javascript"></script>

<script src="<?=base_url('nassets/js/jquery-migrate.js')?>"></script>

<script src="<?=base_url('nassets/js/modernizr.min.js')?>"></script>

<!--Nice Scroll-->
<script src="<?=base_url('nassets/js/jquery.nicescroll.js')?>" type="text/javascript"></script>

<!--right slidebar-->
<script src="<?=base_url('nassets/js/slidebars.min.js')?>"></script>

<!--switchery-->
<script src="<?=base_url('nassets/js/switchery/switchery.min.js')?>"></script>
<script src="<?=base_url('nassets/js/switchery/switchery-init.js')?>"></script>

<!--flot chart -->
<script src="<?=base_url('nassets/js/flot-chart/jquery.flot.js')?>"></script>
<script src="<?=base_url('nassets/js/flot-chart/flot-spline.js')?>"></script>
<script src="<?=base_url('nassets/js/flot-chart/jquery.flot.resize.js')?>"></script>
<script src="<?=base_url('nassets/js/flot-chart/jquery.flot.tooltip.min.js')?>"></script>
<script src="<?=base_url('nassets/js/flot-chart/jquery.flot.pie.js')?>"></script>
<script src="<?=base_url('nassets/js/flot-chart/jquery.flot.selection.js')?>"></script>
<script src="<?=base_url('nassets/js/flot-chart/jquery.flot.stack.js')?>"></script>
<script src="<?=base_url('nassets/js/flot-chart/jquery.flot.crosshair.js')?>"></script>


<!--earning chart init-->
<script src="<?=base_url('nassets/js/earning-chart-init.js')?>"></script>


<!--Sparkline Chart-->
<script src="<?=base_url('nassets/js/sparkline/jquery.sparkline.js')?>"></script>
<script src="<?=base_url('nassets/js/sparkline/sparkline-init.js')?>"></script>

<!--easy pie chart-->
<script src="<?=base_url('nassets/js/jquery-easy-pie-chart/jquery.easy-pie-chart.js')?>"></script>
<script src="<?=base_url('nassets/js/easy-pie-chart.js')?>"></script>


<!--vectormap-->
<script src="<?=base_url('nassets/js/vector-map/jquery-jvectormap-1.2.2.min.js')?>"></script>
<script src="<?=base_url('nassets/js/vector-map/jquery-jvectormap-world-mill-en.js')?>"></script>
<script src="<?=base_url('nassets/js/dashboard-vmap-init.js')?>"></script>

<!--Icheck-->
<script src="<?=base_url('nassets/js/icheck/skins/icheck.min.js')?>"></script>
<script src="<?=base_url('nassets/js/todo-init.js')?>"></script>

<!--jquery countTo-->
<script src="<?=base_url('nassets/js/jquery-countTo/jquery.countTo.js')?>"  type="text/javascript"></script>

<!--owl carousel-->
<script src="<?=base_url('nassets/js/owl.carousel.js')?>"></script>



<!--jquery countTo-->
<script src="<?=base_url('nassets')?>/js/jquery-countTo/jquery.countTo.js"  type="text/javascript"></script>







<!--bootstrap picker-->
<script type="text/javascript" src="<?=base_url('nassets')?>/js/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="<?=base_url('nassets')?>/js/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js"></script>
<script type="text/javascript" src="<?=base_url('nassets')?>/js/bootstrap-daterangepicker/moment.min.js"></script>
<script type="text/javascript" src="<?=base_url('nassets')?>/js/bootstrap-daterangepicker/daterangepicker.js"></script>


<!--picker initialization-->
<script src="<?=base_url('nassets')?>/js/picker-init.js"></script>





<!--common scripts for all pages-->

<script src="<?=base_url('nassets/js/scripts.js')?>"></script>






<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>


<link rel="stylesheet" type="text/css" href="<?=base_url() ?>nassets/autocomplete/jquery.autocomplete.css" />
<script type="text/javascript" src="<?=base_url() ?>nassets/autocomplete/jquery.autocomplete.js"></script>
<script>
$(document).ready(function(){
 $("#tag, #tag1, #tag2, #tag3, #tag4").autocomplete("<?php echo base_url(); ?>admin/autocomplete", {
		selectFirst: true
	});
});
</script>


















<script type="text/javascript">
 
   
function isNumber(evt) {
	    evt = (evt) ? evt : window.event;
	    var charCode = (evt.which) ? evt.which : evt.keyCode;
	    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
	        return false;
	    }
	    return true;
	}

	function isDeciaml(evt, obj) {
 
            var charCode = (evt.which) ? evt.which : event.keyCode
            var value = obj.value;
            var dotcontains = value.indexOf(".") != -1;
            if (dotcontains)
                if (charCode == 46) return false;
            if (charCode == 46) return true;
            if (charCode > 31 && (charCode < 48 || charCode > 57))
                return false;
            return true;
    }

</script>


</body>
</html>
