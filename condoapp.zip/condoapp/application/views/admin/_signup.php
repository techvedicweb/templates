<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Admin Template">
    <meta name="keywords" content="admin dashboard, admin, flat, flat ui, ui kit, app, web app, responsive">
    
    <title>ADMIN PANEL</title>

    <!-- Base Styles -->
    <link href="<?=base_url('nassets/css/style.css')?>" rel="stylesheet">
    <link href="<?=base_url('nassets/css/style-responsive.css')?>" rel="stylesheet">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.min.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
<style>
#manager{display:none;}
#owner{display:none;}

</style>

</head>

  <body class="login-body">
  
  
<div class="err">
	<?php
		$err = $this->session->flashdata('error');
		if(!empty($err))
			echo '<div class="alert alert-warning">'.$err.'</div>';
		$scs = $this->session->flashdata('success');
		if(!empty($scs))
			echo '<div class="alert alert-success">'.$scs.'</div>';
		if(validation_errors())
		{
			echo '<div class="alert alert-warning">';
			if(form_error('agentslist'))
				echo 'Select Atleast One Employee';
			else
				echo validation_errors();
			echo '</div>';
		}
	?>
</div>
 
 
 <style>
.form-group{
	margin-bottom:0;
}
.showhide{
	display:none;
}
#errmsg{
	color:#ff0000;
}
.bbox{
	border:1px solid #ccc;
	margin-bottom:10px;
}
</style>
 
  
  
  
  
  
      <h2 class="form-heading">Sign Up</h2>
      <div class="container log-row">
          <form class="form-signin"  enctype="multipart/form-data" role="form" style="max-width:660px;" method='post' action="<?=base_url().uri_string();  ?>">
		 
              <div class="login-wrap">
                 
				  
				   
				  <div class="form-group row">
					<div class="col-lg-6">
						<label>Your Position </label>
						<select required class="form-control select" id="mpos" name="user_typ"  >
							<option value="">Select Your Position</option>
							<option value="Owner">Condo Owner</option>
							<option  value="Manager">Condo Manager</option>
						</select>
					</div>
					<div class="col-lg-6" >
						<label >Profile Picture</label>
                        <input type="file" name="thumb" class="form-control"   required />
						<span style="font-size;11px; font-style:italic;">
										Picture must show a clear headshot. Pictures with sunglasses or headwear will delay your account approval
										</span>
					</div>
				  </div>
				  
				  
				  
				  
				  
				  <div class="form-group row">
					<div class="col-lg-6">
						<label>First Name </label>
						<input type="text" class="form-control" placeholder="First Name" name='user_name'  id='user_name' required >
					</div>
					
					
					<div class="col-lg-6">
						<label>Last Name </label>
						<input type="text" class="form-control" placeholder="Last Name" name='user_lname'  id='user_lname' required >
					</div>
				  
					<div class="col-lg-6">
						<label>Address </label>
						<input type="text" class="form-control" placeholder="Address" name='address'  id='address' required >
					</div>
					<div class="col-lg-6">
						<label>City </label>
						<input type="text" class="form-control" placeholder="City" name='city'  id='city'  >
					</div>
					<div class="col-lg-6">
						<label>State </label>
						<input type="text" class="form-control" placeholder="State" name='state'  id='state' >
					</div>
				  
				  
					<div class="col-lg-6">
						<label>Country </label>
						<input type="text" class="form-control" placeholder="Country" name='country'  id='country' >
					</div>
					<div class="col-lg-6">
						<label>ZIp </label>
						<input type="text" class="form-control" placeholder="Zip" name='zip' onkeypress="return isNumber(event,this)"  id='zip'  >
					</div>
					<div class="col-lg-6">
						<label>Phone </label>
						<input type="text" class="form-control" maxlength="10" minlength="10" placeholder="Phone" name='phone' onkeypress="return isNumber(event,this)"  id='phone' required >
					</div>
				  
				  
					<div class="col-lg-12">
						<label>Email </label>
						<input type="email" class="form-control" placeholder="Email" name='user_email'  id='user_email' required >
					</div>
					<div class="col-lg-6">
						<label>Password </label>
						<input type="password" class="form-control" placeholder="Password" name='user_password'  id='user_password' required >
					</div>
					<div class="col-lg-6">
						<label>Repeat Password </label>
						<input type="password" class="form-control" placeholder="Password" name='rp_password'  id='rp_password' required >
					</div>
				  </div>
				
				  
				 <div class="form-group row">
					<p id="errmsg"></p>
				 </div>
				  
				  
				  
				   <div class="form-group row">
					
					<div class="col-lg-12">
						<button class="btn btn-lg btn-success btn-block" name='login' id="loginbtn" type="submit">Proceed</button>
					</div>
					
				  </div>
				  
				  
				 
                  
                  
              </div>

              

          </form>
		
			<div style="width:48px; margin:10px  auto;">
		  <a style="text-align:center;  color:rgba(34, 34, 34, 0.71);text-decoration:underline;" href="<?=base_url('admin/login/');  ?>">Log In</a>
		  </div>
	  
	  
	  </div>

      <!--jquery-1.10.2.min-->
      <script src="<?=base_url('nassets/js/jquery-1.11.1.min.js')?>"></script>
      <!--Bootstrap Js-->
      <script src="<?=base_url('nassets/js/bootstrap.min.js')?>"></script>
      <script src="<?=base_url('nassets/js/respond.min.js')?>"></script>
	  
<script>
   
function isNumber(evt) {
	    evt = (evt) ? evt : window.event;
	    var charCode = (evt.which) ? evt.which : evt.keyCode;
	    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
	        return false;
	    }
	    return true;
	}
/*	
$('#mpos').change(function(){
	var vv = $("#mpos").val();
	$('#manager, #owner').hide();
	if(vv=='Manager'){
		$('#manager').show();
	}
	if(vv=='Owner'){
		$('#owner').show();
	}
});
*/

$('#loginbtn').click(function(){
    //console.log($('.validatedForm').valid());
	$( "#errmsg" ).html( "" );
	var p =  $( "#user_password" ).val();
	var rp =  $( "#rp_password" ).val();
	
	if(p!=''  && rp!=''){
		if(p!=rp){
			//$( "#errmsg" ).val()="sdfgdfghdfgh";
			$( "#errmsg" ).html( "Password Mismatch" );
		}
	}
	
	
	
});


</script>
  </body>
</html>
