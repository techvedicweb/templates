<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <meta name="author" content="UBN Soft" />
    <meta name="keyword" content="" />
    <meta name="description" content="" />

	<?php
	if($this->uri->segment(1)=='admin'){
		?><title>Admin Dashboard</title><?php
	}elseif($this->uri->segment(1)=='manager'){
		?><title>Manager Dashboard</title><?php
	}elseif($this->uri->segment(1)=='security'){
		?><title>Security Dashboard</title><?php
	}elseif($this->uri->segment(1)=='sadmin'){
		?><title>Super Admin Dashboard</title><?php
	}else{
		?><title>Dashboard</title><?php
	}
	?>
    

    <!--easy pie chart-->
    <link href="<?=base_url('nassets/js/jquery-easy-pie-chart/jquery.easy-pie-chart.css')?>" rel="stylesheet" type="text/css" media="screen" />

    <!--vector maps -->
    <link rel="stylesheet" href="<?=base_url('nassets/js/vector-map/jquery-jvectormap-1.1.1.css')?>">

    <!--right slidebar-->
    <link href="<?=base_url('nassets/css/slidebars.css')?>" rel="stylesheet">

    <!--switchery-->
    <link href="<?=base_url('nassets/js/switchery/switchery.min.css')?>" rel="stylesheet" type="text/css" media="screen" />

    <!--jquery-ui-->
    <link href="<?=base_url('nassets/js/jquery-ui/jquery-ui-1.10.1.custom.min.css')?>" rel="stylesheet" />

    <!--iCheck-->
    <link href="<?=base_url('nassets/js/icheck/skins/all.css')?>" rel="stylesheet">

    <link href="<?=base_url('nassets/css/owl.carousel.css')?>" rel="stylesheet">

	
<!--bootstrap picker-->
  <link rel="stylesheet" type="text/css" href="<?=base_url('nassets')?>/js/bootstrap-datepicker/css/datepicker.css"/>
	

    <!--common style-->
    <link href="<?=base_url('nassets/css/style.css')?>" rel="stylesheet">
    <link href="<?=base_url('nassets/css/style-responsive.css')?>" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="<?=base_url('nassets/js/html5shiv.js')?>"></script>
    <script src="<?=base_url('nassets/js/respond.min.js')?>"></script>
    <![endif]-->
	
	
	
<link rel="stylesheet" href="<?=base_url('nassets/image_mag/magnific-popup.css')?>">

<style>

/* padding-bottom and top for image */
.mfp-no-margins img.mfp-img {
	padding: 0;
}
/* position of shadow behind the image */
.mfp-no-margins .mfp-figure:after {
	top: 0;
	bottom: 0;
}
/* padding for main container */
.mfp-no-margins .mfp-container {
	padding: 0;
}


/* 

for zoom animation 
uncomment this part if you haven't added this code anywhere else

*/
/*

.mfp-with-zoom .mfp-container,
.mfp-with-zoom.mfp-bg {
	opacity: 0;
	-webkit-backface-visibility: hidden;
	-webkit-transition: all 0.3s ease-out; 
	-moz-transition: all 0.3s ease-out; 
	-o-transition: all 0.3s ease-out; 
	transition: all 0.3s ease-out;
}

.mfp-with-zoom.mfp-ready .mfp-container {
		opacity: 1;
}
.mfp-with-zoom.mfp-ready.mfp-bg {
		opacity: 0.8;
}

.mfp-with-zoom.mfp-removing .mfp-container, 
.mfp-with-zoom.mfp-removing.mfp-bg {
	opacity: 0;
}
*/



.side-navigation > li.nav-active > a:after{
	display:none;
}
.btn-primary, .btn-primary:hover {
	background-color: #985019;
    border-color: #985019;
    color: #FFFFFF;
}
.side-navigation > li.nav-active > a{
	/*color: #dc6409;*/
	color: #985019;
}
.col-lg-6{
	    margin-bottom: 12px;
}
#nav-on a{
	color:#fff;
	background: #212025;
}
</style>
	
	
</head>

<body class="sticky-header">

    <section>