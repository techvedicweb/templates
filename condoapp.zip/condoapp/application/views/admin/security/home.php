            <!-- page head start-->
            <div class="page-head">
                <h3>Dashboard</h3>
                <span class="sub-title">Welcome to DASHBOARD</span>
			</div>
            <!-- page head end-->

			
 	<div class="err">
	<?php
		$err = $this->session->flashdata('error');
		if(!empty($err))
			echo '<div class="alert alert-warning">'.$err.'</div>';
		$scs = $this->session->flashdata('success');
		if(!empty($scs))
			echo '<div class="alert alert-success">'.$scs.'</div>';
		if(validation_errors())
		{
			echo '<div class="alert alert-warning">';
			if(form_error('agentslist'))
				echo 'Select Atleast One Employee';
			else
				echo validation_errors();
			echo '</div>';
		}
	?>
	</div>			
			
			
             <div class="wrapper">
 

 <div class="row">
				<div class="col-lg-12">
					<form class="tools pull-left" style="margin-bottom:8px;" method="post"  >
						<div class="input-group col-md-12">
							
							<input  class="form-control" type="text" name="searchterm" placeholder="Guest Name / Email / Booking Agent" /> 
							<span class="input-group-btn">
								<button name="searchbtn"  class="btn btn-success" type="submit"><i class="fa fa-search fa-fw"></i> Search</button>
							</span>
						</div>
					</form>
				</div>
				
</div>
 
 
 
 
 
 
 
 
 
 
                <div class="row">
            <div class="col-lg-12">
            <section class="panel">
            <header class="panel-heading head-border">
                List Of Bookings
				
				
				
				
            </header>
			<div class="table-responsive">
            <!--<table class="table table-striped custom-table table-hover">-->
            <table class="table table-striped custom-table table-hover">
			
<?php
$guest_nm_link=base_url().$this->uri->segment(1).'/dashboard/SORTY/party_name/ASC';
if($this->uri->segment(3)=='SORTY' && $this->uri->segment(4)=='party_name' && $this->uri->segment(5)=='ASC'){
	$guest_nm_link= base_url().$this->uri->segment(1).'/dashboard/SORTY/party_name/DESC';	
}

$email_link=base_url().$this->uri->segment(1).'/dashboard/SORTY/email/ASC';
if($this->uri->segment(3)=='SORTY' && $this->uri->segment(4)=='email' && $this->uri->segment(5)=='ASC'){
	$email_link=base_url().$this->uri->segment(1).'/dashboard/SORTY/email/DESC';	
}

$checkin_link= base_url().$this->uri->segment(1).'/dashboard/SORTY/book_st_dt/ASC';
if($this->uri->segment(3)=='SORTY' && $this->uri->segment(4)=='book_st_dt' && $this->uri->segment(5)=='ASC'){
	$checkin_link=base_url().$this->uri->segment(1).'/dashboard/SORTY/book_st_dt/DESC';	
}

$checkout_link= base_url().$this->uri->segment(1).'/dashboard/SORTY/book_end_dt/ASC';
if($this->uri->segment(3)=='SORTY' && $this->uri->segment(4)=='book_end_dt' && $this->uri->segment(5)=='ASC'){
	$checkout_link =base_url().$this->uri->segment(1).'/dashboard/SORTY/book_end_dt/DESC';	
}

$condo_link= base_url().$this->uri->segment(1).'/dashboard/SORTY/cn_name/ASC';
if($this->uri->segment(3)=='SORTY' && $this->uri->segment(4)=='cn_name' && $this->uri->segment(5)=='ASC'){
	$condo_link =base_url().$this->uri->segment(1).'/dashboard/SORTY/cn_name/DESC';	
}





?>			
			
			
                <thead>
                <tr>
                    <!--<th><i class="fa fa-bookmark-o"></i> Booking Id</th>-->
                    <th><i class="fa fa-bookmark-o"></i><a href="<?=$condo_link  ?>"> Unit Number </a></th>
					<th> </th>
                    <th><i class="fa fa-bookmark-o"></i> <a href="<?=$guest_nm_link  ?>">Guest Name</a></th>
                    <th><i class="fa fa-bookmark-o"></i> <a href="<?=$email_link  ?>">Guest Email</a></th>
                    <th><i class="fa fa-bookmark-o"></i>  <a href="<?=$checkin_link  ?>">Check In</a> / <a href="<?=$checkout_link  ?>">Check Out</a></th>
                    <th><i class="fa fa-bookmark-o"></i> Booking Agent </th>					
                    
                </tr>
                </thead>
                <tbody>
				<?=$alldf ?>
				
                
				
				
                </tbody>
            </table>
			
			
			
			
            </div>
			
			</section>
            </div>
            </div>
				
				
            </div>
            <!--body wrapper end-->		