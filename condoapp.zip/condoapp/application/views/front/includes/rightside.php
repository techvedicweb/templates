
						<div class="col-md-4">
							<div class="sidebar-widgets-wrap clearfix">
								<div class="widget clearfix">
									<div class="tabs nobottommargin clearfix" id="sidebar-tabs">
										<ul class="tab-nav clearfix">
											<li><a title="Top 5 CM" href="#tabs-1">Top 5 CM</a></li>
											<li><a title="Top 5 MP" href="#tabs-2">Top 5 MP</a></li>
											<li><a title="Top 5 MLA" href="#tabs-3">Top 5 MLA</a></li>
											<li><a title="Top Rating" href="#tabs-4"><i class="fa fa-comments"></i></a></li>
										</ul>
										<div class="tab-container">
											<div class="tab-content clearfix" id="tabs-1">
												<div id="popular-post-list-sidebar">
													<?php
													foreach ($topcm as $tc){
													?>
													<div class="spost clearfix">
														<div class="entry-image">
															<a href="#" class="nobg"><img class="img-circle" src="<?=base_url('assets/images/magazine/small/3.jpg')?>" alt=""></a>
														</div>
														<div class="entry-c">
															<div class="entry-title">
																<h4><a href="#"><?=$tc->leader_name;  ?></a></h4>
															</div>
															<ul class="entry-meta">
																<li><i class="fa fa-fort-awesome"></i><?=$tc->bytype;  ?> : <?=$tc->state_id;  ?></li>
															</ul>
														</div>
													</div>
													<?php
													}
													?>
												</div>
											
											</div>
											<div class="tab-content clearfix" id="tabs-2">
												<div id="popular-post-list-sidebar">
													<?php
													foreach ($topmp as $mp){
													?>
													<div class="spost clearfix">
														<div class="entry-image">
															<a href="#" class="nobg"><img class="img-circle" src="<?=base_url('assets/images/magazine/small/3.jpg')?>" alt=""></a>
														</div>
														<div class="entry-c">
															<div class="entry-title">
																<h4><a href="#"><?=$mp->leader_name;  ?></a></h4>
															</div>
															<ul class="entry-meta">
																<li><i class="fa fa-fort-awesome"></i><?=$mp->bytype;  ?> : <?=$mp->state_id;  ?>, <?=$mp->cityid;  ?></li>
															</ul>
														</div>
													</div>
													<?php
													}
													?>
												</div>
											
											</div>
											
											<div class="tab-content clearfix" id="tabs-3">
												<div id="popular-post-list-sidebar">
													<?php
													foreach ($topmla as $ml){
													?>
													<div class="spost clearfix">
														<div class="entry-image">
															<a href="#" class="nobg"><img class="img-circle" src="<?=base_url('assets/images/magazine/small/3.jpg')?>" alt=""></a>
														</div>
														<div class="entry-c">
															<div class="entry-title">
																<h4><a href="#"><?=$ml->leader_name;  ?></a></h4>
															</div>
															<ul class="entry-meta">
																<li><i class="fa fa-fort-awesome"></i><?=$ml->bytype;  ?> : <?=$ml->state_id;  ?>, <?=$ml->cityid;  ?></li>
															</ul>
														</div>
													</div>
													<?php
													}
													?>
												</div>
											
											
											
											</div>
											
											<div class="tab-content clearfix" id="tabs-4">
												<div id="recent-post-list-sidebar">

													<div class="spost clearfix">
														<div class="entry-image">
															<a href="#" class="nobg"><img class="img-circle" src="<?=base_url('assets/images/icons/avatar.jpg')?>" alt=""></a>
														</div>
														<div class="entry-c">
															<strong>Sriparna Dash:</strong> 
															Very Good Governance, Quality service... [4/5]
															<br> TO: Navin Patnayak (CM: ODISHA)<br>
														</div>
													</div>
													<div class="spost clearfix">
														<div class="entry-image">
															<a href="#" class="nobg"><img class="img-circle" src="<?=base_url('assets/images/icons/avatar.jpg')?>" alt=""></a>
														</div>
														<div class="entry-c">
															<strong>Sriparna Dash:</strong> 
															Very Good Governance, Quality service... [4/5]
															<br> TO: Navin Patnayak (CM: ODISHA)<br>
														</div>
													</div>
													
													<div class="spost clearfix">
														<div class="entry-image">
															<a href="#" class="nobg"><img class="img-circle" src="<?=base_url('assets/images/icons/avatar.jpg')?>" alt=""></a>
														</div>
														<div class="entry-c">
															<strong>Sriparna Dash:</strong> 
															Very Good Governance, Quality service... [4/5]
															<br> TO: Navin Patnayak (CM: ODISHA)<br>
														</div>
													</div>
													

												</div>
											</div>
										</div>
									</div>
								</div>

								<div class="widget widget_links clearfix">
									<h4>STATE WISE NETA-Graphy</h4>
									<div class="col_half nobottommargin">
										<ul>
											<li><a href="#">Assam</a></li>
											<li><a href="#">West Bengal</a></li>
											<li><a href="#">Madhaya Pradesh</a></li>
											
										</ul>
									</div>
									<div class="col_half nobottommargin col_last">
										<ul>
											<li><a href="#">Andra Pradesh</a></li>
											<li><a href="#">Karnatak</a></li>
											<li><a href="#">Manipur</a></li>
											
										</ul>
									</div>
								</div>

								
								<div class="widget clearfix" style="padding-top:0;">
									<img class="aligncenter" src="<?=base_url('assets/images/advs/advtwo.png')?>" alt="">
								</div>
								<div class="widget clearfix">
									<iframe width="420" height="315" src="https://www.youtube.com/embed/_gP1mPkVP6g" frameborder="0" allowfullscreen></iframe>
								</div>
								<div class="widget clearfix">
									<iframe src="//www.facebook.com/plugins/likebox.php?href=https%3A%2F%2Fwww.facebook.com%2Fvoteforneta&amp;width=350&amp;height=350&amp;colorscheme=light&amp;show_faces=true&amp;header=true&amp;stream=false&amp;show_border=true&amp;appId=499481203443583" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:350px; height:240px; max-width: 100% !important;" allowTransparency="true"></iframe>
								</div>

							</div>
						</div>

					</div>
				</div>
			
			</div>
		</section><!-- #content end -->

		