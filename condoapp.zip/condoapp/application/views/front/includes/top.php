
		<!-- Top Bar
		============================================= -->
		<div id="top-bar">

			<div class="container clearfix">

				<div class="col_half nobottommargin">

					<!-- Top Links
					============================================= -->
					<div class="top-links">
						<ul>							
							<li>
							<?php
							
							if(isset($unm) && $unm !=''){
							?>
							<a href="#">Hi <?=$unm;  ?></a>
							<?php
							}else{
							?>
							<a href="#">Login</a>
							<?php
							}
							?>
							
								<div class="top-link-section">
									<!--<form id="top-login" role="form">
										<div class="input-group" id="top-login-username">
											<span class="input-group-addon"><i class="icon-user"></i></span>
											<input type="email" class="form-control" placeholder="Email address" required="">
										</div>
										<div class="input-group" id="top-login-password">
											<span class="input-group-addon"><i class="icon-key"></i></span>
											<input type="password" class="form-control" placeholder="Password" required="">
										</div>
										<button class="btn btn-danger btn-block" type="submit">Sign in</button>
									</form>	-->
										
										<?php
										if(isset($unm) && $unm !=''){
										?>
										<a href="<?=base_url('fblogin/logout')?>" class="btn btn-danger btn-block" style="color:##365C99;" type="submit">Log Out</a>
										
										<?php
										}else{
										?>
										<a href="<?=base_url('fblogin/index')?>" class="btn btn-primary btn-block" style="color:##365C99;" type="submit">Login With Facebook</a>
										<a href="<?=base_url('hauth/login/Google')?>" class="btn btn-danger btn-block" type="submit">Login With Google</a>
										<?php
										}
										?>
										
										
									
								</div>
							</li>
							
							<li><a href="#">Contact</a> 
							
							
							
							
							</li>
						</ul>
					</div><!-- .top-links end -->

				</div>

				<div class="col_half fright col_last nobottommargin">

					<!-- Top Social
					============================================= -->
					<div id="top-social">
						<ul>
							<li><a href="https://www.facebook.com/voteforneta" class="si-facebook"><span class="ts-icon"><i class="icon-facebook"></i></span><span class="ts-text">Facebook</span></a></li>
							<li><a href="https://twitter.com/voteforneta" class="si-twitter"><span class="ts-icon"><i class="icon-twitter"></i></span><span class="ts-text">Twitter</span></a></li>							
							<li><a href="mailto:voteforneta@gmail.com" class="si-pinterest"><span class="ts-icon"><i class="fa fa-google-plus"></i></span><span class="ts-text">Google plus</span></a></li>
							
						</ul>
					</div><!-- #top-social end -->

				</div>

			</div>

		</div><!-- #top-bar end -->

		
		
		
		<!-- Header
		============================================= -->
		<header id="header" class="sticky-style-2">

			<div class="container clearfix">

				<!-- Logo
				============================================= -->
				<div id="logo">
					<a href="<?=base_url() ?>" class="standard-logo" data-dark-logo="images/logo-dark.png"><img src="<?=base_url('assets/images/logo.png')?>" alt="Vote For Neta"></a>
					<a href="<?=base_url() ?>" class="retina-logo" data-dark-logo="images/logo-dark@2x.png"><img src="<?=base_url('assets/images/logo.png')?>" alt="Vote For Neta"></a>
				</div><!-- #logo end -->

				<div class="top-advert">
					<img src="<?=base_url('assets/images/advs/advone.png')?>" alt="swach bharat-adv">
				</div>

			</div>

			<div id="header-wrap">

				<!-- Primary Navigation
				============================================= -->
				<nav id="primary-menu" class="style-2">

					<div class="container clearfix">

						<div id="primary-menu-trigger"><i class="icon-reorder"></i></div>

						<ul>
							<li <?=($this->uri->segment(1)==NULL)?'class="current"':''  ?>><a href="<?=base_url() ?>"><div>Home</div></a></li>
							<li <?=($this->uri->segment(1)=='about_us')?'class="current"':''  ?> ><a href="<?=base_url('about_us') ?>"><div>About Us</div></a>
										<ul>
											<li><a href="<?=base_url('our_objective') ?>"><div>Our Objective</div></a></li>
										</ul>
							</li>
							<li ><a href="#"><div>Trending Now</div></a></li>
							<li ><a href="#"><div>Whats Happening</div></a></li>
							<li ><a href="#"><div>Election Info</div></a></li>
							
						
						
						</ul>

						<!-- Top Search
						============================================= -->
						<div id="top-search">
							<a href="#" id="top-search-trigger"><i class="icon-search3"></i><i class="icon-line-cross"></i></a>
							<form action="search.html" method="get">
								<input type="text" name="q" class="form-control" value="" placeholder="Type &amp; Hit Enter..">
							</form>
						</div><!-- #top-search end -->

					</div>

				</nav><!-- #primary-menu end -->

			</div>

		</header><!-- #header end -->

		
		

		<!-- Content
		============================================= -->
		<section id="content">
			<div class="content-wrap">
				<div class="section header-stick bottommargin-lg clearfix" style="padding: 20px 0;">
					<div>
						<div class="container clearfix">
							<span class="label label-danger bnews-title">Top News:</span>
							<div class="fslider bnews-slider nobottommargin" data-speed="800" data-pause="6000" data-arrows="false" data-pagi="false">
								<div class="flexslider">
									<div class="slider-wrap">
										<?php
										foreach($bignews as $b){
										?>
											<div class="slide">
											<a href="<?=base_url('news/'.$b->page_id)?>">
											<strong><?=$b->page_heading;  ?></strong>
											</a>
											</div>
										<?php
										}
										?>
										
										
										
										
										
										
										
										
										
										<div class="slide"><a href="#"><strong>Opinion poll predicts win for Mamata, lead for Jaya, Kerala to LDF, Assam to NDA</strong></a></div>
										<div class="slide"><a href="#"><strong>PM Modi to meet Saudi King today, may seal key deals with Riyadh</strong></a></div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="container clearfix" style="margin-top:-60px;">
					<div class="row">		
		
		
		