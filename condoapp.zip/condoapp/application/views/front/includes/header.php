<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<head>

	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="author" content="SemiColonWeb" />

	<!-- Stylesheets
	============================================= -->
	<link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="<?=base_url('assets/css/bootstrap.css')?>" type="text/css" />
	<link rel="stylesheet" href="<?=base_url('assets/style.css')?>" type="text/css" />
	<link rel="stylesheet" href="<?=base_url('assets/css/dark.css')?>" type="text/css" />
	<link rel="stylesheet" href="<?=base_url('assets/css/font-icons.css')?>" type="text/css" />
	<link rel="stylesheet" href="<?=base_url('assets/css/animate.css')?>" type="text/css" />
	<link rel="stylesheet" href="<?=base_url('assets/css/magnific-popup.css')?>" type="text/css" />
	
	
	
	
	<link rel="stylesheet" href="<?=base_url('assets/font-awesome/css/font-awesome.css')?>" type="text/css" />
	
	
	
	

	<link rel="stylesheet" href="<?=base_url('assets/css/responsive.css')?>" type="text/css" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<!--[if lt IE 9]>
		<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
	<![endif]-->

	<!-- External JavaScripts
	============================================= -->
	<script type="text/javascript" src="<?=base_url('assets/js/jquery.js')?>"></script>
	<script type="text/javascript" src="<?=base_url('assets/js/plugins.js')?>"></script>

	<!-- Document Title
	============================================= -->
	<?php
	if(isset($pg_title)){
		echo '<title>'.$pg_title.'</title>';
	}else{
		echo '<title>Vote For neta</title>';
	}
	?>
	
	<meta name="description"  content="<?=(isset($pg_desc))?$pg_desc:''  ?>" />
	<meta name="keywords"  content="<?=(isset($pg_key))?$pg_key:''  ?>" />

</head>

<body class="stretched no-transition">

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">