<!-- Footer
		============================================= -->
		<footer id="footer" class="dark">

			
			<!-- Copyrights
			============================================= -->
			<div id="copyrights">

				<div class="container clearfix">

					<div class="col_half">
						Copyrights &copy; <?=date('Y') ?> All Rights Reserved<br>
						<div class="copyright-links"><a href="<?=base_url('terms')?>">Terms of Use</a> / <a href="<?=base_url('privacy_policy')?>">Privacy Policy</a></div>
					</div>

					<div class="col_half col_last tright">
						<div class="fright clearfix">
							<a href="#" class="social-icon si-small si-borderless si-facebook">
								<i class="icon-facebook"></i>
								<i class="icon-facebook"></i>
							</a>

							<a href="#" class="social-icon si-small si-borderless si-twitter">
								<i class="icon-twitter"></i>
								<i class="icon-twitter"></i>
							</a>

							<a href="#" class="social-icon si-small si-borderless si-gplus">
								<i class="icon-gplus"></i>
								<i class="icon-gplus"></i>
							</a>

							
						</div>

						<div class="clear"></div>
						<i class="icon-envelope2"></i> contact@voteforneta.com <span class="middot">&middot;</span> <i class="icon-headphones"></i> +91-99-999-99999 						
					</div>

				</div>

			</div><!-- #copyrights end -->

		</footer><!-- #footer end -->

	</div><!-- #wrapper end -->

	<!-- Go To Top
	============================================= -->
	<div id="gotoTop" class="icon-angle-up"></div>

	<!-- Footer Scripts
	============================================= -->
	<script type="text/javascript" src="<?=base_url('assets/js/functions.js')?>"></script>

</body>
</html>