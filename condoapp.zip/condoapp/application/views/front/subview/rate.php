

<style>

.netalist{

 	



}

.nlist{

padding-bottom:10px; border-bottom:1px dashed #ccc; margin-bottom:5px;	

list-style:none;

}

	</style>

	

    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">

    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">	

	

<link rel="stylesheet" href="<?=base_url('assets/css/star-rating.css')?>" type="text/css" />					

<script type="text/javascript" src="<?=base_url('assets/js/star-rating.js')?>"></script>						

						

<div class="col-md-8 bottommargin">

	<div class="col_full bottommargin-sm clearfix">

		<div class="fancy-title title-border" style="margin-bottom:10px;">

			<h3>Rate Your Neta</h3>

		</div>

	</div>

							

	<div class="row">

		<div class="col-md-12">

			<ul class="netalist">

				<li class="nlist">

					<div class="row">

						<div class="spost clearfix col-md-12">

							<div class="entry-image">

								<a href="#" class="nobg"><img class="img-circle" src="<?=base_url('assets/images/magazine/small/3.jpg'); ?>" alt=""></a>

							</div>

							<div class="entry-c">

								<div class="entry-title">

									<h4><a href="#"><?=$netas->leader_name;  ?></a></h4>

								</div>

								<ul class="entry-meta">

									<li><i class="fa fa-fort-awesome"></i><?=$netas->bytype;  ?> : <?=$netas->cityid;  ?> <?=$netas->state_id;  ?></li>

								</ul>

							</div>

						</div>

						<div class="col-md-12" style="margin-top:20px;">
						<?php
						$uf = $this->session->userdata('userinfoz');   
						if(isset($uf) && $uf['name'] !=''){
						?>
							<form  method="post" action="<?=base_url('rate'); ?>">

								<input type="hidden" name='netaid' value='<?=$netaid  ?>' >

								<h4 style="margin-bottom:2px; padding-bottom:0; color:#1ABC9C">How you feel aout your neta?:</h4><br>

							

							

								<strong>Availability to public:</strong><br>

								<input type="text" name='avl' class="rating rating-loading"  data-size="xs" title=""><br>

								

								<strong>Development of  area:</strong><br>

								<input type="text" name="dvl" class="rating rating-loading"  data-size="xs" title=""><br>

								

								<strong>Behaviour:</strong><br>

								<input type="text" name="beh" class="rating rating-loading"  data-size="xs" title=""><br>

								

								

								<strong>Overall Rating:</strong><br>

								<input type="text" name="all" class="rating rating-loading"  data-size="xs" title=""><br>

								

								<strong>Comment:</strong><br>

								<textarea name="comment" class="form-control" style="height:160px; margin-bottom:15px;" ></textarea>

								

								

								<button class="button button-3d nomargin" name="rate" type="submit" value="submit">RATE</button>

							</form>
						<?php
						}else{
						?>
							<h4 style="margin-bottom:2px; padding-bottom:0; color:#1ABC9C">Login To vote your neta</h4><br> 
							<a href="<?=base_url('fblogin/index')?>" class="btn btn-primary btn-block" style="color:##365C99;" type="submit">Login With Facebook</a>
							<a class="btn btn-danger btn-block" type="submit">Login With Google</a>
						<?php
						}
						?>
						</div>

						

					</div>

				</li>

			</ul>

		</div>

	</div>

</div>



