



						<div class="col-md-8 bottommargin">

						<!--   //////////////BANNER SLIDER AREA>>>>>>>>.......////////////////////////////////              ---->

							<div class="col_full bottommargin-sm">

								<div class="fslider flex-thumb-grid grid-6" data-animation="fade" data-arrows="true" data-thumbs="true">

									<div class="flexslider">

										<div class="slider-wrap">

											<div class="slide" data-thumb="<?=base_url('assets/images/banner/thumb/1.jpg')?>">

												<a href="#">

													<img src="<?=base_url('assets/images/banner/1.jpg')?>" alt="">

												</a>

											</div>

											

											<div class="slide" data-thumb="<?=base_url('assets/images/banner/thumb/2.jpg')?>">

												<a href="#">

													<img src="<?=base_url('assets/images/banner/2.jpg')?>" alt="">

												</a>

											</div>

											<div class="slide" data-thumb="<?=base_url('assets/images/banner/thumb/1.jpg')?>">

												<a href="#">

													<img src="<?=base_url('assets/images/banner/1.jpg')?>" alt="">

												</a>

											</div>

											

											<div class="slide" data-thumb="<?=base_url('assets/images/banner/thumb/2.jpg')?>">

												<a href="#">

													<img src="<?=base_url('assets/images/banner/2.jpg')?>" alt="">

												</a>

											</div>

											<div class="slide" data-thumb="<?=base_url('assets/images/banner/thumb/1.jpg')?>">

												<a href="#">

													<img src="<?=base_url('assets/images/banner/1.jpg')?>" alt="">

												</a>

											</div>

											

											<div class="slide" data-thumb="<?=base_url('assets/images/banner/thumb/2.jpg')?>">

												<a href="#">

													<img src="<?=base_url('assets/images/banner/2.jpg')?>" alt="">

												</a>

											</div>

											

											

									</div>

									</div>

								</div>

							</div>



							<div class="clear"></div>

							<!--   //////////////SEARCH AREA>>>>>>>>.......////////////////////////////////              ---->

							<div class="col_full bottommargin-sm clearfix">



								<div class="fancy-title title-border" style="margin-bottom:10px;">

									<h3>Search Your Neta</h3>

								</div>

								<div class="ipost clearfix">

									<form id='srch' method="POST" action="<?=base_url('search'); ?>">

									<div class="col_one_fourth" style="width:30%; margin-right:0.5%">

										<select required name="pos" class="sm-form-control">

											<option value="">Select Leader Position</option>

											<option value="PM">PM</option>

											<option value="MP">MP</option>

											<option value="CM">CM</option>

											<option value="MLA">MLA</option>

										</select>

									</div>

									<div class="col_one_fourth" style="width:22%; margin-right:0.5%">

										<select required class="sm-form-control" name="stt" id="stt" onchange="getconst(encodeURI(this.value));" >

										<option value="">Select State</option>

										<?php

										foreach($states as $st){

											echo '<option value ="'.$st->statename.'">'.$st->statename.'</option>';

										}

										?>

										</select>

									</div>

									<div class="col_one_fourth" style="width:25%; margin-right:0.5%">

										<select required id="const" name="const" class="sm-form-control">

										<option value="">Select Constituency</option>

										</select>

									</div>

									<div class="col_one_fourth" style="width:20%; margin-right:0.5%">

										<button class="button button-3d nomargin" name="serach" type="submit" value="submit">Search</button>

									</div>

									</form>

									

									

								</div>

							</div>



							

							

							<!--

							<div class="bottommargin-sm">

								<img src="<?=base_url('assets/images/magazine/ad.jpg')?>" alt="Ad" class="aligncenter notopmargin nobottommargin">

							</div>

							-->

							

							

							<!--   //////////////TOP NEWS>>>>>>>>.......///////////////////////              ---->

							

							<div class="col_full bottommargin-lg clearfix">

								<div class="fancy-title title-border">

									<h3>Top Trending News</h3>

								</div>

								<div class="ipost clearfix">

									<div class="col_half bottommargin-sm">

										<div class="entry-image">

											<a href="<?=base_url('news/'.$onenews->page_id)?>">

											<img class="image_fade" src="<?=base_url('uploads/news/'.$onenews->thumbnail)?>" alt="Image" />

											</a>

										</div>

									</div>

									<div class="col_half bottommargin-sm col_last">

										<div class="entry-title">

											<h3><a href="<?=base_url('news/'.$onenews->page_id)?>"><?=$onenews->page_heading  ?></a></h3>

										</div>

										<ul class="entry-meta clearfix">

											<li><i class="icon-calendar3"></i> <?=date('M d Y',strtotime($onenews->insert_date))  ?></li>

											<li><a href="blog-single.html#comments"><i class="icon-comments"></i> 21</a></li>

											

										</ul>

										<div class="entry-content">

											<?=character_limiter($onenews->page_txt, 200);  ?>

										</div>

									</div>

								</div>

								

								

								

								

								<div class="clear"></div>

								

							

							</div>



							<div class="col_half nobottommargin">

									<?php

									$cnt =  count($bignews); 

									if($cnt>3){

									for ($i=0; $i<4; $i++){

									?>

										<div class="spost clearfix">

										<div class="entry-image">

											<a href="<?=base_url('news/'.$bignews[$i]->page_id)?>">

											<img src="<?=base_url('uploads/news/s/'.$bignews[$i]->thumbnail)?>" alt=""></a>

										</div>

										<div class="entry-c">

											<div class="entry-title">

												<h4><a href="<?=base_url('news/'.$bignews[$i]->page_id)?>"><?=$bignews[$i]->page_heading; ?></a></h4>

											</div>

											<ul class="entry-meta">

												<li><i class="icon-calendar3"></i><?=date('M d Y',strtotime($bignews[$i]->insert_date))  ?></li>

												<li><a href="#"><i class="icon-comments"></i> 32</a></li>

											</ul>

										</div>

									</div>

									

									<?php

									}

									}

									?>

								</div>

							<div class="col_half nobottommargin col_last">

								<?php

									$cnt =  count($bignews);

									if($cnt>7){

									for ($i=4; $i<8; $i++){

									?>

									<div class="spost clearfix">

										<div class="entry-image">

											<a href="#"><img src="<?=base_url('uploads/news/s/'.$bignews[$i]->thumbnail)?>" alt=""></a>

										</div>

										<div class="entry-c">

											<div class="entry-title">

												<h4><a href="#"><?=$bignews[$i]->page_heading; ?></a></h4>

											</div>

											<ul class="entry-meta">

												<li><i class="icon-calendar3"></i><?=date('M d Y',strtotime($bignews[$i]->insert_date))  ?></li>

												<li><a href="#"><i class="icon-comments"></i> 32</a></li>

											</ul>

										</div>

									</div>

									

									<?php

									}

									}

								?>	

							</div>

							



						</div>

						

						

<script type="text/Jscript">

function getconst(str)

	{

		//alert('hi');

		var xmlhttp;    

		if (str=="")

		{

		  document.getElementById("const").innerHTML="<option value=''>Select Constituency.</option>";

		  return;

		}

		if (window.XMLHttpRequest)

		{// code for IE7+, Firefox, Chrome, Opera, Safari

		  xmlhttp=new XMLHttpRequest();

		}

		else

		{// code for IE6, IE5

		  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");

		}

		xmlhttp.onreadystatechange=function()

		{

		  if (xmlhttp.readyState==4 && xmlhttp.status==200)

		  {

		    document.getElementById("const").innerHTML=xmlhttp.responseText;

		  }

		}

		xmlhttp.open("POST","<?php echo base_url('page/getconst'); ?>/"+str+'?isajax=true',true);

		xmlhttp.setRequestHeader("Cache-Control", "no-cache");

		xmlhttp.setRequestHeader("Pragma", "no-cache");

		xmlhttp.setRequestHeader("If-Modified-Since", "Sat, 1 Jan 2000 00:00:00 GMT");

		xmlhttp.send();

	}





</script>						

