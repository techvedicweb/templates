						<div class="col-md-8 bottommargin">
							<h1 style="border-bottom:1px solid #ccc;"><?=$page_data->page_heading;  ?></h1>
							<?php
							if($this->uri->segment(1)=='news'){
							?>
							<img src="<?=base_url('uploads/news/'.$page_data->thumbnail)?>" alt="">
							
							<?php
							}
							?>
							<?=$page_data->page_txt;  ?>
						</div>
