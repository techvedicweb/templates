<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Sadmin extends Admin_Controller 
{
	function __construct() 
	{
		parent::__construct();
		$this->load->model('Condo_M');
		$this->load->model('Book_M');
		$this->load->model('User_M');
		$this->load->model('Mngrcondo_M');
		
		$this->load->library('my_upload');
		$this->load->library("pagination");
		$this->load->library('email');
		
		$myid = $this->session->userdata('user_id');
		$myinfo = $this->User_M->get($myid, TRUE);
		$this->data['myinfo']=  $myinfo;
		if($myinfo->thumbnail==''){
			$this->data['mypic']=  base_url('nassets/img/avatar-mini.jpg');
		}else{
			$this->data['mypic']= base_url('nassets/img/profpic').'/'.$myinfo->thumbnail;
		}
		
		$bb = array("dashboard", "logout" , "login");
		if (!in_array($this->uri->segment(2), $bb) && $myinfo->status=='I' ){
			redirect(base_url("sadmin/dashboard"));
		}
	}
	
	
	public function rejection($typ,$typ_id){
		
		if($_POST){
			$data['rejection_cause']=$this->input->post('rejection_cause');
			$data['rejection_detail']=$this->input->post('rejection_detail');
			
			$cz =$this->input->post('rejection_cause');
			$r_dtl =$this->input->post('rejection_detail');
			
			
			$backlink = $this->input->post('backurl');
			
			if($typ=='user'){
				$data['status']='D';
				$r=$this->User_M->save($data, $typ_id);
				if($r){
					
					////EMAIL PACK START
					$udtl=$this->User_M->get($typ_id, TRUE);
				
						///EMAIL PACK START
						$sender_email="no-reply@grandcondominium.com";
						$sender_nm="Condo APP";
						$receiver_eml=array($udtl->user_email,'lokanathnayak@yahoo.co.in','andres@creativomiami.com');
						$subjects="Your account has been suspended";
						$msg = 'Hi '.$udtl->user_name.' '.$udtl->user_lname.',<br><br>
								Your Account Has been suspended. Below are the reason <br><br>
								
								Cause: '.$cz.' <br>
								Detail: '.$r_dtl.' <br>
								
								
								
								<br>
								Thanks, <br>Condo Association';
						$vv = $this->sendemail($sender_email, $sender_nm, $receiver_eml, $subjects, $msg );
						////EMAIL PACK END
					
					
					
					
					$smsg= "User Rejected Successfully";
					$typs='success';
				}else{
					$smsg= "Error Occurs While Rejecting User";
					$typs='error';
				}
			}
			
			if($typ=='condo'){
				$data['status']='I';
				$r=$this->Condo_M->save($data, $typ_id);
				if($r){
					$smsg= "Condo Rejected Successfully";
					$typs='success';
				}else{
					$smsg= "Error Occurs While Rejecting Condo";
					$typs='error';
				}
			}
			
			if($typ=='condom'){
				$data['status']='I';
				$r=$this->Mngrcondo_M->save($data, $typ_id);
				if($r){
					$smsg= "Condo Rejected Successfully";
					$typs='success';
				}else{
					$smsg= "Error Occurs While Rejecting Condo";
					$typs='error';
				}
			}
			
			
			if($typ=='book'){
				$data['status']='D';
				$r=$this->Book_M->save($data, $typ_id);
				if($r){
					$smsg= "Booking Rejected Successfully";
					$typs='success';
				}else{
					$smsg= "Error Occurs While Rejecting Booking";
					$typs='error';
				}
			}
			
			
			
			
			$this->session->set_flashdata($typs,$smsg);
				redirect($backlink);
		}
		
		
		
		
		$this->data['sub_view']='admin/s_subview/rejection';
		$this->load->view('admin/_layout',$this->data);
	}
	
	
	
	
	
	public function index()
	{
		redirect(base_url("admin/login"), "refresh");
	}
	public function editprofile()
	{
	
		$myid = $this->session->userdata('user_id');
		$myinfo = $this->User_M->get($myid, TRUE);
		if(isset($_POST['editprofile']))
		{
			$rules['phone']= array('field'=>'phone','label'=>'Phone', 'rules'=>'trim|required');
			$rules['address']= array('field'=>'address','label'=>'Address', 'rules'=>'trim|required');
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				
				$data['user_name']=$this->input->post('user_name');
				$data['user_mname']=$this->input->post('user_mname');
				$data['user_lname']=$this->input->post('user_lname');
				
				$data['phone']=$this->input->post('phone');
				$data['address']=$this->input->post('address');
				
				$data['city']=$this->input->post('city');
				$data['state']=$this->input->post('state');
				$data['country']=$this->input->post('country');
				$data['zip']=$this->input->post('zip');
				
				//print_result($data); exit;
				
				$r=$this->User_M->save($data, $myid);
				if($r){
					$smsg= "Profile Information Changed Successfully";
					$typ='success';
				}else{
					$smsg= "Error Occurs While Changing Profile Information";
					$typ='error';
				}
					
					
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("sadmin/editprofile/"));
		}
		
	
		$this->data['sub_view']='admin/subview/editprofile';
		$this->load->view('admin/_layout',$this->data);
	}
	
	public function changepass()
	{
	
		$myid = $this->session->userdata('user_id');
		$myinfo = $this->User_M->get($myid, TRUE);
		if(isset($_POST['changepassword']))
		{
			$rules['oldp']= array('field'=>'oldp','label'=>'Old Password', 'rules'=>'trim|required');
			$rules['newp']= array('field'=>'newp','label'=>'New Password', 'rules'=>'trim|required');
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				$oldp = $this->input->post('oldp');
				$newp = $this->input->post('newp');
				$repeatp = $this->input->post('repeatp');
				
				
				
				if($myinfo->user_password==$oldp ){
					if($newp==$repeatp){
						$data['user_password']=$newp;
						
						$r=$this->User_M->save($data, $myid);
						if($r){
							$smsg= "Password Changed Successfully";
							$typ='success';
						}else{
							$smsg= "Error Occurs While Changing Password";
							$typ='error';
						}
					}else{
						$smsg= "Password Mismatches";
						$typ='error';
					}
				}else{
					$smsg= "Provide proper Old Password";
					$typ='error';
				}
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url().$this->uri->segment(1).'/changepass');
		}
		
	
	
	
		$this->data['sub_view']='admin/subview/changepass';
		$this->load->view('admin/_layout',$this->data);
	}
	
	
	public function condomlist($typ=NULL)   
	{
		if(isset($_POST['approve'])){
			$data['status']='A';
			$uid = $this->input->post('user_id');
			$r=$this->Mngrcondo_M->save($data, $uid);
			
			$thisd = $this->Mngrcondo_M->get($uid);
			
			
			$d=$this->Condo_M->save($data, $thisd->cn_id);
			if($r){
				$smsg= "Condo Approved Successfully";
				$typs='success';
			}else{
				$smsg= "Error Occurs While Approving Condo";
				$typs='error';
			}
			$this->session->set_flashdata($typs,$smsg);
			redirect(base_url("sadmin/condolist/").'/'.$typ);
		}
		if(isset($_POST['reject'])){
			$uid = $this->input->post('user_id');
			$data['status']='I';
			$r=$this->Mngrcondo_M->save($data, $uid);
			if($r){
				$smsg= "Condo Rejected Successfully";
				$typs='success';
			}else{
				$smsg= "Error Occurs While Rejecting Condo";
				$typs='error';
			}
			$this->session->set_flashdata($typs,$smsg);
			redirect(base_url("sadmin/condolist/").'/'.$typ);
		}
		
		
		
		
		
		
		if($typ){
			if($typ=='ALL'){
				$logs=  $this->Mngrcondo_M->get();
			}elseif($typ=='PENDING'){
				$logs=  $this->Mngrcondo_M->get_by(array('status'=>'P'));
			}elseif($typ=='APPROVED'){
				$logs=  $this->Mngrcondo_M->get_by(array('status'=>'A'));
			}
		}else{
			$logs=  $this->Mngrcondo_M->get();
		}
		
		$m='';
		if(count($logs)>0){
			foreach($logs as $ad){
				$d= $ad->user_id;
				$ins = $this->User_M->get($d, TRUE);
				
				$stbtn ='';
				$frm ='';
				if($ad->status=='P'){
					$stbtn ='<p>Pending</p>';
					$frm ='
					<form method="post" style="float:left;" onsubmit="return confirm(\'Are you sure you want to approve it?\');">
					<input type="hidden" name="user_id" value="'.$ad->mc_id.'"  />	
					<button type="submit" name="approve"  title="Approve" 					  
					class="btn btn-primary"><i class="fa fa-check"></i></button>
					</form>
					
					
					<form method="post" style="float:left; margin-left:5px;" onsubmit="return confirm(\'Are you sure to reject it? Condo will be parmanently deleted.\');">
					<input type="hidden" name="user_id" value="'.$ad->mc_id.'"  />	
					<button type="submit" name="reject" title="Reject" 
					class="btn btn-primary"><i class="fa fa-trash" ></i></button>
					</form>
					';
				}
				if($ad->status=='A'){
					$stbtn ='<p>Active</p>';
					$frm ='
					
					<form method="post" style="float:left; margin-left:5px;" onsubmit="return confirm(\'Are you sure to reject it? Condo will be parmanently deleted.\');">
					<input type="hidden" name="user_id" value="'.$ad->mc_id.'"  />	
					<button type="submit" name="reject" title="Reject" 
					class="btn btn-primary"><i class="fa fa-trash" ></i></button>
					</form>
					';
				}
				
				$m = $m. '
                <tr>
                    <td>'.$ad->cn_name.'</td>
					<td>'.date('M d Y',strtotime($ad->insert_date)).'</td>
                    <td>'.$ins->user_name.' '.$ins->user_mname.' '.$ins->user_lname.'</td>
                    <td>'.$stbtn.'</td>
                    
                    <td class="hidden-xs">
                        '.$frm.'
                    </td>
                </tr>
				';
				
			}
		}
		
		//echo $m ; exit;
		
		$this->data['alldf']=$m;		
		
		
		$this->data['sub_view']='admin/s_subview/page_list';
		$this->load->view('admin/_layout',$this->data);
	}
	
	public function condolist($typ=NULL)   
	{
		if(isset($_POST['approve'])){
			$data['status']='A';
			$uid = $this->input->post('user_id');
			$r=$this->Condo_M->save($data, $uid);
			if($r){
				$smsg= "Condo Approved Successfully";
				$typs='success';
			}else{
				$smsg= "Error Occurs While Approving Condo";
				$typs='error';
			}
			$this->session->set_flashdata($typs,$smsg);
			redirect(base_url("sadmin/condolist/").'/'.$typ);
		}
		if(isset($_POST['reject'])){
			$uid = $this->input->post('user_id');
			$data['status']='I';
			$r=$this->Condo_M->save($data, $uid);
			if($r){
				$smsg= "Condo Rejected Successfully";
				$typs='success';
			}else{
				$smsg= "Error Occurs While Rejecting Condo";
				$typs='error';
			}
			$this->session->set_flashdata($typs,$smsg);
			redirect(base_url("sadmin/condolist/").'/'.$typ);
		}
		
		if(isset($_POST['export'])){
			
			$qry="SELECT  `cn_name` as Condo_Name,   `user_name` as Owner_First_Name,  `user_lname` as Owner_Last_Name,  			  
			`user_email` as Owner_Email 
			
			FROM `condo_mst` cm LEFT JOIN  user_mst um ON cm.insert_by = um.user_id
			WHERE cm.status='A'  
			";
			//exit;
			$flnm ="condo_list_";
			$this->exportinfo($qry,$flnm);
		}
		
		
		
		if($typ){
			if($typ=='ALL'){
				$logs=  $this->Condo_M->get();
			}elseif($typ=='PENDING'){
				$logs=  $this->Condo_M->get_by(array('status'=>'P'));
			}elseif($typ=='APPROVED'){
				$logs=  $this->Condo_M->get_by(array('status'=>'A'));
			}
		}else{
			$logs=  $this->Condo_M->get();
		}
		
		$m='';
		if(count($logs)>0){
			foreach($logs as $ad){
				$d= $ad->insert_by;
				$ins = $this->User_M->get($d, TRUE);
				
				
				$stbtn ='';
				$frm ='';
				if($ad->status=='P'){
					$stbtn ='<p>Pending</p>';
					$frm ='
					<form method="post" style="float:left;" onsubmit="return confirm(\'Are you sure you want to approve it?\');">
					<input type="hidden" name="user_id" value="'.$ad->cn_id.'"  />	
					<button type="submit" name="approve"  title="Approve" 					  
					class="btn btn-primary"><i class="fa fa-check"></i></button>
					</form>
					
					
					
					<a style="float:left; margin-left:5px;" class="btn btn-primary" href="'.base_url('sadmin/rejection/condo/'.$ad->cn_id).'">
					<i class="fa fa-trash" ></i></a>
					
					';
				}
				if($ad->status=='A'){
					$stbtn ='<p>Active</p>';
					$frm ='
					
					<a style="float:left; margin-left:5px;" class="btn btn-primary" href="'.base_url('sadmin/rejection/condo/'.$ad->cn_id).'">
					<i class="fa fa-trash" ></i></a>
					';
					
				}
				
				
				$m = $m. '
                <tr>
                    <td>'.$ad->cn_name.'</td>
					<td>'.date('M d Y',strtotime($ad->insert_date)).'</td>
                    <td>'.$ins->user_name.' '.$ins->user_mname.' '.$ins->user_lname.'</td>
                    <td>'.$ins->user_name.' '.$ins->user_mname.' '.$ins->user_lname.'</td>
                    <td>'.$stbtn.'</td>
                    
                    <td class="hidden-xs">
                        '.$frm.'
                    </td>
                </tr>
				';
				
			}
		}
		
		//////////////////////////
		
		if($typ){
			if($typ=='ALL'){
				$logsm=  $this->Mngrcondo_M->get();
			}elseif($typ=='PENDING'){
				$logsm=  $this->Mngrcondo_M->get_by(array('status'=>'P'));
			}elseif($typ=='APPROVED'){
				$logsm=  $this->Mngrcondo_M->get_by(array('status'=>'A'));
			}
		}else{
			$logsm=  $this->Mngrcondo_M->get();
		}
		
		
		if(count($logsm)>0){
			foreach($logsm as $adm){
				$d= $adm->user_id;
				$ins = $this->User_M->get($d, TRUE);
				
				
				$ow_n = $this->User_M->get_by(array('user_email'=>$adm->owner_email), TRUE);
				
				$stbtn ='';
				$frm ='';
				if($adm->status=='P'){
					$stbtn ='<p>Pending</p>';
					$frm ='
					<form method="post" action ="'.base_url().'sadmin/condomlist/'.$this->uri->segment(3).'" style="float:left;" onsubmit="return confirm(\'Are you sure you want to approve it?\');">
					<input type="hidden" name="user_id" value="'.$adm->mc_id.'"  />	
					<button type="submit" name="approve"  title="Approve" 					  
					class="btn btn-primary"><i class="fa fa-check"></i></button>
					</form>
					
					
					<a style="float:left; margin-left:5px;" class="btn btn-primary" href="'.base_url('sadmin/rejection/condom/'.$adm->mc_id).'">
					<i class="fa fa-trash" ></i></a>
					';
				}
				if($adm->status=='A'){
					$stbtn ='<p>Active</p>';
					$frm ='
					
					<a style="float:left; margin-left:5px;" class="btn btn-primary" href="'.base_url('sadmin/rejection/condom/'.$adm->mc_id).'">
					<i class="fa fa-trash" ></i></a>
					';
				}
				
				$m = $m. '
                <tr>
                    <td>'.$adm->cn_name.'</td>
					<td>'.date('M d Y',strtotime($adm->insert_date)).'</td>
                    <td title="'.$ins->user_email.'">'.$ins->user_name.' '.$ins->user_mname.' '.$ins->user_lname.'</td>
                    <td title="'.$ow_n->user_email.'">'.$ow_n->user_name.' '.$ow_n->user_mname.' '.$ow_n->user_lname.'</td>
                    <td>'.$stbtn.'.</td>
                    
                    <td class="hidden-xs">
                        '.$frm.'
                    </td>
                </tr>
				';
				
			}
		}
		
		
		
		
		/////////////////////////////
		
		
		
		
		
		
		$this->data['alldf']=$m;		
		
		
		$this->data['sub_view']='admin/s_subview/page_list';
		$this->load->view('admin/_layout',$this->data);
	}
	
	
	public function userlist($typ=NULL,$utype=NULL)   
	{
		
		if(isset($_POST['approve'])){
			$data['status']='A';
			$uid = $this->input->post('user_id');
			$r=$this->User_M->save($data, $uid);
			if($r){
				
				$udtl=$this->User_M->get($uid, TRUE);
				
						///EMAIL PACK START
						$sender_email="no-reply@grandcondominium.com";
						$sender_nm="Condo APP";
						$receiver_eml=array($udtl->user_email,'lokanathnayak@yahoo.co.in','andres@creativomiami.com');
						$subjects="Your account has been approved";
						$msg = 'Hi '.$udtl->user_name.' '.$udtl->user_lname.',<br><br>
								Your Account Has ben approved, <br><br>
								Please login to the application to process your work. <br><br>
								
								<br>
								Many Thanks, <br>Condo Association';
						$vv = $this->sendemail($sender_email, $sender_nm, $receiver_eml, $subjects, $msg );
						////EMAIL PACK END
				
				
				
				
				$smsg= "User Approved Successfully";
				$typs='success';
			}else{
				$smsg= "Error Occurs While Approving User";
				$typs='error';
			}
			$this->session->set_flashdata($typs,$smsg);
			redirect(base_url("sadmin/userlist/").'/'.$typ);
		}
		if(isset($_POST['reject'])){
			$uid = $this->input->post('user_id');
			
			$data['status']='D';
			$r=$this->User_M->save($data, $uid);
			//$r=$this->User_M->delete($uid);
			if($r){
				$smsg= "User Rejected Successfully";
				$typs='success';
			}else{
				$smsg= "Error Occurs While Rejecting User";
				$typs='error';
			}
			$this->session->set_flashdata($typs,$smsg);
			redirect(base_url("sadmin/userlist/").'/'.$typ.'/'.$utype);
		}
		if(isset($_POST['export'])){
			
			$qry="SELECT  `user_name` as First_Name,  `user_lname` as Last_Name, `user_typ` as Position, 
			 `address` as Address, `city` as City, `state` as State, `country` as Country, `zip` as zip, `phone` as phone, 
			`user_email` as Email FROM `user_mst`
			WHERE status='A'  AND user_typ='$utype'
			";
			//exit;
			$flnm ="user_list_".$utype."_";
			$this->exportinfo($qry,$flnm);
		}
		
		
		if($typ)
		{
			if($typ=='ALL'){
				$logs=  $this->User_M->get_by(array('user_typ !='=>'Admin'));
				if($utype){
					$logs=  $this->User_M->get_by(array('user_typ !='=>'Admin','user_typ'=> $utype));
				}
			}elseif($typ=='PENDING'){
				$logs=  $this->User_M->get_by(array('status'=>'I','user_typ !='=>'Admin'));
				if($utype){
					$logs=  $this->User_M->get_by(array('status'=>'I','user_typ !='=>'Admin','user_typ'=> $utype));
				}
			}elseif($typ=='APPROVED'){
				$logs=  $this->User_M->get_by(array('status'=>'A','user_typ !='=>'Admin'));
				if($utype){
					$logs=  $this->User_M->get_by(array('status'=>'A','user_typ !='=>'Admin','user_typ'=> $utype));
				}
			}
		}else
		{
			$logs=  $this->User_M->get_by(array('user_typ !='=>'Admin'));
			if($utype){
					$logs=  $this->User_M->get_by(array('user_typ !='=>'Admin','user_typ'=> $utype));
			}
		}
		
		$m='';
		if(count($logs)>0){
			foreach($logs as $ad){
				
				
				$stbtn ='';
				$frm ='';
				if($ad->status=='I'){
					$frm ='
					<form method="post" style="float:left;" onsubmit="return confirm(\'Are you sure you want to approve this user?\');">
					<input type="hidden" name="user_id" value="'.$ad->user_id.'"  />	
					<button type="submit" name="approve"  title="Approve" 					  
					class="btn btn-primary"><i class="fa fa-check"></i></button>
					</form>
					
					
					<a style="float:left; margin-left:5px;" class="btn btn-primary" href="'.base_url('sadmin/rejection/user/'.$ad->user_id).'"><i class="fa fa-trash" ></i></a>
					
					';
				}
				if($ad->status=='A'){
					$frm ='
					
					
					
					<a style="float:left; margin-left:5px;" class="btn btn-primary" href="'.base_url('sadmin/rejection/user/'.$ad->user_id).'"><i class="fa fa-trash" ></i></a>
					
					';
				}
				
				
				$m = $m. '
                <tr>
                    <td>'.$ad->user_name.' '.$ad->user_mname.' '.$ad->user_lname.'</td>
                    <td>'.$ad->user_email.'</td>
                    <td>'.$ad->user_typ.'</td>
					
                    <td class="hidden-xs">
                        '.$frm.'
                    </td>
                </tr>
				';
				
			}
		}
		
		//echo $m ; exit;
		
		$this->data['alldf']=$m;		
		
		
		$this->data['sub_view']='admin/s_subview/user_list';
		$this->load->view('admin/_layout',$this->data);
	}
	
	
	public function bookinglist($typ=NULL, $param = NULL, $sorty='DESC')   
	{
		
		if(isset($_POST['approve'])){
			$data['status']='A';
			$uid = $this->input->post('user_id');
			$r=$this->Book_M->save($data, $uid);
			if($r){
				$smsg= "Booking Approved Successfully";
				$typs='success';
			}else{
				$smsg= "Error Occurs While Approving Booking";
				$typs='error';
			}
			$this->session->set_flashdata($typs,$smsg);
			redirect(base_url("sadmin/bookinglist/").'/'.$typ);
		}
		if(isset($_POST['reject'])){
			$uid = $this->input->post('user_id');
			$data['status']='D';
			$r=$this->Book_M->save($data, $uid);
			if($r){
				$smsg= "Booking Rejected Successfully";
				$typs='success';
			}else{
				$smsg= "Error Occurs While Rejecting Booking";
				$typs='error';
			}
			$this->session->set_flashdata($typs,$smsg);
			redirect(base_url("sadmin/bookinglist/").'/'.$typ);
		}
		
		
		
		
		
		if($this->session->userdata('user_typ')=='Owner'){
			$ownerid = $this->session->userdata('user_id');
		}else{
			$ownerid = $this->session->userdata('owner_id');
		}
		
		$basicq = "SELECT b.*, cn_name, user_name, user_mname, user_lname 
		FROM `booking_mst` b 
		left join condo_mst c on b.condo_id = c.cn_id 
		left join user_mst u on b.insert_by = u.user_id ";
		if($typ){
			if($typ=='ALL'){
				$nqry= $basicq." where 1 ORDER BY b.entry_date DESC";
				
			}elseif($typ=='PENDING'){
				$nqry=$basicq." where   b.status ='P' ORDER BY b.entry_date DESC ";
			}elseif($typ=='APPROVED'){
				$nqry=$basicq." where   b.status ='A' ORDER BY b.entry_date DESC ";
			
			}elseif($typ=='SORTY'){
				$nqry=$basicq." where 1 ORDER BY ".$param."  ".$sorty."";
			}
		}else{
			
			$nqry=$basicq." where 1 ORDER BY entry_date DESC";
		}
		//echo $nqry; exit;
		if(isset($_POST['searchbtn'])){
			$searchterm = $this->input->post('searchterm');
			$nqry=$basicq." where b.owner_id = $ownerid AND
			(party_name LIKE '%$searchterm%' OR  email LIKE '%$searchterm%'  
			OR  cn_name LIKE '%$searchterm%'  
			OR  user_name LIKE '%$searchterm%'  
			OR  user_lname LIKE '%$searchterm%' )  ";
		}
		$nquery = $this->db->query($nqry);
		$logs = $nquery->result();
		
		
		
		
		
		
		
		$m='';
		if(count($logs)>0){
			$v=0;
			foreach($logs as $ad){
				$v++;
				$d= $ad->insert_by;
				$ins = $this->User_M->get($d, TRUE);
				$c_id=  $ad->condo_id;
				$cnd = $this->Condo_M->get($c_id, TRUE);
				
				if($ad->status=='P'){
					$stbtn ='<p>Pending</p>';
					$frm ='
					<form method="post" style="float:left;" onsubmit="return confirm(\'Are you sure you want to approve it?\');">
					<input type="hidden" name="user_id" value="'.$ad->book_id.'"  />	
					<button type="submit" name="approve"  title="Approve" 					  
					class="btn btn-primary"><i class="fa fa-check"></i></button>
					</form>
					
					
					
					
					<a style="float:left; margin-left:5px;" class="btn btn-primary" href="'.base_url('sadmin/rejection/book/'.$ad->book_id).'">
					<i class="fa fa-trash" ></i></a>
					
					
					';
				}
				if($ad->status=='A'){
					$stbtn ='<p>Active</p>';
					$frm ='
					
					<a style="float:left; margin-left:5px;" class="btn btn-primary" href="'.base_url('sadmin/rejection/book/'.$ad->book_id).'">
					<i class="fa fa-trash" ></i></a>
					
					';
					
				}
				
				$stbtn ='';
				if($ad->status=='P'){
					$stbtn ='<p style="color:#ff0000;" >Pending</p>';
				}elseif($ad->status=='A'){
					$stbtn ='<p style="color:#69c2fe;" >Active</p>';
				}
				if($ad->party_thumb!=''){
					$imglnkz= '
					<a class="image-popup-vertical-fit" href="'.base_url('uploads/visiter/'.$ad->party_thumb).'" >
					<img width="70" src="'.base_url('uploads/visiter/'.$ad->party_thumb).'" />
					</a>
					';
				}else{
					$imglnkz= '';
				}
				
				
				$pocdtl = $this->User_M->get($ad->poc_id,true);
				
				
				
				$m = $m. '
                <tr>
                   
                    <td> '.$ad->tran_id.' </td>
                    <td>'.$cnd->cn_name.'</td>
                    <td>'.$imglnkz.'</td>
                    <td><a href="mailto:'.$ad->email.'" >'.$ad->party_name.' '.$ad->party_lname.'</a> | '.preg_replace("/^(\d{3})(\d{3})(\d{4})$/", "$1-$2-$3", $ad->phone).'</td>
					<td>'.date('M d Y',strtotime($ad->book_st_dt)).' to '.date('M d Y',strtotime($ad->book_end_dt)).'</td>
					<td> <a href="mailto:'.$pocdtl->user_email.' ">'.$pocdtl->user_name.' '.$pocdtl->user_mname.' 
					'.$pocdtl->user_lname.'</a> | '.preg_replace("/^(\d{3})(\d{3})(\d{4})$/", "$1-$2-$3", $pocdtl->phone).'</td>
                    <td>'.$stbtn.'</td>
                    <td class="hidden-xs">
                        '.$frm.'
                    </td>
                </tr>
				';
				
			}
		}
		
		
		
		$this->data['alldf']=$m;		
		
		
		$this->data['sub_view']='admin/s_subview/bookinglist_n';
		$this->load->view('admin/_layout',$this->data);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public function logout()
	{
		$this->session->sess_destroy();
		redirect(base_url('admin/login'),'refresh');
	}
	
	
	public function dashboard()
	{
		$myid = $this->session->userdata('user_id');
		if(isset($_POST['editprofile']))
		{
			
			
			$rules['phone']= array('field'=>'phone','label'=>'Phone', 'rules'=>'trim|required');
			$rules['address']= array('field'=>'address','label'=>'Address', 'rules'=>'trim|required');
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				
				$data['user_name']=$this->input->post('user_name');
				$data['user_mname']=$this->input->post('user_mname');
				$data['user_lname']=$this->input->post('user_lname');
				
				$data['phone']=$this->input->post('phone');
				$data['address']=$this->input->post('address');
				
				$data['city']=$this->input->post('city');
				$data['state']=$this->input->post('state');
				$data['country']=$this->input->post('country');
				$data['zip']=$this->input->post('zip');
				
				//print_result($data); exit;
				
				$r=$this->User_M->save($data, $myid);
				if($r){
					$smsg= "Profile Information Changed Successfully";
					$typ='success';
				}else{
					$smsg= "Error Occurs While Changing Profile Information";
					$typ='error';
				}
					
					
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("sadmin/dashboard/"));
		}
		
		if(isset($_POST['changepassword']))
		{
			$rules['oldp']= array('field'=>'oldp','label'=>'Old Password', 'rules'=>'trim|required');
			$rules['newp']= array('field'=>'newp','label'=>'New Password', 'rules'=>'trim|required');
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				$oldp = $this->input->post('oldp');
				$newp = $this->input->post('newp');
				$repeatp = $this->input->post('repeatp');
				
				
				
				if($myinfo->user_password==$oldp ){
					if($newp==$repeatp){
						$data['user_password']=$newp;
						
						$r=$this->User_M->save($data, $myid);
						if($r){
							$smsg= "Password Changed Successfully";
							$typ='success';
						}else{
							$smsg= "Error Occurs While Changing Password";
							$typ='error';
						}
					}else{
						$smsg= "Password Mismatches";
						$typ='error';
					}
				}else{
					$smsg= "Provide proper Old Password";
					$typ='error';
				}
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("sadmin/dashboard/"));
		}
		
		
		
		$basicq = "SELECT b.*, cn_name, user_name, user_mname, user_lname 
		FROM `booking_mst` b 
		left join condo_mst c on b.condo_id = c.cn_id 
		left join user_mst u on b.insert_by = u.user_id ";
		
		$nqry=$basicq." where   b.status ='A' ORDER BY b.entry_date DESC  LIMIT 0,10";
			
		
		
		
		$nquery = $this->db->query($nqry);
		$logs = $nquery->result();
		
		
		
		
		
		
		
		$m='';
		if(count($logs)>0){
			$v=0;
			foreach($logs as $ad){
				$v++;
				$d= $ad->insert_by;
				$ins = $this->User_M->get($d, TRUE);
				$c_id=  $ad->condo_id;
				$cnd = $this->Condo_M->get($c_id, TRUE);
				
				if($ad->status=='P'){
					$stbtn ='<p>Pending</p>';
					$frm ='
					<form method="post" style="float:left;" onsubmit="return confirm(\'Are you sure you want to approve it?\');">
					<input type="hidden" name="user_id" value="'.$ad->book_id.'"  />	
					<button type="submit" name="approve"  title="Approve" 					  
					class="btn btn-primary"><i class="fa fa-check"></i></button>
					</form>
					
					
					
					
					<a style="float:left; margin-left:5px;" class="btn btn-primary" href="'.base_url('sadmin/rejection/book/'.$ad->book_id).'">
					<i class="fa fa-trash" ></i></a>
					
					
					';
				}
				if($ad->status=='A'){
					$stbtn ='<p>Active</p>';
					$frm ='
					
					<a style="float:left; margin-left:5px;" class="btn btn-primary" href="'.base_url('sadmin/rejection/book/'.$ad->book_id).'">
					<i class="fa fa-trash" ></i></a>
					
					';
					
				}
				
				$stbtn ='';
				if($ad->status=='P'){
					$stbtn ='<p style="color:#ff0000;" >Pending</p>';
				}elseif($ad->status=='A'){
					$stbtn ='<p style="color:#69c2fe;" >Active</p>';
				}
				if($ad->party_thumb!=''){
					$imglnkz= '
					<a class="image-popup-vertical-fit" href="'.base_url('uploads/visiter/'.$ad->party_thumb).'" >
					<img width="70" src="'.base_url('uploads/visiter/'.$ad->party_thumb).'" />
					</a>
					';
				}else{
					$imglnkz= '';
				}
				
				
				$pocdtl = $this->User_M->get($ad->poc_id,true);
				
				
				
				$m = $m. '
                <tr>
                   
                    <td> '.$ad->tran_id.' </td>
                    <td>'.$cnd->cn_name.'</td>
                    <td>'.$imglnkz.'</td>
                    <td><a href="mailto:'.$ad->email.'" >'.$ad->party_name.' '.$ad->party_lname.'</a> | '.preg_replace("/^(\d{3})(\d{3})(\d{4})$/", "$1-$2-$3", $ad->phone).'</td>
					<td>'.date('M d Y',strtotime($ad->book_st_dt)).' to '.date('M d Y',strtotime($ad->book_end_dt)).'</td>
					<td> <a href="mailto:'.$pocdtl->user_email.' ">'.$pocdtl->user_name.' '.$pocdtl->user_mname.' 
					'.$pocdtl->user_lname.'</a> | '.preg_replace("/^(\d{3})(\d{3})(\d{4})$/", "$1-$2-$3", $pocdtl->phone).'</td>
                    <td>'.$stbtn.'</td>
                    <td class="hidden-xs">
                        '.$frm.'
                    </td>
                </tr>
				';
				
			}
		}
		
		
		
		$this->data['alldf']=$m;
		
		
		
		
		
		$this->data['sub_view']='admin/s_subview/homesadmin';
		$this->load->view('admin/_layout',$this->data);
	}



public function sendemail($sender_email=NULL, $sender_nm=NULL, $receiver_eml=NULL, $subjects=NULL, $msg = NULL )
	{
		////email sending process...
		$config['mailtype'] = 'html';
		$config['wordwrap'] = TRUE;
		$this->email->initialize($config);
		
		if($sender_email!=NULL){
			$this->email->from($sender_email, $sender_nm);
		}else{
			$this->email->from('no-reply@grandcondominium.com', 'Condo App');
		}
		
		if($receiver_eml!=NULL){
			$rcv = $receiver_eml; //array we are expecting
		}else{
			$rcv = array('andres.corazza@gmail.com');
		}
						
		if($subjects==NULL){
			$subjects = "Test Email";
		}			
		if($msg==NULL){
			$msg = 'Hi there,<br><br>
				A new email is sent to you an test, <br><br>
				Date: Data Calue <br>
				<br>
				Thanks, <br>SAMPL Team';
		}				
						
						$this->email->to($rcv); 
						$this->email->subject($subjects);
						$this->email->message($msg);	


						$this->email->send();
						/////EMAIL SEND COMPLETE
	}
	
	
	
	











	
}
