<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Extn extends My_Controller 
{
	function __construct() 
	{
		parent::__construct();
		$this->load->model('Condo_M');
		$this->load->model('Book_M');
		$this->load->model('User_M');
		$this->load->model('Mngrcondo_M');
		
		$this->load->library('my_upload');
		$this->load->library("pagination");
		$this->load->library('email');
		$this->load->library('session');
	}
	
	
	public function index()
	{
		redirect(base_url("admin/login"), "refresh");
	}
	
	
	public function publiclist($typ=NULL, $param = NULL, $sorty='DESC')
	{
		
		$basicq = "SELECT b.*, cn_name, user_name, user_mname, user_lname 
		FROM `booking_mst` b 
		left join condo_mst c on b.condo_id = c.cn_id 
		left join user_mst u on b.insert_by = u.user_id ";
		if($typ){
			if($typ=='ALL'){
				$nqry= $basicq." where b.status <>'D' ORDER BY b.entry_date DESC";
				
			}elseif($typ=='PENDING'){
				$nqry=$basicq." where  b.status ='P' ORDER BY b.entry_date DESC";
			}elseif($typ=='APPROVED'){
				$nqry=$basicq." where  b.status ='A' ORDER BY b.entry_date DESC";
			
			}elseif($typ=='SORTY'){
				$nqry=$basicq." where 1 ORDER BY ".$param."  ".$sorty."";
			}
		}else{
			
			$nqry=$basicq." where b.status ='A' ORDER BY entry_date DESC";
		}
		//echo $nqry; exit;
		if($_POST){
			$searchterm = $this->input->post('searchterm');
			$nqry=$basicq." where party_name LIKE '%$searchterm%' OR  email LIKE '%$searchterm%'  
			OR  cn_name LIKE '%$searchterm%'  
			OR  user_name LIKE '%$searchterm%'  
			OR  user_lname LIKE '%$searchterm%'   ";
		}
		
		
		$nquery = $this->db->query($nqry);
		$logs = $nquery->result();
		
		
		
		
		
		$m='';
		if(count($logs)>0){
			foreach($logs as $ad){
				$stbtn ='';
				if($ad->status=='P'){
					$stbtn ='<p style="color:#ff0000;" >Pending</p>';
				}elseif($ad->status=='A'){
					$stbtn ='<p style="color:#69c2fe;" >Active</p>';
				}
				if($ad->party_thumb!=''){
					$imglnkz= '
					<a class="image-popup-vertical-fit" href="'.base_url('uploads/visiter/'.$ad->party_thumb).'" >
					<img width="70" src="'.base_url('uploads/visiter/'.$ad->party_thumb).'" />
					</a>
					';
				}else{
					$imglnkz= '';
				}
				
				$pocdtl = $this->User_M->get($ad->poc_id,true);
				
				
				$m = $m. '
                <tr>
                   
                    
                    <td>'.$ad->cn_name.'</td>
                    <td>'.$imglnkz.'</td>
                    <td><a href="mailto:'.$ad->email.'" >'.$ad->party_name.' '.$ad->party_lname.'</a> </td>
                    <td>'.$ad->email.'</td>
                    <td> <a href="mailto:'.$pocdtl->user_email.' ">'.$pocdtl->user_name.' '.$pocdtl->user_mname.' '.$pocdtl->user_lname.'</a> </td>
					<td>'.date('M d Y',strtotime($ad->book_st_dt)).' to '.date('M d Y',strtotime($ad->book_end_dt)).'</td>
                    <td>'.$stbtn.'</td>
                    
					
                </tr>
				';
				
			}
		}
		
		
		
		$this->data['alldf']=$m;	
		
		$this->load->view('admin/_plist',$this->data);
	}
	
	
	
	
	
	
	
}
