<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->library("braintree_lib");
    }


	
	
	public function payit()
    {
        $price='3';
		$card_number='4737029949110201';   /// end is 0
		$card_name='ANDRES CORAZZA';
		$expirationDate='04/18';
		$cvv='284';
		
		
		
		$data = $this->braintree_lib->do_cc_pay($price, $card_number, $card_name, $expirationDate, $cvv);
        print_result($data);
		
		
		
		
		
		
		if ($data->success)
		{
			//echo $data->transaction->id;
		}
    }

}
?>
