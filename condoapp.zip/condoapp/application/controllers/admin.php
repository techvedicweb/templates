<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin extends Admin_Controller 
{
	function __construct() 
	{
		parent::__construct();
		$this->load->model('Condo_M');
		$this->load->model('Book_M');
		$this->load->model('User_M');
		$this->load->model('Mngrcondo_M');
		
		$this->load->library('my_upload');
		$this->load->library("pagination");
		$this->load->library('email');
		$this->load->library('session');
		
		
		$this->load->library("braintree_lib");
		
		$myid = $this->session->userdata('user_id');
		$myinfos = $this->User_M->get($myid, TRUE);
		$this->data['myinfo']=  $myinfos;
		
		if($myinfos->thumbnail==''){
			$this->data['mypic']=  base_url('nassets/img/avatar-mini.jpg');
		}else{
			$this->data['mypic']= base_url('nassets/img/profpic').'/'.$myinfos->thumbnail;
		}
		
		$bb = array("dashboard", "logout" , "register" , "registernext" , "registersuccess" , "forgotpassword" , "autocomplete" , "login");
		if (!in_array($this->uri->segment(2), $bb) && $myinfos->status=='I' ){
			redirect(base_url("admin/dashboard"));
		}
		
		
		

	}
	
	
	public function index()
	{
		redirect(base_url("admin/login"), "refresh");
	}
	
	public function login()
	{
		$typ =$this->session->userdata('user_typ');
		
		if($this->User_M->isLoggedin() == TRUE)
		{
			//redirect(base_url("admin/dashboard"));
			if($typ=='Owner'){
				redirect(base_url("admin/dashboard"));
			}elseif($typ=='Manager'){
				redirect(base_url("manager/dashboard"));
			}elseif($typ=='Admin'){
				redirect(base_url("sadmin/dashboard"));
			}elseif($typ=='Security'){
				redirect(base_url("security/dashboard"));
			}
		}	
		$rules = $this->User_M->rule_login;
		$this->form_validation->set_rules($rules);
	
		if($this->form_validation->run() == TRUE)
		{
			if($this->User_M->login() == TRUE)
			{
				
				
				if($typ=='Owner'){
					redirect(base_url("admin/dashboard"));
				}elseif($typ=='Manager'){
					redirect(base_url("manager/dashboard"));
				}elseif($typ=='Admin'){
					redirect(base_url("sadmin/dashboard"));
				}
					
			}
			else
			{				
				$this->session->set_flashdata('error','Email ID / Password Combination Doesn\'t Exist');
				redirect(base_url("admin/login"), "refresh");
			}
		}
		
		$this->load->view('admin/_login');
	}
	
	
	public function editprofile()
	{
	
		$myid = $this->session->userdata('user_id');
		$myinfo = $this->User_M->get($myid, TRUE);
		if(isset($_POST['editprofile']))
		{
			
			
			$rules['phone']= array('field'=>'phone','label'=>'Phone', 'rules'=>'trim|required');
			$rules['address']= array('field'=>'address','label'=>'Address', 'rules'=>'trim|required');
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				
				$data['user_name']=$this->input->post('user_name');
				$data['user_mname']=$this->input->post('user_mname');
				$data['user_lname']=$this->input->post('user_lname');
				
				$data['phone']=$this->input->post('phone');
				$data['address']=$this->input->post('address');
				
				$data['city']=$this->input->post('city');
				$data['state']=$this->input->post('state');
				$data['country']=$this->input->post('country');
				$data['zip']=$this->input->post('zip');
				
				//print_result($data); exit;
				
				$r=$this->User_M->save($data, $myid);
				if($r){
					$smsg= "Profile Information Changed Successfully";
					$typ='success';
				}else{
					$smsg= "Error Occurs While Changing Profile Information";
					$typ='error';
				}
					
					
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("admin/editprofile/"));
		}
		
	
	
	
		$this->data['sub_view']='admin/subview/editprofile';
		$this->load->view('admin/_layout',$this->data);
	}
	
	
	public function changepass()
	{
	
		$myid = $this->session->userdata('user_id');
		$myinfo = $this->User_M->get($myid, TRUE);
		if(isset($_POST['changepassword']))
		{
			$rules['oldp']= array('field'=>'oldp','label'=>'Old Password', 'rules'=>'trim|required');
			$rules['newp']= array('field'=>'newp','label'=>'New Password', 'rules'=>'trim|required');
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				$oldp = $this->input->post('oldp');
				$newp = $this->input->post('newp');
				$repeatp = $this->input->post('repeatp');
				
				
				
				if($myinfo->user_password==$oldp ){
					if($newp==$repeatp){
						$data['user_password']=$newp;
						
						$r=$this->User_M->save($data, $myid);
						if($r){
							$smsg= "Password Changed Successfully";
							$typ='success';
						}else{
							$smsg= "Error Occurs While Changing Password";
							$typ='error';
						}
					}else{
						$smsg= "Password Mismatches";
						$typ='error';
					}
				}else{
					$smsg= "Provide proper Old Password";
					$typ='error';
				}
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url().$this->uri->segment(1).'/changepass');
		}
		
	
	
	
		$this->data['sub_view']='admin/subview/changepass';
		$this->load->view('admin/_layout',$this->data);
	}
	
	public function forgotpassword()
	{
		if($_POST)
		{
			$rules['user_email']= array('field'=>'user_email','label'=>'Email', 'rules'=>'trim|required');
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				$eml = $this->input->post('user_email');
				$iseml = $this->User_M->get_by(array('user_email'=>$eml),TRUE);
				if(count($iseml)>0){
					////email sending process...
					$config['mailtype'] = 'html';
					$config['wordwrap'] = TRUE;
					$this->email->initialize($config);
					
					
					$this->email->from('no-reply@grandcondominium.com', 'CONDO APP');
					$this->email->to($eml); 
					

					$this->email->subject('Forgot your password at CONDO APP!');
					$this->email->message('Hi, <br> We got your request. Here is your Password:  '.$iseml->user_password. '<br>Thanks <br>Team CONDO');	
					$this->email->send();
					
					$smsg= "An email has been sent to you with your login informations.";
					$typ='success';
				}
				else
				{
					$smsg= "We dont have such email id with us.";
					$typ='error';
				}
				
				
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("admin/login/"));
		}
	}
	
	public function register()
	{
		if($_POST)
		{
			$rules['user_email']= array('field'=>'user_email','label'=>'Email', 'rules'=>'trim|required');
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				$eml = $this->input->post('user_email');
				$iseml = $this->User_M->get_by(array('user_email'=>$eml));
				if(count($iseml)>0){
					$smsg= "This user is already with us";
					$typ='error';
					$this->session->set_flashdata($typ,$smsg);
					redirect(base_url("admin/register/"));
				}
				else
				{
					$flname= md5(date("YmdHis")) ;
					$uploadimage = $this->do_upload('thumb', 'nassets/img/profpic/', 450, 450, $flname);
					
					$allsignup= $_POST;
					$allsignup['thumbnail'] = $uploadimage;

					$this->session->set_userdata('allsignup', $allsignup);
					redirect(base_url("admin/registernext/"));
				}
			}
		}
		
		
		
		if(isset($_POST['old']))
		{
			$rules['user_email']= array('field'=>'user_email','label'=>'Email', 'rules'=>'trim|required');
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				
				$flname= md5(date("YmdHis")) ;
				$uploadimage = $this->do_upload('thumb', 'nassets/img/profpic/', 300, 300, $flname);
				
				
				$data['thumbnail']=$uploadimage;
				
				
				$eml = $this->input->post('user_email');
				$iseml = $this->User_M->get_by(array('user_email'=>$eml));
				if(count($iseml)>0){
					$smsg= "This user is already with us";
					$typ='error';
				}
				else
				{
					$data['user_name']=$this->input->post('user_name');
					$data['user_mname']=$this->input->post('user_mname');
					$data['user_lname']=$this->input->post('user_lname');
					
					$data['address']=$this->input->post('address');
					$data['city']=$this->input->post('city');
					$data['state']=$this->input->post('state');
					$data['country']=$this->input->post('country');
					$data['zip']=$this->input->post('zip');
					
					$data['phone']=$this->input->post('phone');
					$data['user_email']=$this->input->post('user_email');
					$data['user_password']=$this->input->post('user_password');
					$data['user_typ']=$this->input->post('user_typ');
					
					$user_typ = $this->input->post('user_typ');
					
					
					$r=$this->User_M->save($data);
					if($r){
						$smsg='';
						$suc=0;
						if($user_typ=='Owner')
						{
							$condolist = $this->input->post('unit');
							foreach($condolist as $c){
								if($c!=''){
									$isc = $this->Condo_M->get_by(array('cn_name'=>$c));
									if(count($isc)>0){
										// no entry
									}else{
										$datab['user_id']=$r;
										$datab['cn_name']=$c;
										$datab['insert_by']=$r;
										$rm=$this->Condo_M->save($datab);
										$suc++;
									}
								}
							}
							if($suc>0){
								$smsg = 'with '.$suc.' condo request.';
							}
							
						}
						
						if($user_typ=='Manager')
						{
							$condolist = $this->input->post('unitm');
							$oname = $this->input->post('oname');
							$oemail = $this->input->post('oemail');
							
							//print_result($condolist);
							
							
							//echo $condolist[1];
							//exit;
							
							
							
							//foreach($condolist as $c){
							for ($x = 0; $x <= 4; $x++) 
							{	
								if($condolist[$x]!='' && $oemail[$x]!='')
								{
									$isc = $this->Condo_M->get_by(array('cn_name'=>$condolist[$x]),TRUE);
									// check if condo already present?
									if(count($isc)>0)
									{
										$owneridz = $isc->user_id;
										$ownerinfo = $this->User_M->get($owneridz, TRUE);
										$dataz['cn_name']=$condolist[$x];				
										$dataz['user_id']=$r;						
										
										$dataz['cn_id']=$isc->cn_id;
										$dataz['entry_page']='signup';
										
										$dataz['owner_nm']=$ownerinfo->user_name.' '.$ownerinfo->user_mname.' '.$ownerinfo->user_lname;
										$dataz['owner_email']= $ownerinfo->user_email;
										
										$rv=$this->Mngrcondo_M->save($dataz);
										
										$suc++;
									}else
									{
										$em = $this->User_M->get_by(array('user_email'=>$oemail[$x], 'user_typ'=>'Owner'),TRUE);
										/// find if the owner email is a real user or not
										if(count($em)>0){
											$dataz['cn_name']=$condolist[$x];				
											$dataz['user_id']=$r;
											$dataz['entry_page']='signup';
											$dataz['owner_nm']=$em->user_name.' '.$em->user_mname.' '.$em->user_lname;
											$dataz['owner_email']= $oemail[$x];
											$rv=$this->Mngrcondo_M->save($dataz);
											/////////////////////////////////////
											$datab['user_id']=  $em->user_id;
											$datab['cn_name']=$condolist[$x];
											$datab['insert_by']=$r;
											$rm=$this->Condo_M->save($datab);
											$suc++;
										}
										
									}
								}
							}
							if($suc>0){
								$smsg = 'with '.$suc.' condo request.';
							}
						}
						
						
						
						$smsg= "You Have  Registered Successfully ".$smsg;
						$typ='success';
					}else{
						$smsg= "Error Occurs While Registering";
						$typ='error';
					}
				}
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("admin/register/"));
		}
		
		
		
		$this->load->view('admin/_signup');
	}
	
	public function registernext()
	{
		
		$sd = $this->session->userdata('allsignup');
		$user_typ = $sd['user_typ'];
		
		if($user_typ){
		}else{
			redirect(base_url("admin/register/"));
		}
		
		
		
		if($_POST)
		{
			$sd = $this->session->userdata('allsignup');
			$user_typ = $sd['user_typ'];
			if($user_typ)
			{	
				$data['thumbnail']=$sd['thumbnail'];
					$data['user_name']=$sd['user_name'];
					//$data['user_mname']=$sd['user_mname'];
					$data['user_lname']=$sd['user_lname'];
					
					$data['address']=$sd['address'];
					$data['city']=$sd['city'];
					$data['state']=$sd['state'];
					$data['country']=$sd['country'];
					$data['zip']=$sd['zip'];
					
					$data['phone']=$sd['phone'];
					$data['user_email']=$sd['user_email'];
					$data['user_password']=$sd['user_password'];
					$data['user_typ']=$sd['user_typ'];
					
					$user_typ = $sd['user_typ'];
					
					
					$r=$this->User_M->save($data);
					if($r){
						$smsg='';
						$suc=0;
						if($user_typ=='Owner')
						{
							$condolist = $this->input->post('unit');
							foreach($condolist as $c){
								if($c!=''){
									$isc = $this->Condo_M->get_by(array('cn_name'=>$c));
									if(count($isc)>0){
										// no entry
									}else{
										$datab['user_id']=$r;
										$datab['cn_name']=$c;
										$datab['insert_by']=$r;
										$rm=$this->Condo_M->save($datab);
										$suc++;
									}
								}
							}
							if($suc>0){
								$smsg = 'with '.$suc.' condo request.';
							}
							
						}
						
						if($user_typ=='Manager')
						{
							$condolist = $this->input->post('unitm');
							$oname = $this->input->post('oname');
							$oemail = $this->input->post('oemail');
							
							//foreach($condolist as $c){
							for ($x = 0; $x <= 4; $x++) 
							{	
								$vm = $oemail[$x];
								$dmd = explode(" - ",$vm);
								$oemail[$x] = $dmd[1];
								$em_dtl = $this->User_M->get_by(array('user_email'=>$oemail[$x]),TRUE);
								$oemail[$x] = $em_dtl->user_id;    // we set the user id here.....
						
						
								if($condolist[$x]!='' && $oemail[$x]!='')
								{
									$isc = $this->Condo_M->get_by(array('cn_name'=>$condolist[$x]),TRUE);
									// check if condo already present?
									if(count($isc)>0)
									{
										if($isc->user_id == $oemail[$x]){
											$owneridz = $isc->user_id;
											$ownerinfo = $this->User_M->get($owneridz, TRUE);
											$dataz['cn_name']=$condolist[$x];				
											$dataz['user_id']=$r;						
											$dataz['cn_id']=$isc->cn_id;
											$dataz['entry_page']='signup';
											$dataz['owner_nm']=$ownerinfo->user_name.' '.$ownerinfo->user_mname.' '.$ownerinfo->user_lname;
											$dataz['owner_email']= $ownerinfo->user_email;
											$rv=$this->Mngrcondo_M->save($dataz);
											$suc++;
										}else{
											///wrong info selected
										}
									}else
									{
										$em = $em_dtl;
										/// find if the owner email is a real user or not
										if(count($em)>0){
											$dataz['cn_name']=$condolist[$x];				
											$dataz['user_id']=$r;
											$dataz['entry_page']='signup';
											$dataz['owner_nm']=$em->user_name.' '.$em->user_mname.' '.$em->user_lname;
											$dataz['owner_email']= $oemail[$x];
											$rv=$this->Mngrcondo_M->save($dataz);
											/////////////////////////////////////
											$datab['user_id']=  $em->user_id;
											$datab['cn_name']=$condolist[$x];
											$datab['insert_by']=$r;
											$rm=$this->Condo_M->save($datab);
											$suc++;
										}
										
									}
								}
							}
							if($suc>0){
								$smsg = 'with '.$suc.' condo request.';
							}
						}
						
						
						///EMAIL PACK START
						$sender_email="no-reply@condoapp.com";
						$sender_nm="Condo APP";
						$receiver_eml=array('mntnayak@yahoo.co.in','andres@creativomiami.com');
						$subjects="New user created";
						$msg = 'Hi Condo Association,<br><br>
								A new user has been created, <br><br>
								User Type: '.$user_typ.' <br>
								Name: '.$sd['user_name'].' '.$sd['user_lname'].' <br>
								Address: '.$sd['address'].' '.$sd['city'].' '.$sd['state'].' '.$sd['country'].' - '.$sd['zip'].' <br>
								Phone: '.$sd['phone'].' <br>
								Email: '.$sd['user_email'].' <br>
								<br>
								From, <br>Condo App';
						$vv = $this->sendemail($sender_email, $sender_nm, $receiver_eml, $subjects, $msg );
						  ////----2
							
							$receiver_emlz=array($sd['user_email']);
							$subjectsz="Welcome To Condo App";
							$msgz = 'Hi '.$sd['user_name'].' '.$sd['user_lname'].',<br><br>
									Thanks for joining with us, <br><br>
									Our team will review your application. <br>
									You will receive an email notification confirming your account. 
									For immediate questions you may visit our offices . 
									You can also submit your inquiries to str@grandcondominium.com 
									We try to reply to all inquiries within 24 hours., <br><br>
									
									<br>
									Many Thanks, <br>Condo Association';
							$vvm = $this->sendemail($sender_email, $sender_nm, $receiver_emlz, $subjectsz, $msgz );
						
						
						
						////EMAIL PACK END
						
						$smsg= "You Have  Registered Successfully ".$smsg;
						$typ='success';
					}else{
						$smsg= "Error Occurs While Registering";
						$typ='error';
					}
				
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("admin/registersuccess/"));
		}
		
		
		$this->data['allowner']=$this->User_M->get_by(array('user_typ'=>'Owner','status'=>'A'));
		$this->data['user_typ']=$user_typ;
		$this->load->view('admin/_signupnext',$this->data);
	}
	
	public function autocomplete(){
        $keyword = $this->input->post('term');
        $data['response'] = 'false'; //Set default response
        $query = $this->User_M->get_by(array('user_typ'=>'Owner','status'=>'A'));
        if( ! empty($query) )
        {
            $data['response'] = 'true'; //Set response
            $data['message'] = array(); //Create array
            foreach( $query as $row )
            {
                echo $row->user_name.' '.$row->user_lname.' - '.$row->user_email."\n";
            }
        }
        
    }
		
	public function registersuccess()
	{
		
		$this->data['success']='yes';
		$this->load->view('admin/_signupsuccess',$this->data);
	}
	
	
	
	
	
	public function addcondo()  
	{
		if($this->session->userdata('user_typ')=='Owner'){
			$ownerid = $this->session->userdata('user_id');
		}else{
			$ownerid = $this->session->userdata('owner_id');
		}
		
		
		if($_POST)
		{
			$rules['cn_name']= array('field'=>'cn_name','label'=>'Condo Name', 'rules'=>'trim|required');
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				$cnm = $this->input->post('cn_name');
				$isc = $this->Condo_M->get_by(array('cn_name'=>$cnm));
				if(count($isc)>0){
					$smsg= "A Condo with same name already present in our system.";
					$typ='error';
				}else{
					$data['cn_name']=$this->input->post('cn_name');				
					$data['insert_by']=$this->session->userdata('user_id');
					$data['user_id']=$ownerid;
									
					$r=$this->Condo_M->save($data);
					if($r){
						$smsg= "Condo request added successfully.";
						$typ='success';
					}else{
						$smsg= "Error Occurs While Creating Condo";
						$typ='error';
					}
				}
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("admin/condolist/"));
		}
				
		
		$this->data['sub_view']='admin/subview/addcondo';
		$this->load->view('admin/_layout',$this->data);
	}
	
	
	public function editcondo($pageid)  
	{
		if($_POST)
		{
			$rules['cn_name']= array('field'=>'cn_name','label'=>'Condo Name', 'rules'=>'trim|required');

			
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
						
				
				
				$data['cn_name']=$this->input->post('cn_name');
				
				$r=$this->Condo_M->save($data,$pageid);
				if($r){
					$smsg= "Condo Updated Successfully";
					$typ=  'success';
				}else{
					$smsg= "Error Occurs While Updating Condo";
					$typ='error';
				}
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("admin/condolist/"));
		}
				
		$this->data['this_pages']=$this->Condo_M->get($pageid, TRUE);
		$this->data['sub_view']='admin/subview/editcondo';
		$this->load->view('admin/_layout',$this->data);
	}
	
	public function deletecondo($pageid)  
	{
		$data['status']='D';
		$r=$this->Condo_M->save($data,$pageid);
		if($r){
			$smsg= "Condo Disabled Successfully";
			$typ=  'success';
		}else{
			$smsg= "Error Occurs While Disabling Condo";
			$typ='error';
		}
		$this->session->set_flashdata($typ,$smsg);
		redirect(base_url("admin/condolist/"));
		
	}
	
	
	
	
	
	public function condolist($typ=NULL)   
	{
		if($this->session->userdata('user_typ')=='Owner'){
			$ownerid = $this->session->userdata('user_id');
		}else{
			$ownerid = $this->session->userdata('owner_id');
		}
		
		
		
		if($_POST)
		{
			$rules['cn_name']= array('field'=>'cn_name','label'=>'Condo Name', 'rules'=>'trim|required');
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				$cnm = $this->input->post('cn_name');
				$isc = $this->Condo_M->get_by(array('cn_name'=>$cnm));
				if(count($isc)>0){
					$smsg= "A Condo with same name already present in our system.";
					$typ='error';
				}else{
					$data['cn_name']=$this->input->post('cn_name');				
					$data['insert_by']=$this->session->userdata('user_id');
					$data['user_id']=$ownerid;
									
					$r=$this->Condo_M->save($data);
					if($r){
						$smsg= "Condo request added successfully.";
						$typ='success';
					}else{
						$smsg= "Error Occurs While Creating Condo";
						$typ='error';
					}
				}
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("admin/condolist/"));
		}
				
		
		
		
		
		
		
		
		
		
		
		
		if($typ){
			if($typ=='ALL'){
				$logs=  $this->Condo_M->get_by(array('user_id'=>$ownerid, 'status !='=>'D'));
			}elseif($typ=='PENDING'){
				$logs=  $this->Condo_M->get_by(array('status'=>'P', 'user_id'=>$ownerid));
			}elseif($typ=='APPROVED'){
				$logs=  $this->Condo_M->get_by(array('status'=>'A', 'user_id'=>$ownerid));
			}elseif($typ=='DISABLED'){
				$logs=  $this->Condo_M->get_by(array('status'=>'D', 'user_id'=>$ownerid));
			}
		}else{
			$logs=  $this->Condo_M->get_by(array('user_id'=>$ownerid, 'status !='=>'D'));
		}
		
		$m='';
		if(count($logs)>0){
			foreach($logs as $ad){
				$d= $ad->insert_by;
				$ins = $this->User_M->get($d, TRUE);
				if($ins){
					$dnm = $ins->user_name.' '.$ins->user_mname.' '.$ins->user_lname;
				}else{
					$dnm = '<span title="'.$d.'">--</span>';
				}
				
				$stbtn ='';
				if($ad->status=='P'){
					$stbtn ='<p class="btn btn-primary">Pending</p>';
					$delbtn ='<a  href="'.base_url('admin/deletecondo/'.$ad->cn_id).'"  onclick="return confirm(\'Are you sure?\')" class="btn btn-primary btn-xs"><i class="fa fa-trash"></i></a>';
				}elseif($ad->status=='A'){
					$stbtn ='<p class="btn btn-info">Active</p>';
					$delbtn ='';
				}elseif($ad->status=='D'){
					$stbtn ='<p class="btn btn-info disabled" >Disabled</p>';
					$delbtn ='';
				}elseif($ad->status=='I'){
					$stbtn ='<p class="btn btn-warning">Inacive</p>';
					$delbtn ='<a  href="'.base_url('admin/deletecondo/'.$ad->cn_id).'"  onclick="return confirm(\'Are you sure?\')" class="btn btn-primary btn-xs"><i class="fa fa-trash"></i></a>';
				}
				
				
				$m = $m. '
                <tr>
                    <td>'.$ad->cn_name.'</td>
					<td>'.date('M d Y',strtotime($ad->insert_date)).'</td>
                    <td>'.$dnm.'</td>
                    <td>'.$stbtn.'</td>
                    
                    <td class="hidden-xs">'.$delbtn.'</td>
                </tr>
				';
				//onclick="return confirmbox("Are you sure to delete?")"
			}
		}
		
		//echo $m ; exit;
		
		$this->data['alldf']=$m;		
		
		
		$this->data['sub_view']='admin/subview/page_list';
		$this->load->view('admin/_layout',$this->data);
	}
	
	/////////////////////////////////////////////////////
	/*public function bookinglist($typ=NULL)   
	{
		if($this->session->userdata('user_typ')=='Owner'){
			$ownerid = $this->session->userdata('user_id');
		}else{
			$ownerid = $this->session->userdata('owner_id');
		}
		if($typ){
			if($typ=='ALL'){
				$logs=  $this->Book_M->get_by(array('insert_by'=>$ownerid));
			}elseif($typ=='PENDING'){
				$logs=  $this->Book_M->get_by(array('status'=>'P', 'insert_by'=>$ownerid));
			}elseif($typ=='APPROVED'){
				$logs=  $this->Book_M->get_by(array('status'=>'A', 'insert_by'=>$ownerid));
			}
		}else{
			$logs=  $this->Book_M->get_by(array('insert_by'=>$ownerid));
		}
		
		$m='';
		if(count($logs)>0){
			foreach($logs as $ad){
				$d= $ad->insert_by;
				$ins = $this->User_M->get($d, TRUE);
				$c_id=  $ad->condo_id;
				$cnd = $this->Condo_M->get($c_id, TRUE);
				
				
				
				$stbtn ='';
				if($ad->status=='P'){
					$stbtn ='<p class="btn btn-primary">Pending</p>';
				}elseif($ad->status=='A'){
					$stbtn ='<p class="btn btn-info">Active</p>';
				}
				
				
				$m = $m. '
                <tr>
                    <td>'.$cnd->cn_name.'</td>
                    <td><a href="mailto:'.$ad->email.'" >'.$ad->party_name.'</a> | '.$ad->phone.'</td>
					<td>'.date('M d Y',strtotime($ad->book_st_dt)).' to '.date('M d Y',strtotime($ad->book_end_dt)).'</td>
                    <td>'.$ins->user_name.' '.$ins->user_mname.' '.$ins->user_lname.'</td>
                    <td>'.$stbtn.'</td>
                    
                    <td class="hidden-xs">
                        <a href="'.base_url('admin/editbooking/'.$ad->book_id).'" class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></a>
                    </td>
                </tr>
				';
				
			}
		}
		
		
		
		$this->data['alldf']=$m;		
		
		
		$this->data['sub_view']='admin/subview/bookinglist';
		$this->load->view('admin/_layout',$this->data);
	}
	
	public function addbooking()  
	{
		if($this->session->userdata('user_typ')=='Owner'){
			$ownerid = $this->session->userdata('user_id');
		}else{
			$ownerid = $this->session->userdata('owner_id');
		}
		
		
		if($_POST)
		{
			$rules['condo_id']= array('field'=>'condo_id','label'=>'Condo', 'rules'=>'trim|required');
			$rules['book_st_dt']= array('field'=>'book_st_dt','label'=>'Start Date', 'rules'=>'trim|required');
			$rules['book_end_dt']= array('field'=>'book_end_dt','label'=>'End Date', 'rules'=>'trim|required');
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				$stdt = $this->input->post('book_st_dt');
					$parts = explode('/',$christmas);
					$stdt = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
				
				$enddt = $this->input->post('book_end_dt');
					$partsn = explode('/',$christmas);
					$enddt = $partsn[2] . '-' . $partsn[0] . '-' . $partsn[1];
				
				
				$data['condo_id']=$this->input->post('condo_id');
				$data['book_st_dt']= $stdt;
				$data['book_end_dt']= $enddt;
				
				$data['party_name']=$this->input->post('party_name');
				$data['email']=$this->input->post('email');
				$data['phone']=$this->input->post('phone');
				$data['address']=$this->input->post('address');
				$data['city']=$this->input->post('city');
				$data['state']=$this->input->post('state');
				$data['country']=$this->input->post('country');
				$data['zip']=$this->input->post('zip');
				
				$data['insert_by']=$this->session->userdata('user_id');
				
				
				
				
				
				$r=$this->Book_M->save($data);
				if($r){
					$smsg= "Booking Created Successfully";
					$typ='success';
				}else{
					$smsg= "Error Occurs While Creating Booking";
					$typ='error';
				}
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("admin/bookinglist/"));
		}
		

		$logs=  $this->Condo_M->get_by(array('status'=>'A', 'user_id'=>$ownerid));
		$m='';
		if(count($logs)>0){
			foreach($logs as $ad){
				$m = $m. '<option value="'.$ad->cn_id.'">'.$ad->cn_name.'</option> ';
			}
		}
				
		$this->data['allselect']=$m;
		
		$this->data['sub_view']='admin/subview/addbooking';
		$this->load->view('admin/_layout',$this->data);
	}
	
	*/
	

	public function bookinglist($typ=NULL, $param = NULL, $sorty='DESC')   
	{
		if($this->session->userdata('user_typ')=='Owner'){
			$ownerid = $this->session->userdata('user_id');
		}else{
			$ownerid = $this->session->userdata('owner_id');
		}
		/*if($typ){
			if($typ=='ALL'){
				$logs=  $this->Book_M->get_by(array('owner_id'=>$ownerid),FALSE,FALSE, 'entry_date', 'DESC');
			}elseif($typ=='PENDING'){
				$logs=  $this->Book_M->get_by(array('status'=>'P', 'owner_id'=>$ownerid),FALSE,FALSE, 'entry_date', 'DESC');
			}elseif($typ=='APPROVED'){
				$logs=  $this->Book_M->get_by(array('status'=>'A', 'owner_id'=>$ownerid),FALSE,FALSE, 'entry_date', 'DESC');
			}
		}else{
			$logs=  $this->Book_M->get_by(array('owner_id'=>$ownerid),FALSE,FALSE, 'entry_date', 'DESC');
		}
		*/
		
		
		
		$basicq = "SELECT b.*, cn_name, user_name, user_mname, user_lname 
		FROM `booking_mst` b 
		left join condo_mst c on b.condo_id = c.cn_id 
		left join user_mst u on b.insert_by = u.user_id ";
		if($typ){
			if($typ=='ALL'){
				$nqry= $basicq." where b.owner_id = $ownerid ORDER BY b.entry_date DESC";
				
			}elseif($typ=='PENDING'){
				$nqry=$basicq." where b.owner_id = $ownerid AND  b.status ='P' ORDER BY b.entry_date DESC ";
			}elseif($typ=='APPROVED'){
				$nqry=$basicq." where b.owner_id = $ownerid AND  b.status ='A' ORDER BY b.entry_date DESC ";
			
			}elseif($typ=='SORTY'){
				$nqry=$basicq." where b.owner_id = $ownerid ORDER BY ".$param."  ".$sorty."";
			}
		}else{
			
			$nqry=$basicq." where b.owner_id = $ownerid  ORDER BY entry_date DESC";
		}
		//echo $nqry; exit;
		if(isset($_POST['searchbtn'])){
			$searchterm = $this->input->post('searchterm');
			$nqry=$basicq." where b.owner_id = $ownerid AND
			(party_name LIKE '%$searchterm%' OR  email LIKE '%$searchterm%'  
			OR  cn_name LIKE '%$searchterm%'  
			OR  user_name LIKE '%$searchterm%'  
			OR  user_lname LIKE '%$searchterm%' )  ";
		}
		$nquery = $this->db->query($nqry);
		$logs = $nquery->result();
		
		
		
		
		
		
		
		$m='';
		if(count($logs)>0){
			$v=0;
			foreach($logs as $ad){
				$v++;
				$d= $ad->insert_by;
				$ins = $this->User_M->get($d, TRUE);
				$c_id=  $ad->condo_id;
				$cnd = $this->Condo_M->get($c_id, TRUE);
				
				
				
				$stbtn ='';
				if($ad->status=='P'){
					$stbtn ='<p style="color:#ff0000;" >Pending</p>';
				}elseif($ad->status=='A'){
					$stbtn ='<p style="color:#69c2fe;" >Active</p>';
				}
				if($ad->party_thumb!=''){
					$imglnkz= '
					<a class="image-popup-vertical-fit" href="'.base_url('uploads/visiter/'.$ad->party_thumb).'" >
					<img width="70" src="'.base_url('uploads/visiter/'.$ad->party_thumb).'" />
					</a>
					';
				}else{
					$imglnkz= '';
				}
				
				
				$pocdtl = $this->User_M->get($ad->poc_id,true);
				
				
				
				$m = $m. '
                <tr>
                   
                    <td> '.$ad->tran_id.' </td>
                    <td>'.$cnd->cn_name.'</td>
                    <td>'.$imglnkz.'</td>
                    <td><a href="mailto:'.$ad->email.'" >'.$ad->party_name.' '.$ad->party_lname.'</a> | '.preg_replace("/^(\d{3})(\d{3})(\d{4})$/", "$1-$2-$3", $ad->phone).'</td>
					<td>'.date('M d Y',strtotime($ad->book_st_dt)).' to '.date('M d Y',strtotime($ad->book_end_dt)).'</td>
					<td> <a href="mailto:'.$pocdtl->user_email.' ">'.$pocdtl->user_name.' '.$pocdtl->user_mname.' '.$pocdtl->user_lname.'</a> | '.preg_replace("/^(\d{3})(\d{3})(\d{4})$/", "$1-$2-$3", $pocdtl->phone).'</td>
                    <td>'.$stbtn.'</td>
                    
                </tr>
				';
				
			}
		}
		
		
		
		$this->data['alldf']=$m;		
		
		
		$this->data['sub_view']='admin/subview/bookinglist';
		$this->load->view('admin/_layout',$this->data);
	}
	
	public function addbooking()  
	{
		if($this->session->userdata('user_typ')=='Owner'){
			$ownerid = $this->session->userdata('user_id');
		}else{
			$ownerid = $this->session->userdata('owner_id');
		}
		
		if($_POST)
		{
			
			$flname= md5(date("YmdHis")) ;
			$uploadimage = $this->do_upload('thumb', 'uploads/visiter/', 300, 300, $flname);
			
			$allpost= $_POST;
			$allpost['uploadimage'] = $uploadimage;
			//print_result($allpost); exit;
			$this->session->set_userdata('allpost', $allpost);
			redirect(base_url("admin/tnc/"));
		}
		
		if(isset($_POST['old']))/// paused this func...
		{
		//if($_POST['old'])  /// paused this func...
		//{
			$rules['condo_id']= array('field'=>'condo_id','label'=>'Condo', 'rules'=>'trim|required');
			$rules['book_st_dt']= array('field'=>'book_st_dt','label'=>'Start Date', 'rules'=>'trim|required');
			$rules['book_end_dt']= array('field'=>'book_end_dt','label'=>'End Date', 'rules'=>'trim|required');
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				$flname= md5(date("YmdHis")) ;
				$uploadimage = $this->do_upload('thumb', 'uploads/visiter/', 300, 300, $flname);
				
				
				
				$stdt = $this->input->post('book_st_dt');
					$parts = explode('/',$stdt);
					$stdt = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
				
				$enddt = $this->input->post('book_end_dt');
					$partsn = explode('/',$enddt);
					$enddt = $partsn[2] . '-' . $partsn[0] . '-' . $partsn[1];
				
				
				$data['condo_id']=$this->input->post('condo_id');
				$data['book_st_dt']= $stdt;
				$data['book_end_dt']= $enddt;
				
				$data['party_name']=$this->input->post('party_name');
				$data['party_thumb']= $uploadimage;
				$data['email']=$this->input->post('email');
				$data['phone']=$this->input->post('phone');
				$data['description']=$this->input->post('description');
				
				
				$data['insert_by']=$this->session->userdata('user_id');
				$data['owner_id']=$ownerid;
				$data['poc_id']=$this->input->post('poc_id');
				
				
				
				
				
				$r=$this->Book_M->save($data);
				if($r){
					$smsg= "Booking Created Successfully";
					$typ='success';
				}else{
					$smsg= "Error Occurs While Creating Booking";
					$typ='error';
				}
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("admin/bookinglist/"));
		}
		

		$logs=  $this->Condo_M->get_by(array('status'=>'A', 'user_id'=>$ownerid));
		$m='';
		if(count($logs)>0){
			foreach($logs as $ad){
				$m = $m. '<option value="'.$ad->cn_id.'">'.$ad->cn_name.'</option> ';
			}
		}
		$this->data['allselect']=$m;
		
		if($this->session->userdata('user_typ')=='Owner'){
			$ownerid = $this->session->userdata('user_id');
			$mngrs = $this->User_M->get_by(array('owner_id'=>$ownerid));
			
			$mn='';
			if(count($mngrs)>0){
				foreach($mngrs as $as){
					$mn = $mn. '<option value="'.$as->user_id.'">'.$as->user_name.' '.$as->user_mname.' '.$as->user_lname.'</option> ';
				}
			}
			$this->data['allmngr']=$mn;
			
			
			
		}else{
			$this->data['allmngr']="";
		}
		
		
		
		
		
		
		$this->data['sub_view']='admin/subview/addbooking';
		$this->load->view('admin/_layout',$this->data);
	}
	
	public function tnc()  
	{
		if(isset($_POST['continue']))
		{
			redirect(base_url("admin/card/"));
		}elseif(isset($_POST['decline'])){
			redirect(base_url("admin/dashboard/"));			
		}
		
		$this->data['sub_view']='admin/subview/tnc';
		$this->load->view('admin/_layout',$this->data);
	}
	
	public function card()  
	{
		$vv = $this->session->userdata('allpost');
		
		//print_result($vv); exit;
		
		
		
		
		
		
		if($vv){
		}else{
			redirect(base_url("admin/addbooking/"));
		}
		
		if($this->session->userdata('user_typ')=='Owner'){
			$ownerid = $this->session->userdata('user_id');
		}else{
			$ownerid = $this->session->userdata('owner_id');
		}
		if($_POST) 
		{
			
			//$data['city']=$this->input->post('city');
			$price=  $this->input->post('amount');
			$card_number= $this->input->post('card_no');
			$card_name= $this->input->post('card_holder');
			$expirationDate=$this->input->post('exp_month').'/'.$this->input->post('exp_year'); 
			$cvv=$this->input->post('cvv');
			
			
			//exit;
			
			
			$datam = $this->braintree_lib->do_cc_pay($price, $card_number, $card_name, $expirationDate, $cvv);
			//print_result($data);
						
			if ($datam->success)
			{
				$tid = $datam->transaction->id;
				$vv = $this->session->userdata('allpost');
				$stdt = $vv['book_st_dt'];
					$parts = explode('/',$stdt);
					$stdt = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
				
				$enddt = $vv['book_end_dt'];
					$partsn = explode('/',$enddt);
					$enddt = $partsn[2] . '-' . $partsn[0] . '-' . $partsn[1];
				
				
				$data['condo_id']=  $vv['condo_id'];
				$data['book_st_dt']= $stdt;
				$data['book_end_dt']= $enddt;
				
				$data['party_name']=    $vv['party_name'];
				$data['party_lname']=    $vv['party_lname'];
				$data['party_thumb']= 	$vv['uploadimage'];
				$data['email']=   $vv['email'];
				$data['phone']=   $vv['phone'];
				$data['description']=   $vv['description'];
				$data['tran_id']=   $tid;
				
				if(isset($vv['isparking']) && $vv['isparking']=='yes'){
					$data['tran_message'] = 30;
				}else{
					$data['tran_message'] = 15;
				}
				
				
				$data['insert_by']=$this->session->userdata('user_id');
				$data['owner_id']=$ownerid;
				$data['poc_id']=  $vv['poc_id'];
				
				
				$r=$this->Book_M->save($data);
				if($r){
					
					
					///EMAIL PACK START
						$sender_email="no-reply@condoapp.com";
						$sender_nm="Condo APP";
						$receiver_eml=array('mntnayak@yahoo.co.in','andres@creativomiami.com');
						$subjects="New user created";
						$msg = 'Hi Condo Association,<br><br>
								A new booking is waiting for your approval, <br><br>
								
								Party name: '.$vv['party_name'].' '.$vv['party_lname'].' <br>
								Party email: '.$vv['email'].' <br>
								Party phone: '.$vv['phone'].' <br>
								Start Date: '.$vv['book_st_dt'].' <br>
								End Date: '.$vv['book_end_dt'].' <br>
								
								
								<br>
								From, <br>Condo App';
						$vv = $this->sendemail($sender_email, $sender_nm, $receiver_eml, $subjects, $msg );
						if(isset($vv['isparking']) && $vv['isparking']=='yes'){
							$receiver_emlz=array('mntnayak@yahoo.co.in','andres@creativomiami.com');
							$subjectsz="Alert For Parking Dept";
							$msgz = 'Hi Parking Team,<br><br>
								A new booking has been processed with parking, <br><br>
								
								Party name: '.$vv['party_name'].' '.$vv['party_lname'].' <br>
								Party email: '.$vv['email'].' <br>
								Party phone: '.$vv['phone'].' <br>
								Start Date: '.$vv['book_st_dt'].' <br>
								End Date: '.$vv['book_end_dt'].' <br>
								
								
								<br>
								From, <br>Condo App';
						$vv = $this->sendemail($sender_email, $sender_nm, $receiver_emlz, $subjectsz, $msgz );

						}						
						////EMAIL PACK END
					
					
					
					
					
					
					
					
					$smsg= "Booking Created Successfully";
					$typ='success';
				}else{
					$smsg= "Error Occurs While Creating Booking";
					$typ='error';
				}
			}else{
				$smsg= $datam->message;
				$typ='error';
			}
			
			$this->session->set_userdata('tran_typ', $typ);
			$this->session->set_userdata('tran_msg', $smsg);
			redirect(base_url("admin/booksuccess/"));
		}
		
		if(isset($vv['isparking']) && $vv['isparking']=='yes'){
			$this->data['topay']=  25;
		}else{
			$this->data['topay']=  15;
		}
		
		$this->data['sub_view']='admin/subview/card';
		$this->load->view('admin/_layout',$this->data);
	}
	public function booksuccess()  
	{
		$tran_typ = $this->session->userdata('tran_typ');
		if($tran_typ){
		}else{
			redirect(base_url("admin/card/"));
		}
		
		$this->data['tran_typ']=$tran_typ;
		$this->data['tran_msg']=$this->session->userdata('tran_msg');
		
		
		$this->data['sub_view']='admin/subview/booksuccess';
		$this->load->view('admin/_layout',$this->data);
	}
	
	public function editbooking($pageid)  
	{
		if($_POST)
		{
			$rules['email']= array('field'=>'email','label'=>'Email', 'rules'=>'trim|required');

			
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				$data['party_name']=$this->input->post('party_name');
				$data['email']=$this->input->post('email');
				$data['phone']=$this->input->post('phone');
				$data['address']=$this->input->post('address');
				$data['city']=$this->input->post('city');
				$data['state']=$this->input->post('state');
				$data['country']=$this->input->post('country');
				$data['zip']=$this->input->post('zip');
				
				
				$r=$this->Book_M->save($data,$pageid);
				if($r){
					$smsg= "Booking Updated Successfully";
					$typ='success';
				}else{
					$smsg= "Error Occurs While Updating Booking";
					$typ='error';
				}
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("admin/bookinglist/"));
		}
				
		$this->data['dbook']=$this->Book_M->get($pageid, TRUE);
		
		$dbook=$this->Book_M->get($pageid, TRUE);
		
		$c_id=  $dbook->condo_id;
		$cnd = $this->Condo_M->get($c_id, TRUE);
		$this->data['condonm']=$cnd->cn_name;
		
		
		
		$this->data['sub_view']='admin/subview/editbooking';
		$this->load->view('admin/_layout',$this->data);
	}
	
	
	

	
	
	public function logout()
	{
		$this->session->sess_destroy();
		redirect(base_url('admin/login'),'refresh');
	}
	
	
	public function dashboard($typ=NULL, $param = NULL, $sorty='DESC')
	{
		//////////////////////////////////////////////////
		if($this->session->userdata('user_typ')=='Owner'){
			$ownerid = $this->session->userdata('user_id');
		}else{
			$ownerid = $this->session->userdata('owner_id');
		}
		
		
		$basicq = "SELECT b.*, cn_name, user_name, user_mname, user_lname 
		FROM `booking_mst` b 
		left join condo_mst c on b.condo_id = c.cn_id 
		left join user_mst u on b.insert_by = u.user_id ";
		if($typ){
			if($typ=='ALL'){
				$nqry= $basicq." where b.owner_id = $ownerid ORDER BY b.entry_date DESC LIMIT 0,10";
				
			}elseif($typ=='PENDING'){
				$nqry=$basicq." where b.owner_id = $ownerid AND  b.status ='P' ORDER BY b.entry_date DESC LIMIT 0,10";
			}elseif($typ=='APPROVED'){
				$nqry=$basicq." where b.owner_id = $ownerid AND  b.status ='A' ORDER BY b.entry_date DESC LIMIT 0,10";
			
			}elseif($typ=='SORTY'){
				$nqry=$basicq." where b.owner_id = $ownerid ORDER BY ".$param."  ".$sorty."";
			}
		}else{
			
			$nqry=$basicq." where b.owner_id = $ownerid  ORDER BY entry_date DESC LIMIT 0,10";
		}
		//echo $nqry; exit;
		if(isset($_POST['searchbtn'])){
			$searchterm = $this->input->post('searchterm');
			$nqry=$basicq." where b.owner_id = $ownerid AND 
			( party_name LIKE '%$searchterm%' OR  email LIKE '%$searchterm%'  
			OR  cn_name LIKE '%$searchterm%'  
			OR  user_name LIKE '%$searchterm%'  
			OR  user_lname LIKE '%$searchterm%'  ) ";
		}
		$nquery = $this->db->query($nqry);
		$logs = $nquery->result();
		
		
		
		
		
		
		
		
		
		$m='';
		if(count($logs)>0){
			$v=0;
			foreach($logs as $ad){
				$v++;
				$d= $ad->insert_by;
				$ins = $this->User_M->get($d, TRUE);
				$c_id=  $ad->condo_id;
				$cnd = $this->Condo_M->get($c_id, TRUE);
				
				
				
				$stbtn ='';
				if($ad->status=='P'){
					$stbtn ='<p style="color:#ff0000;" >Pending</p>';
				}elseif($ad->status=='A'){
					$stbtn ='<p style="color:#69c2fe;" >Active</p>';
				}
				if($ad->party_thumb!=''){
					$imglnkz= '
					<a class="image-popup-vertical-fit" href="'.base_url('uploads/visiter/'.$ad->party_thumb).'" >
					<img width="70" src="'.base_url('uploads/visiter/'.$ad->party_thumb).'" />
					</a>
					';
				}else{
					$imglnkz= '';
				}
				$pocdtl = $this->User_M->get($ad->poc_id,true);
				$m = $m. '
                <tr>
                   
                    <td> '.$ad->tran_id.' </td>
                    <td>'.$cnd->cn_name.'</td>
                    <td>'.$imglnkz.'</td>
                    <td><a href="mailto:'.$ad->email.'" >'.$ad->party_name.' '.$ad->party_lname.'</a> | '.preg_replace("/^(\d{3})(\d{3})(\d{4})$/", "$1-$2-$3", $ad->phone).'</td>
					<td>'.date('M d Y',strtotime($ad->book_st_dt)).' to '.date('M d Y',strtotime($ad->book_end_dt)).'</td>
					<td> <a href="mailto:'.$pocdtl->user_email.' ">'.$pocdtl->user_name.' '.$pocdtl->user_mname.' '.$pocdtl->user_lname.'</a> | '.preg_replace("/^(\d{3})(\d{3})(\d{4})$/", "$1-$2-$3", $pocdtl->phone).'</td>
                    <td>'.$stbtn.'</td>
                </tr>
				';
				
			}
		}
		
		$this->data['alldf']=$m;
		
		
		
		
		
		
		
		//////////////////////////////////////////////////////
		
		
		
		
		
		
		
		
		$myid = $this->session->userdata('user_id');
		$myinfo = $this->User_M->get($myid, TRUE);
		//$this->data['myinfo']=  $myinfo;
		
		if($this->session->userdata('user_typ')=='Owner'){
			$ownerid = $this->session->userdata('user_id');
			
			$this->data['managers'] = $this->User_M->get_by(array('owner_id'=>$myid));
			
		}else{
			$ownerid = $this->session->userdata('owner_id');
		}
		$allcondo=  $this->Condo_M->get_by(array('user_id'=>$ownerid));
		$this->data['num_condo']=count($allcondo);
		
		$pbook=  $this->Book_M->get_by(array('status'=>'P', 'insert_by'=>$ownerid));
		$this->data['num_pendingbook']=count($pbook);
		
		
		
		if(isset($_POST['editprofile']))
		{
			
			
			$rules['phone']= array('field'=>'phone','label'=>'Phone', 'rules'=>'trim|required');
			$rules['address']= array('field'=>'address','label'=>'Address', 'rules'=>'trim|required');
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				
				$data['user_name']=$this->input->post('user_name');
				$data['user_mname']=$this->input->post('user_mname');
				$data['user_lname']=$this->input->post('user_lname');
				
				$data['phone']=$this->input->post('phone');
				$data['address']=$this->input->post('address');
				
				$data['city']=$this->input->post('city');
				$data['state']=$this->input->post('state');
				$data['country']=$this->input->post('country');
				$data['zip']=$this->input->post('zip');
				
				//print_result($data); exit;
				
				$r=$this->User_M->save($data, $myid);
				if($r){
					$smsg= "Profile Information Changed Successfully";
					$typ='success';
				}else{
					$smsg= "Error Occurs While Changing Profile Information";
					$typ='error';
				}
					
					
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("admin/dashboard/"));
		}
		
		
		
		
		
		
		
		
		if(isset($_POST['changepassword']))
		{
			$rules['oldp']= array('field'=>'oldp','label'=>'Old Password', 'rules'=>'trim|required');
			$rules['newp']= array('field'=>'newp','label'=>'New Password', 'rules'=>'trim|required');
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				$oldp = $this->input->post('oldp');
				$newp = $this->input->post('newp');
				$repeatp = $this->input->post('repeatp');
				
				
				
				if($myinfo->user_password==$oldp ){
					if($newp==$repeatp){
						$data['user_password']=$newp;
						
						$r=$this->User_M->save($data, $myid);
						if($r){
							$smsg= "Password Changed Successfully";
							$typ='success';
						}else{
							$smsg= "Error Occurs While Changing Password";
							$typ='error';
						}
					}else{
						$smsg= "Password Mismatches";
						$typ='error';
					}
				}else{
					$smsg= "Provide proper Old Password";
					$typ='error';
				}
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("admin/dashboard/"));
		}
		
		if(isset($_POST['profpic']))
		{

				$flname= md5(date("YmdHis")) ;
				$uploadimage = $this->do_upload('thumb', 'nassets/img/profpic/', 300, 300, $flname);
				
				
				$data['thumbnail']=$uploadimage;
				
				$r=$this->User_M->save($data, $myid);
				
				if($r){
					$smsg= "Picture Uploaded Successfully";
					$typ='success';
				}else{
					$smsg= "Error Occurs While Uploading Picture";
					$typ='error';
				}
			
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("admin/dashboard/"));
		}
		
		if(isset($_POST['approval']))
		{
				$user_id=  $this->input->post('user_id');
				$data['status']='A';
				$r=$this->User_M->save($data, $user_id);
				
				if($r){
					$smsg= "Manager Approved Successfully";
					$typ='success';
				}else{
					$smsg= "Error Occurs While Approving Manager";
					$typ='error';
				}
			
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("admin/dashboard/"));
		}
		



		
		
		if($myinfo->status=='I'){
			$this->data['sub_view']='admin/subview/homenull';
			$this->load->view('admin/_layout',$this->data);
		}else{
			$this->data['sub_view']='admin/subview/home';
			$this->load->view('admin/_layout',$this->data);
		}
		
		
	}
	
		
  function do_upload($fieldname = 'profimg', $directory='uploads/userpics/', $width=600, $height =300, $filename=NULL) {
    
	if($filename==NULL){
		$filename= md5(date("YmdHis")) ;
	}
		
	
    $this->my_upload->upload($_FILES[$fieldname]);
    if ( $this->my_upload->uploaded == true  ) {
      //$this->my_upload->allowed         = array('image/*');
      $this->my_upload->file_new_name_body    = $filename;
      $this->my_upload->image_resize          = true;
      $this->my_upload->image_ratio_crop          = true;
	  
      $this->my_upload->image_x               = $width;
      $this->my_upload->image_y         = $height;
	  
      $this->my_upload->process($directory);
      if ( $this->my_upload->processed == true ) {
         $output = $this->my_upload->file_dst_name;
		 
      } else {
        $output = NULL;
      }
    } else  {
      $output = NULL;
    }
	return $output; 
  } 

  
	public function sendemail($sender_email=NULL, $sender_nm=NULL, $receiver_eml=NULL, $subjects=NULL, $msg = NULL )
	{
		////email sending process...
		$config['mailtype'] = 'html';
		$config['wordwrap'] = TRUE;
		$this->email->initialize($config);
		
		if($sender_email!=NULL){
			$this->email->from($sender_email, $sender_nm);
		}else{
			$this->email->from('no-reply@grandcondominium.com', 'Condo App');
		}
		
		if($receiver_eml!=NULL){
			$rcv = $receiver_eml; //array we are expecting
		}else{
			$rcv = array('andres.corazza@gmail.com');
		}
						
		if($subjects==NULL){
			$subjects = "Test Email";
		}			
		if($msg==NULL){
			$msg = 'Hi there,<br><br>
				A new email is sent to you an test, <br><br>
				Date: Data Calue <br>
				<br>
				Thanks, <br>SAMPL Team';
		}				
						
						$this->email->to($rcv); 
						$this->email->subject($subjects);
						$this->email->message($msg);	


						$this->email->send();
						/////EMAIL SEND COMPLETE
	}
	
	
	
	
	
	
	
}
