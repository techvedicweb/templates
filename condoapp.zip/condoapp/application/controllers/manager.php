<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Manager extends Admin_Controller 
{
	function __construct() 
	{
		parent::__construct();
		$this->load->model('Condo_M');
		$this->load->model('Book_M');
		$this->load->model('User_M');
		$this->load->model('Mngrcondo_M');
		
		$this->load->library("braintree_lib");
		
		$this->load->library('my_upload');
		$this->load->library("pagination");
		
		$myid = $this->session->userdata('user_id');
		$myinfo = $this->User_M->get($myid, TRUE);
		$this->data['myinfo']=  $myinfo;
		if($myinfo->thumbnail==''){
			$this->data['mypic']=  base_url('nassets/img/avatar-mini.jpg');
		}else{
			$this->data['mypic']= base_url('nassets/img/profpic').'/'.$myinfo->thumbnail;
		}
		
		$bb = array("dashboard", "logout" , "login");
		if (!in_array($this->uri->segment(2), $bb) && $myinfo->status=='I' ){
			redirect(base_url("manager/dashboard"));
		}
		
		
		

	}
	
	
	public function index()
	{
		redirect(base_url("admin/login"), "refresh");
	}
	

	
	
	public function editprofile()
	{
	
		$myid = $this->session->userdata('user_id');
		$myinfo = $this->User_M->get($myid, TRUE);
		if(isset($_POST['editprofile']))
		{
			$rules['phone']= array('field'=>'phone','label'=>'Phone', 'rules'=>'trim|required');
			$rules['address']= array('field'=>'address','label'=>'Address', 'rules'=>'trim|required');
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				
				$data['user_name']=$this->input->post('user_name');
				$data['user_mname']=$this->input->post('user_mname');
				$data['user_lname']=$this->input->post('user_lname');
				
				$data['phone']=$this->input->post('phone');
				$data['address']=$this->input->post('address');
				
				$data['city']=$this->input->post('city');
				$data['state']=$this->input->post('state');
				$data['country']=$this->input->post('country');
				$data['zip']=$this->input->post('zip');
				
				//print_result($data); exit;
				
				$r=$this->User_M->save($data, $myid);
				if($r){
					$smsg= "Profile Information Changed Successfully";
					$typ='success';
				}else{
					$smsg= "Error Occurs While Changing Profile Information";
					$typ='error';
				}
					
					
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("manager/editprofile/"));
		}
		
	
		$this->data['sub_view']='admin/subview/editprofile';
		$this->load->view('admin/_layout',$this->data);
	}
	
	public function changepass()
	{
	
		$myid = $this->session->userdata('user_id');
		$myinfo = $this->User_M->get($myid, TRUE);
		if(isset($_POST['changepassword']))
		{
			$rules['oldp']= array('field'=>'oldp','label'=>'Old Password', 'rules'=>'trim|required');
			$rules['newp']= array('field'=>'newp','label'=>'New Password', 'rules'=>'trim|required');
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				$oldp = $this->input->post('oldp');
				$newp = $this->input->post('newp');
				$repeatp = $this->input->post('repeatp');
				
				
				
				if($myinfo->user_password==$oldp ){
					if($newp==$repeatp){
						$data['user_password']=$newp;
						
						$r=$this->User_M->save($data, $myid);
						if($r){
							$smsg= "Password Changed Successfully";
							$typ='success';
						}else{
							$smsg= "Error Occurs While Changing Password";
							$typ='error';
						}
					}else{
						$smsg= "Password Mismatches";
						$typ='error';
					}
				}else{
					$smsg= "Provide proper Old Password";
					$typ='error';
				}
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url().$this->uri->segment(1).'/changepass');
		}
		
	
	
	
		$this->data['sub_view']='admin/subview/changepass';
		$this->load->view('admin/_layout',$this->data);
	}
	
	
	
	
	
	
	
	
	
	
	public function dashboard($typ=NULL, $param = NULL, $sorty='DESC')
	{
		//////////////////////////////////////////////////
		$ownerid = $this->session->userdata('user_id');
		
		/*
		if($typ){
			if($typ=='ALL'){
				$this->db->limit(10, 0);
				$logs=  $this->Book_M->get_by(array('insert_by'=>$ownerid));
			}elseif($typ=='PENDING'){
				$this->db->limit(10, 0);
				$logs=  $this->Book_M->get_by(array('status'=>'P', 'insert_by'=>$ownerid));
			}elseif($typ=='APPROVED'){
				$this->db->limit(10, 0);
				$logs=  $this->Book_M->get_by(array('status'=>'A', 'insert_by'=>$ownerid));
			}
		}else{
			$this->db->limit(10, 0);
			$logs=  $this->Book_M->get_by(array('insert_by'=>$ownerid),FALSE,FALSE, 'entry_date', 'DESC');
		}*/
		
		
		$basicq = "SELECT b.*, cn_name, user_name, user_mname, user_lname 
		FROM `booking_mst` b 
		left join condo_mst c on b.condo_id = c.cn_id 
		left join user_mst u on b.insert_by = u.user_id ";
		if($typ){
			if($typ=='ALL'){
				$nqry= $basicq." where b.insert_by = $ownerid ORDER BY b.entry_date DESC LIMIT 0,10";
				
			}elseif($typ=='PENDING'){
				$nqry=$basicq." where b.insert_by = $ownerid AND  b.status ='P' ORDER BY b.entry_date DESC LIMIT 0,10";
			}elseif($typ=='APPROVED'){
				$nqry=$basicq." where b.insert_by = $ownerid AND  b.status ='A' ORDER BY b.entry_date DESC LIMIT 0,10";
			
			}elseif($typ=='SORTY'){
				$nqry=$basicq." where b.insert_by = $ownerid ORDER BY ".$param."  ".$sorty."";
			}
		}else{
			
			$nqry=$basicq." where b.insert_by = $ownerid  ORDER BY entry_date DESC LIMIT 0,10";
		}
		//echo $nqry; exit;
		if(isset($_POST['searchbtn'])){
			$searchterm = $this->input->post('searchterm');
			$nqry=$basicq." where b.insert_by = $ownerid 
			AND (party_name LIKE '%$searchterm%' OR  email LIKE '%$searchterm%'  
			OR  cn_name LIKE '%$searchterm%'  
			OR  user_name LIKE '%$searchterm%'  
			OR  user_lname LIKE '%$searchterm%' )  ";
		}
		$nquery = $this->db->query($nqry);
		$logs = $nquery->result();
		
		
		
		
		
		
		
		$m='';
		if(count($logs)>0){
			$v=0;
			foreach($logs as $ad){
				$v++;
				$d= $ad->insert_by;
				$ins = $this->User_M->get($d, TRUE);
				$c_id=  $ad->condo_id;
				$cnd = $this->Condo_M->get($c_id, TRUE);
				
				
				
				$stbtn ='';
				if($ad->status=='P'){
					$stbtn ='<p style="color:#ff0000;" >Pending</p>';
				}elseif($ad->status=='A'){
					$stbtn ='<p style="color:#69c2fe;" >Active</p>';
				}
				if($ad->party_thumb!=''){
					$imglnkz= '
					<a class="image-popup-vertical-fit" href="'.base_url('uploads/visiter/'.$ad->party_thumb).'" >
					<img width="70" src="'.base_url('uploads/visiter/'.$ad->party_thumb).'" />
					</a>
					';
				}else{
					$imglnkz= '';
				}
				$pocdtl = $this->User_M->get($ad->poc_id,true);
				
				
				
				
				$m = $m. '
                <tr>
                   
                    <td> '.$ad->tran_id.' </td>
                    <td>'.$cnd->cn_name.'</td>
                    <td>'.$imglnkz.'</td>
                    <td><a href="mailto:'.$ad->email.'" >'.$ad->party_name.' '.$ad->party_lname.'</a> | '.preg_replace("/^(\d{3})(\d{3})(\d{4})$/", "$1-$2-$3", $ad->phone).'</td>
					<td>'.date('M d Y',strtotime($ad->book_st_dt)).' to '.date('M d Y',strtotime($ad->book_end_dt)).'</td>
					<td> <a href="mailto:'.$pocdtl->user_email.' ">'.$pocdtl->user_name.' '.$pocdtl->user_mname.' '.$pocdtl->user_lname.'</a> | '.preg_replace("/^(\d{3})(\d{3})(\d{4})$/", "$1-$2-$3", $pocdtl->phone).'</td>
                    <td>'.$stbtn.'</td>
                    
                </tr>
				';
				
			}
		}
		
		$this->data['alldf']=$m;
		
		
		//////////////////////////////////////////////////////
		
		
		
		
		
		
		
		
		$myid = $this->session->userdata('user_id');
		$myinfo = $this->User_M->get($myid, TRUE);
		//$this->data['myinfo']=  $myinfo;
		
		if($this->session->userdata('user_typ')=='Owner'){
			$ownerid = $this->session->userdata('user_id');
			
			$this->data['managers'] = $this->User_M->get_by(array('owner_id'=>$myid));
			
		}else{
			$ownerid = $this->session->userdata('owner_id');
		}
		$allcondo=  $this->Condo_M->get_by(array('user_id'=>$ownerid));
		$this->data['num_condo']=count($allcondo);
		
		$pbook=  $this->Book_M->get_by(array('status'=>'P', 'insert_by'=>$ownerid));
		$this->data['num_pendingbook']=count($pbook);
		
		
		
		if(isset($_POST['editprofile']))
		{
			
			
			$rules['phone']= array('field'=>'phone','label'=>'Phone', 'rules'=>'trim|required');
			$rules['address']= array('field'=>'address','label'=>'Address', 'rules'=>'trim|required');
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				
				$data['user_name']=$this->input->post('user_name');
				$data['user_mname']=$this->input->post('user_mname');
				$data['user_lname']=$this->input->post('user_lname');
				
				$data['phone']=$this->input->post('phone');
				$data['address']=$this->input->post('address');
				
				$data['city']=$this->input->post('city');
				$data['state']=$this->input->post('state');
				$data['country']=$this->input->post('country');
				$data['zip']=$this->input->post('zip');
				
				//print_result($data); exit;
				
				$r=$this->User_M->save($data, $myid);
				if($r){
					$smsg= "Profile Information Changed Successfully";
					$typ='success';
				}else{
					$smsg= "Error Occurs While Changing Profile Information";
					$typ='error';
				}
					
					
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("manager/dashboard/"));
		}
		
		
		
		
		
		
		
		
		if(isset($_POST['changepassword']))
		{
			$rules['oldp']= array('field'=>'oldp','label'=>'Old Password', 'rules'=>'trim|required');
			$rules['newp']= array('field'=>'newp','label'=>'New Password', 'rules'=>'trim|required');
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				$oldp = $this->input->post('oldp');
				$newp = $this->input->post('newp');
				$repeatp = $this->input->post('repeatp');
				
				
				
				if($myinfo->user_password==$oldp ){
					if($newp==$repeatp){
						$data['user_password']=$newp;
						
						$r=$this->User_M->save($data, $myid);
						if($r){
							$smsg= "Password Changed Successfully";
							$typ='success';
						}else{
							$smsg= "Error Occurs While Changing Password";
							$typ='error';
						}
					}else{
						$smsg= "Password Mismatches";
						$typ='error';
					}
				}else{
					$smsg= "Provide proper Old Password";
					$typ='error';
				}
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("manager/dashboard/"));
		}
		
		if(isset($_POST['profpic']))
		{

				$flname= md5(date("YmdHis")) ;
				$uploadimage = $this->do_upload('thumb', 'nassets/img/profpic/', 300, 300, $flname);
				
				
				$data['thumbnail']=$uploadimage;
				
				$r=$this->User_M->save($data, $myid);
				
				if($r){
					$smsg= "Picture Uploaded Successfully";
					$typ='success';
				}else{
					$smsg= "Error Occurs While Uploading Picture";
					$typ='error';
				}
			
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("admin/dashboard/"));
		}
		
		if(isset($_POST['approval']))
		{
				$user_id=  $this->input->post('user_id');
				$data['status']='A';
				$r=$this->User_M->save($data, $user_id);
				
				if($r){
					$smsg= "Manager Approved Successfully";
					$typ='success';
				}else{
					$smsg= "Error Occurs While Approving Manager";
					$typ='error';
				}
			
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("admin/dashboard/"));
		}
		



		
		
		if($myinfo->status=='I'){
			$this->data['sub_view']='admin/subview/homenull';
			$this->load->view('admin/_layout',$this->data);
		}else{
			$this->data['sub_view']='admin/subview/home';
			$this->load->view('admin/_layout',$this->data);
		}
		
		
	}
	
	public function condolist($typ=NULL)   
	{
		$ownerid = $this->session->userdata('user_id');
		if($_POST)
		{
			$rules['cn_name']= array('field'=>'cn_name','label'=>'Condo Name', 'rules'=>'trim|required');
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				$cnm = $this->input->post('cn_name');
				$isc = $this->Condo_M->get_by(array('cn_name'=>$cnm),TRUE);
				$imsc = $this->Mngrcondo_M->get_by(array('cn_name'=>$cnm));
				if(count($imsc)>0){
					$smsg= "Sorry, a condo with same number already exits in our database";
					$typ='error';
				}else{
					if(count($isc)>0){
						//Condo is already present   ( Condo Will Be added to  Mngrcondo_M)
						$owneridz = $isc->user_id;
						
						$own_nm_eml = $this->input->post('owner_id');
						$dmd = explode(" - ",$own_nm_eml);
						$owner_email = $dmd[1];
						$odtl =  $this->User_M->get_by(array('user_email'=>$owner_email), TRUE);
						$o_id = $odtl->user_id;
						
						
						$oidz = $o_id;
						
						if($owneridz!=$oidz){
							$smsg= "Requested condo owner record does not match";
							$typ='error';
						}else{
							$ownerinfo = $this->User_M->get($owneridz, TRUE);
							$data['cn_name']=$this->input->post('cn_name');				
							$data['user_id']=$this->session->userdata('user_id');						
							
							$data['cn_id']=$isc->cn_id;
							$data['entry_page']='condo';
							
							$data['owner_nm']=$ownerinfo->user_name.' '.$ownerinfo->user_mname.' '.$ownerinfo->user_lname;
							$data['owner_email']= $ownerinfo->user_email;
											
							$r=$this->Mngrcondo_M->save($data);
							if($r){
								$smsg= "Condo request added successfully.";
								$typ='success';
							}else{
								$smsg= "Error Occurs While Creating Condo";
								$typ='error';
							}	
						}
					}else
					{
						// manager adding this condo ( Condo Will Be added to Condo_M And Mngrcondo_M)
						
						$own_nm_eml = $this->input->post('owner_id');
						$dmd = explode(" - ",$own_nm_eml);
						$owner_email = $dmd[1];
						$odtl =  $this->User_M->get_by(array('user_email'=>$owner_email), TRUE);
						
						
						
						$owneridz = $odtl->user_id;
						$ownerinfo = $odtl;
						
						
						$data['cn_name']=$this->input->post('cn_name');				
						$data['insert_by']=$this->session->userdata('user_id');
						$data['user_id']=$owneridz;
						$r=$this->Condo_M->save($data);
						
						///////////////////
						
						$datav['cn_name']=$this->input->post('cn_name');				
						$datav['user_id']=$this->session->userdata('user_id');						
						$datav['cn_id']=$r;
						$datav['entry_page']='condo';
						$datav['owner_nm']=$ownerinfo->user_name.' '.$ownerinfo->user_mname.' '.$ownerinfo->user_lname;
						$datav['owner_email']= $ownerinfo->user_email;
						$rs=$this->Mngrcondo_M->save($datav);
						
						if($r){
							$smsg= "Condo request added successfully.";
							$typ='success';
						}else{
							$smsg= "Error Occurs While Creating Condo";
							$typ='error';
						}
						
					}
					
					
					
					
				}
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("manager/condolist/"));
		}
		if($typ){
			if($typ=='ALL'){
				$logs=  $this->Mngrcondo_M->get_by(array('user_id'=>$ownerid));
			}elseif($typ=='PENDING'){
				$logs=  $this->Mngrcondo_M->get_by(array('status'=>'P', 'user_id'=>$ownerid));
			}elseif($typ=='APPROVED'){
				$logs=  $this->Mngrcondo_M->get_by(array('status'=>'A', 'user_id'=>$ownerid));
			}
		}else{
			$logs=  $this->Mngrcondo_M->get_by(array('user_id'=>$ownerid));
		}
		$m='';
		if(count($logs)>0){
			foreach($logs as $ad){
				$d= $ad->user_id;
				$ins = $this->User_M->get($d, TRUE);
				
				$stbtn ='';
				if($ad->status=='P'){
					$stbtn ='<p class="btn btn-primary">Pending</p>';
				}elseif($ad->status=='A'){
					$stbtn ='<p class="btn btn-info">Active</p>';
				}
				
				
				$m = $m. '
                <tr>
                    <td>'.$ad->cn_name.'</td>
					<td>'.date('M d Y',strtotime($ad->insert_date)).'</td>
                    <td>'.$ins->user_name.' '.$ins->user_mname.' '.$ins->user_lname.'</td>
                    <td>'.$stbtn.'</td>
                    
                    
                </tr>
				';
				
			}
		}
		$this->data['alldf']=$m;
		$this->data['allowner']=$this->User_M->get_by(array('user_typ'=>'Owner','status'=>'A'));
		
		$this->data['sub_view']='admin/m_subview/page_list';
		$this->load->view('admin/_layout',$this->data);
	}
	

	public function autocomplete(){
        $keyword = $this->input->post('term');
        $data['response'] = 'false'; //Set default response
        $query = $this->User_M->get_by(array('user_typ'=>'Owner','status'=>'A'));
        if( ! empty($query) )
        {
            $data['response'] = 'true'; //Set response
            $data['message'] = array(); //Create array
            foreach( $query as $row )
            {
                echo $row->user_name.' '.$row->user_lname.' - '.$row->user_email."\n";
            }
        }
        
    }
		
	
	
	
	
	/////////////////////////////////////////////////////
	public function bookinglist($typ=NULL, $param = NULL, $sorty='DESC')   
	{
		
		$ownerid = $this->session->userdata('user_id');
		
		/*
		if($typ){
			if($typ=='ALL'){
				$logs=  $this->Book_M->get_by(array('insert_by'=>$ownerid));
			}elseif($typ=='PENDING'){
				$logs=  $this->Book_M->get_by(array('status'=>'P', 'insert_by'=>$ownerid),FALSE,FALSE, 'entry_date', 'DESC');
			}elseif($typ=='APPROVED'){
				$logs=  $this->Book_M->get_by(array('status'=>'A', 'insert_by'=>$ownerid),FALSE,FALSE, 'entry_date', 'DESC');
			}
		}else{
			$logs=  $this->Book_M->get_by(array('insert_by'=>$ownerid),FALSE,FALSE, 'entry_date', 'DESC');
		}
		*/
		
		$basicq = "SELECT b.*, cn_name, user_name, user_mname, user_lname 
		FROM `booking_mst` b 
		left join condo_mst c on b.condo_id = c.cn_id 
		left join user_mst u on b.insert_by = u.user_id ";
		if($typ){
			if($typ=='ALL'){
				$nqry= $basicq." where b.insert_by = $ownerid ORDER BY b.entry_date DESC ";
				
			}elseif($typ=='PENDING'){
				$nqry=$basicq." where b.insert_by = $ownerid AND  b.status ='P' ORDER BY b.entry_date DESC LIMIT ";
			}elseif($typ=='APPROVED'){
				$nqry=$basicq." where b.insert_by = $ownerid AND  b.status ='A' ORDER BY b.entry_date DESC LIMIT ";
			
			}elseif($typ=='SORTY'){
				$nqry=$basicq." where b.insert_by = $ownerid ORDER BY ".$param."  ".$sorty."";
			}
		}else{
			
			$nqry=$basicq." where b.insert_by = $ownerid  ORDER BY entry_date DESC ";
		}
		//echo $nqry; exit;
		if(isset($_POST['searchbtn'])){
			$searchterm = $this->input->post('searchterm');
			$nqry=$basicq." where b.insert_by = $ownerid 
			AND (party_name LIKE '%$searchterm%' OR  email LIKE '%$searchterm%'  
			OR  cn_name LIKE '%$searchterm%'  
			OR  user_name LIKE '%$searchterm%'  
			OR  user_lname LIKE '%$searchterm%' )  ";
		}
		$nquery = $this->db->query($nqry);
		$logs = $nquery->result();
		
		
		
		
		
		
		$m='';
		if(count($logs)>0){
			foreach($logs as $ad){
				$d= $ad->insert_by;
				$ins = $this->User_M->get($d, TRUE);
				$c_id=  $ad->condo_id;
				$cnd = $this->Condo_M->get($c_id, TRUE);
				
				
				
				$stbtn ='';
				if($ad->status=='P'){
					$stbtn ='<p style="color:#ff0000;" >Pending</p>';
				}elseif($ad->status=='A'){
					$stbtn ='<p style="color:#69c2fe;" >Active</p>';
				}
				
				if($ad->party_thumb!=''){
					$imglnkz= '
					<a class="image-popup-vertical-fit" href="'.base_url('uploads/visiter/'.$ad->party_thumb).'" >
					<img width="70" src="'.base_url('uploads/visiter/'.$ad->party_thumb).'" />
					</a>
					';
				}else{
					$imglnkz= '';
				}
				
				
				$pocdtl = $this->User_M->get($ad->poc_id,true);
				
				
				
				$m = $m. '
                <tr>
                   
                    <td> '.$ad->tran_id.'</td>
                    <td>'.$cnd->cn_name.'</td>
                    <td>'.$imglnkz.'</td>
                    <td><a href="mailto:'.$ad->email.'" >'.$ad->party_name.' '.$ad->party_lname.'</a> | '.preg_replace("/^(\d{3})(\d{3})(\d{4})$/", "$1-$2-$3", $ad->phone).'</td>
					<td>'.date('M d Y',strtotime($ad->book_st_dt)).' to '.date('M d Y',strtotime($ad->book_end_dt)).'</td>
					<td> <a href="mailto:'.$pocdtl->user_email.' ">'.$pocdtl->user_name.' '.$pocdtl->user_mname.' '.$pocdtl->user_lname.'</a> |
					'.preg_replace("/^(\d{3})(\d{3})(\d{4})$/", "$1-$2-$3", $pocdtl->phone).'</td>
                    <td>'.$stbtn.'</td>
                    
                </tr>
				';
				
			}
		}
		
		
		
		$this->data['alldf']=$m;		
		
		
		$this->data['sub_view']='admin/subview/bookinglist';
		$this->load->view('admin/_layout',$this->data);
	}
	
	public function addbooking()  
	{
		
		$ownerid = $this->session->userdata('user_id');
		if($_POST)
		{
			
			$flname= md5(date("YmdHis")) ;
			$uploadimage = $this->do_upload('thumb', 'uploads/visiter/', 300, 300, $flname);
			
			$allpost= $_POST;
			$allpost['uploadimage'] = $uploadimage;
			
			$pocid =  $this->input->post('poc_id');
			$condoid =  $this->input->post('condo_id');
			if($pocid=='owner'){
				$condodttl = $this->Condo_M->get($condoid);
				$allpost['poc_id'] = $condodttl->user_id;
			}
			
			$this->session->set_userdata('allpost', $allpost);
			redirect(base_url("manager/tnc/"));
		}
		
		
		

		$logs=  $this->Mngrcondo_M->get_by(array('status'=>'A', 'user_id'=>$ownerid));
		$m='';
		if(count($logs)>0){
			foreach($logs as $ad){
				$m = $m. '<option value="'.$ad->cn_id.'">'.$ad->cn_name.'</option> ';
			}
		}
				
		$this->data['allselect']=$m;
		
		$this->data['sub_view']='admin/m_subview/addbooking';
		$this->load->view('admin/_layout',$this->data);
	}
	
	public function tnc()  
	{
		if(isset($_POST['continue']))
		{
			redirect(base_url("manager/card/"));
		}elseif(isset($_POST['decline'])){
			redirect(base_url("manager/dashboard/"));			
		}
		
		$this->data['sub_view']='admin/subview/tnc';
		$this->load->view('admin/_layout',$this->data);
	}
	
	public function card()  
	{
		$vv = $this->session->userdata('allpost');
		
		
		
		if($vv){
		}else{
			redirect(base_url("manager/addbooking/"));
		}
		
		if($this->session->userdata('user_typ')=='Owner'){
			$ownerid = $this->session->userdata('user_id');
		}else{
			$ownerid = $this->session->userdata('owner_id');
		}
		if($_POST) 
		{
			
			//$data['city']=$this->input->post('city');
			$price= $this->input->post('amount');
			$card_number= $this->input->post('card_no');
			$card_name= $this->input->post('card_holder');
			$expirationDate=$this->input->post('exp_month').'/'.$this->input->post('exp_year'); 
			$cvv=$this->input->post('cvv');
			
			
			//exit;
			
			
			$datam = $this->braintree_lib->do_cc_pay($price, $card_number, $card_name, $expirationDate, $cvv);
			//print_result($data);
						
			if ($datam->success)
			{
				$tid = $datam->transaction->id;
				$vv = $this->session->userdata('allpost');
				$stdt = $vv['book_st_dt'];
					$parts = explode('/',$stdt);
					$stdt = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
				
				$enddt = $vv['book_end_dt'];
					$partsn = explode('/',$enddt);
					$enddt = $partsn[2] . '-' . $partsn[0] . '-' . $partsn[1];
				
				
				$data['condo_id']=  $vv['condo_id'];
				$data['book_st_dt']= $stdt;
				$data['book_end_dt']= $enddt;
				
				$data['party_name']=    $vv['party_name'];
				$data['party_lname']=    $vv['party_lname'];
				$data['party_thumb']= 	$vv['uploadimage'];
				$data['email']=   $vv['email'];
				$data['phone']=   $vv['phone'];
				$data['description']=   $vv['description'];
				$data['tran_id']=   $tid;
				
				if(isset($vv['isparking']) && $vv['isparking']=='yes'){
					$data['tran_message'] = 30;
				}else{
					$data['tran_message'] = 15;
				}
				
				
				$data['insert_by']=$this->session->userdata('user_id');
				$data['owner_id']=$ownerid;
				$data['poc_id']=  $vv['poc_id'];
				
				
				$r=$this->Book_M->save($data);
				if($r){
					$smsg= "Booking Created Successfully";
					$typ='success';
				}else{
					$smsg= "Error Occurs While Creating Booking";
					$typ='error';
				}
			}else{
				$smsg= $datam->message;
				$typ='error';
			}
			
			$this->session->set_userdata('tran_typ', $typ);
			$this->session->set_userdata('tran_msg', $smsg);
			redirect(base_url("manager/booksuccess/"));
		}
		
		if(isset($vv['isparking']) && $vv['isparking']=='yes'){
			$this->data['topay']= 30;
		}else{
			$this->data['topay']= 15;
		}
		
		
		$this->data['topay']= 0.3;     //for demo 
		
		
		
		
		$this->data['sub_view']='admin/subview/card';
		$this->load->view('admin/_layout',$this->data);
	}
	public function booksuccess()  
	{
		$tran_typ = $this->session->userdata('tran_typ');
		if($tran_typ){
		}else{
			redirect(base_url("manager/card/"));
		}
		
		$this->data['tran_typ']=$tran_typ;
		$this->data['tran_msg']=$this->session->userdata('tran_msg');
		
		
		$this->data['sub_view']='admin/subview/booksuccess';
		$this->load->view('admin/_layout',$this->data);
	}
	
	
	
	public function editbooking($pageid)  
	{
		if($_POST)
		{
			$rules['email']= array('field'=>'email','label'=>'Email', 'rules'=>'trim|required');

			
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				$data['party_name']=$this->input->post('party_name');
				$data['email']=$this->input->post('email');
				$data['phone']=$this->input->post('phone');
				$data['address']=$this->input->post('address');
				$data['city']=$this->input->post('city');
				$data['state']=$this->input->post('state');
				$data['country']=$this->input->post('country');
				$data['zip']=$this->input->post('zip');
				
				
				$r=$this->Book_M->save($data,$pageid);
				if($r){
					$smsg= "Booking Updated Successfully";
					$typ='success';
				}else{
					$smsg= "Error Occurs While Updating Booking";
					$typ='error';
				}
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("manager/bookinglist/"));
		}
				
		$this->data['dbook']=$this->Book_M->get($pageid, TRUE);
		
		$dbook=$this->Book_M->get($pageid, TRUE);
		
		$c_id=  $dbook->condo_id;
		$cnd = $this->Condo_M->get($c_id, TRUE);
		$this->data['condonm']=$cnd->cn_name;
		
		
		
		$this->data['sub_view']='admin/subview/editbooking';
		$this->load->view('admin/_layout',$this->data);
	}
	
	

	
	
	
	public function logout()
	{
		$this->session->sess_destroy();
		redirect(base_url('admin/login'),'refresh');
	}
	
  function do_upload($fieldname = 'profimg', $directory='uploads/userpics/', $width=600, $height =300, $filename=NULL) {
    
	if($filename==NULL){
		$filename= md5(date("YmdHis")) ;
	}
		
	
    $this->my_upload->upload($_FILES[$fieldname]);
    if ( $this->my_upload->uploaded == true  ) {
      //$this->my_upload->allowed         = array('image/*');
      $this->my_upload->file_new_name_body    = $filename;
      $this->my_upload->image_resize          = true;
      $this->my_upload->image_ratio_crop          = true;
	  
      $this->my_upload->image_x               = $width;
      $this->my_upload->image_y         = $height;
	  
      $this->my_upload->process($directory);
      if ( $this->my_upload->processed == true ) {
         $output = $this->my_upload->file_dst_name;
		 
      } else {
        $output = NULL;
      }
    } else  {
      $output = NULL;
    }
	return $output; 
  } 

 
}
