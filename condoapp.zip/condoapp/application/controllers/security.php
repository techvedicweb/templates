<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Security extends Admin_Controller 
{
	function __construct() 
	{
		parent::__construct();
		$this->load->model('Condo_M');
		$this->load->model('Book_M');
		$this->load->model('User_M');
		$this->load->model('Mngrcondo_M');
		
		$this->load->library('my_upload');
		$this->load->library("pagination");
		
		$myid = $this->session->userdata('user_id');
		$myinfo = $this->User_M->get($myid, TRUE);
		$this->data['myinfo']=  $myinfo;
		if($myinfo->thumbnail==''){
			$this->data['mypic']=  base_url('nassets/img/avatar-mini.jpg');
		}else{
			$this->data['mypic']= base_url('nassets/img/profpic').'/'.$myinfo->thumbnail;
		}
		
		$bb = array("dashboard", "logout" , "login");
		if (!in_array($this->uri->segment(2), $bb) && $myinfo->status=='I' ){
			redirect(base_url("sadmin/dashboard"));
		}
	}
	
	
	public function index()
	{
		redirect(base_url("admin/login"), "refresh");
	}
	public function editprofile()
	{
	
		$myid = $this->session->userdata('user_id');
		$myinfo = $this->User_M->get($myid, TRUE);
		if(isset($_POST['editprofile']))
		{
			$rules['phone']= array('field'=>'phone','label'=>'Phone', 'rules'=>'trim|required');
			$rules['address']= array('field'=>'address','label'=>'Address', 'rules'=>'trim|required');
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				
				$data['user_name']=$this->input->post('user_name');
				$data['user_mname']=$this->input->post('user_mname');
				$data['user_lname']=$this->input->post('user_lname');
				
				$data['phone']=$this->input->post('phone');
				$data['address']=$this->input->post('address');
				
				$data['city']=$this->input->post('city');
				$data['state']=$this->input->post('state');
				$data['country']=$this->input->post('country');
				$data['zip']=$this->input->post('zip');
				
				//print_result($data); exit;
				
				$r=$this->User_M->save($data, $myid);
				if($r){
					$smsg= "Profile Information Changed Successfully";
					$typ='success';
				}else{
					$smsg= "Error Occurs While Changing Profile Information";
					$typ='error';
				}
					
					
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("security/editprofile/"));
		}
		
	
		$this->data['sub_view']='admin/subview/editprofile';
		$this->load->view('admin/_layout',$this->data);
	}
	
	public function changepass()
	{
	
		$myid = $this->session->userdata('user_id');
		$myinfo = $this->User_M->get($myid, TRUE);
		if(isset($_POST['changepassword']))
		{
			$rules['oldp']= array('field'=>'oldp','label'=>'Old Password', 'rules'=>'trim|required');
			$rules['newp']= array('field'=>'newp','label'=>'New Password', 'rules'=>'trim|required');
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				$oldp = $this->input->post('oldp');
				$newp = $this->input->post('newp');
				$repeatp = $this->input->post('repeatp');
				
				
				
				if($myinfo->user_password==$oldp ){
					if($newp==$repeatp){
						$data['user_password']=$newp;
						
						$r=$this->User_M->save($data, $myid);
						if($r){
							$smsg= "Password Changed Successfully";
							$typ='success';
						}else{
							$smsg= "Error Occurs While Changing Password";
							$typ='error';
						}
					}else{
						$smsg= "Password Mismatches";
						$typ='error';
					}
				}else{
					$smsg= "Provide proper Old Password";
					$typ='error';
				}
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url().$this->uri->segment(1).'/changepass');
		}
		
	
	
	
		$this->data['sub_view']='admin/subview/changepass';
		$this->load->view('admin/_layout',$this->data);
	}
	
	
	
	
	
	
	
	
	

	public function logout()
	{
		$this->session->sess_destroy();
		redirect(base_url('admin/login'),'refresh');
	}
	
	
	public function dashboard($typ=NULL, $param = NULL, $sorty='DESC')
	{
		$myid = $this->session->userdata('user_id');
		if(isset($_POST['editprofile']))
		{
			
			
			$rules['phone']= array('field'=>'phone','label'=>'Phone', 'rules'=>'trim|required');
			$rules['address']= array('field'=>'address','label'=>'Address', 'rules'=>'trim|required');
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				
				$data['user_name']=$this->input->post('user_name');
				$data['user_mname']=$this->input->post('user_mname');
				$data['user_lname']=$this->input->post('user_lname');
				
				$data['phone']=$this->input->post('phone');
				$data['address']=$this->input->post('address');
				
				$data['city']=$this->input->post('city');
				$data['state']=$this->input->post('state');
				$data['country']=$this->input->post('country');
				$data['zip']=$this->input->post('zip');
				
				//print_result($data); exit;
				
				$r=$this->User_M->save($data, $myid);
				if($r){
					$smsg= "Profile Information Changed Successfully";
					$typ='success';
				}else{
					$smsg= "Error Occurs While Changing Profile Information";
					$typ='error';
				}
					
					
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("security/dashboard/"));
		}
		
		
		
		if(isset($_POST['changepassword']))
		{
			$rules['oldp']= array('field'=>'oldp','label'=>'Old Password', 'rules'=>'trim|required');
			$rules['newp']= array('field'=>'newp','label'=>'New Password', 'rules'=>'trim|required');
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				$oldp = $this->input->post('oldp');
				$newp = $this->input->post('newp');
				$repeatp = $this->input->post('repeatp');
				
				
				
				if($myinfo->user_password==$oldp ){
					if($newp==$repeatp){
						$data['user_password']=$newp;
						
						$r=$this->User_M->save($data, $myid);
						if($r){
							$smsg= "Password Changed Successfully";
							$typ='success';
						}else{
							$smsg= "Error Occurs While Changing Password";
							$typ='error';
						}
					}else{
						$smsg= "Password Mismatches";
						$typ='error';
					}
				}else{
					$smsg= "Provide proper Old Password";
					$typ='error';
				}
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("security/dashboard/"));
		}
		
		
		
		
		
		
		
		
		
		$basicq = "SELECT b.*, cn_name, user_name, user_mname, u.phone, user_email, user_lname 
		FROM `booking_mst` b 
		left join condo_mst c on b.condo_id = c.cn_id 
		left join user_mst u on b.insert_by = u.user_id 
		WHERE b.status = 'A' ";
		if($typ){
			if($typ=='ALL'){
				$nqry= $basicq."  ORDER BY b.entry_date DESC";
				
			}elseif($typ=='PENDING'){
				$nqry=$basicq." AND  b.status ='P' ORDER BY b.entry_date DESC";
			}elseif($typ=='APPROVED'){
				$nqry=$basicq." AND  b.status ='A' ORDER BY b.entry_date DESC";
			
			}elseif($typ=='SORTY'){
				$nqry=$basicq."  ORDER BY ".$param."  ".$sorty."";
			}
		}else{
			
			$nqry=$basicq."  ORDER BY entry_date DESC";
		}
		//echo $nqry; exit;
		if(isset($_POST['searchbtn'])){
			$searchterm = $this->input->post('searchterm');
			$nqry=$basicq." AND party_name LIKE '%$searchterm%' OR  email LIKE '%$searchterm%'  
			OR  cn_name LIKE '%$searchterm%'  
			OR  user_name LIKE '%$searchterm%'  
			OR  user_lname LIKE '%$searchterm%'   ";
		}
		
		
		$nquery = $this->db->query($nqry);
		$logs = $nquery->result();
		
		
		
		
		
		$m='';
		if(count($logs)>0){
			foreach($logs as $ad){
				$stbtn ='';
				if($ad->status=='P'){
					$stbtn ='<p style="color:#ff0000;" >Pending</p>';
				}elseif($ad->status=='A'){
					$stbtn ='<p style="color:#69c2fe;" >Active</p>';
				}
				if($ad->party_thumb!=''){
					$imglnkz= '<img width="70" src="'.base_url('uploads/visiter/'.$ad->party_thumb).'" />';
				}else{
					$imglnkz= '';
				}
				
				$m = $m. '
                <tr>
                    <td>'.$ad->cn_name.'</td>
                    <td>'.$imglnkz.'</td>
                    <td><a href="mailto:'.$ad->email.'" >'.$ad->party_name.' '.$ad->party_lname.'</a> | '.preg_replace("/^(\d{3})(\d{3})(\d{4})$/", "$1-$2-$3", $ad->phone).'</td>
                    <td>'.$ad->email.'</td>
					<td>'.date('M d Y',strtotime($ad->book_st_dt)).' to '.date('M d Y',strtotime($ad->book_end_dt)).'</td>
                    <td>'.$ad->user_name.' '. $ad->user_mname.' '. $ad->user_lname. ' | '.$ad->user_email. ' | '.preg_replace("/^(\d{3})(\d{3})(\d{4})$/", "$1-$2-$3", $ad->phone).'</td>
                    
                </tr>
				';
				
			}
		}
		
		
		
		$this->data['alldf']=$m;
		
		$this->data['sub_view']='admin/security/home';
		$this->load->view('admin/_layout',$this->data);
	}
	
}
