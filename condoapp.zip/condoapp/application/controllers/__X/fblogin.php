<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Fblogin extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('Visiter_M');
		
        $this->load->helper('url');
		$this->load->library('session');
	}
	public function index(){
		
		$ref_url = $_SERVER['HTTP_REFERER'];
		 
		$this->session->set_userdata('ref',$ref_url);
		redirect('fblogin/login');
	}
	
	
	public function login(){
		$this->load->library('facebook'); // Automatically picks appId and secret from config
		$user = $this->facebook->getUser();
        
        if ($user) {
            try {
                $vvv = $this->facebook->api('/me?fields=id,name,first_name,last_name,gender,email');

				$this->session->set_userdata('userinfoz',$vvv);
				redirect(base_url('page/datapull/'),'refresh');
				
            } catch (FacebookApiException $e) {
                $user = null;
            }
        }else {
        }


		
        if ($user) {
				$vvv = $this->facebook->api('/me?fields=id,name,first_name,last_name,gender,email');
                
				//print_result($vvv);  
				$this->session->set_userdata('userinfoz',$vvv);
				redirect(base_url('page/datapull'),'refresh');
		   
		   
        } else {
            $login_url = $this->facebook->getLoginUrl(array(
                'redirect_uri' => base_url('fblogin/login'), 
                'scope' => array("email") // permissions here
            ));
			redirect($login_url);
        }
        //$this->load->view('login',$data);
		

	}

    public function logout(){
		$ref_url = $_SERVER['HTTP_REFERER'];

        $this->load->library('facebook');
        $this->facebook->destroySession();
        // Destory website session
		$this->session->unset_userdata('userinfoz');
		
		$this->session->sess_destroy();
		redirect($ref_url,'refresh');
	
	
    }

}

