<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Action extends Admin_Controller 
{
	function __construct() 
	{
		parent::__construct();
		$this->load->model('Vfn_page_M');
		$this->load->model('State_M');
		$this->load->model('City_M');
		$this->load->model('Neta_M');
		
		
		
		
		
		$this->load->library('my_upload');
		$this->load->library("pagination");
	}
	
	
	public function index()
	{
		redirect(base_url("admin/login"), "refresh");
	}
	
	
	public function edit_page($pageid)  
	{
		if($_POST)
		{
			$rules['page_heading']= array('field'=>'page_heading','label'=>'Heading', 'rules'=>'trim|required');
			$rules['page_txt']= array('field'=>'page_txt','label'=>'Contant', 'rules'=>'required');
			$rules['meta_title']= array('field'=>'meta_title','label'=>'Meta Title', 'rules'=>'trim|required');
			
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				$data['page_heading']=$this->input->post('page_heading');
				$data['page_txt']=$this->input->post('page_txt');
				$data['meta_title']=$this->input->post('meta_title');
				$data['meta_desc']=$this->input->post('meta_desc');
				$data['meta_keyword']=$this->input->post('meta_keyword');
				
				$r=$this->Vfn_page_M->save($data,$pageid);
				if($r){
					$smsg= "Page Updated Successfully";
					$typ='success';
				}else{
					$smsg= "Error Occurs While Updating Page";
					$typ='error';
				}
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("action/edit_page/".$pageid));
		}
				
		
		
		$this->data['this_pages']=$this->Vfn_page_M->get($pageid, TRUE);
		
		$this->data['pageid']=$pageid;  //default value given
		$this->data['sub_view']='admin/subview/edit_page';
		$this->load->view('admin/_layout',$this->data);
	}
	
	
	
	public function pagelist()   
	{
		
		
			
		$logs=  $this->Vfn_page_M->get_by(array('page_type'=> 'Page', 'status'=> 'Y'));
		$m='';
		if(count($logs)>0){
			foreach($logs as $ad){
				$m = $m. '
                <tr>
                    <td>'.$ad->page_heading.'</td>
                    <td class="hidden-xs">
                        <a href="'.base_url('action/edit_page/'.$ad->page_id).'" class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></a>
                    </td>
                </tr>
				';
				
			}
		}
		
		//echo $m ; exit;
		
		$this->data['alldf']=$m;		
		
		
		$this->data['sub_view']='admin/subview/page_list';
		$this->load->view('admin/_layout',$this->data);
	}
	
	
	public function newslist()   
	{
			
		$logs=  $this->Vfn_page_M->get_by(array('page_type'=> 'News', 'status'=> 'Y'));
		$m='';
		if(count($logs)>0){
			foreach($logs as $ad){
				$m = $m. '
                <tr>
                    <td>'.$ad->page_heading.'</td>
                    <td class="hidden-xs">
                        <a href="'.base_url('action/editnews/'.$ad->page_id).'" class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></a>
                    </td>
                </tr>
				';
				
			}
		}
		
		//echo $m ; exit;
		
		$this->data['alldf']=$m;		
		
		
		$this->data['sub_view']='admin/subview/news_list';
		$this->load->view('admin/_layout',$this->data);
	}
	public function addnews()  
	{
		if($_POST)
		{
			$rules['page_heading']= array('field'=>'page_heading','label'=>'Heading', 'rules'=>'trim|required');
			$rules['page_txt']= array('field'=>'page_txt','label'=>'Contant', 'rules'=>'required');
			$rules['meta_title']= array('field'=>'meta_title','label'=>'Meta Title', 'rules'=>'trim|required');
			
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				$flname= md5(date("YmdHis")) ;
				$uploadimage = $this->do_upload('thumb', 'uploads/news/', 1280, 720, $flname);
				$uploadimagesml = $this->do_upload('thumb', 'uploads/news/s/', 300, 300, $flname);
		
							
				
				
				$data['page_heading']=$this->input->post('page_heading');
				$data['page_txt']=$this->input->post('page_txt');
				$data['meta_title']=$this->input->post('meta_title');
				$data['meta_desc']=$this->input->post('meta_desc');
				$data['meta_keyword']=$this->input->post('meta_keyword');
				$data['page_type']='News';
				$data['thumbnail']=$uploadimage;
				
				$r=$this->Vfn_page_M->save($data);
				if($r){
					$smsg= "News Created Successfully";
					$typ='success';
				}else{
					$smsg= "Error Occurs While Creating News";
					$typ='error';
				}
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("action/newslist/"));
		}
				
		
		$this->data['sub_view']='admin/subview/addnews';
		$this->load->view('admin/_layout',$this->data);
	}
	
	public function editnews($pageid)  
	{
		if($_POST)
		{
			$rules['page_heading']= array('field'=>'page_heading','label'=>'Heading', 'rules'=>'trim|required');
			$rules['page_txt']= array('field'=>'page_txt','label'=>'Contant', 'rules'=>'required');
			$rules['meta_title']= array('field'=>'meta_title','label'=>'Meta Title', 'rules'=>'trim|required');
			
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				if($this->input->post('thumb')!=''){
					$flname= md5(date("YmdHis")) ;
					$uploadimage = $this->do_upload('thumb', 'uploads/news/', 1280, 720, $flname);
					$uploadimagesml = $this->do_upload('thumb', 'uploads/news/s/', 300, 300, $flname);
					$data['thumbnail']=$uploadimage;
				}		
				
				
				$data['page_heading']=$this->input->post('page_heading');
				$data['page_txt']=$this->input->post('page_txt');
				$data['meta_title']=$this->input->post('meta_title');
				$data['meta_desc']=$this->input->post('meta_desc');
				$data['meta_keyword']=$this->input->post('meta_keyword');
				$data['page_type']='News';
				
				
				$r=$this->Vfn_page_M->save($data,$pageid);
				if($r){
					$smsg= "News Updated Successfully";
					$typ='success';
				}else{
					$smsg= "Error Occurs While Updating News";
					$typ='error';
				}
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("action/newslist/"));
		}
				
		$this->data['this_pages']=$this->Vfn_page_M->get($pageid, TRUE);
		$this->data['sub_view']='admin/subview/editnews';
		$this->load->view('admin/_layout',$this->data);
	}
	
	
	public function states($stateid=NULL)   
	{
		
		if($stateid!=NULL){
			$this->session->set_userdata('stid',$stateid);
			redirect(base_url("action/constit"), "refresh");
		}
		
		
		
		if($_POST)
		{
			$rules['state']= array('field'=>'state','label'=>'state', 'rules'=>'trim|required');
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				$st = $this->input->post('state');
				$pp=  $this->State_M->get_by(array('statename'=> $st));
				if(count($pp)>0){
					$smsg= "THis Name is already recorded.";
					$typ='error';
				}else{
					$data['statename']=$this->input->post('state');
					$r=$this->State_M->save($data);
					if($r){
						$smsg= "State Created Successfully";
						$typ='success';
					}else{
						$smsg= "Error Occurs While Creating State";
						$typ='error';
					}
				}
				
				
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("action/states/"));
		}
		
		
		
		
		$logs=  $this->State_M->get();
		$m='';
		if(count($logs)>0){
			foreach($logs as $ad){
				$logv=  $this->City_M->get_by(array('stateid'=>$ad->statename));
				$m = $m. '
                <tr>
                    <td>'.$ad->statename.' (<a href="'.base_url('action/states/'.$ad->stateid).'" >'.count($logv).'</a>) </td>
                    <td class="hidden-xs">
                        <a href="'.base_url('action/edit_state/'.$ad->stateid).'" class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></a>
                    </td>
                </tr>
				';
				
			}
		}
		$this->data['alldf']=$m;		
		$this->data['sub_view']='admin/subview/states';
		$this->load->view('admin/_layout',$this->data);
	}
	
	public function edit_state($id)   
	{
		
		if($_POST)
		{
			$rules['state']= array('field'=>'state','label'=>'state', 'rules'=>'trim|required');
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				$st = $this->input->post('state');
				$data['statename']=$this->input->post('state');
				$r=$this->State_M->save($data,$id);
				if($r){
					$smsg= "State Updated Successfully";
					$typ='success';
				}else{
					$smsg= "Error Occurs While Updating State";
					$typ='error';
				}
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("action/states/"));
		}
		
		
		
		
		$logs=  $this->State_M->get();
		$m='';
		if(count($logs)>0){
			foreach($logs as $ad){
				$m = $m. '
                <tr>
                    <td>'.$ad->statename.'</td>
                    <td class="hidden-xs">
                        <a href="'.base_url('action/edit_state/'.$ad->stateid).'" class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></a>
                    </td>
                </tr>
				';
				
			}
		}
		$this->data['alldf']=$m;

		
		$this->data['thisdata']=$this->State_M->get($id);

		
		$this->data['sub_view']='admin/subview/states';
		$this->load->view('admin/_layout',$this->data);
	}
	
	
	public function allconstit()   
	{
		//$this->session->set_userdata('stid',$stateid);
		$this->session->unset_userdata('stid');
		redirect(base_url("action/constit"));
	}
	
	
	public function constit()   
	{
		if(isset($_POST['deletecity'])){
			
			$r=$this->City_M->delete($data);
			if($r){
				$smsg= "Constituency Deleted Successfully";
				$typ='success';
			}else{
				$smsg= "Error Occurs While Deleting Constituency";
				$typ='error';
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("action/constit/"));
			
		}
		
		
		if(isset($_POST['addcity']))
		{
			$rules['cityname']= array('field'=>'cityname','label'=>'Constituency', 'rules'=>'trim|required');
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				$ct = $this->input->post('cityname');
				$pp=  $this->City_M->get_by(array('cityname'=> $ct));
				if(count($pp)>0){
					$smsg= "THis Name is already recorded.";
					$typ='error';
				}else{
					$data['cityname']=$this->input->post('cityname');
					$data['stateid']=$this->input->post('stateid');
					$r=$this->City_M->save($data);
					if($r){
						$smsg= "Constituency Created Successfully";
						$typ='success';
					}else{
						$smsg= "Error Occurs While Creating Constituency";
						$typ='error';
					}
				}
				
				
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("action/constit/"));
		}
		
		
		
		
		
		
		
		$stid = $this->session->userdata('stid');
		
		

		if($stid!=NULL){
			$s = $this->State_M->get($stid);
			$this->data['s_state']=$s;
			$alld =   $this->City_M->get_by(array('stateid'=> $s->statename));
		}else{
			$alld =   $this->City_M->get();
			$this->data['s_state']=NULL;
		}
		/////----
		
	  $config = array();
      $config["base_url"] = base_url() . "action/constit";
      $config["total_rows"] = count($alld);
      $config["per_page"] = 200;
      $config["uri_segment"] = 3;
	  $config['num_links']=6;
		///////
      $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
       //$data["results"] = $this->Countries->fetch_countries($config["per_page"], $page);
        $this->data["links"] = $this->pagination->create_links();
		
		
		////------
		
		
		
		if($stid!=NULL){
			$st=  $this->State_M->get($stid, TRUE);
			$this->db->limit($config["per_page"], $page);
			$logs=  $this->City_M->get_by(array('stateid'=>$st->statename), FALSE,FALSE, 'stateid', 'ASC');
		}else{
			$this->db->limit($config["per_page"], $page);
			$logs=  $this->City_M->get(NULL, FALSE,FALSE, 'stateid', 'ASC');
		}
		
		
		
		
		
		$m='';
		if(count($logs)>0){
			foreach($logs as $ad){
				$m = $m. '
                <tr>
                    <td>'.$ad->stateid.'</td>
                    <td>'.$ad->cityname.'</td>
                    <td class="hidden-xs">
                        
						<form method="post">
							<input type="hidden" name="cityid" value ="'.$ad->cityid.'"  />
							<button type="submit" name="deletecity" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></button>
						</form>
                    </td>
                </tr>
				';
				
			}
		}
		$this->data['allst']=$this->State_M->get();	
		
		$this->data['alldf']=$m;		
		$this->data['sub_view']='admin/subview/constit';
		$this->load->view('admin/_layout',$this->data);
	}
	
	
	
	public function neta()   
	{
		

	$alld =   $this->Neta_M->get();
			
			
			
	  $config = array();
      $config["base_url"] = base_url() . "action/constit";
      $config["total_rows"] = count($alld);
      $config["per_page"] = 200;
      $config["uri_segment"] = 3;
	  $config['num_links']=6;
		///////
      $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $this->data["links"] = $this->pagination->create_links();
		
		
		////------
		
		
		

		
		$this->db->limit($config["per_page"], $page);
		$logs=  $this->Neta_M->get(NULL, FALSE,FALSE, 'state_id', 'ASC');
		
		
		
		$m='';
		if(count($logs)>0){
			foreach($logs as $ad){
				$m = $m. '
                <tr>
                    <td>'.$ad->leader_name.'</td>
                    <td>'.$ad->state_id.'</td>
                    <td>'.$ad->cityid.'</td>
                    <td class="hidden-xs">
                        
						<form method="post">
							<input type="hidden" name="id" value ="'.$ad->id.'"  />
							<button type="submit" name="deletecity" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></button>
						</form>
                    </td>
                </tr>
				';
				
			}
		}
		$this->data['allst']=$this->State_M->get();	
		
		$this->data['alldf']=$m;		
		$this->data['sub_view']='admin/subview/neta';
		$this->load->view('admin/_layout',$this->data);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
  function do_upload($fieldname = 'profimg', $directory='uploads/userpics/', $width=600, $height =300, $filename=NULL) {
    
	if($filename==NULL){
		$filename= md5(date("YmdHis")) ;
	}
		
	
    $this->my_upload->upload($_FILES[$fieldname]);
    if ( $this->my_upload->uploaded == true  ) {
      //$this->my_upload->allowed         = array('image/*');
      $this->my_upload->file_new_name_body    = $filename;
      $this->my_upload->image_resize          = true;
      $this->my_upload->image_ratio_crop          = true;
	  
      $this->my_upload->image_x               = $width;
      $this->my_upload->image_y         = $height;
	  
      $this->my_upload->process($directory);
      if ( $this->my_upload->processed == true ) {
         $output = $this->my_upload->file_dst_name;
		 
      } else {
        $output = NULL;
      }
    } else  {
      $output = NULL;
    }
	return $output; 
  } 
}
