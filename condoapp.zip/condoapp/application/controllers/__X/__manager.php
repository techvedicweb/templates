<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Manager extends Admin_Controller 
{
	function __construct() 
	{
		parent::__construct();
		$this->load->model('Condo_M');
		$this->load->model('Book_M');
		$this->load->model('User_M');
		
		$this->load->library('my_upload');
		$this->load->library("pagination");
		
		$myid = $this->session->userdata('user_id');
		$myinfo = $this->User_M->get($myid, TRUE);
		
		if($myinfo->thumbnail==''){
			$this->data['mypic']=  base_url('nassets/img/avatar-mini.jpg');
		}else{
			$this->data['mypic']= base_url('nassets/img/profpic').'/'.$myinfo->thumbnail;
		}
		
		$bb = array("dashboard", "logout" , "login");
		if (!in_array($this->uri->segment(2), $bb) && $myinfo->status=='I' ){
			redirect(base_url("manager/dashboard"));
		}
		
		
		

	}
	
	
	public function index()
	{
		redirect(base_url("admin/login"), "refresh");
	}
	
	
	
	
	
	public function addcondo()  
	{
		if($this->session->userdata('user_typ')=='Owner'){
			$ownerid = $this->session->userdata('user_id');
		}else{
			$ownerid = $this->session->userdata('owner_id');
		}
		
		
		if($_POST)
		{
			$rules['cn_name']= array('field'=>'cn_name','label'=>'Condo Name', 'rules'=>'trim|required');
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				$flname= md5(date("YmdHis")) ;
				$uploadimage = $this->do_upload('thumb', 'uploads/condo/', 600, 600, $flname);
		
				
				$data['cn_name']=$this->input->post('cn_name');
				$data['cn_desc']=$this->input->post('cn_desc');
				$data['insert_by']=$this->session->userdata('user_id');
				$data['user_id']=$ownerid;
				$data['cn_thumbnail']=$uploadimage;
				
				//print_result($data); exit;
				
				
				
				$r=$this->Condo_M->save($data);
				if($r){
					$smsg= "Condo Created Successfully";
					$typ='success';
				}else{
					$smsg= "Error Occurs While Creating Condo";
					$typ='error';
				}
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("manager/addcondo/"));
		}
				
		
		$this->data['sub_view']='admin/subview/addcondo';
		$this->load->view('admin/_layout',$this->data);
	}
	
	
	public function editcondo($pageid)  
	{
		if($_POST)
		{
			$rules['cn_name']= array('field'=>'cn_name','label'=>'Condo Name', 'rules'=>'trim|required');

			
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				if($this->input->post('thumb')!=''){
					$flname= md5(date("YmdHis")) ;
					$uploadimage = $this->do_upload('thumb', 'uploads/condo/', 600, 600, $flname);
					$data['cn_thumbnail']=$uploadimage;
				}		
				
				
				$data['cn_name']=$this->input->post('cn_name');
				$data['cn_desc']=$this->input->post('cn_desc');
				
				
				$r=$this->Condo_M->save($data,$pageid);
				if($r){
					$smsg= "Condo Updated Successfully";
					$typ='success';
				}else{
					$smsg= "Error Occurs While Updating Condo";
					$typ='error';
				}
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("manager/condolist/"));
		}
				
		$this->data['this_pages']=$this->Condo_M->get($pageid, TRUE);
		$this->data['sub_view']='admin/subview/editcondo';
		$this->load->view('admin/_layout',$this->data);
	}
	
	public function condolist($typ=NULL)   
	{
		//print_result($this->session->userdata); exit;
		
		if($this->session->userdata('user_typ')=='Owner'){
			$ownerid = $this->session->userdata('user_id');
		}else{
			$ownerid = $this->session->userdata('owner_id');
		}
		
		if($typ){
			if($typ=='ALL'){
				$logs=  $this->Condo_M->get_by(array('user_id'=>$ownerid));
			}elseif($typ=='PENDING'){
				$logs=  $this->Condo_M->get_by(array('status'=>'P', 'user_id'=>$ownerid));
			}elseif($typ=='APPROVED'){
				$logs=  $this->Condo_M->get_by(array('status'=>'A', 'user_id'=>$ownerid));
			}
		}else{
			$logs=  $this->Condo_M->get_by(array('user_id'=>$ownerid));
		}
		
		$m='';
		if(count($logs)>0){
			foreach($logs as $ad){
				$d= $ad->insert_by;
				$ins = $this->User_M->get($d, TRUE);
				
				$stbtn ='';
				if($ad->status=='P'){
					$stbtn ='<p class="btn btn-primary">Pending</p>';
				}elseif($ad->status=='A'){
					$stbtn ='<p class="btn btn-info">Active</p>';
				}
				
				
				$m = $m. '
                <tr>
                    <td>'.$ad->cn_name.'</td>
					<td>'.date('M d Y',strtotime($ad->insert_date)).'</td>
                    <td>'.$ins->user_name.' '.$ins->user_mname.' '.$ins->user_lname.'</td>
                    <td>'.$stbtn.'</td>
                    
                    <td class="hidden-xs">
                        <a href="'.base_url('manager/editcondo/'.$ad->cn_id).'" class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></a>
                    </td>
                </tr>
				';
				
			}
		}
		
		//echo $m ; exit;
		
		$this->data['alldf']=$m;		
		
		
		$this->data['sub_view']='admin/subview/page_list';
		$this->load->view('admin/_layout',$this->data);
	}
	
	/////////////////////////////////////////////////////
	public function bookinglist($typ=NULL)   
	{
		if($this->session->userdata('user_typ')=='Owner'){
			$ownerid = $this->session->userdata('user_id');
		}else{
			$ownerid = $this->session->userdata('owner_id');
		}
		if($typ){
			if($typ=='ALL'){
				$logs=  $this->Book_M->get_by(array('owner_id'=>$ownerid));
			}elseif($typ=='PENDING'){
				$logs=  $this->Book_M->get_by(array('status'=>'P', 'owner_id'=>$ownerid));
			}elseif($typ=='APPROVED'){
				$logs=  $this->Book_M->get_by(array('status'=>'A', 'owner_id'=>$ownerid));
			}
		}else{
			$logs=  $this->Book_M->get_by(array('owner_id'=>$ownerid));
		}
		
		$m='';
		if(count($logs)>0){
			foreach($logs as $ad){
				$d= $ad->insert_by;
				$ins = $this->User_M->get($d, TRUE);
				$c_id=  $ad->condo_id;
				$cnd = $this->Condo_M->get($c_id, TRUE);
				
				
				
				$stbtn ='';
				if($ad->status=='P'){
					$stbtn ='<p class="btn btn-primary">Pending</p>';
				}elseif($ad->status=='A'){
					$stbtn ='<p class="btn btn-info">Active</p>';
				}
				
				
				$m = $m. '
                <tr>
                    <td>'.$cnd->cn_name.'</td>
                    <td><a href="mailto:'.$ad->email.'" >'.$ad->party_name.'</a> | '.$ad->phone.'</td>
					<td>'.date('M d Y',strtotime($ad->book_st_dt)).' to '.date('M d Y',strtotime($ad->book_end_dt)).'</td>
                    <td>'.$ins->user_name.' '.$ins->user_mname.' '.$ins->user_lname.'</td>
                    <td>'.$stbtn.'</td>
                    
                    <td class="hidden-xs">
                        <a href="'.base_url('manager/editbooking/'.$ad->book_id).'" class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></a>
                    </td>
                </tr>
				';
				
			}
		}
		
		
		
		$this->data['alldf']=$m;		
		
		
		$this->data['sub_view']='admin/subview/bookinglist';
		$this->load->view('admin/_layout',$this->data);
	}
	
	public function addbooking()  
	{
		if($this->session->userdata('user_typ')=='Owner'){
			$ownerid = $this->session->userdata('user_id');
		}else{
			$ownerid = $this->session->userdata('owner_id');
		}
		
		
		if($_POST)
		{
			$rules['condo_id']= array('field'=>'condo_id','label'=>'Condo', 'rules'=>'trim|required');
			$rules['book_st_dt']= array('field'=>'book_st_dt','label'=>'Start Date', 'rules'=>'trim|required');
			$rules['book_end_dt']= array('field'=>'book_end_dt','label'=>'End Date', 'rules'=>'trim|required');
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				$stdt = $this->input->post('book_st_dt');
					$parts = explode('/',$stdt);
					$stdt = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
				
				$enddt = $this->input->post('book_end_dt');
					$partsn = explode('/',$enddt);
					$enddt = $partsn[2] . '-' . $partsn[0] . '-' . $partsn[1];
				
				
				$data['condo_id']=$this->input->post('condo_id');
				$data['book_st_dt']= $stdt;
				$data['book_end_dt']= $enddt;
				
				$data['party_name']=$this->input->post('party_name');
				$data['email']=$this->input->post('email');
				$data['phone']=$this->input->post('phone');
				$data['address']=$this->input->post('address');
				$data['city']=$this->input->post('city');
				$data['state']=$this->input->post('state');
				$data['country']=$this->input->post('country');
				$data['zip']=$this->input->post('zip');
				
				$data['insert_by']=$this->session->userdata('user_id');
				$data['owner_id']=$ownerid;
				
				
				
				
				
				$r=$this->Book_M->save($data);
				if($r){
					$smsg= "Booking Created Successfully";
					$typ='success';
				}else{
					$smsg= "Error Occurs While Creating Booking";
					$typ='error';
				}
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("manager/bookinglist/"));
		}
		

		$logs=  $this->Condo_M->get_by(array('status'=>'A', 'user_id'=>$ownerid));
		$m='';
		if(count($logs)>0){
			foreach($logs as $ad){
				$m = $m. '<option value="'.$ad->cn_id.'">'.$ad->cn_name.'</option> ';
			}
		}
				
		$this->data['allselect']=$m;
		
		$this->data['sub_view']='admin/subview/addbooking';
		$this->load->view('admin/_layout',$this->data);
	}
	
	public function editbooking($pageid)  
	{
		if($_POST)
		{
			$rules['email']= array('field'=>'email','label'=>'Email', 'rules'=>'trim|required');

			
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				$data['party_name']=$this->input->post('party_name');
				$data['email']=$this->input->post('email');
				$data['phone']=$this->input->post('phone');
				$data['address']=$this->input->post('address');
				$data['city']=$this->input->post('city');
				$data['state']=$this->input->post('state');
				$data['country']=$this->input->post('country');
				$data['zip']=$this->input->post('zip');
				
				
				$r=$this->Book_M->save($data,$pageid);
				if($r){
					$smsg= "Booking Updated Successfully";
					$typ='success';
				}else{
					$smsg= "Error Occurs While Updating Booking";
					$typ='error';
				}
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("manager/bookinglist/"));
		}
				
		$this->data['dbook']=$this->Book_M->get($pageid, TRUE);
		
		$dbook=$this->Book_M->get($pageid, TRUE);
		
		$c_id=  $dbook->condo_id;
		$cnd = $this->Condo_M->get($c_id, TRUE);
		$this->data['condonm']=$cnd->cn_name;
		
		
		
		$this->data['sub_view']='admin/subview/editbooking';
		$this->load->view('admin/_layout',$this->data);
	}
	
	

	
	
	
	public function logout()
	{
		$this->session->sess_destroy();
		redirect(base_url('admin/login'),'refresh');
	}
	
	
	public function dashboard()
	{
		$myid = $this->session->userdata('user_id');
		$myinfo = $this->User_M->get($myid, TRUE);
		
		if($this->session->userdata('user_typ')=='Owner'){
			$ownerid = $this->session->userdata('user_id');
			
			$this->data['managers'] = $this->User_M->get_by(array('owner_id'=>$myid));
			
		}else{
			$ownerid = $this->session->userdata('owner_id');
			$this->data['managers'] = NULL;
		}
		$allcondo=  $this->Condo_M->get_by(array('user_id'=>$ownerid));
		$this->data['num_condo']=count($allcondo);
		
		$pbook=  $this->Book_M->get_by(array('status'=>'P', 'insert_by'=>$ownerid));
		$this->data['num_pendingbook']=count($pbook);
		
		
		
		
		
		
		
		
		
		
		
		if(isset($_POST['changepassword']))
		{
			$rules['oldp']= array('field'=>'oldp','label'=>'Old Password', 'rules'=>'trim|required');
			$rules['newp']= array('field'=>'newp','label'=>'New Password', 'rules'=>'trim|required');
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				$oldp = $this->input->post('oldp');
				$newp = $this->input->post('newp');
				$repeatp = $this->input->post('repeatp');
				
				
				
				if($myinfo->user_password==$oldp ){
					if($newp==$repeatp){
						$data['user_password']=$newp;
						
						$r=$this->User_M->save($data, $myid);
						if($r){
							$smsg= "Password Changed Successfully";
							$typ='success';
						}else{
							$smsg= "Error Occurs While Changing Password";
							$typ='error';
						}
					}else{
						$smsg= "Password Mismatches";
						$typ='error';
					}
				}else{
					$smsg= "Provide proper Old Password";
					$typ='error';
				}
			}else{
				$data['errors']=validation_errors();
			}
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("manager/dashboard/"));
		}
		
		if(isset($_POST['profpic']))
		{

				$flname= md5(date("YmdHis")) ;
				$uploadimage = $this->do_upload('thumb', 'nassets/img/profpic/', 300, 300, $flname);
				
				
				$data['thumbnail']=$uploadimage;
				
				$r=$this->User_M->save($data, $myid);
				
				if($r){
					$smsg= "Picture Uploaded Successfully";
					$typ='success';
				}else{
					$smsg= "Error Occurs While Uploading Picture";
					$typ='error';
				}
			
			$this->session->set_flashdata($typ,$smsg);
			redirect(base_url("manager/dashboard/"));
		}
		
		



		
		
		if($myinfo->status=='I'){
			$this->data['sub_view']='admin/subview/homenull';
			$this->load->view('admin/_layout',$this->data);
		}else{
			$this->data['sub_view']='admin/subview/home';
			$this->load->view('admin/_layout',$this->data);
		}
		
		
	}
	
		
  function do_upload($fieldname = 'profimg', $directory='uploads/userpics/', $width=600, $height =300, $filename=NULL) {
    
	if($filename==NULL){
		$filename= md5(date("YmdHis")) ;
	}
		
	
    $this->my_upload->upload($_FILES[$fieldname]);
    if ( $this->my_upload->uploaded == true  ) {
      //$this->my_upload->allowed         = array('image/*');
      $this->my_upload->file_new_name_body    = $filename;
      $this->my_upload->image_resize          = true;
      $this->my_upload->image_ratio_crop          = true;
	  
      $this->my_upload->image_x               = $width;
      $this->my_upload->image_y         = $height;
	  
      $this->my_upload->process($directory);
      if ( $this->my_upload->processed == true ) {
         $output = $this->my_upload->file_dst_name;
		 
      } else {
        $output = NULL;
      }
    } else  {
      $output = NULL;
    }
	return $output; 
  } 

  
	
	
	
}
