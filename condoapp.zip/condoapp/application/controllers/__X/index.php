<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Index extends CI_Controller 
{
	function __construct() 
	{
		parent::__construct();
		if($this->uri->segment(2) !='login')
		{
			$ag = $this->session->userdata('agent_id');
			if($ag)
			{
				// do nothing
			}
			else
			{
				redirect(base_url('index/login'),'refresh');
			}
		}
	}
	
	public function index()
	{
		$txt=  "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque eget faucibus nisi. Vestibulum at augue in arcu malesuada sodales vel nec risus. Proin dignissim diam in mi ornare, a interdum nulla consectetur. Proin eget dui sit amet nunc vestibulum vehicula. Mauris sollicitudin molestie nisl ac condimentum {{%name%}}. 
		
		
		Sed in porttitor dolor. Phasellus eu gravida elit, {{%phone%}} at faucibus magna. Nam sollicitudin, sapien non euismod pulvinar, nisl tortor ultrices enim, nec gravida nulla ex vel dui. Nam mollis dignissim magna, nec mattis eros vestibulum sit amet. Proin interdum ante et est lobortis commodo. Aliquam eget nulla et massa efficitur blandit id et enim. {{%email%}} Sed a nisi nisl. Maecenas dolor orci, varius consectetur finibus id, imperdiet et nisl. Interdum et malesuada fames ac ante ipsum primis in faucibus. Vestibulum sodales auctor {{%email%}} volutpat.";
		
		
		$this->data['text']= $this->processTextToken($txt);
		
		
		
		
		
		
		$this->data['sub_view']='home/subview/home';
		$this->load->view('home/_layout',$this->data);
	}
	
	public function processTextToken($data)
	{
		preg_match_all('/{{%\w*%}}/',$data, $matches);	  // track the tokens...
		$uniq = array_unique($matches[0]);   /// remove repeated ones and make unique		
		//print_result($uniq);
		
		///////----- original data should be here  or can be taken from database..
		$name = '<b>LOKANATH</b>';
		$phone = '<b>+91 9876587654</b>';
		$email = '<b>loka@gmail.com</b>';
		////////
		
		
		foreach($uniq as $u){
			$pp = $u;
			$u = str_replace('{{%', '', $u);
			$u = str_replace('%}}', '', $u);
			$orgdata = $$u;    
			$data =  str_replace($pp, $orgdata, $data);
		}
		return $data;
	}
	
	
	
	public function login()
	{
		if($_POST)
		{
			$rules['user_id']= array('field'=>'user_id','label'=>'User Id', 'rules'=>'trim|required');
			$rules['password']= array('field'=>'password','label'=>'Password', 'rules'=>'trim|required');
			
			$this->form_validation->set_rules($rules);
			if($this->form_validation->run() == TRUE)
			{
				$uid= $this->input->post('user_id');
				$pass= $this->input->post('password');
				//echo $uid.' | '.$pass;
				if($uid=='agent4u' && $pass=='123456')
				{
					$this->session->set_userdata(array('agent_id'=>$uid));
					//redirect('index/index','refresh');
					redirect(base_url('index/index'),'refresh');
				}
				else
				{
					$smsg= "Login fails with your provided login details";
					$typ='error';
					$this->session->set_flashdata($typ,$smsg);
				}
			}
			else
			{
				$data['errors']=validation_errors();
			}
		
		}
		////SET session:
		//$this->session->set_userdata(array('xxxxx'=>'somedata'));
		//////UNSET session
		//$this->session->unset_userdata('xxxxx');
		$this->load->view('home/_login');
		
	}
	

	public function logout()
	{
		
		
		//////UNSET session
		//$this->session->unset_userdata('xxxxx');
		$this->session->sess_destroy();
		redirect(base_url('index/login'),'refresh');
		
	}
	
	
	
	}
