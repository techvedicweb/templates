<?php
class Myuploads extends CI_Controller {
  
  function __construct() {
    parent::__construct();
    $this->load->helper(array('form', 'url'));
    $this->load->library('my_upload');
  }
  
  function index() { 
  //echo 'dfgdfgh';
  if($_POST)
	{
		$datam = $this->do_upload('profimg', 'uploads/userpics/', 500, 300);
		
		echo 'Output is '.$datam;
	    
	}
  
  
  
    $data['page'] = 'upload_form';
    $data['errors'] = '';
    $data['title'] = 'Upload From';
    $this->load->view('front/_imgupload',$data);
	
	
	
	
	
	
  }

  function do_upload($fieldname = 'profimg', $directory='uploads/userpics/', $width=600, $height =300) {
    $filename= md5(date("YmdHis")) ;
	
    $this->my_upload->upload($_FILES[$fieldname]);
    if ( $this->my_upload->uploaded == true  ) {
      //$this->my_upload->allowed         = array('image/*');
      $this->my_upload->file_new_name_body    = $filename;
      $this->my_upload->image_resize          = true;
      $this->my_upload->image_ratio_crop          = true;
	  
      $this->my_upload->image_x               = $width;
      $this->my_upload->image_y         = $height;
	  
      $this->my_upload->process($directory);
      if ( $this->my_upload->processed == true ) {
         $output = $this->my_upload->file_dst_name;
      } else {
        $output = NULL;
      }
    } else  {
      $output = NULL;
    }
	return $output; 
  } 

  
  
  
  }


?>