<?php
class Upload extends CI_Controller {
  
  function __construct() {
    parent::__construct();
    $this->load->helper(array('form', 'url'));
    $this->load->library('upload');
  }
  
  function index() { 
  echo 'dfgdfgh';
   /* $data['page'] = 'upload_form';
    $data['errors'] = '';
    $data['title'] = 'Upload From';
    $this->load->view('container',$data);*/
  }

  function do_upload() {
    $now = date("YmdHis");
    $this->my_upload->upload($_FILES["userfile"]);
    if ( $this->my_upload->uploaded == true  ) {
      $this->my_upload->allowed         = array('image/*');
      $this->my_upload->file_new_name_body    = 'image_resized' . $now;
      $this->my_upload->image_resize          = true;
      $this->my_upload->image_x               = 100;
      $this->my_upload->image_ratio_y         = true;
      $this->my_upload->process('./uploads/userpics/');
      if ( $this->my_upload->processed == true ) {
        $data['page'] = 'upload_success';
        $this->load->view('container',$data);
        $this->my_upload->clean();  
      } else {
        $data['errors'] = $this->my_upload->error;
        $data['page'] = 'upload_form';
        $this->load->view('container',$data);
      }
    } else  {
      $data['errors'] = $this->my_upload->error;
      $data['page'] = 'upload_form';
      $this->load->view('container',$data); 
    }
  } 
}


?>