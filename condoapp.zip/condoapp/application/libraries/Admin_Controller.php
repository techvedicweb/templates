<?php
class Admin_Controller extends MY_Controller {
	
	
	function __construct() {
		parent::__construct();
		$this->load->model('User_M');
		$exception_url=array("admin/login", "admin/autocomplete",  "admin/forgotpassword","admin/logout","admin/reset_password","admin/register","admin/registernext","admin/registersuccess");
		
		//echo 'LOKAAAA..'.$this->User_M->isLoggedin();exit;
		
		if(($this->User_M->isLoggedin() == FALSE))
		{
			if((in_array(uri_string(),$exception_url) == FALSE) )
				redirect(base_url("admin/login"), "refresh");
		}
		
		//////////////////USER TYPE WISE CONTROLLER REDIRECTED
		/// By LOKANATH  on 17 may 2016 for condo app.... Andrew...
		
		
		
		$typ =$this->session->userdata('user_typ');
		if($typ=='Owner' && $this->uri->segment(1) !='admin'){
			redirect(base_url("admin/dashboard"));
		}
		if($typ=='Manager' && $this->uri->segment(1) !='manager'){
			redirect(base_url("manager/dashboard"));
		}
		if($typ=='Admin' && $this->uri->segment(1) !='sadmin'){
			redirect(base_url("sadmin/dashboard"));
		}
		
		
		
		
		
		
	}
	public function exportinfo($qrery= NULL,$filename= NULL) 	{  		if($qrery != NULL){		  	$qry = $qrery;			}else{  			$qry = 'SELECT USER_ID FROM USER_MST';		}		if($filename != NULL){		  	$filenm = $filename;			}else{  			$filenm = 'excel_output_';		}						$qrz = $this->db->query($qry); 		$querym = $qrz->result();						if(count($querym)>0)		{			$query = $qrz->result_array();						$fstarr = $query[0];			$titlearray = array_keys($fstarr);	        if(!$query)	            return false;										        $this->load->library('Excel');	        $objPHPExcel = new PHPExcel();	        $objPHPExcel->getProperties()->setTitle("Output")->setDescription("none");	        $objPHPExcel->setActiveSheetIndex(0);	 	        	        $fields = $titlearray;	        $col = 0;	        foreach ($fields as $field)	        {            $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col, 1, $field);            $col++;        	}																        $row = 2;	        foreach($query as $data)	        {	            $col = 0;	            foreach ($fields as $fieldz)	            {	                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col, $row,  $data[$fieldz]);	                $col++;	            }	            $row++;                   	}	 	        $objPHPExcel->setActiveSheetIndex(0);	 	        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');	       		   	        header('Content-Type: application/vnd.ms-excel');	        header('Content-Disposition: attachment;filename="'.$filenm.date('dMy').'.xls"');	        header('Cache-Control: max-age=0');	        $objWriter->save('php://output');			        }        else{			return false;		}	}    
}
?>