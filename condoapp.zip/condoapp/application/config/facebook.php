<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


$config['appId']   = '1542650976038940';
$config['secret']  = 'e62fe07c1045b17650dad3d3543baa86';

?>
