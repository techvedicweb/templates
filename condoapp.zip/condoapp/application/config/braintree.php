<?php
defined('BASEPATH') OR exit('No direct script access allowed');

  $config['braintree_merchant_id'] = 'mwhf24tryknwc33b';
  $config['braintree_public_key']  = 'crrcpr9kvcyn7qnk';
  $config['braintree_private_key'] = '978af8cbf90895ac3ae4999dcf3576ea';
  $config['braintree_environment'] = 'production'; //production or sandbok
