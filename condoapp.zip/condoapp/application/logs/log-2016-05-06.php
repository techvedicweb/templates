<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-05-06 19:12:57 --> 404 Page Not Found --> single_blog.php
ERROR - 2016-05-06 19:17:06 --> 404 Page Not Found --> page/index
