<?php
class User_M extends MY_Model 
{
	protected $_primary_key = 'user_id';
	protected $_table_name = 'user_mst';
	protected $_order_by = 'user_name';
	public $rule_login = array(
				'user_id' => array('field'=>'user_id','label'=>'Email Id','rules' => 'trim|required|email|xss_clean'),
				'password' => array('field'=>'password','label'=>'Password', 'rules'=>'trim|required')
				);
	
	
	function __construct()
	{
		parent::__construct();
	}
	public function login()
	{
		$user = $this->get_by(array(
									'user_email'=> $this->input->post('user_id'),
									'user_password' => $this->input->post('password'),
									'status !=' => 'D'
									), TRUE);
		//echo $this->db2->last_query();exit;
		if(count($user))
		{
			$data = array('user_name'=>$user->user_name,
						  'user_mname'=>$user->user_mname, 
						  'user_lname'=>$user->user_lname, 
						  'phone'=>$user->phone, 
						  'user_id'=>$user->user_id, 
						  'user_email'=>$user->user_email,
						  'last_login'=>$user->last_login,
						  'user_typ'=>$user->user_typ,
						  'owner_id'=>$user->owner_id,
						  'loggedin'=>TRUE);
			//print_r($data);exit;
			$this->session->set_userdata($data);
		}
		
		
	}
	public function forgotpass()
	{
		$user = $this->get_by(array('email_id'=> $this->input->post('login_id')), TRUE);
		if(count($user))
		{
			return $user;
		}
		else
		{
			return (bool)FALSE;
		}
	}
	
	public function logout()
	{
		$this->session->sess_destroy();
		// session_write_close();
	}
	
	public function isLoggedin()
	{
		return (bool)$this->session->userdata('loggedin');
	}
	
}
?>