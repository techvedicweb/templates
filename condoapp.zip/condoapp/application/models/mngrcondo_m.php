<?php
class  Mngrcondo_M extends MY_Model {	protected $_primary_key = 'mc_id';	protected $_table_name = 'mngr_condo';	protected $_order_by = 'mc_id';	function __construct()	{		parent::__construct();	}
}	
?>