<?php
class  City_M extends MY_Model 
{
	protected $_primary_key = 'cityid';
	protected $_table_name = 'tbl_city';
	protected $_order_by = 'cityid';
	
	function __construct()
	{
		parent::__construct();
		
	}
}	
?>