<?php
class  Condo_M extends MY_Model 
{
	protected $_primary_key = 'cn_id';
	protected $_table_name = 'condo_mst';
	protected $_order_by = 'cn_id';
	
	function __construct()
	{
		parent::__construct();
		
	}
}	
?>