<?php
class  Neta_M extends MY_Model 
{
	protected $_primary_key = 'id';
	protected $_table_name = 'tbl_blog';
	protected $_order_by = 'id';
	
	function __construct()
	{
		parent::__construct();
		
	}
}	
?>