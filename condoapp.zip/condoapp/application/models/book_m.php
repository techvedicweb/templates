<?php
class  Book_M extends MY_Model 
{
	protected $_primary_key = 'book_id';
	protected $_table_name = 'booking_mst';
	protected $_order_by = 'book_id';
	
	function __construct()
	{
		parent::__construct();
		
		
		
	}
}	
?>