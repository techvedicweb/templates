<?php
function btn_duplicate($url)
{
	return anchor($url, '<i class="fa fa-fw fa-copy"></i>','title="Duplicate"');
}
function btn_edit($url)
{
	return anchor($url, '<span class="glyphicon glyphicon-pencil"></span>','title="Edit"');
}
function btn_edit_link($url)
{
	return anchor($url, 'Edit','title="Edit" style="font-size:11px;"');
}
function btn_change_password($url)
{
	return anchor($url, '<span class="glyphicon glyphicon-flash"></span>','title="Reset Password"');
}
function btn_view($url)
{
	return anchor($url, '<span class="glyphicon glyphicon-expand"></span> View',array('class'=>"btn btn-success btn-rounded-lg"),'title="View"');
}
function btn_delete($url)
{
	return anchor($url,'<span class="glyphicon glyphicon-trash"></span>', array('onclick'=>"return confirm('You are about to delete a record')",'title'=>"Delete"));
}
function btn_cancel($url)
{
	return anchor($url,'<span class="glyphicon glyphicon-remove"></span>', array('onclick'=>"return confirm('You are about to Cancel an Advertisement')",'title'=>"Cancel",'class'=>"btn btn-danger btn-rounded-lg"));
}
function btn_escalation($url)
{
	return anchor($url,'<span class="glyphicon glyphicon-share"></span> Escalation','title="Escalation" class="btn btn-primary btn-rounded-lg"');
}
function btn_reopen($url)
{
	return anchor($url,'<span class="glyphicon glyphicon-share"></span> Re-Open','title="Re-Open" class="btn btn-info btn-rounded-lg"');
}
function btn_active($url)
{
	return anchor($url,'<span class="glyphicon glyphicon-ok"></span>','title="Approve" class="btn btn-success btn-rounded-lg"');
}
function btn_back($url=NULL,$extra_class=NULL)
{
	if($url)
		return anchor($url,'<i class="fa fa-arrow-left"></i> Back','title="Back" class="btn btn-info btn-xs '.$extra_class.'" style="font-size: 14px; padding: 1px 12px;"');
	else
		return '<button onclick="window.history.go(-1)" class="btn btn-primary '.$extra_class.'">Back</button>';
}
function btn_viewdetail($url)
{
	return anchor($url, '<span class="fa fa-eye"></span>','title="View Details"');
}
function btn_back2()
{
	return '<span onclick="window.history.go(-1);" style="font-size: 16px; padding: 1px 12px;" class="btn btn-info btn-xs"><i class="fa fa-arrow-left"></i> Back</span>';
	//return anchor($url, '<span class="glyphicon glyphicon-search"></span>','title="View Details"');
}
function print_result($data)
{
	echo '<pre>';
	print_r($data);
	echo '</pre>';
}
function cleanDomain($domain)
{
	$domain = str_replace("https://www.", "", $domain);
	$domain = str_replace("https://", "", $domain);
	$domain = str_replace("www.", "", $domain);
	$domain = str_replace("/", "", $domain);
	return $domain;
}
?>