Cufon.replace('#menu li a, #menu_active, .text1, .button, h2', { fontFamily: 'Myriad Pro', hover:true });

